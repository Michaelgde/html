function loadNotes() {
  const notesContainer = document.getElementById('notes-container');
  notesContainer.innerHTML = '';
  const notes = JSON.parse(localStorage.getItem('notes')) || [];

  notes.forEach((note, index) => {
    const div = document.createElement('div');
    div.className = 'note';
    div.innerHTML = `
      <p>${note}</p>
      <button onclick="deleteNote(${index})">Delete</button>
    `;
    notesContainer.appendChild(div);
  });
}

function addNote() {
  const input = document.getElementById('note-input');
  const text = input.value.trim();
  if (text === '') return;

  const notes = JSON.parse(localStorage.getItem('notes')) || [];
  notes.push(text);
  localStorage.setItem('notes', JSON.stringify(notes));
  input.value = '';
  loadNotes();
}

function deleteNote(index) {
  const notes = JSON.parse(localStorage.getItem('notes')) || [];
  notes.splice(index, 1);
  localStorage.setItem('notes', JSON.stringify(notes));
  loadNotes();
}

window.onload = loadNotes;
