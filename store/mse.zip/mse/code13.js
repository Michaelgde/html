gdjs.autoCode = {};
gdjs.autoCode.localVariables = [];


gdjs.autoCode.eventsList0 = function(runtimeScene) {

};

gdjs.autoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.autoCode.eventsList0(runtimeScene);


return;

}

gdjs['autoCode'] = gdjs.autoCode;
