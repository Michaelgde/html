gdjs.mse_95htmlCode = {};
gdjs.mse_95htmlCode.localVariables = [];
gdjs.mse_95htmlCode.GDcropObjects1_1final = [];

gdjs.mse_95htmlCode.GDmusic_9595containerObjects1_1final = [];

gdjs.mse_95htmlCode.forEachIndex2 = 0;

gdjs.mse_95htmlCode.forEachIndex3 = 0;

gdjs.mse_95htmlCode.forEachIndex4 = 0;

gdjs.mse_95htmlCode.forEachObjects2 = [];

gdjs.mse_95htmlCode.forEachObjects3 = [];

gdjs.mse_95htmlCode.forEachObjects4 = [];

gdjs.mse_95htmlCode.forEachTemporary2 = null;

gdjs.mse_95htmlCode.forEachTemporary3 = null;

gdjs.mse_95htmlCode.forEachTemporary4 = null;

gdjs.mse_95htmlCode.forEachTotalCount2 = 0;

gdjs.mse_95htmlCode.forEachTotalCount3 = 0;

gdjs.mse_95htmlCode.forEachTotalCount4 = 0;

gdjs.mse_95htmlCode.GDpanelObjects1= [];
gdjs.mse_95htmlCode.GDpanelObjects2= [];
gdjs.mse_95htmlCode.GDpanelObjects3= [];
gdjs.mse_95htmlCode.GDpanelObjects4= [];
gdjs.mse_95htmlCode.GDpanelObjects5= [];
gdjs.mse_95htmlCode.GDpanelObjects6= [];
gdjs.mse_95htmlCode.GDpanel2Objects1= [];
gdjs.mse_95htmlCode.GDpanel2Objects2= [];
gdjs.mse_95htmlCode.GDpanel2Objects3= [];
gdjs.mse_95htmlCode.GDpanel2Objects4= [];
gdjs.mse_95htmlCode.GDpanel2Objects5= [];
gdjs.mse_95htmlCode.GDpanel2Objects6= [];
gdjs.mse_95htmlCode.GDsound_9595nameObjects1= [];
gdjs.mse_95htmlCode.GDsound_9595nameObjects2= [];
gdjs.mse_95htmlCode.GDsound_9595nameObjects3= [];
gdjs.mse_95htmlCode.GDsound_9595nameObjects4= [];
gdjs.mse_95htmlCode.GDsound_9595nameObjects5= [];
gdjs.mse_95htmlCode.GDsound_9595nameObjects6= [];
gdjs.mse_95htmlCode.GDdrawObjects1= [];
gdjs.mse_95htmlCode.GDdrawObjects2= [];
gdjs.mse_95htmlCode.GDdrawObjects3= [];
gdjs.mse_95htmlCode.GDdrawObjects4= [];
gdjs.mse_95htmlCode.GDdrawObjects5= [];
gdjs.mse_95htmlCode.GDdrawObjects6= [];
gdjs.mse_95htmlCode.GDnameObjects1= [];
gdjs.mse_95htmlCode.GDnameObjects2= [];
gdjs.mse_95htmlCode.GDnameObjects3= [];
gdjs.mse_95htmlCode.GDnameObjects4= [];
gdjs.mse_95htmlCode.GDnameObjects5= [];
gdjs.mse_95htmlCode.GDnameObjects6= [];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1= [];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects2= [];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3= [];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects4= [];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects5= [];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects6= [];
gdjs.mse_95htmlCode.GDplay_9595nodeObjects1= [];
gdjs.mse_95htmlCode.GDplay_9595nodeObjects2= [];
gdjs.mse_95htmlCode.GDplay_9595nodeObjects3= [];
gdjs.mse_95htmlCode.GDplay_9595nodeObjects4= [];
gdjs.mse_95htmlCode.GDplay_9595nodeObjects5= [];
gdjs.mse_95htmlCode.GDplay_9595nodeObjects6= [];
gdjs.mse_95htmlCode.GDplayObjects1= [];
gdjs.mse_95htmlCode.GDplayObjects2= [];
gdjs.mse_95htmlCode.GDplayObjects3= [];
gdjs.mse_95htmlCode.GDplayObjects4= [];
gdjs.mse_95htmlCode.GDplayObjects5= [];
gdjs.mse_95htmlCode.GDplayObjects6= [];
gdjs.mse_95htmlCode.GDdebugObjects1= [];
gdjs.mse_95htmlCode.GDdebugObjects2= [];
gdjs.mse_95htmlCode.GDdebugObjects3= [];
gdjs.mse_95htmlCode.GDdebugObjects4= [];
gdjs.mse_95htmlCode.GDdebugObjects5= [];
gdjs.mse_95htmlCode.GDdebugObjects6= [];
gdjs.mse_95htmlCode.GDstopObjects1= [];
gdjs.mse_95htmlCode.GDstopObjects2= [];
gdjs.mse_95htmlCode.GDstopObjects3= [];
gdjs.mse_95htmlCode.GDstopObjects4= [];
gdjs.mse_95htmlCode.GDstopObjects5= [];
gdjs.mse_95htmlCode.GDstopObjects6= [];
gdjs.mse_95htmlCode.GDfast_9595forwardObjects1= [];
gdjs.mse_95htmlCode.GDfast_9595forwardObjects2= [];
gdjs.mse_95htmlCode.GDfast_9595forwardObjects3= [];
gdjs.mse_95htmlCode.GDfast_9595forwardObjects4= [];
gdjs.mse_95htmlCode.GDfast_9595forwardObjects5= [];
gdjs.mse_95htmlCode.GDfast_9595forwardObjects6= [];
gdjs.mse_95htmlCode.GDfast_9595backwardObjects1= [];
gdjs.mse_95htmlCode.GDfast_9595backwardObjects2= [];
gdjs.mse_95htmlCode.GDfast_9595backwardObjects3= [];
gdjs.mse_95htmlCode.GDfast_9595backwardObjects4= [];
gdjs.mse_95htmlCode.GDfast_9595backwardObjects5= [];
gdjs.mse_95htmlCode.GDfast_9595backwardObjects6= [];
gdjs.mse_95htmlCode.GDgearObjects1= [];
gdjs.mse_95htmlCode.GDgearObjects2= [];
gdjs.mse_95htmlCode.GDgearObjects3= [];
gdjs.mse_95htmlCode.GDgearObjects4= [];
gdjs.mse_95htmlCode.GDgearObjects5= [];
gdjs.mse_95htmlCode.GDgearObjects6= [];
gdjs.mse_95htmlCode.GDbar1Objects1= [];
gdjs.mse_95htmlCode.GDbar1Objects2= [];
gdjs.mse_95htmlCode.GDbar1Objects3= [];
gdjs.mse_95htmlCode.GDbar1Objects4= [];
gdjs.mse_95htmlCode.GDbar1Objects5= [];
gdjs.mse_95htmlCode.GDbar1Objects6= [];
gdjs.mse_95htmlCode.GDyyyObjects1= [];
gdjs.mse_95htmlCode.GDyyyObjects2= [];
gdjs.mse_95htmlCode.GDyyyObjects3= [];
gdjs.mse_95htmlCode.GDyyyObjects4= [];
gdjs.mse_95htmlCode.GDyyyObjects5= [];
gdjs.mse_95htmlCode.GDyyyObjects6= [];
gdjs.mse_95htmlCode.GDcacaObjects1= [];
gdjs.mse_95htmlCode.GDcacaObjects2= [];
gdjs.mse_95htmlCode.GDcacaObjects3= [];
gdjs.mse_95htmlCode.GDcacaObjects4= [];
gdjs.mse_95htmlCode.GDcacaObjects5= [];
gdjs.mse_95htmlCode.GDcacaObjects6= [];
gdjs.mse_95htmlCode.GDdraw2Objects1= [];
gdjs.mse_95htmlCode.GDdraw2Objects2= [];
gdjs.mse_95htmlCode.GDdraw2Objects3= [];
gdjs.mse_95htmlCode.GDdraw2Objects4= [];
gdjs.mse_95htmlCode.GDdraw2Objects5= [];
gdjs.mse_95htmlCode.GDdraw2Objects6= [];
gdjs.mse_95htmlCode.GDddObjects1= [];
gdjs.mse_95htmlCode.GDddObjects2= [];
gdjs.mse_95htmlCode.GDddObjects3= [];
gdjs.mse_95htmlCode.GDddObjects4= [];
gdjs.mse_95htmlCode.GDddObjects5= [];
gdjs.mse_95htmlCode.GDddObjects6= [];
gdjs.mse_95htmlCode.GDjson_9595iconObjects1= [];
gdjs.mse_95htmlCode.GDjson_9595iconObjects2= [];
gdjs.mse_95htmlCode.GDjson_9595iconObjects3= [];
gdjs.mse_95htmlCode.GDjson_9595iconObjects4= [];
gdjs.mse_95htmlCode.GDjson_9595iconObjects5= [];
gdjs.mse_95htmlCode.GDjson_9595iconObjects6= [];
gdjs.mse_95htmlCode.GDavObjects1= [];
gdjs.mse_95htmlCode.GDavObjects2= [];
gdjs.mse_95htmlCode.GDavObjects3= [];
gdjs.mse_95htmlCode.GDavObjects4= [];
gdjs.mse_95htmlCode.GDavObjects5= [];
gdjs.mse_95htmlCode.GDavObjects6= [];
gdjs.mse_95htmlCode.GDexportObjects1= [];
gdjs.mse_95htmlCode.GDexportObjects2= [];
gdjs.mse_95htmlCode.GDexportObjects3= [];
gdjs.mse_95htmlCode.GDexportObjects4= [];
gdjs.mse_95htmlCode.GDexportObjects5= [];
gdjs.mse_95htmlCode.GDexportObjects6= [];
gdjs.mse_95htmlCode.GDbadObjects1= [];
gdjs.mse_95htmlCode.GDbadObjects2= [];
gdjs.mse_95htmlCode.GDbadObjects3= [];
gdjs.mse_95htmlCode.GDbadObjects4= [];
gdjs.mse_95htmlCode.GDbadObjects5= [];
gdjs.mse_95htmlCode.GDbadObjects6= [];
gdjs.mse_95htmlCode.GDpaintObjects1= [];
gdjs.mse_95htmlCode.GDpaintObjects2= [];
gdjs.mse_95htmlCode.GDpaintObjects3= [];
gdjs.mse_95htmlCode.GDpaintObjects4= [];
gdjs.mse_95htmlCode.GDpaintObjects5= [];
gdjs.mse_95htmlCode.GDpaintObjects6= [];
gdjs.mse_95htmlCode.GDproject_9595nameObjects1= [];
gdjs.mse_95htmlCode.GDproject_9595nameObjects2= [];
gdjs.mse_95htmlCode.GDproject_9595nameObjects3= [];
gdjs.mse_95htmlCode.GDproject_9595nameObjects4= [];
gdjs.mse_95htmlCode.GDproject_9595nameObjects5= [];
gdjs.mse_95htmlCode.GDproject_9595nameObjects6= [];
gdjs.mse_95htmlCode.GDinffofoObjects1= [];
gdjs.mse_95htmlCode.GDinffofoObjects2= [];
gdjs.mse_95htmlCode.GDinffofoObjects3= [];
gdjs.mse_95htmlCode.GDinffofoObjects4= [];
gdjs.mse_95htmlCode.GDinffofoObjects5= [];
gdjs.mse_95htmlCode.GDinffofoObjects6= [];
gdjs.mse_95htmlCode.GDlogoObjects1= [];
gdjs.mse_95htmlCode.GDlogoObjects2= [];
gdjs.mse_95htmlCode.GDlogoObjects3= [];
gdjs.mse_95htmlCode.GDlogoObjects4= [];
gdjs.mse_95htmlCode.GDlogoObjects5= [];
gdjs.mse_95htmlCode.GDlogoObjects6= [];
gdjs.mse_95htmlCode.GDasdObjects1= [];
gdjs.mse_95htmlCode.GDasdObjects2= [];
gdjs.mse_95htmlCode.GDasdObjects3= [];
gdjs.mse_95htmlCode.GDasdObjects4= [];
gdjs.mse_95htmlCode.GDasdObjects5= [];
gdjs.mse_95htmlCode.GDasdObjects6= [];
gdjs.mse_95htmlCode.GDmenuObjects1= [];
gdjs.mse_95htmlCode.GDmenuObjects2= [];
gdjs.mse_95htmlCode.GDmenuObjects3= [];
gdjs.mse_95htmlCode.GDmenuObjects4= [];
gdjs.mse_95htmlCode.GDmenuObjects5= [];
gdjs.mse_95htmlCode.GDmenuObjects6= [];
gdjs.mse_95htmlCode.GDpanel3Objects1= [];
gdjs.mse_95htmlCode.GDpanel3Objects2= [];
gdjs.mse_95htmlCode.GDpanel3Objects3= [];
gdjs.mse_95htmlCode.GDpanel3Objects4= [];
gdjs.mse_95htmlCode.GDpanel3Objects5= [];
gdjs.mse_95htmlCode.GDpanel3Objects6= [];
gdjs.mse_95htmlCode.GDhelpObjects1= [];
gdjs.mse_95htmlCode.GDhelpObjects2= [];
gdjs.mse_95htmlCode.GDhelpObjects3= [];
gdjs.mse_95htmlCode.GDhelpObjects4= [];
gdjs.mse_95htmlCode.GDhelpObjects5= [];
gdjs.mse_95htmlCode.GDhelpObjects6= [];
gdjs.mse_95htmlCode.GDexObjects1= [];
gdjs.mse_95htmlCode.GDexObjects2= [];
gdjs.mse_95htmlCode.GDexObjects3= [];
gdjs.mse_95htmlCode.GDexObjects4= [];
gdjs.mse_95htmlCode.GDexObjects5= [];
gdjs.mse_95htmlCode.GDexObjects6= [];
gdjs.mse_95htmlCode.GDinfoObjects1= [];
gdjs.mse_95htmlCode.GDinfoObjects2= [];
gdjs.mse_95htmlCode.GDinfoObjects3= [];
gdjs.mse_95htmlCode.GDinfoObjects4= [];
gdjs.mse_95htmlCode.GDinfoObjects5= [];
gdjs.mse_95htmlCode.GDinfoObjects6= [];
gdjs.mse_95htmlCode.GDbackObjects1= [];
gdjs.mse_95htmlCode.GDbackObjects2= [];
gdjs.mse_95htmlCode.GDbackObjects3= [];
gdjs.mse_95htmlCode.GDbackObjects4= [];
gdjs.mse_95htmlCode.GDbackObjects5= [];
gdjs.mse_95htmlCode.GDbackObjects6= [];
gdjs.mse_95htmlCode.GDpanel4Objects1= [];
gdjs.mse_95htmlCode.GDpanel4Objects2= [];
gdjs.mse_95htmlCode.GDpanel4Objects3= [];
gdjs.mse_95htmlCode.GDpanel4Objects4= [];
gdjs.mse_95htmlCode.GDpanel4Objects5= [];
gdjs.mse_95htmlCode.GDpanel4Objects6= [];
gdjs.mse_95htmlCode.GDerrObjects1= [];
gdjs.mse_95htmlCode.GDerrObjects2= [];
gdjs.mse_95htmlCode.GDerrObjects3= [];
gdjs.mse_95htmlCode.GDerrObjects4= [];
gdjs.mse_95htmlCode.GDerrObjects5= [];
gdjs.mse_95htmlCode.GDerrObjects6= [];
gdjs.mse_95htmlCode.GDai_9595placerkObjects1= [];
gdjs.mse_95htmlCode.GDai_9595placerkObjects2= [];
gdjs.mse_95htmlCode.GDai_9595placerkObjects3= [];
gdjs.mse_95htmlCode.GDai_9595placerkObjects4= [];
gdjs.mse_95htmlCode.GDai_9595placerkObjects5= [];
gdjs.mse_95htmlCode.GDai_9595placerkObjects6= [];
gdjs.mse_95htmlCode.GDhoverObjects1= [];
gdjs.mse_95htmlCode.GDhoverObjects2= [];
gdjs.mse_95htmlCode.GDhoverObjects3= [];
gdjs.mse_95htmlCode.GDhoverObjects4= [];
gdjs.mse_95htmlCode.GDhoverObjects5= [];
gdjs.mse_95htmlCode.GDhoverObjects6= [];
gdjs.mse_95htmlCode.GDsub_9595audObjects1= [];
gdjs.mse_95htmlCode.GDsub_9595audObjects2= [];
gdjs.mse_95htmlCode.GDsub_9595audObjects3= [];
gdjs.mse_95htmlCode.GDsub_9595audObjects4= [];
gdjs.mse_95htmlCode.GDsub_9595audObjects5= [];
gdjs.mse_95htmlCode.GDsub_9595audObjects6= [];
gdjs.mse_95htmlCode.GDaudio_9595idObjects1= [];
gdjs.mse_95htmlCode.GDaudio_9595idObjects2= [];
gdjs.mse_95htmlCode.GDaudio_9595idObjects3= [];
gdjs.mse_95htmlCode.GDaudio_9595idObjects4= [];
gdjs.mse_95htmlCode.GDaudio_9595idObjects5= [];
gdjs.mse_95htmlCode.GDaudio_9595idObjects6= [];
gdjs.mse_95htmlCode.GDexport_9595aObjects1= [];
gdjs.mse_95htmlCode.GDexport_9595aObjects2= [];
gdjs.mse_95htmlCode.GDexport_9595aObjects3= [];
gdjs.mse_95htmlCode.GDexport_9595aObjects4= [];
gdjs.mse_95htmlCode.GDexport_9595aObjects5= [];
gdjs.mse_95htmlCode.GDexport_9595aObjects6= [];
gdjs.mse_95htmlCode.GDidObjects1= [];
gdjs.mse_95htmlCode.GDidObjects2= [];
gdjs.mse_95htmlCode.GDidObjects3= [];
gdjs.mse_95htmlCode.GDidObjects4= [];
gdjs.mse_95htmlCode.GDidObjects5= [];
gdjs.mse_95htmlCode.GDidObjects6= [];
gdjs.mse_95htmlCode.GDname2Objects1= [];
gdjs.mse_95htmlCode.GDname2Objects2= [];
gdjs.mse_95htmlCode.GDname2Objects3= [];
gdjs.mse_95htmlCode.GDname2Objects4= [];
gdjs.mse_95htmlCode.GDname2Objects5= [];
gdjs.mse_95htmlCode.GDname2Objects6= [];
gdjs.mse_95htmlCode.GDeventObjects1= [];
gdjs.mse_95htmlCode.GDeventObjects2= [];
gdjs.mse_95htmlCode.GDeventObjects3= [];
gdjs.mse_95htmlCode.GDeventObjects4= [];
gdjs.mse_95htmlCode.GDeventObjects5= [];
gdjs.mse_95htmlCode.GDeventObjects6= [];
gdjs.mse_95htmlCode.GDshow_9595eventObjects1= [];
gdjs.mse_95htmlCode.GDshow_9595eventObjects2= [];
gdjs.mse_95htmlCode.GDshow_9595eventObjects3= [];
gdjs.mse_95htmlCode.GDshow_9595eventObjects4= [];
gdjs.mse_95htmlCode.GDshow_9595eventObjects5= [];
gdjs.mse_95htmlCode.GDshow_9595eventObjects6= [];
gdjs.mse_95htmlCode.GDsearchObjects1= [];
gdjs.mse_95htmlCode.GDsearchObjects2= [];
gdjs.mse_95htmlCode.GDsearchObjects3= [];
gdjs.mse_95htmlCode.GDsearchObjects4= [];
gdjs.mse_95htmlCode.GDsearchObjects5= [];
gdjs.mse_95htmlCode.GDsearchObjects6= [];
gdjs.mse_95htmlCode.GDenterObjects1= [];
gdjs.mse_95htmlCode.GDenterObjects2= [];
gdjs.mse_95htmlCode.GDenterObjects3= [];
gdjs.mse_95htmlCode.GDenterObjects4= [];
gdjs.mse_95htmlCode.GDenterObjects5= [];
gdjs.mse_95htmlCode.GDenterObjects6= [];
gdjs.mse_95htmlCode.GDsaveObjects1= [];
gdjs.mse_95htmlCode.GDsaveObjects2= [];
gdjs.mse_95htmlCode.GDsaveObjects3= [];
gdjs.mse_95htmlCode.GDsaveObjects4= [];
gdjs.mse_95htmlCode.GDsaveObjects5= [];
gdjs.mse_95htmlCode.GDsaveObjects6= [];
gdjs.mse_95htmlCode.GDspeedObjects1= [];
gdjs.mse_95htmlCode.GDspeedObjects2= [];
gdjs.mse_95htmlCode.GDspeedObjects3= [];
gdjs.mse_95htmlCode.GDspeedObjects4= [];
gdjs.mse_95htmlCode.GDspeedObjects5= [];
gdjs.mse_95htmlCode.GDspeedObjects6= [];
gdjs.mse_95htmlCode.GDhomeObjects1= [];
gdjs.mse_95htmlCode.GDhomeObjects2= [];
gdjs.mse_95htmlCode.GDhomeObjects3= [];
gdjs.mse_95htmlCode.GDhomeObjects4= [];
gdjs.mse_95htmlCode.GDhomeObjects5= [];
gdjs.mse_95htmlCode.GDhomeObjects6= [];
gdjs.mse_95htmlCode.GDcropObjects1= [];
gdjs.mse_95htmlCode.GDcropObjects2= [];
gdjs.mse_95htmlCode.GDcropObjects3= [];
gdjs.mse_95htmlCode.GDcropObjects4= [];
gdjs.mse_95htmlCode.GDcropObjects5= [];
gdjs.mse_95htmlCode.GDcropObjects6= [];
gdjs.mse_95htmlCode.GDsettings_9595icObjects1= [];
gdjs.mse_95htmlCode.GDsettings_9595icObjects2= [];
gdjs.mse_95htmlCode.GDsettings_9595icObjects3= [];
gdjs.mse_95htmlCode.GDsettings_9595icObjects4= [];
gdjs.mse_95htmlCode.GDsettings_9595icObjects5= [];
gdjs.mse_95htmlCode.GDsettings_9595icObjects6= [];
gdjs.mse_95htmlCode.GDsetObjects1= [];
gdjs.mse_95htmlCode.GDsetObjects2= [];
gdjs.mse_95htmlCode.GDsetObjects3= [];
gdjs.mse_95htmlCode.GDsetObjects4= [];
gdjs.mse_95htmlCode.GDsetObjects5= [];
gdjs.mse_95htmlCode.GDsetObjects6= [];
gdjs.mse_95htmlCode.GDsnap_9595boolObjects1= [];
gdjs.mse_95htmlCode.GDsnap_9595boolObjects2= [];
gdjs.mse_95htmlCode.GDsnap_9595boolObjects3= [];
gdjs.mse_95htmlCode.GDsnap_9595boolObjects4= [];
gdjs.mse_95htmlCode.GDsnap_9595boolObjects5= [];
gdjs.mse_95htmlCode.GDsnap_9595boolObjects6= [];
gdjs.mse_95htmlCode.GDshow_9595boolObjects1= [];
gdjs.mse_95htmlCode.GDshow_9595boolObjects2= [];
gdjs.mse_95htmlCode.GDshow_9595boolObjects3= [];
gdjs.mse_95htmlCode.GDshow_9595boolObjects4= [];
gdjs.mse_95htmlCode.GDshow_9595boolObjects5= [];
gdjs.mse_95htmlCode.GDshow_9595boolObjects6= [];
gdjs.mse_95htmlCode.GDset_9595snapObjects1= [];
gdjs.mse_95htmlCode.GDset_9595snapObjects2= [];
gdjs.mse_95htmlCode.GDset_9595snapObjects3= [];
gdjs.mse_95htmlCode.GDset_9595snapObjects4= [];
gdjs.mse_95htmlCode.GDset_9595snapObjects5= [];
gdjs.mse_95htmlCode.GDset_9595snapObjects6= [];
gdjs.mse_95htmlCode.GDdebug2Objects1= [];
gdjs.mse_95htmlCode.GDdebug2Objects2= [];
gdjs.mse_95htmlCode.GDdebug2Objects3= [];
gdjs.mse_95htmlCode.GDdebug2Objects4= [];
gdjs.mse_95htmlCode.GDdebug2Objects5= [];
gdjs.mse_95htmlCode.GDdebug2Objects6= [];
gdjs.mse_95htmlCode.GDbuttonObjects1= [];
gdjs.mse_95htmlCode.GDbuttonObjects2= [];
gdjs.mse_95htmlCode.GDbuttonObjects3= [];
gdjs.mse_95htmlCode.GDbuttonObjects4= [];
gdjs.mse_95htmlCode.GDbuttonObjects5= [];
gdjs.mse_95htmlCode.GDbuttonObjects6= [];
gdjs.mse_95htmlCode.GDUnnamedObjects1= [];
gdjs.mse_95htmlCode.GDUnnamedObjects2= [];
gdjs.mse_95htmlCode.GDUnnamedObjects3= [];
gdjs.mse_95htmlCode.GDUnnamedObjects4= [];
gdjs.mse_95htmlCode.GDUnnamedObjects5= [];
gdjs.mse_95htmlCode.GDUnnamedObjects6= [];
gdjs.mse_95htmlCode.GDUnnamed2Objects1= [];
gdjs.mse_95htmlCode.GDUnnamed2Objects2= [];
gdjs.mse_95htmlCode.GDUnnamed2Objects3= [];
gdjs.mse_95htmlCode.GDUnnamed2Objects4= [];
gdjs.mse_95htmlCode.GDUnnamed2Objects5= [];
gdjs.mse_95htmlCode.GDUnnamed2Objects6= [];
gdjs.mse_95htmlCode.GDUnnamed3Objects1= [];
gdjs.mse_95htmlCode.GDUnnamed3Objects2= [];
gdjs.mse_95htmlCode.GDUnnamed3Objects3= [];
gdjs.mse_95htmlCode.GDUnnamed3Objects4= [];
gdjs.mse_95htmlCode.GDUnnamed3Objects5= [];
gdjs.mse_95htmlCode.GDUnnamed3Objects6= [];
gdjs.mse_95htmlCode.GDUnnamed4Objects1= [];
gdjs.mse_95htmlCode.GDUnnamed4Objects2= [];
gdjs.mse_95htmlCode.GDUnnamed4Objects3= [];
gdjs.mse_95htmlCode.GDUnnamed4Objects4= [];
gdjs.mse_95htmlCode.GDUnnamed4Objects5= [];
gdjs.mse_95htmlCode.GDUnnamed4Objects6= [];
gdjs.mse_95htmlCode.GDscriptObjects1= [];
gdjs.mse_95htmlCode.GDscriptObjects2= [];
gdjs.mse_95htmlCode.GDscriptObjects3= [];
gdjs.mse_95htmlCode.GDscriptObjects4= [];
gdjs.mse_95htmlCode.GDscriptObjects5= [];
gdjs.mse_95htmlCode.GDscriptObjects6= [];
gdjs.mse_95htmlCode.GDcoderObjects1= [];
gdjs.mse_95htmlCode.GDcoderObjects2= [];
gdjs.mse_95htmlCode.GDcoderObjects3= [];
gdjs.mse_95htmlCode.GDcoderObjects4= [];
gdjs.mse_95htmlCode.GDcoderObjects5= [];
gdjs.mse_95htmlCode.GDcoderObjects6= [];
gdjs.mse_95htmlCode.GDfuncObjects1= [];
gdjs.mse_95htmlCode.GDfuncObjects2= [];
gdjs.mse_95htmlCode.GDfuncObjects3= [];
gdjs.mse_95htmlCode.GDfuncObjects4= [];
gdjs.mse_95htmlCode.GDfuncObjects5= [];
gdjs.mse_95htmlCode.GDfuncObjects6= [];
gdjs.mse_95htmlCode.GDsaving_9595projectObjects1= [];
gdjs.mse_95htmlCode.GDsaving_9595projectObjects2= [];
gdjs.mse_95htmlCode.GDsaving_9595projectObjects3= [];
gdjs.mse_95htmlCode.GDsaving_9595projectObjects4= [];
gdjs.mse_95htmlCode.GDsaving_9595projectObjects5= [];
gdjs.mse_95htmlCode.GDsaving_9595projectObjects6= [];
gdjs.mse_95htmlCode.GDversionObjects1= [];
gdjs.mse_95htmlCode.GDversionObjects2= [];
gdjs.mse_95htmlCode.GDversionObjects3= [];
gdjs.mse_95htmlCode.GDversionObjects4= [];
gdjs.mse_95htmlCode.GDversionObjects5= [];
gdjs.mse_95htmlCode.GDversionObjects6= [];


gdjs.mse_95htmlCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95htmlCode.GDdrawObjects3);
gdjs.copyArray(gdjs.mse_95htmlCode.GDnameObjects2, gdjs.mse_95htmlCode.GDnameObjects3);

{for(var i = 0, len = gdjs.mse_95htmlCode.GDdrawObjects3.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdrawObjects3[i].drawLineV2(gdjs.evtTools.camera.getCameraX(runtimeScene, "Layer", 0) - (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.mse_95htmlCode.GDnameObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDnameObjects3[0].getY()) + 64, gdjs.evtTools.camera.getCameraX(runtimeScene, "Layer", 0) + (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.mse_95htmlCode.GDnameObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDnameObjects3[0].getY()) + 64, 1);
}
}}

}


};gdjs.mse_95htmlCode.asyncCallback22774948 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95htmlCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("info"), gdjs.mse_95htmlCode.GDinfoObjects2);

{for(var i = 0, len = gdjs.mse_95htmlCode.GDinfoObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDinfoObjects2[i].getBehavior("Text").setText("");
}
}gdjs.mse_95htmlCode.localVariables.length = 0;
}
gdjs.mse_95htmlCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95htmlCode.localVariables);
for (const obj of gdjs.mse_95htmlCode.GDinfoObjects1) asyncObjectsList.addObject("info", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.mse_95htmlCode.asyncCallback22774948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95htmlCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDplay_95959595nodeObjects2Objects = Hashtable.newFrom({"play_node": gdjs.mse_95htmlCode.GDplay_9595nodeObjects2});
gdjs.mse_95htmlCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDplay_95959595nodeObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects2);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDplay_9595nodeObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplay_9595nodeObjects2[i].setX(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "g");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "f");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects1);
{gdjs.evtTools.sound.setMusicOnChannelPlayingOffset(runtimeScene, 1, (( gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[0].getPointX("")) / 50);
}}

}


};gdjs.mse_95htmlCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) <= 0;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "error");
}}

}


};gdjs.mse_95htmlCode.asyncCallback22789068 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95htmlCode.localVariables);

{ //Subevents
gdjs.mse_95htmlCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.mse_95htmlCode.localVariables.length = 0;
}
gdjs.mse_95htmlCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95htmlCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.mse_95htmlCode.asyncCallback22789068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDfast_95959595forwardObjects1Objects = Hashtable.newFrom({"fast_forward": gdjs.mse_95htmlCode.GDfast_9595forwardObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDfast_95959595backwardObjects1Objects = Hashtable.newFrom({"fast_backward": gdjs.mse_95htmlCode.GDfast_9595backwardObjects1});
gdjs.mse_95htmlCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects2);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDplay_9595nodeObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplay_9595nodeObjects2[i].setX(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) * 50);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95htmlCode.GDgearObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDgearObjects1.length;i<l;++i) {
    if ( !(gdjs.mse_95htmlCode.GDgearObjects1[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDgearObjects1[k] = gdjs.mse_95htmlCode.GDgearObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDgearObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDgearObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDgearObjects1[i].SetValue(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDplay_95959595nodeObjects1Objects = Hashtable.newFrom({"play_node": gdjs.mse_95htmlCode.GDplay_9595nodeObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDplay_95959595nodeObjects1Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95htmlCode.GDeventObjects1);
/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].returnVariable(gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getVariables().getFromIndex(0)).setString((( gdjs.mse_95htmlCode.GDeventObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDeventObjects1[0].getText()));
}
}}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDstopObjects1Objects = Hashtable.newFrom({"stop": gdjs.mse_95htmlCode.GDstopObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDplayObjects1Objects = Hashtable.newFrom({"play": gdjs.mse_95htmlCode.GDplayObjects1});
gdjs.mse_95htmlCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.mse_95htmlCode.GDplayObjects1, gdjs.mse_95htmlCode.GDplayObjects2);

{for(var i = 0, len = gdjs.mse_95htmlCode.GDplayObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplayObjects2[i].getBehavior("Animation").setAnimationName("pausef");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDplayObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Animation").setAnimationName("playing");
}
}}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects2Objects = Hashtable.newFrom({"crop": gdjs.mse_95htmlCode.GDcropObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95htmlCode.GDdraw2Objects3);
gdjs.copyArray(gdjs.mse_95htmlCode.GDyyyObjects2, gdjs.mse_95htmlCode.GDyyyObjects3);

{for(var i = 0, len = gdjs.mse_95htmlCode.GDdraw2Objects3.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdraw2Objects3[i].drawLineV2(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.mse_95htmlCode.GDyyyObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDyyyObjects3[0].getPointY("")) + 96, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.mse_95htmlCode.GDyyyObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDyyyObjects3[0].getPointY("")) + 96, 1);
}
}}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmenuObjects1Objects = Hashtable.newFrom({"menu": gdjs.mse_95htmlCode.GDmenuObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDexObjects2Objects = Hashtable.newFrom({"ex": gdjs.mse_95htmlCode.GDexObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDhelpObjects2Objects = Hashtable.newFrom({"help": gdjs.mse_95htmlCode.GDhelpObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDai_95959595placerkObjects2Objects = Hashtable.newFrom({"ai_placerk": gdjs.mse_95htmlCode.GDai_9595placerkObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDbackObjects2Objects = Hashtable.newFrom({"back": gdjs.mse_95htmlCode.GDbackObjects2});
gdjs.mse_95htmlCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "audio_manager_html", true);
}}

}


};gdjs.mse_95htmlCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ex"), gdjs.mse_95htmlCode.GDexObjects2);
gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95htmlCode.GDpanel3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDpanel3Objects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDpanel3Objects2[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDpanel3Objects2[k] = gdjs.mse_95htmlCode.GDpanel3Objects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDpanel3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDexObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "pop_up");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("help"), gdjs.mse_95htmlCode.GDhelpObjects2);
gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95htmlCode.GDpanel3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDpanel3Objects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDpanel3Objects2[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDpanel3Objects2[k] = gdjs.mse_95htmlCode.GDpanel3Objects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDpanel3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDhelpObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "help");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ai_placerk"), gdjs.mse_95htmlCode.GDai_9595placerkObjects2);
gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95htmlCode.GDpanel3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDpanel3Objects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDpanel3Objects2[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDpanel3Objects2[k] = gdjs.mse_95htmlCode.GDpanel3Objects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDpanel3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDai_95959595placerkObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(true);
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "equalizador");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.mse_95htmlCode.GDbackObjects2);
gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95htmlCode.GDpanel3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDpanel3Objects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDpanel3Objects2[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDpanel3Objects2[k] = gdjs.mse_95htmlCode.GDpanel3Objects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDpanel3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDbackObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.unloadMusic(runtimeScene, "audio.ogg");
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95htmlCode.GDavObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95htmlCode.GDavObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDexport_95959595aObjects2Objects = Hashtable.newFrom({"export_a": gdjs.mse_95htmlCode.GDexport_9595aObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects3});
gdjs.mse_95htmlCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("project_name"), gdjs.mse_95htmlCode.GDproject_9595nameObjects4);
{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, (( gdjs.mse_95htmlCode.GDproject_9595nameObjects4.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDproject_9595nameObjects4[0].getText()) + ".json", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(3)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.mse_95htmlCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(3)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects3Objects) * 3;
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95htmlCode.forEachIndex3 = 0;gdjs.mse_95htmlCode.forEachIndex3 < gdjs.mse_95htmlCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95htmlCode.forEachIndex3) {
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95htmlCode.forEachTemporary3 = gdjs.mse_95htmlCode.GDmusic_9595containerObjects2[gdjs.mse_95htmlCode.forEachIndex3];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.push(gdjs.mse_95htmlCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(3), (( gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[0].getX()));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(3), (( gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[0].getY()));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(3), ((gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[0].getVariables()).getFromIndex(0).getAsString());
}
{ //Subevents: 
gdjs.mse_95htmlCode.eventsList13(runtimeScene);} //Subevents end.
}
}

}


};gdjs.mse_95htmlCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(3));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95htmlCode.GDavObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95htmlCode.GDavObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDexportObjects2Objects = Hashtable.newFrom({"export": gdjs.mse_95htmlCode.GDexportObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects3});
gdjs.mse_95htmlCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("project_name"), gdjs.mse_95htmlCode.GDproject_9595nameObjects4);
{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, (( gdjs.mse_95htmlCode.GDproject_9595nameObjects4.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDproject_9595nameObjects4[0].getText()) + ".json", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(3)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.mse_95htmlCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(3)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects3Objects);
if (isConditionTrue_0) {
{gdjs.evtsExt__ArrayTools__Sort.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95htmlCode.forEachIndex3 = 0;gdjs.mse_95htmlCode.forEachIndex3 < gdjs.mse_95htmlCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95htmlCode.forEachIndex3) {
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95htmlCode.forEachTemporary3 = gdjs.mse_95htmlCode.GDmusic_9595containerObjects2[gdjs.mse_95htmlCode.forEachIndex3];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.push(gdjs.mse_95htmlCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(3), (( gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[0].getX()) / 50);
}
{ //Subevents: 
gdjs.mse_95htmlCode.eventsList17(runtimeScene);} //Subevents end.
}
}

}


};gdjs.mse_95htmlCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(3));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95htmlCode.GDavObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95htmlCode.GDavObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDbadObjects2Objects = Hashtable.newFrom({"bad": gdjs.mse_95htmlCode.GDbadObjects2});
gdjs.mse_95htmlCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95htmlCode.GDavObjects2);
gdjs.copyArray(runtimeScene.getObjects("export_a"), gdjs.mse_95htmlCode.GDexport_9595aObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDavObjects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDavObjects2[i].getZOrder() != 17 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDavObjects2[k] = gdjs.mse_95htmlCode.GDavObjects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDavObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDexport_95959595aObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95htmlCode.GDavObjects2);
gdjs.copyArray(runtimeScene.getObjects("export"), gdjs.mse_95htmlCode.GDexportObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDavObjects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDavObjects2[i].getZOrder() != 17 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDavObjects2[k] = gdjs.mse_95htmlCode.GDavObjects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDavObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDexportObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95htmlCode.GDavObjects2);
gdjs.copyArray(runtimeScene.getObjects("bad"), gdjs.mse_95htmlCode.GDbadObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDavObjects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDavObjects2[i].getZOrder() != 17 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDavObjects2[k] = gdjs.mse_95htmlCode.GDavObjects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDavObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDavObjects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDbadObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "pop_up");
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95htmlCode.eventsList21 = function(runtimeScene) {

};gdjs.mse_95htmlCode.eventsList22 = function(runtimeScene) {

{


const repeatCount3 = gdjs.evtTools.window.getWindowInnerWidth() / runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber();
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95htmlCode.GDdrawObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0)
{
{for(var i = 0, len = gdjs.mse_95htmlCode.GDdrawObjects3.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdrawObjects3[i].drawLineV2(runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), -(10), runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), gdjs.evtTools.window.getWindowInnerHeight() + 500, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(7).add(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber());
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95htmlCode.eventsList23 = function(runtimeScene) {

};gdjs.mse_95htmlCode.eventsList24 = function(runtimeScene) {

{


const repeatCount3 = gdjs.evtTools.window.getWindowInnerWidth() / 4;
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95htmlCode.GDdrawObjects3);

let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.mse_95htmlCode.GDdrawObjects3.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdrawObjects3[i].drawLineV2(runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), -(10), runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), gdjs.evtTools.window.getWindowInnerHeight() + 500, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(7).add(4);
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects2});
gdjs.mse_95htmlCode.eventsList25 = function(runtimeScene) {

};gdjs.mse_95htmlCode.eventsList26 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(2));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.mse_95htmlCode.GDmusic_9595containerObjects2.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects2Objects, runtimeScene.getGame().getVariables().getFromIndex(2).getChild(runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber()).getAsNumber(), 300, "");
}{runtimeScene.getScene().getVariables().getFromIndex(8).add(1);
}}
}

}


};gdjs.mse_95htmlCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22839644);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(8).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(false);
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects3});
gdjs.mse_95htmlCode.eventsList28 = function(runtimeScene) {

};gdjs.mse_95htmlCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount3 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node")) / 3;
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(gdjs.mse_95htmlCode.GDmusic_9595containerObjects1, gdjs.mse_95htmlCode.GDmusic_9595containerObjects3);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects3Objects, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() + 1).getAsNumber(), "");
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[i].returnVariable(gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[i].getVariables().getFromIndex(0)).setString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() + 2).getAsString());
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(3);
}}
}

}


};gdjs.mse_95htmlCode.eventsList30 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("set_snap"), gdjs.mse_95htmlCode.GDset_9595snapObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDset_9595snapObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDset_9595snapObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsString());
}
}}

}


};gdjs.mse_95htmlCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.mse_95htmlCode.eventsList29(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("MSE(set)", "MSE(set)");
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MSE(set)", "MSE(set)", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(20));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(20).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(18));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDsaveObjects2Objects = Hashtable.newFrom({"save": gdjs.mse_95htmlCode.GDsaveObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects4Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects4});
gdjs.mse_95htmlCode.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.mse_95htmlCode.GDsaving_9595projectObjects2, gdjs.mse_95htmlCode.GDsaving_9595projectObjects5);

{for(var i = 0, len = gdjs.mse_95htmlCode.GDsaving_9595projectObjects5.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsaving_9595projectObjects5[i].getBehavior("Text").setText("");
}
}}

}


};gdjs.mse_95htmlCode.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(STATE)", "MSE(STATE)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.eventsList34 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("hhh", variable);
}
gdjs.mse_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects4Objects) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node")) / 3;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber()).getChild("json").setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList33(runtimeScene);} //End of subevents
}
gdjs.mse_95htmlCode.localVariables.pop();

}


};gdjs.mse_95htmlCode.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects3);

for (gdjs.mse_95htmlCode.forEachIndex4 = 0;gdjs.mse_95htmlCode.forEachIndex4 < gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length;++gdjs.mse_95htmlCode.forEachIndex4) {
gdjs.mse_95htmlCode.GDmusic_9595containerObjects4.length = 0;


gdjs.mse_95htmlCode.forEachTemporary4 = gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[gdjs.mse_95htmlCode.forEachIndex4];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects4.push(gdjs.mse_95htmlCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"), (( gdjs.mse_95htmlCode.GDmusic_9595containerObjects4.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects4[0].getX()));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"), (( gdjs.mse_95htmlCode.GDmusic_9595containerObjects4.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects4[0].getY()));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"), ((gdjs.mse_95htmlCode.GDmusic_9595containerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95htmlCode.GDmusic_9595containerObjects4[0].getVariables()).getFromIndex(0).getAsString());
}
{ //Subevents: 
gdjs.mse_95htmlCode.eventsList34(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDhomeObjects1Objects = Hashtable.newFrom({"home": gdjs.mse_95htmlCode.GDhomeObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects3});
gdjs.mse_95htmlCode.eventsList36 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("saving_project"), gdjs.mse_95htmlCode.GDsaving_9595projectObjects4);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDsaving_9595projectObjects4.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsaving_9595projectObjects4[i].getBehavior("Text").setText("saved");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "project_manager_html", true);
}}

}


};gdjs.mse_95htmlCode.eventsList37 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(STATE)", "MSE(STATE)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.eventsList38 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("hhh", variable);
}
gdjs.mse_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects3Objects) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node")) / 3;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber()).getChild("json").setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(3)));
}{gdjs.evtTools.sound.unloadMusic(runtimeScene, "audio.ogg");
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList37(runtimeScene);} //End of subevents
}
gdjs.mse_95htmlCode.localVariables.pop();

}


};gdjs.mse_95htmlCode.mapOfEmptyGDmusic_9595containerObjects = Hashtable.newFrom({"music_container": []});
gdjs.mse_95htmlCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95htmlCode.forEachIndex3 = 0;gdjs.mse_95htmlCode.forEachIndex3 < gdjs.mse_95htmlCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95htmlCode.forEachIndex3) {
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95htmlCode.forEachTemporary3 = gdjs.mse_95htmlCode.GDmusic_9595containerObjects2[gdjs.mse_95htmlCode.forEachIndex3];
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.push(gdjs.mse_95htmlCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"), (( gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[0].getX()));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"), (( gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[0].getY()));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"), ((gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95htmlCode.GDmusic_9595containerObjects3[0].getVariables()).getFromIndex(0).getAsString());
}
{ //Subevents: 
gdjs.mse_95htmlCode.eventsList38(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfEmptyGDmusic_9595containerObjects) < 1;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "project_manager_html", true);
}}

}


};gdjs.mse_95htmlCode.eventsList40 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("save"), gdjs.mse_95htmlCode.GDsaveObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDsaveObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("saving_project"), gdjs.mse_95htmlCode.GDsaving_9595projectObjects2);
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"));
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDsaving_9595projectObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsaving_9595projectObjects2[i].getBehavior("Text").setText("saving....");
}
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList35(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.mse_95htmlCode.GDhomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDhomeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects1Objects = Hashtable.newFrom({"crop": gdjs.mse_95htmlCode.GDcropObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDenterObjects1Objects = Hashtable.newFrom({"enter": gdjs.mse_95htmlCode.GDenterObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.eventsList41 = function(runtimeScene) {

{

/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
/* Reuse gdjs.mse_95htmlCode.GDsearchObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getVariableString(gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getVariables().getFromIndex(0)) == (( gdjs.mse_95htmlCode.GDsearchObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDsearchObjects1[0].getText()) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[k] = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i].setX((( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[0].getX()));
}
}}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDsettings_95959595icObjects1Objects = Hashtable.newFrom({"settings_ic": gdjs.mse_95htmlCode.GDsettings_9595icObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDsnap_95959595boolObjects2Objects = Hashtable.newFrom({"snap_bool": gdjs.mse_95htmlCode.GDsnap_9595boolObjects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDshow_95959595boolObjects2Objects = Hashtable.newFrom({"show_bool": gdjs.mse_95htmlCode.GDshow_9595boolObjects2});
gdjs.mse_95htmlCode.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("snap_bool"), gdjs.mse_95htmlCode.GDsnap_9595boolObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDsnap_95959595boolObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("snap"));
}{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("show_bool"), gdjs.mse_95htmlCode.GDshow_9595boolObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDshow_95959595boolObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid"));
}{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("set_snap"), gdjs.mse_95htmlCode.GDset_9595snapObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDset_9595snapObjects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDset_9595snapObjects2[i].isFocused() ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDset_9595snapObjects2[k] = gdjs.mse_95htmlCode.GDset_9595snapObjects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDset_9595snapObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.mse_95htmlCode.GDset_9595snapObjects2.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDset_9595snapObjects2[0].getText())) > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.mse_95htmlCode.GDset_9595snapObjects2.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDset_9595snapObjects2[0].getText())) != runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber());
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDset_9595snapObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").setNumber(gdjs.evtTools.common.toNumber((( gdjs.mse_95htmlCode.GDset_9595snapObjects2.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDset_9595snapObjects2[0].getText())));
}{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("show_bool"), gdjs.mse_95htmlCode.GDshow_9595boolObjects2);
gdjs.copyArray(runtimeScene.getObjects("snap_bool"), gdjs.mse_95htmlCode.GDsnap_9595boolObjects2);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDsnap_9595boolObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsnap_9595boolObjects2[i].getBehavior("Animation").setAnimationName(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("snap").getAsString());
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDshow_9595boolObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDshow_9595boolObjects2[i].getBehavior("Animation").setAnimationName(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid").getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects1Objects = Hashtable.newFrom({"crop": gdjs.mse_95htmlCode.GDcropObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects1Objects = Hashtable.newFrom({"crop": gdjs.mse_95htmlCode.GDcropObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects1Objects = Hashtable.newFrom({"crop": gdjs.mse_95htmlCode.GDcropObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95htmlCode.GDmusic_9595containerObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDUnnamedObjects1Objects = Hashtable.newFrom({"Unnamed": gdjs.mse_95htmlCode.GDUnnamedObjects1});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDUnnamedObjects1Objects = Hashtable.newFrom({"Unnamed": gdjs.mse_95htmlCode.GDUnnamedObjects1});
gdjs.mse_95htmlCode.userFunc0x10e6470 = function GDJSInlineCode(runtimeScene) {
"use strict";
try {
    eval(runtimeScene.getVariables().get("func2").getAsString()+runtimeScene.getGame().getVariables().get("data").getChildNamed("script")   .getAsString());
} catch (e) {
    console.clear()
}

};
gdjs.mse_95htmlCode.eventsList43 = function(runtimeScene) {

{


gdjs.mse_95htmlCode.userFunc0x10e6470(runtimeScene);

}


};gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95htmlCode.GDpanel3Objects2});
gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDscriptObjects2Objects = Hashtable.newFrom({"script": gdjs.mse_95htmlCode.GDscriptObjects2});
gdjs.mse_95htmlCode.userFunc0x12697f8 = function GDJSInlineCode(runtimeScene) {
"use strict";
const audio = new Audio();
audio.src = runtimeScene.getGame().getVariables().get("data").getChildNamed("audio").getAsString()
audio.addEventListener('loadedmetadata', () => {
    console.log(`Duration: ${audio.duration} seconds`);
    runtimeScene.getGame().getVariables().get("audio_len").setNumber(audio.duration)
    
});





};
gdjs.mse_95htmlCode.eventsList44 = function(runtimeScene) {

{


gdjs.mse_95htmlCode.userFunc0x12697f8(runtimeScene);

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95htmlCode.eventsList45 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95htmlCode.GDcoderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDcoderObjects2.length;i<l;++i) {
    if ( !(gdjs.mse_95htmlCode.GDcoderObjects2[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDcoderObjects2[k] = gdjs.mse_95htmlCode.GDcoderObjects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDcoderObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList43(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(21).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95htmlCode.GDcoderObjects2);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDcoderObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcoderObjects2[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(21).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95htmlCode.GDcoderObjects2);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDcoderObjects2.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcoderObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95htmlCode.GDpanel3Objects2);
gdjs.copyArray(runtimeScene.getObjects("script"), gdjs.mse_95htmlCode.GDscriptObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDpanel3Objects2.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDpanel3Objects2[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDpanel3Objects2[k] = gdjs.mse_95htmlCode.GDpanel3Objects2[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDpanel3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDpanel3Objects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDscriptObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "drop_down");
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(21));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("audio").getAsString()) > 6);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22887268);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList44(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95htmlCode.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.mse_95htmlCode.GDnameObjects1);

for (gdjs.mse_95htmlCode.forEachIndex2 = 0;gdjs.mse_95htmlCode.forEachIndex2 < gdjs.mse_95htmlCode.GDnameObjects1.length;++gdjs.mse_95htmlCode.forEachIndex2) {
gdjs.mse_95htmlCode.GDnameObjects2.length = 0;


gdjs.mse_95htmlCode.forEachTemporary2 = gdjs.mse_95htmlCode.GDnameObjects1[gdjs.mse_95htmlCode.forEachIndex2];
gdjs.mse_95htmlCode.GDnameObjects2.push(gdjs.mse_95htmlCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid").getAsBoolean();
}
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.mse_95htmlCode.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22772188);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95htmlCode.GDavObjects1);
gdjs.copyArray(runtimeScene.getObjects("dd"), gdjs.mse_95htmlCode.GDddObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95htmlCode.GDdrawObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95htmlCode.GDdraw2Objects1);
gdjs.copyArray(runtimeScene.getObjects("fast_backward"), gdjs.mse_95htmlCode.GDfast_9595backwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("fast_forward"), gdjs.mse_95htmlCode.GDfast_9595forwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95htmlCode.GDgearObjects1);
gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.mse_95htmlCode.GDhomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("json_icon"), gdjs.mse_95htmlCode.GDjson_9595iconObjects1);
gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95htmlCode.GDmenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.mse_95htmlCode.GDnameObjects1);
gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95htmlCode.GDplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects1);
gdjs.copyArray(runtimeScene.getObjects("save"), gdjs.mse_95htmlCode.GDsaveObjects1);
gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95htmlCode.GDsettings_9595icObjects1);
gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95htmlCode.GDstopObjects1);
gdjs.copyArray(runtimeScene.getObjects("yyy"), gdjs.mse_95htmlCode.GDyyyObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDyyyObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDyyyObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i].setColor("117;0;141");
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDddObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDddObjects1[i].setColor("117;0;141");
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDavObjects1[i].setColor("117;0;141");
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdrawObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDnameObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDfast_9595forwardObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDfast_9595forwardObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDfast_9595backwardObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDfast_9595backwardObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDstopObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdraw2Objects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDjson_9595iconObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDjson_9595iconObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDavObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDhomeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDhomeObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDsaveObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsaveObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDgearObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmenuObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95htmlCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "playing" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDplayObjects1[k] = gdjs.mse_95htmlCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.mse_95htmlCode.GDinfoObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDinfoObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDinfoObjects1[i].getBehavior("Text").setText("no audio being played press the spuare button");
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDinfoObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDinfoObjects1[i].setCenterXInScene(gdjs.evtTools.window.getWindowInnerWidth() / 2);
}
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95htmlCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "playing" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDplayObjects1[k] = gdjs.mse_95htmlCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22776036);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22777356);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22778564);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPaused(runtimeScene, 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{


gdjs.mse_95htmlCode.eventsList3(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("dd"), gdjs.mse_95htmlCode.GDddObjects1);
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.mse_95htmlCode.GDdebugObjects1);
gdjs.copyArray(runtimeScene.getObjects("debug2"), gdjs.mse_95htmlCode.GDdebug2Objects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdebugObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0))));
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDddObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDddObjects1[i].setCenterXInScene(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) * 50);
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDdebug2Objects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdebug2Objects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.round(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber())) + " sec");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("speed"), gdjs.mse_95htmlCode.GDspeedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber() != gdjs.evtTools.common.toNumber((( gdjs.mse_95htmlCode.GDspeedObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDspeedObjects1[0].getText())));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDspeedObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDspeedObjects1[i].getBehavior("Text").getText() != "0" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDspeedObjects1[k] = gdjs.mse_95htmlCode.GDspeedObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDspeedObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.mse_95htmlCode.GDspeedObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDspeedObjects1[0].getText())) > 0);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDspeedObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(17).setNumber(gdjs.evtTools.common.toNumber((( gdjs.mse_95htmlCode.GDspeedObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDspeedObjects1[0].getText())));
}{gdjs.evtTools.sound.setMusicOnChannelPitch(runtimeScene, 1, runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "error");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) > 0;
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "error");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95htmlCode.GDplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95htmlCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "playing" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDplayObjects1[k] = gdjs.mse_95htmlCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDstopObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDstopObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDstopObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDstopObjects1[k] = gdjs.mse_95htmlCode.GDstopObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDstopObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) <= 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1));
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("fast_forward"), gdjs.mse_95htmlCode.GDfast_9595forwardObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDfast_95959595forwardObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setMusicOnChannelPlayingOffset(runtimeScene, 1, gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) + (0.5));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fast_backward"), gdjs.mse_95htmlCode.GDfast_9595backwardObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDfast_95959595backwardObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setMusicOnChannelPlayingOffset(runtimeScene, 1, gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) - (0.5));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95htmlCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDstopObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDstopObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDstopObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDstopObjects1[k] = gdjs.mse_95htmlCode.GDstopObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDstopObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelPaused(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio.ogg", 1, false, 60, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95htmlCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDstopObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDstopObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDstopObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDstopObjects1[k] = gdjs.mse_95htmlCode.GDstopObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDstopObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDstopObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDstopObjects1[i].getBehavior("Animation").setAnimationName("play");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95htmlCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDstopObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDstopObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDstopObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDstopObjects1[k] = gdjs.mse_95htmlCode.GDstopObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDstopObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDstopObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDstopObjects1[i].getBehavior("Animation").setAnimationName("stop");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95htmlCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDstopObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDstopObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDstopObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDstopObjects1[k] = gdjs.mse_95htmlCode.GDstopObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDstopObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1);
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i].getX() > 638 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[k] = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDplay_9595nodeObjects1 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[0].getPointX("")), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i].getX() <= 638 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[k] = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 638, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95htmlCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "pausef" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDplayObjects1[k] = gdjs.mse_95htmlCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95htmlCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "pausef" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDplayObjects1[k] = gdjs.mse_95htmlCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22800972);
}
}
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "j");
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95htmlCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDstopObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDstopObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDstopObjects1[i].returnVariable(gdjs.mse_95htmlCode.GDstopObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95htmlCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDplayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setBoolean(false);
variables._declare("play3", variable);
}
gdjs.mse_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
}
gdjs.mse_95htmlCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{

gdjs.mse_95htmlCode.GDcropObjects1.length = 0;

gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.mse_95htmlCode.GDcropObjects1_1final.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects2);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects2Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.mse_95htmlCode.GDmusic_9595containerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1_1final.indexOf(gdjs.mse_95htmlCode.GDmusic_9595containerObjects2[j]) === -1 )
            gdjs.mse_95htmlCode.GDmusic_9595containerObjects1_1final.push(gdjs.mse_95htmlCode.GDmusic_9595containerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95htmlCode.GDcropObjects2);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects2Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects2Objects, false, runtimeScene, true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.mse_95htmlCode.GDcropObjects2.length; j < jLen ; ++j) {
        if ( gdjs.mse_95htmlCode.GDcropObjects1_1final.indexOf(gdjs.mse_95htmlCode.GDcropObjects2[j]) === -1 )
            gdjs.mse_95htmlCode.GDcropObjects1_1final.push(gdjs.mse_95htmlCode.GDcropObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.mse_95htmlCode.GDmusic_9595containerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1_1final.indexOf(gdjs.mse_95htmlCode.GDmusic_9595containerObjects2[j]) === -1 )
            gdjs.mse_95htmlCode.GDmusic_9595containerObjects1_1final.push(gdjs.mse_95htmlCode.GDmusic_9595containerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.mse_95htmlCode.GDcropObjects1_1final, gdjs.mse_95htmlCode.GDcropObjects1);
gdjs.copyArray(gdjs.mse_95htmlCode.GDmusic_9595containerObjects1_1final, gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "c");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects1);
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects, (( gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[0].getPointX("")), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - 48, "");
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Resizable").setSize(16, 96);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "n");
if (isConditionTrue_0) {
{gdjs.fileSystem.saveVariableToJSONFileAsync(runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "tesst.txt", gdjs.VariablesContainer.badVariable);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "pop_up");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("yyy"), gdjs.mse_95htmlCode.GDyyyObjects1);

for (gdjs.mse_95htmlCode.forEachIndex2 = 0;gdjs.mse_95htmlCode.forEachIndex2 < gdjs.mse_95htmlCode.GDyyyObjects1.length;++gdjs.mse_95htmlCode.forEachIndex2) {
gdjs.mse_95htmlCode.GDyyyObjects2.length = 0;


gdjs.mse_95htmlCode.forEachTemporary2 = gdjs.mse_95htmlCode.GDyyyObjects1[gdjs.mse_95htmlCode.forEachIndex2];
gdjs.mse_95htmlCode.GDyyyObjects2.push(gdjs.mse_95htmlCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.mse_95htmlCode.eventsList9(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("caca"), gdjs.mse_95htmlCode.GDcacaObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDcacaObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcacaObjects1[i].setCenterXInScene(Math.round(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 16) * 16);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.mse_95htmlCode.GDdebugObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);
{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects, runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber(), 96, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdebugObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95htmlCode.GDmenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmenuObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmenuObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDmenuObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmenuObjects1[k] = gdjs.mse_95htmlCode.GDmenuObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmenuObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "drop_down");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95htmlCode.GDmenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmenuObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmenuObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDmenuObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmenuObjects1[k] = gdjs.mse_95htmlCode.GDmenuObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmenuObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "drop_down");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95htmlCode.GDmenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmenuObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDmenuObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmenuObjects1[i].returnVariable(gdjs.mse_95htmlCode.GDmenuObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "drop_down");
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pop_up");
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid").getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("caca"), gdjs.mse_95htmlCode.GDcacaObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber((( gdjs.mse_95htmlCode.GDcacaObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDcacaObjects1[0].getPointX("")));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() < 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid").getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("caca"), gdjs.mse_95htmlCode.GDcacaObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber((( gdjs.mse_95htmlCode.GDcacaObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDcacaObjects1[0].getPointX("")));
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList24(runtimeScene);} //End of subevents
}

}


{


gdjs.mse_95htmlCode.eventsList27(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.mse_95htmlCode.GDinfoObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDinfoObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDinfoObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(437 - 360));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95htmlCode.GDavObjects1);
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95htmlCode.GDcoderObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95htmlCode.GDdrawObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95htmlCode.GDdraw2Objects1);
gdjs.copyArray(runtimeScene.getObjects("fast_backward"), gdjs.mse_95htmlCode.GDfast_9595backwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("fast_forward"), gdjs.mse_95htmlCode.GDfast_9595forwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95htmlCode.GDgearObjects1);
gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.mse_95htmlCode.GDhomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("json_icon"), gdjs.mse_95htmlCode.GDjson_9595iconObjects1);
gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95htmlCode.GDmenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.mse_95htmlCode.GDnameObjects1);
gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.mse_95htmlCode.GDname2Objects1);
gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95htmlCode.GDplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95htmlCode.GDplay_9595nodeObjects1);
gdjs.copyArray(runtimeScene.getObjects("save"), gdjs.mse_95htmlCode.GDsaveObjects1);
gdjs.copyArray(runtimeScene.getObjects("saving_project"), gdjs.mse_95htmlCode.GDsaving_9595projectObjects1);
gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95htmlCode.GDsettings_9595icObjects1);
gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95htmlCode.GDstopObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDname2Objects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDname2Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(11).getAsString());
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDcoderObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcoderObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("script").getAsString());
}
}{gdjs.evtTools.sound.setMusicOnChannelPitch(runtimeScene, 1, 1);
}{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 1, 70);
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdrawObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDnameObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDfast_9595forwardObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDfast_9595forwardObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDfast_9595backwardObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDfast_9595backwardObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDstopObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdraw2Objects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDjson_9595iconObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDjson_9595iconObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDavObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDhomeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDhomeObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDsaveObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsaveObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDgearObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmenuObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdrawObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDnameObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDfast_9595forwardObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDfast_9595forwardObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDfast_9595backwardObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDfast_9595backwardObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDstopObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdraw2Objects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDjson_9595iconObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDjson_9595iconObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDavObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDhomeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDhomeObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDsaveObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsaveObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDgearObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmenuObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdrawObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDnameObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplayObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDfast_9595forwardObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDfast_9595forwardObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDfast_9595backwardObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDfast_9595backwardObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDstopObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDdraw2Objects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDjson_9595iconObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDjson_9595iconObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDavObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDhomeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDhomeObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDsaveObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsaveObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDgearObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmenuObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDplay_9595nodeObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDsaving_9595projectObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsaving_9595projectObjects1[i].getBehavior("Text").setText("");
}
}
{ //Subevents
gdjs.mse_95htmlCode.eventsList31(runtimeScene);} //End of subevents
}

}


{


gdjs.mse_95htmlCode.eventsList40(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95htmlCode.GDeventObjects1);
/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].returnVariable(gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getVariables().getFromIndex(0)).setString((( gdjs.mse_95htmlCode.GDeventObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDeventObjects1[0].getText()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95htmlCode.GDcropObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects1Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects, false, runtimeScene, true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95htmlCode.GDeventObjects1);
/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].returnVariable(gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getVariables().getFromIndex(0)).setString((( gdjs.mse_95htmlCode.GDeventObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDeventObjects1[0].getText()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("show_event"), gdjs.mse_95htmlCode.GDshow_9595eventObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDshow_9595eventObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDshow_9595eventObjects1[i].getBehavior("Text").setText("properties\nevents: " + ((gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[0].getVariables()).getFromIndex(0).getAsString() + "\nX: " + gdjs.evtTools.common.toString((( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[0].getX())) + "\nY: " + gdjs.evtTools.common.toString((( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[0].getY())));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("enter"), gdjs.mse_95htmlCode.GDenterObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("search"), gdjs.mse_95htmlCode.GDsearchObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDenterObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDsearchObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDsearchObjects1[i].getBehavior("Text").getText() != "" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDsearchObjects1[k] = gdjs.mse_95htmlCode.GDsearchObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDsearchObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList41(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95htmlCode.GDcropObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDcropObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcropObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - (gdjs.mse_95htmlCode.GDcropObjects1[i].getX()), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - (gdjs.mse_95htmlCode.GDcropObjects1[i].getY()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95htmlCode.GDsettings_9595icObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDsettings_95959595icObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDsettings_9595icObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].returnVariable(gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95htmlCode.GDsettings_9595icObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDsettings_9595icObjects1[k] = gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "settings");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95htmlCode.GDsettings_9595icObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getVariableBoolean(gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDsettings_9595icObjects1[k] = gdjs.mse_95htmlCode.GDsettings_9595icObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "settings");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "settings");
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95htmlCode.eventsList42(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22871748);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95htmlCode.GDcropObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDcropObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcropObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.mse_95htmlCode.GDcropObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcropObjects1[i].getBehavior("Opacity").setOpacity(100);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95htmlCode.GDcropObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects1Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects, true, runtimeScene, true);
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDcropObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDcropObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcropObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95htmlCode.GDcropObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDcropObjects1Objects, gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDmusic_95959595containerObjects1Objects, true, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right"));
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDcropObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDcropObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcropObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95htmlCode.GDcropObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDcropObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDcropObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[k] = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getX() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.window.getWindowInnerWidth() / 2) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[k] = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Resizable").getWidth() != runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[k] = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Resizable").setWidth(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95htmlCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getX() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[k] = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (gdjs.evtTools.window.getWindowInnerWidth() / 2) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[k] = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Resizable").getWidth() != runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[k] = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDmusic_9595containerObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDmusic_9595containerObjects1[i].getBehavior("Resizable").setWidth(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95htmlCode.GDgearObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDgearObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDgearObjects1[i].MaxValue((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDgearObjects1[k] = gdjs.mse_95htmlCode.GDgearObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDgearObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDgearObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDgearObjects1[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95htmlCode.GDgearObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDgearObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDgearObjects1[i].MaxValue((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDgearObjects1[k] = gdjs.mse_95htmlCode.GDgearObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDgearObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDgearObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDgearObjects1[i].Activate(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95htmlCode.GDgearObjects1);
{for(var i = 0, len = gdjs.mse_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDgearObjects1[i].SetMaxValue(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95htmlCode.GDgearObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95htmlCode.GDgearObjects1.length;i<l;++i) {
    if ( gdjs.mse_95htmlCode.GDgearObjects1[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95htmlCode.GDgearObjects1[k] = gdjs.mse_95htmlCode.GDgearObjects1[i];
        ++k;
    }
}
gdjs.mse_95htmlCode.GDgearObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDgearObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{gdjs.evtTools.sound.setMusicOnChannelPlayingOffset(runtimeScene, 1, (( gdjs.mse_95htmlCode.GDgearObjects1.length === 0 ) ? 0 :gdjs.mse_95htmlCode.GDgearObjects1[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Unnamed"), gdjs.mse_95htmlCode.GDUnnamedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDUnnamedObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDUnnamedObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDUnnamedObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDUnnamedObjects1[i].getBehavior("Effect").enableEffect("Effect2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Unnamed"), gdjs.mse_95htmlCode.GDUnnamedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95htmlCode.mapOfGDgdjs_9546mse_959595htmlCode_9546GDUnnamedObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95htmlCode.GDUnnamedObjects1 */
{for(var i = 0, len = gdjs.mse_95htmlCode.GDUnnamedObjects1.length ;i < len;++i) {
    gdjs.mse_95htmlCode.GDUnnamedObjects1[i].getBehavior("Effect").enableEffect("Effect2", false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95htmlCode.GDcoderObjects1);
gdjs.copyArray(runtimeScene.getObjects("func"), gdjs.mse_95htmlCode.GDfuncObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(19).setString((( gdjs.mse_95htmlCode.GDfuncObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDfuncObjects1[0].getBehavior("Text").getText()) + gdjs.evtTools.string.newLine());
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("script").setString((( gdjs.mse_95htmlCode.GDcoderObjects1.length === 0 ) ? "" :gdjs.mse_95htmlCode.GDcoderObjects1[0].getBehavior("Text").getText()));
}}

}


{


gdjs.mse_95htmlCode.eventsList45(runtimeScene);
}


};

gdjs.mse_95htmlCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.mse_95htmlCode.GDpanelObjects1.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects2.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects3.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects4.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects5.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects6.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects1.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects2.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects3.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects4.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects5.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects6.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects1.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects2.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects3.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects4.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects5.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects6.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects1.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects2.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects3.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects4.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects5.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects6.length = 0;
gdjs.mse_95htmlCode.GDnameObjects1.length = 0;
gdjs.mse_95htmlCode.GDnameObjects2.length = 0;
gdjs.mse_95htmlCode.GDnameObjects3.length = 0;
gdjs.mse_95htmlCode.GDnameObjects4.length = 0;
gdjs.mse_95htmlCode.GDnameObjects5.length = 0;
gdjs.mse_95htmlCode.GDnameObjects6.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects2.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects4.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects5.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects6.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects2.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects3.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects4.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects5.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects6.length = 0;
gdjs.mse_95htmlCode.GDplayObjects1.length = 0;
gdjs.mse_95htmlCode.GDplayObjects2.length = 0;
gdjs.mse_95htmlCode.GDplayObjects3.length = 0;
gdjs.mse_95htmlCode.GDplayObjects4.length = 0;
gdjs.mse_95htmlCode.GDplayObjects5.length = 0;
gdjs.mse_95htmlCode.GDplayObjects6.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects1.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects2.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects3.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects4.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects5.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects6.length = 0;
gdjs.mse_95htmlCode.GDstopObjects1.length = 0;
gdjs.mse_95htmlCode.GDstopObjects2.length = 0;
gdjs.mse_95htmlCode.GDstopObjects3.length = 0;
gdjs.mse_95htmlCode.GDstopObjects4.length = 0;
gdjs.mse_95htmlCode.GDstopObjects5.length = 0;
gdjs.mse_95htmlCode.GDstopObjects6.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects1.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects2.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects3.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects4.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects5.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects6.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects1.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects2.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects3.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects4.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects5.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects6.length = 0;
gdjs.mse_95htmlCode.GDgearObjects1.length = 0;
gdjs.mse_95htmlCode.GDgearObjects2.length = 0;
gdjs.mse_95htmlCode.GDgearObjects3.length = 0;
gdjs.mse_95htmlCode.GDgearObjects4.length = 0;
gdjs.mse_95htmlCode.GDgearObjects5.length = 0;
gdjs.mse_95htmlCode.GDgearObjects6.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects1.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects2.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects3.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects4.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects5.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects6.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects1.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects2.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects3.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects4.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects5.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects6.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects1.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects2.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects3.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects4.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects5.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects6.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects1.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects2.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects3.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects4.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects5.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects6.length = 0;
gdjs.mse_95htmlCode.GDddObjects1.length = 0;
gdjs.mse_95htmlCode.GDddObjects2.length = 0;
gdjs.mse_95htmlCode.GDddObjects3.length = 0;
gdjs.mse_95htmlCode.GDddObjects4.length = 0;
gdjs.mse_95htmlCode.GDddObjects5.length = 0;
gdjs.mse_95htmlCode.GDddObjects6.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects1.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects2.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects3.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects4.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects5.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects6.length = 0;
gdjs.mse_95htmlCode.GDavObjects1.length = 0;
gdjs.mse_95htmlCode.GDavObjects2.length = 0;
gdjs.mse_95htmlCode.GDavObjects3.length = 0;
gdjs.mse_95htmlCode.GDavObjects4.length = 0;
gdjs.mse_95htmlCode.GDavObjects5.length = 0;
gdjs.mse_95htmlCode.GDavObjects6.length = 0;
gdjs.mse_95htmlCode.GDexportObjects1.length = 0;
gdjs.mse_95htmlCode.GDexportObjects2.length = 0;
gdjs.mse_95htmlCode.GDexportObjects3.length = 0;
gdjs.mse_95htmlCode.GDexportObjects4.length = 0;
gdjs.mse_95htmlCode.GDexportObjects5.length = 0;
gdjs.mse_95htmlCode.GDexportObjects6.length = 0;
gdjs.mse_95htmlCode.GDbadObjects1.length = 0;
gdjs.mse_95htmlCode.GDbadObjects2.length = 0;
gdjs.mse_95htmlCode.GDbadObjects3.length = 0;
gdjs.mse_95htmlCode.GDbadObjects4.length = 0;
gdjs.mse_95htmlCode.GDbadObjects5.length = 0;
gdjs.mse_95htmlCode.GDbadObjects6.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects1.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects2.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects3.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects4.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects5.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects6.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects1.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects2.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects3.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects4.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects5.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects6.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects1.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects2.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects3.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects4.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects5.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects6.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects1.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects2.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects3.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects4.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects5.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects6.length = 0;
gdjs.mse_95htmlCode.GDasdObjects1.length = 0;
gdjs.mse_95htmlCode.GDasdObjects2.length = 0;
gdjs.mse_95htmlCode.GDasdObjects3.length = 0;
gdjs.mse_95htmlCode.GDasdObjects4.length = 0;
gdjs.mse_95htmlCode.GDasdObjects5.length = 0;
gdjs.mse_95htmlCode.GDasdObjects6.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects1.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects2.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects3.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects4.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects5.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects6.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects1.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects2.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects3.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects4.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects5.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects6.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects1.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects2.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects3.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects4.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects5.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects6.length = 0;
gdjs.mse_95htmlCode.GDexObjects1.length = 0;
gdjs.mse_95htmlCode.GDexObjects2.length = 0;
gdjs.mse_95htmlCode.GDexObjects3.length = 0;
gdjs.mse_95htmlCode.GDexObjects4.length = 0;
gdjs.mse_95htmlCode.GDexObjects5.length = 0;
gdjs.mse_95htmlCode.GDexObjects6.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects1.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects2.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects3.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects4.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects5.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects6.length = 0;
gdjs.mse_95htmlCode.GDbackObjects1.length = 0;
gdjs.mse_95htmlCode.GDbackObjects2.length = 0;
gdjs.mse_95htmlCode.GDbackObjects3.length = 0;
gdjs.mse_95htmlCode.GDbackObjects4.length = 0;
gdjs.mse_95htmlCode.GDbackObjects5.length = 0;
gdjs.mse_95htmlCode.GDbackObjects6.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects1.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects2.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects3.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects4.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects5.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects6.length = 0;
gdjs.mse_95htmlCode.GDerrObjects1.length = 0;
gdjs.mse_95htmlCode.GDerrObjects2.length = 0;
gdjs.mse_95htmlCode.GDerrObjects3.length = 0;
gdjs.mse_95htmlCode.GDerrObjects4.length = 0;
gdjs.mse_95htmlCode.GDerrObjects5.length = 0;
gdjs.mse_95htmlCode.GDerrObjects6.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects1.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects2.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects3.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects4.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects5.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects6.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects1.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects2.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects3.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects4.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects5.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects6.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects1.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects2.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects3.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects4.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects5.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects6.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects1.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects2.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects3.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects4.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects5.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects6.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects1.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects2.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects3.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects4.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects5.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects6.length = 0;
gdjs.mse_95htmlCode.GDidObjects1.length = 0;
gdjs.mse_95htmlCode.GDidObjects2.length = 0;
gdjs.mse_95htmlCode.GDidObjects3.length = 0;
gdjs.mse_95htmlCode.GDidObjects4.length = 0;
gdjs.mse_95htmlCode.GDidObjects5.length = 0;
gdjs.mse_95htmlCode.GDidObjects6.length = 0;
gdjs.mse_95htmlCode.GDname2Objects1.length = 0;
gdjs.mse_95htmlCode.GDname2Objects2.length = 0;
gdjs.mse_95htmlCode.GDname2Objects3.length = 0;
gdjs.mse_95htmlCode.GDname2Objects4.length = 0;
gdjs.mse_95htmlCode.GDname2Objects5.length = 0;
gdjs.mse_95htmlCode.GDname2Objects6.length = 0;
gdjs.mse_95htmlCode.GDeventObjects1.length = 0;
gdjs.mse_95htmlCode.GDeventObjects2.length = 0;
gdjs.mse_95htmlCode.GDeventObjects3.length = 0;
gdjs.mse_95htmlCode.GDeventObjects4.length = 0;
gdjs.mse_95htmlCode.GDeventObjects5.length = 0;
gdjs.mse_95htmlCode.GDeventObjects6.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects1.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects2.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects3.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects4.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects5.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects6.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects1.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects2.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects3.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects4.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects5.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects6.length = 0;
gdjs.mse_95htmlCode.GDenterObjects1.length = 0;
gdjs.mse_95htmlCode.GDenterObjects2.length = 0;
gdjs.mse_95htmlCode.GDenterObjects3.length = 0;
gdjs.mse_95htmlCode.GDenterObjects4.length = 0;
gdjs.mse_95htmlCode.GDenterObjects5.length = 0;
gdjs.mse_95htmlCode.GDenterObjects6.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects1.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects2.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects3.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects4.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects5.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects6.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects1.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects2.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects3.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects4.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects5.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects6.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects1.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects2.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects3.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects4.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects5.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects6.length = 0;
gdjs.mse_95htmlCode.GDcropObjects1.length = 0;
gdjs.mse_95htmlCode.GDcropObjects2.length = 0;
gdjs.mse_95htmlCode.GDcropObjects3.length = 0;
gdjs.mse_95htmlCode.GDcropObjects4.length = 0;
gdjs.mse_95htmlCode.GDcropObjects5.length = 0;
gdjs.mse_95htmlCode.GDcropObjects6.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects2.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects3.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects4.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects5.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects6.length = 0;
gdjs.mse_95htmlCode.GDsetObjects1.length = 0;
gdjs.mse_95htmlCode.GDsetObjects2.length = 0;
gdjs.mse_95htmlCode.GDsetObjects3.length = 0;
gdjs.mse_95htmlCode.GDsetObjects4.length = 0;
gdjs.mse_95htmlCode.GDsetObjects5.length = 0;
gdjs.mse_95htmlCode.GDsetObjects6.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects1.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects2.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects3.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects4.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects5.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects6.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects1.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects2.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects3.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects4.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects5.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects6.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects1.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects2.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects3.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects4.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects5.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects6.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects1.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects2.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects3.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects4.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects5.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects6.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects1.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects2.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects3.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects4.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects5.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects6.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects1.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects2.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects3.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects4.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects5.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects6.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects1.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects2.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects3.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects4.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects5.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects6.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects1.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects2.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects3.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects4.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects5.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects6.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects1.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects2.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects3.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects4.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects5.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects6.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects1.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects2.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects3.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects4.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects5.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects6.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects1.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects2.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects3.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects4.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects5.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects6.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects1.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects2.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects3.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects4.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects5.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects6.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects1.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects2.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects3.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects4.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects5.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects6.length = 0;
gdjs.mse_95htmlCode.GDversionObjects1.length = 0;
gdjs.mse_95htmlCode.GDversionObjects2.length = 0;
gdjs.mse_95htmlCode.GDversionObjects3.length = 0;
gdjs.mse_95htmlCode.GDversionObjects4.length = 0;
gdjs.mse_95htmlCode.GDversionObjects5.length = 0;
gdjs.mse_95htmlCode.GDversionObjects6.length = 0;

gdjs.mse_95htmlCode.eventsList46(runtimeScene);
gdjs.mse_95htmlCode.GDpanelObjects1.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects2.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects3.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects4.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects5.length = 0;
gdjs.mse_95htmlCode.GDpanelObjects6.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects1.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects2.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects3.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects4.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects5.length = 0;
gdjs.mse_95htmlCode.GDpanel2Objects6.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects1.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects2.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects3.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects4.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects5.length = 0;
gdjs.mse_95htmlCode.GDsound_9595nameObjects6.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects1.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects2.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects3.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects4.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects5.length = 0;
gdjs.mse_95htmlCode.GDdrawObjects6.length = 0;
gdjs.mse_95htmlCode.GDnameObjects1.length = 0;
gdjs.mse_95htmlCode.GDnameObjects2.length = 0;
gdjs.mse_95htmlCode.GDnameObjects3.length = 0;
gdjs.mse_95htmlCode.GDnameObjects4.length = 0;
gdjs.mse_95htmlCode.GDnameObjects5.length = 0;
gdjs.mse_95htmlCode.GDnameObjects6.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects1.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects2.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects3.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects4.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects5.length = 0;
gdjs.mse_95htmlCode.GDmusic_9595containerObjects6.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects1.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects2.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects3.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects4.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects5.length = 0;
gdjs.mse_95htmlCode.GDplay_9595nodeObjects6.length = 0;
gdjs.mse_95htmlCode.GDplayObjects1.length = 0;
gdjs.mse_95htmlCode.GDplayObjects2.length = 0;
gdjs.mse_95htmlCode.GDplayObjects3.length = 0;
gdjs.mse_95htmlCode.GDplayObjects4.length = 0;
gdjs.mse_95htmlCode.GDplayObjects5.length = 0;
gdjs.mse_95htmlCode.GDplayObjects6.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects1.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects2.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects3.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects4.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects5.length = 0;
gdjs.mse_95htmlCode.GDdebugObjects6.length = 0;
gdjs.mse_95htmlCode.GDstopObjects1.length = 0;
gdjs.mse_95htmlCode.GDstopObjects2.length = 0;
gdjs.mse_95htmlCode.GDstopObjects3.length = 0;
gdjs.mse_95htmlCode.GDstopObjects4.length = 0;
gdjs.mse_95htmlCode.GDstopObjects5.length = 0;
gdjs.mse_95htmlCode.GDstopObjects6.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects1.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects2.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects3.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects4.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects5.length = 0;
gdjs.mse_95htmlCode.GDfast_9595forwardObjects6.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects1.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects2.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects3.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects4.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects5.length = 0;
gdjs.mse_95htmlCode.GDfast_9595backwardObjects6.length = 0;
gdjs.mse_95htmlCode.GDgearObjects1.length = 0;
gdjs.mse_95htmlCode.GDgearObjects2.length = 0;
gdjs.mse_95htmlCode.GDgearObjects3.length = 0;
gdjs.mse_95htmlCode.GDgearObjects4.length = 0;
gdjs.mse_95htmlCode.GDgearObjects5.length = 0;
gdjs.mse_95htmlCode.GDgearObjects6.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects1.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects2.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects3.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects4.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects5.length = 0;
gdjs.mse_95htmlCode.GDbar1Objects6.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects1.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects2.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects3.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects4.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects5.length = 0;
gdjs.mse_95htmlCode.GDyyyObjects6.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects1.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects2.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects3.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects4.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects5.length = 0;
gdjs.mse_95htmlCode.GDcacaObjects6.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects1.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects2.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects3.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects4.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects5.length = 0;
gdjs.mse_95htmlCode.GDdraw2Objects6.length = 0;
gdjs.mse_95htmlCode.GDddObjects1.length = 0;
gdjs.mse_95htmlCode.GDddObjects2.length = 0;
gdjs.mse_95htmlCode.GDddObjects3.length = 0;
gdjs.mse_95htmlCode.GDddObjects4.length = 0;
gdjs.mse_95htmlCode.GDddObjects5.length = 0;
gdjs.mse_95htmlCode.GDddObjects6.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects1.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects2.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects3.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects4.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects5.length = 0;
gdjs.mse_95htmlCode.GDjson_9595iconObjects6.length = 0;
gdjs.mse_95htmlCode.GDavObjects1.length = 0;
gdjs.mse_95htmlCode.GDavObjects2.length = 0;
gdjs.mse_95htmlCode.GDavObjects3.length = 0;
gdjs.mse_95htmlCode.GDavObjects4.length = 0;
gdjs.mse_95htmlCode.GDavObjects5.length = 0;
gdjs.mse_95htmlCode.GDavObjects6.length = 0;
gdjs.mse_95htmlCode.GDexportObjects1.length = 0;
gdjs.mse_95htmlCode.GDexportObjects2.length = 0;
gdjs.mse_95htmlCode.GDexportObjects3.length = 0;
gdjs.mse_95htmlCode.GDexportObjects4.length = 0;
gdjs.mse_95htmlCode.GDexportObjects5.length = 0;
gdjs.mse_95htmlCode.GDexportObjects6.length = 0;
gdjs.mse_95htmlCode.GDbadObjects1.length = 0;
gdjs.mse_95htmlCode.GDbadObjects2.length = 0;
gdjs.mse_95htmlCode.GDbadObjects3.length = 0;
gdjs.mse_95htmlCode.GDbadObjects4.length = 0;
gdjs.mse_95htmlCode.GDbadObjects5.length = 0;
gdjs.mse_95htmlCode.GDbadObjects6.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects1.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects2.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects3.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects4.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects5.length = 0;
gdjs.mse_95htmlCode.GDpaintObjects6.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects1.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects2.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects3.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects4.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects5.length = 0;
gdjs.mse_95htmlCode.GDproject_9595nameObjects6.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects1.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects2.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects3.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects4.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects5.length = 0;
gdjs.mse_95htmlCode.GDinffofoObjects6.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects1.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects2.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects3.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects4.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects5.length = 0;
gdjs.mse_95htmlCode.GDlogoObjects6.length = 0;
gdjs.mse_95htmlCode.GDasdObjects1.length = 0;
gdjs.mse_95htmlCode.GDasdObjects2.length = 0;
gdjs.mse_95htmlCode.GDasdObjects3.length = 0;
gdjs.mse_95htmlCode.GDasdObjects4.length = 0;
gdjs.mse_95htmlCode.GDasdObjects5.length = 0;
gdjs.mse_95htmlCode.GDasdObjects6.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects1.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects2.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects3.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects4.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects5.length = 0;
gdjs.mse_95htmlCode.GDmenuObjects6.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects1.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects2.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects3.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects4.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects5.length = 0;
gdjs.mse_95htmlCode.GDpanel3Objects6.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects1.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects2.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects3.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects4.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects5.length = 0;
gdjs.mse_95htmlCode.GDhelpObjects6.length = 0;
gdjs.mse_95htmlCode.GDexObjects1.length = 0;
gdjs.mse_95htmlCode.GDexObjects2.length = 0;
gdjs.mse_95htmlCode.GDexObjects3.length = 0;
gdjs.mse_95htmlCode.GDexObjects4.length = 0;
gdjs.mse_95htmlCode.GDexObjects5.length = 0;
gdjs.mse_95htmlCode.GDexObjects6.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects1.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects2.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects3.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects4.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects5.length = 0;
gdjs.mse_95htmlCode.GDinfoObjects6.length = 0;
gdjs.mse_95htmlCode.GDbackObjects1.length = 0;
gdjs.mse_95htmlCode.GDbackObjects2.length = 0;
gdjs.mse_95htmlCode.GDbackObjects3.length = 0;
gdjs.mse_95htmlCode.GDbackObjects4.length = 0;
gdjs.mse_95htmlCode.GDbackObjects5.length = 0;
gdjs.mse_95htmlCode.GDbackObjects6.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects1.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects2.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects3.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects4.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects5.length = 0;
gdjs.mse_95htmlCode.GDpanel4Objects6.length = 0;
gdjs.mse_95htmlCode.GDerrObjects1.length = 0;
gdjs.mse_95htmlCode.GDerrObjects2.length = 0;
gdjs.mse_95htmlCode.GDerrObjects3.length = 0;
gdjs.mse_95htmlCode.GDerrObjects4.length = 0;
gdjs.mse_95htmlCode.GDerrObjects5.length = 0;
gdjs.mse_95htmlCode.GDerrObjects6.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects1.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects2.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects3.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects4.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects5.length = 0;
gdjs.mse_95htmlCode.GDai_9595placerkObjects6.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects1.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects2.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects3.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects4.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects5.length = 0;
gdjs.mse_95htmlCode.GDhoverObjects6.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects1.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects2.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects3.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects4.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects5.length = 0;
gdjs.mse_95htmlCode.GDsub_9595audObjects6.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects1.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects2.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects3.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects4.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects5.length = 0;
gdjs.mse_95htmlCode.GDaudio_9595idObjects6.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects1.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects2.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects3.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects4.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects5.length = 0;
gdjs.mse_95htmlCode.GDexport_9595aObjects6.length = 0;
gdjs.mse_95htmlCode.GDidObjects1.length = 0;
gdjs.mse_95htmlCode.GDidObjects2.length = 0;
gdjs.mse_95htmlCode.GDidObjects3.length = 0;
gdjs.mse_95htmlCode.GDidObjects4.length = 0;
gdjs.mse_95htmlCode.GDidObjects5.length = 0;
gdjs.mse_95htmlCode.GDidObjects6.length = 0;
gdjs.mse_95htmlCode.GDname2Objects1.length = 0;
gdjs.mse_95htmlCode.GDname2Objects2.length = 0;
gdjs.mse_95htmlCode.GDname2Objects3.length = 0;
gdjs.mse_95htmlCode.GDname2Objects4.length = 0;
gdjs.mse_95htmlCode.GDname2Objects5.length = 0;
gdjs.mse_95htmlCode.GDname2Objects6.length = 0;
gdjs.mse_95htmlCode.GDeventObjects1.length = 0;
gdjs.mse_95htmlCode.GDeventObjects2.length = 0;
gdjs.mse_95htmlCode.GDeventObjects3.length = 0;
gdjs.mse_95htmlCode.GDeventObjects4.length = 0;
gdjs.mse_95htmlCode.GDeventObjects5.length = 0;
gdjs.mse_95htmlCode.GDeventObjects6.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects1.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects2.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects3.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects4.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects5.length = 0;
gdjs.mse_95htmlCode.GDshow_9595eventObjects6.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects1.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects2.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects3.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects4.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects5.length = 0;
gdjs.mse_95htmlCode.GDsearchObjects6.length = 0;
gdjs.mse_95htmlCode.GDenterObjects1.length = 0;
gdjs.mse_95htmlCode.GDenterObjects2.length = 0;
gdjs.mse_95htmlCode.GDenterObjects3.length = 0;
gdjs.mse_95htmlCode.GDenterObjects4.length = 0;
gdjs.mse_95htmlCode.GDenterObjects5.length = 0;
gdjs.mse_95htmlCode.GDenterObjects6.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects1.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects2.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects3.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects4.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects5.length = 0;
gdjs.mse_95htmlCode.GDsaveObjects6.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects1.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects2.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects3.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects4.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects5.length = 0;
gdjs.mse_95htmlCode.GDspeedObjects6.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects1.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects2.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects3.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects4.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects5.length = 0;
gdjs.mse_95htmlCode.GDhomeObjects6.length = 0;
gdjs.mse_95htmlCode.GDcropObjects1.length = 0;
gdjs.mse_95htmlCode.GDcropObjects2.length = 0;
gdjs.mse_95htmlCode.GDcropObjects3.length = 0;
gdjs.mse_95htmlCode.GDcropObjects4.length = 0;
gdjs.mse_95htmlCode.GDcropObjects5.length = 0;
gdjs.mse_95htmlCode.GDcropObjects6.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects1.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects2.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects3.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects4.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects5.length = 0;
gdjs.mse_95htmlCode.GDsettings_9595icObjects6.length = 0;
gdjs.mse_95htmlCode.GDsetObjects1.length = 0;
gdjs.mse_95htmlCode.GDsetObjects2.length = 0;
gdjs.mse_95htmlCode.GDsetObjects3.length = 0;
gdjs.mse_95htmlCode.GDsetObjects4.length = 0;
gdjs.mse_95htmlCode.GDsetObjects5.length = 0;
gdjs.mse_95htmlCode.GDsetObjects6.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects1.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects2.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects3.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects4.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects5.length = 0;
gdjs.mse_95htmlCode.GDsnap_9595boolObjects6.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects1.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects2.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects3.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects4.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects5.length = 0;
gdjs.mse_95htmlCode.GDshow_9595boolObjects6.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects1.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects2.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects3.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects4.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects5.length = 0;
gdjs.mse_95htmlCode.GDset_9595snapObjects6.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects1.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects2.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects3.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects4.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects5.length = 0;
gdjs.mse_95htmlCode.GDdebug2Objects6.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects1.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects2.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects3.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects4.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects5.length = 0;
gdjs.mse_95htmlCode.GDbuttonObjects6.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects1.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects2.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects3.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects4.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects5.length = 0;
gdjs.mse_95htmlCode.GDUnnamedObjects6.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects1.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects2.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects3.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects4.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects5.length = 0;
gdjs.mse_95htmlCode.GDUnnamed2Objects6.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects1.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects2.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects3.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects4.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects5.length = 0;
gdjs.mse_95htmlCode.GDUnnamed3Objects6.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects1.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects2.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects3.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects4.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects5.length = 0;
gdjs.mse_95htmlCode.GDUnnamed4Objects6.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects1.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects2.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects3.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects4.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects5.length = 0;
gdjs.mse_95htmlCode.GDscriptObjects6.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects1.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects2.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects3.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects4.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects5.length = 0;
gdjs.mse_95htmlCode.GDcoderObjects6.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects1.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects2.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects3.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects4.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects5.length = 0;
gdjs.mse_95htmlCode.GDfuncObjects6.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects1.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects2.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects3.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects4.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects5.length = 0;
gdjs.mse_95htmlCode.GDsaving_9595projectObjects6.length = 0;
gdjs.mse_95htmlCode.GDversionObjects1.length = 0;
gdjs.mse_95htmlCode.GDversionObjects2.length = 0;
gdjs.mse_95htmlCode.GDversionObjects3.length = 0;
gdjs.mse_95htmlCode.GDversionObjects4.length = 0;
gdjs.mse_95htmlCode.GDversionObjects5.length = 0;
gdjs.mse_95htmlCode.GDversionObjects6.length = 0;


return;

}

gdjs['mse_95htmlCode'] = gdjs.mse_95htmlCode;
