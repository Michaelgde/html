
if (typeof gdjs.evtsExt__load_audio__file_loader_to_subs !== "undefined") {
  gdjs.evtsExt__load_audio__file_loader_to_subs.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__load_audio__file_loader_to_subs = {};


gdjs.evtsExt__load_audio__file_loader_to_subs.userFunc0x146e0f0 = function GDJSInlineCode(runtimeScene, eventsFunctionContext) {
"use strict";
const fileinput = document.createElement('input');
fileinput.type = 'file';
fileinput.accept = 'audio/';
fileinput.style.display = 'none';
fileinput.addEventListener('change',(event) => {
    const file = event.target.files[0];
    if (file){
        const reader = new FileReader();
        reader.onload = (e)=> {
            const audioData = e.target.result;
            const audio = new Audio(audioData);
            runtimeScene.getSoundManager().unloadAll
            runtimeScene
    .getGame()
    .getSoundManager()._resourceLoader.getResource("y").file = audioData
            
            runtimeScene.getVariables().get("musicData").setString(audioData)
            runtimeScene.getGame().getVariables().get("musicDatah").setString(audioData)
            runtimeScene.getVariables().get("loadedMusic").setValue(audio);
            runtimeScene.getGame().getVariables().get("data").getChildNamed('subAudio').getChildAt(eventsFunctionContext.getArgument("num")).getChildNamed('data').setString(audioData)
            
        }
        reader.readAsDataURL(file);
    }
});
fileinput.click()        
};
gdjs.evtsExt__load_audio__file_loader_to_subs.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__load_audio__file_loader_to_subs.userFunc0x146e0f0(runtimeScene, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__load_audio__file_loader_to_subs.func = function(runtimeScene, num, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("load_audio"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("load_audio"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "num") return num;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__load_audio__file_loader_to_subs.eventsList0(runtimeScene, eventsFunctionContext);


return;
}

gdjs.evtsExt__load_audio__file_loader_to_subs.registeredGdjsCallbacks = [];