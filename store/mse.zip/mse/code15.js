gdjs.lvl_95editorCode = {};
gdjs.lvl_95editorCode.localVariables = [];
gdjs.lvl_95editorCode.GDListPanelObjects1= [];
gdjs.lvl_95editorCode.GDListPanelObjects2= [];
gdjs.lvl_95editorCode.GDListPanelObjects3= [];
gdjs.lvl_95editorCode.GDListPanelObjects4= [];
gdjs.lvl_95editorCode.GDListPanelObjects5= [];
gdjs.lvl_95editorCode.GDTITLEObjects1= [];
gdjs.lvl_95editorCode.GDTITLEObjects2= [];
gdjs.lvl_95editorCode.GDTITLEObjects3= [];
gdjs.lvl_95editorCode.GDTITLEObjects4= [];
gdjs.lvl_95editorCode.GDTITLEObjects5= [];
gdjs.lvl_95editorCode.GDplace_9595holderObjects1= [];
gdjs.lvl_95editorCode.GDplace_9595holderObjects2= [];
gdjs.lvl_95editorCode.GDplace_9595holderObjects3= [];
gdjs.lvl_95editorCode.GDplace_9595holderObjects4= [];
gdjs.lvl_95editorCode.GDplace_9595holderObjects5= [];
gdjs.lvl_95editorCode.GDNewSpriteObjects1= [];
gdjs.lvl_95editorCode.GDNewSpriteObjects2= [];
gdjs.lvl_95editorCode.GDNewSpriteObjects3= [];
gdjs.lvl_95editorCode.GDNewSpriteObjects4= [];
gdjs.lvl_95editorCode.GDNewSpriteObjects5= [];
gdjs.lvl_95editorCode.GDbackgroundObjects1= [];
gdjs.lvl_95editorCode.GDbackgroundObjects2= [];
gdjs.lvl_95editorCode.GDbackgroundObjects3= [];
gdjs.lvl_95editorCode.GDbackgroundObjects4= [];
gdjs.lvl_95editorCode.GDbackgroundObjects5= [];
gdjs.lvl_95editorCode.GDpopObjects1= [];
gdjs.lvl_95editorCode.GDpopObjects2= [];
gdjs.lvl_95editorCode.GDpopObjects3= [];
gdjs.lvl_95editorCode.GDpopObjects4= [];
gdjs.lvl_95editorCode.GDpopObjects5= [];
gdjs.lvl_95editorCode.GDbuttonObjects1= [];
gdjs.lvl_95editorCode.GDbuttonObjects2= [];
gdjs.lvl_95editorCode.GDbuttonObjects3= [];
gdjs.lvl_95editorCode.GDbuttonObjects4= [];
gdjs.lvl_95editorCode.GDbuttonObjects5= [];
gdjs.lvl_95editorCode.GDobject_9595txtObjects1= [];
gdjs.lvl_95editorCode.GDobject_9595txtObjects2= [];
gdjs.lvl_95editorCode.GDobject_9595txtObjects3= [];
gdjs.lvl_95editorCode.GDobject_9595txtObjects4= [];
gdjs.lvl_95editorCode.GDobject_9595txtObjects5= [];
gdjs.lvl_95editorCode.GDinsertNameObjects1= [];
gdjs.lvl_95editorCode.GDinsertNameObjects2= [];
gdjs.lvl_95editorCode.GDinsertNameObjects3= [];
gdjs.lvl_95editorCode.GDinsertNameObjects4= [];
gdjs.lvl_95editorCode.GDinsertNameObjects5= [];
gdjs.lvl_95editorCode.GDloadingObjects1= [];
gdjs.lvl_95editorCode.GDloadingObjects2= [];
gdjs.lvl_95editorCode.GDloadingObjects3= [];
gdjs.lvl_95editorCode.GDloadingObjects4= [];
gdjs.lvl_95editorCode.GDloadingObjects5= [];
gdjs.lvl_95editorCode.GDbutton2Objects1= [];
gdjs.lvl_95editorCode.GDbutton2Objects2= [];
gdjs.lvl_95editorCode.GDbutton2Objects3= [];
gdjs.lvl_95editorCode.GDbutton2Objects4= [];
gdjs.lvl_95editorCode.GDbutton2Objects5= [];
gdjs.lvl_95editorCode.GDbackground2Objects1= [];
gdjs.lvl_95editorCode.GDbackground2Objects2= [];
gdjs.lvl_95editorCode.GDbackground2Objects3= [];
gdjs.lvl_95editorCode.GDbackground2Objects4= [];
gdjs.lvl_95editorCode.GDbackground2Objects5= [];
gdjs.lvl_95editorCode.GDlayersName098Objects1= [];
gdjs.lvl_95editorCode.GDlayersName098Objects2= [];
gdjs.lvl_95editorCode.GDlayersName098Objects3= [];
gdjs.lvl_95editorCode.GDlayersName098Objects4= [];
gdjs.lvl_95editorCode.GDlayersName098Objects5= [];


gdjs.lvl_95editorCode.userFunc0xd79c90 = function GDJSInlineCode(runtimeScene) {
"use strict";
//runtimeScene.setLayerIndex('ui253mich126',Object.keys(runtimeScene._layers.items))
//runtimeScene._layers.items
//console.log(runtimeScene._layers)

};
gdjs.lvl_95editorCode.eventsList0 = function(runtimeScene) {

{


gdjs.lvl_95editorCode.userFunc0xd79c90(runtimeScene);

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(11)) - 2);
}{gdjs.fileSystem.saveStringToFileAsync(runtimeScene.getScene().getVariables().getFromIndex(14).getAsString(), gdjs.fileSystem.getDesktopPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "gdevelop Debug" + gdjs.fileSystem.getPathDelimiter() + "debug.txt", gdjs.VariablesContainer.badVariable);
}}

}


};gdjs.lvl_95editorCode.userFunc0x17a5c60 = function GDJSInlineCode(runtimeScene) {
"use strict";
function registerLayer(layerName,r,g,b){
    runtimeScene.addLayer({
    name : layerName,
    renderingType : 2,
    cameraType : 0,
    visibility : true,
    effects : [],
    isLightingLayer : false,
    ambientLightColorR : r,
    ambientLightColorB : g,
    ambientLightColorG : b

})
}




var id  = runtimeScene.getGame().getVariables().get('selected_layout').getAsNumber()
var sl = runtimeScene.getGame().getVariables().get('SelectedLayer').getAsString()
var gdResources = runtimeScene.getGame().getVariables().get('data').getChildNamed('resources').getChildNamed('resourcesURL')
console.log('layout => '+id)
var scene =  JSON.parse(runtimeScene.getGame().getVariables().get('data').getChildNamed('lvlData').getAsString())
var obj = []
var objectss = JSON.stringify(scene.layouts[id].objects)
var intancee = JSON.stringify(scene.layouts[id].instances)
var resources = JSON.stringify(scene.resources.resources)
console.log('objects => '+JSON.parse(objectss))
runtimeScene.getVariables().get('lvlData').getChildNamed('Objects').fromJSON(objectss)
runtimeScene.getVariables().get('lvlData').getChildNamed('instances').fromJSON(intancee)
runtimeScene.getVariables().get('lvlData').getChildNamed('resources').fromJSON(resources)



scene.layouts[id].objects.forEach(regg=> {
    runtimeScene.registerObject(regg); 
    obj.push(); 
})

console.log(gdResources.toJSObject())
scene.layouts[id].layers.forEach(regg=> {runtimeScene.addLayer(regg);runtimeScene.getVariables().get('layerCount').add(1)})
console.log('layout json parsed')
scene.layouts[id].instances.forEach(regg=> {
    var proceed = true
    //console.log('instance=>' + regg.name)
    var obje = runtimeScene.createObject(regg.name)
    obje.setPosition(regg.x,regg.y)
    obje.setLayer("")
    obje.setAngle(regg.angle)
    obje.setHeight(regg.height)
    obje.setWidth(regg.width)
    var behave = {
        "checkCollisionMask": true,
        "name": "Draggable",
        "type": "DraggableBehavior::Draggable"
    }

    obje.addNewBehavior(behave)

    
}
)
runtimeScene.getVariables().get("resourceURL").fromJSObject(obj)
runtimeScene.getVariables().get('createObjects').setString('true')


registerLayer('1new2UI2Layer1',0,0,0)
console.log('created layer')
var lm =  ['TITLE','background2']
lm.forEach(objr=> runtimeScene.getObjects(objr)[0].setLayer('1new2UI2Layer1'))
console.log(sl)

//obj.forEach(objN=> runtimeScene.getObjects(objN).forEach(objEcTr=> {if(!objEcTr.getLayer() == sl){objEcTr.deleteFromScene(runtimeScene)}}))




};
gdjs.lvl_95editorCode.eventsList1 = function(runtimeScene) {

{


gdjs.lvl_95editorCode.userFunc0x17a5c60(runtimeScene);

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.lvl_95editorCode.userFunc0x11bacb8 = function GDJSInlineCode(runtimeScene) {
"use strict";
console.log(runtimeScene.getGame()._resourcesLoader._resources[0])

};
gdjs.lvl_95editorCode.mapOfGDgdjs_9546lvl_959595editorCode_9546GDobject_95959595txtObjects3Objects = Hashtable.newFrom({"object_txt": gdjs.lvl_95editorCode.GDobject_9595txtObjects3});
gdjs.lvl_95editorCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.lvl_95editorCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{



}


{


gdjs.lvl_95editorCode.userFunc0x11bacb8(runtimeScene);

}


{


const keyIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(6);
const valueIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(5);
const iterableReference3 = runtimeScene.getScene().getVariables().getFromIndex(13).getChild("Objects");
if(!iterableReference3.isPrimitive()) {
for(
    const iteratorKey3 in 
    iterableReference3.getType() === "structure"
      ? iterableReference3.getAllChildren()
      : iterableReference3.getType() === "array"
        ? iterableReference3.getAllChildrenArray()
        : []
) {
    if(iterableReference3.getType() === "structure")
        keyIteratorReference3.setString(iteratorKey3);
    else if(iterableReference3.getType() === "array")
        keyIteratorReference3.setNumber(iteratorKey3);
    const structureChildVariable3 = iterableReference3.getChild(iteratorKey3)
    valueIteratorReference3.castTo(structureChildVariable3.getType())
    if(structureChildVariable3.isPrimitive()) {
        valueIteratorReference3.setValue(structureChildVariable3.getValue());
    } else if (structureChildVariable3.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference3.replaceChildren(structureChildVariable3.getAllChildren());
    } else if (structureChildVariable3.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference3.replaceChildrenArray(structureChildVariable3.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.lvl_95editorCode.GDobject_9595txtObjects3.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvl_95editorCode.mapOfGDgdjs_9546lvl_959595editorCode_9546GDobject_95959595txtObjects3Objects, 1051 + 10, 10 + (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() * 32), "ui253mich126");
}{for(var i = 0, len = gdjs.lvl_95editorCode.GDobject_9595txtObjects3.length ;i < len;++i) {
    gdjs.lvl_95editorCode.GDobject_9595txtObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("name").getAsString());
}
}
{ //Subevents: 
gdjs.lvl_95editorCode.eventsList2(runtimeScene);} //Subevents end.
}
}
}

}


};gdjs.lvl_95editorCode.eventsList4 = function(runtimeScene) {

{



}


};gdjs.lvl_95editorCode.eventsList5 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "t");
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "t");
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_95editorCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvlData").getAsString()) > 30);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23888172);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvl_95editorCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "u");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("place_holder"), gdjs.lvl_95editorCode.GDplace_9595holderObjects2);
{gdjs.evtTools.debuggerTools.log(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(13).getChild("instances"))), "info", "");
}{for(var i = 0, len = gdjs.lvl_95editorCode.GDplace_9595holderObjects2.length ;i < len;++i) {
    gdjs.lvl_95editorCode.GDplace_9595holderObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.lvl_95editorCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.lvl_95editorCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{



}


};gdjs.lvl_95editorCode.mapOfGDgdjs_9546lvl_959595editorCode_9546GDobject_95959595txtObjects1Objects = Hashtable.newFrom({"object_txt": gdjs.lvl_95editorCode.GDobject_9595txtObjects1});
gdjs.lvl_95editorCode.eventsList6 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "error404Niv28");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "error404Niv28");
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("");
variable.addChild("object", variable1);
}
variables._declare("namer", variable);
}
gdjs.lvl_95editorCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.lvl_95editorCode.eventsList5(runtimeScene);} //End of subevents
}
gdjs.lvl_95editorCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("object_txt"), gdjs.lvl_95editorCode.GDobject_9595txtObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.lvl_95editorCode.mapOfGDgdjs_9546lvl_959595editorCode_9546GDobject_95959595txtObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23918596);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvl_95editorCode.GDobject_9595txtObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(8).setString((( gdjs.lvl_95editorCode.GDobject_9595txtObjects1.length === 0 ) ? "" :gdjs.lvl_95editorCode.GDobject_9595txtObjects1[0].getBehavior("Text").getText()));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "add8object45");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__UploadDownloadTextFile__UploadFinished.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString()) > 30);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvlData").getAsString());
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "r");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl_editor", true);
}}

}


};

gdjs.lvl_95editorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvl_95editorCode.GDListPanelObjects1.length = 0;
gdjs.lvl_95editorCode.GDListPanelObjects2.length = 0;
gdjs.lvl_95editorCode.GDListPanelObjects3.length = 0;
gdjs.lvl_95editorCode.GDListPanelObjects4.length = 0;
gdjs.lvl_95editorCode.GDListPanelObjects5.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects1.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects2.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects3.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects4.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects5.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects1.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects2.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects3.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects4.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects5.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects1.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects2.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects3.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects4.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects5.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects1.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects2.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects3.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects4.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects5.length = 0;
gdjs.lvl_95editorCode.GDpopObjects1.length = 0;
gdjs.lvl_95editorCode.GDpopObjects2.length = 0;
gdjs.lvl_95editorCode.GDpopObjects3.length = 0;
gdjs.lvl_95editorCode.GDpopObjects4.length = 0;
gdjs.lvl_95editorCode.GDpopObjects5.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects1.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects2.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects3.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects4.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects5.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects1.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects2.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects3.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects4.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects5.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects1.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects2.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects3.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects4.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects5.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects1.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects2.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects3.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects4.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects5.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects1.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects2.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects3.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects4.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects5.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects1.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects2.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects3.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects4.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects5.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects1.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects2.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects3.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects4.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects5.length = 0;

gdjs.lvl_95editorCode.eventsList6(runtimeScene);
gdjs.lvl_95editorCode.GDListPanelObjects1.length = 0;
gdjs.lvl_95editorCode.GDListPanelObjects2.length = 0;
gdjs.lvl_95editorCode.GDListPanelObjects3.length = 0;
gdjs.lvl_95editorCode.GDListPanelObjects4.length = 0;
gdjs.lvl_95editorCode.GDListPanelObjects5.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects1.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects2.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects3.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects4.length = 0;
gdjs.lvl_95editorCode.GDTITLEObjects5.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects1.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects2.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects3.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects4.length = 0;
gdjs.lvl_95editorCode.GDplace_9595holderObjects5.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects1.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects2.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects3.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects4.length = 0;
gdjs.lvl_95editorCode.GDNewSpriteObjects5.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects1.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects2.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects3.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects4.length = 0;
gdjs.lvl_95editorCode.GDbackgroundObjects5.length = 0;
gdjs.lvl_95editorCode.GDpopObjects1.length = 0;
gdjs.lvl_95editorCode.GDpopObjects2.length = 0;
gdjs.lvl_95editorCode.GDpopObjects3.length = 0;
gdjs.lvl_95editorCode.GDpopObjects4.length = 0;
gdjs.lvl_95editorCode.GDpopObjects5.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects1.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects2.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects3.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects4.length = 0;
gdjs.lvl_95editorCode.GDbuttonObjects5.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects1.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects2.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects3.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects4.length = 0;
gdjs.lvl_95editorCode.GDobject_9595txtObjects5.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects1.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects2.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects3.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects4.length = 0;
gdjs.lvl_95editorCode.GDinsertNameObjects5.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects1.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects2.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects3.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects4.length = 0;
gdjs.lvl_95editorCode.GDloadingObjects5.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects1.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects2.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects3.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects4.length = 0;
gdjs.lvl_95editorCode.GDbutton2Objects5.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects1.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects2.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects3.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects4.length = 0;
gdjs.lvl_95editorCode.GDbackground2Objects5.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects1.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects2.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects3.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects4.length = 0;
gdjs.lvl_95editorCode.GDlayersName098Objects5.length = 0;


return;

}

gdjs['lvl_95editorCode'] = gdjs.lvl_95editorCode;
