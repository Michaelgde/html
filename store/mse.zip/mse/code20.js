gdjs.resourcesCode = {};
gdjs.resourcesCode.localVariables = [];
gdjs.resourcesCode.GDresourceNameObjects1= [];
gdjs.resourcesCode.GDresourceNameObjects2= [];
gdjs.resourcesCode.GDrdObjects1= [];
gdjs.resourcesCode.GDrdObjects2= [];
gdjs.resourcesCode.GDnameInputObjects1= [];
gdjs.resourcesCode.GDnameInputObjects2= [];
gdjs.resourcesCode.GDbuttonObjects1= [];
gdjs.resourcesCode.GDbuttonObjects2= [];
gdjs.resourcesCode.GDaddObjects1= [];
gdjs.resourcesCode.GDaddObjects2= [];


gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDresourceNameObjects2Objects = Hashtable.newFrom({"resourceName": gdjs.resourcesCode.GDresourceNameObjects2});
gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects2Objects = Hashtable.newFrom({"rd": gdjs.resourcesCode.GDrdObjects2});
gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects2Objects = Hashtable.newFrom({"rd": gdjs.resourcesCode.GDrdObjects2});
gdjs.resourcesCode.eventsList0 = function(runtimeScene) {

};gdjs.resourcesCode.eventsList1 = function(runtimeScene) {

{


const keyIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(1);
const valueIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(0);
const iterableReference2 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("list");
if(!iterableReference2.isPrimitive()) {
for(
    const iteratorKey2 in 
    iterableReference2.getType() === "structure"
      ? iterableReference2.getAllChildren()
      : iterableReference2.getType() === "array"
        ? iterableReference2.getAllChildrenArray()
        : []
) {
    if(iterableReference2.getType() === "structure")
        keyIteratorReference2.setString(iteratorKey2);
    else if(iterableReference2.getType() === "array")
        keyIteratorReference2.setNumber(iteratorKey2);
    const structureChildVariable2 = iterableReference2.getChild(iteratorKey2)
    valueIteratorReference2.castTo(structureChildVariable2.getType())
    if(structureChildVariable2.isPrimitive()) {
        valueIteratorReference2.setValue(structureChildVariable2.getValue());
    } else if (structureChildVariable2.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference2.replaceChildren(structureChildVariable2.getAllChildren());
    } else if (structureChildVariable2.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference2.replaceChildrenArray(structureChildVariable2.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(gdjs.resourcesCode.GDrdObjects1, gdjs.resourcesCode.GDrdObjects2);

gdjs.copyArray(gdjs.resourcesCode.GDresourceNameObjects1, gdjs.resourcesCode.GDresourceNameObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDresourceNameObjects2Objects, 0, gdjs.resourcesCode.localVariables[0].getFromIndex(0).getAsNumber() * 32, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects2Objects, 400, gdjs.resourcesCode.localVariables[0].getFromIndex(0).getAsNumber() * 32, "");
}{for(var i = 0, len = gdjs.resourcesCode.GDresourceNameObjects2.length ;i < len;++i) {
    gdjs.resourcesCode.GDresourceNameObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}{for(var i = 0, len = gdjs.resourcesCode.GDresourceNameObjects2.length ;i < len;++i) {
    gdjs.resourcesCode.GDresourceNameObjects2[i].returnVariable(gdjs.resourcesCode.GDresourceNameObjects2[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}{for(var i = 0, len = gdjs.resourcesCode.GDrdObjects2.length ;i < len;++i) {
    gdjs.resourcesCode.GDrdObjects2[i].returnVariable(gdjs.resourcesCode.GDrdObjects2[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}{gdjs.resourcesCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("list").getChild(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString()).getAsString(), gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects2Objects, false, 64, 64, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.resourcesCode.GDrdObjects2.length ;i < len;++i) {
    gdjs.resourcesCode.GDrdObjects2[i].getBehavior("Resizable").setSize(32, 32);
}
}}
}
}

}


};gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.resourcesCode.GDbuttonObjects1});
gdjs.resourcesCode.userFunc0x13e52b8 = function GDJSInlineCode(runtimeScene) {
"use strict";
const fileinput = document.createElement('input');
fileinput.type = 'file';
fileinput.accept = 'image/png';
fileinput.style.display = 'none';
fileinput.addEventListener('change',(event) => {
    const file = event.target.files[0];
    if (file){
        const reader = new FileReader();
        reader.onload = (e)=> {
            const imgData = e.target.result;          
            var name = runtimeScene.getVariables().get("nameOfVar").getAsString()
            runtimeScene.getGame().getVariables().get("data").getChildNamed("resources").getChildNamed('list').getChildNamed(name).setString(imgData)
            runtimeScene.getVariables().get("temp").setString(imgData)
            //runtimeScene.getGame().getVariables().get("tempTextures").setString(imgData)
            
        }
        reader.readAsDataURL(file);
    }
});
fileinput.click()       

};
gdjs.resourcesCode.eventsList2 = function(runtimeScene) {

{


gdjs.resourcesCode.userFunc0x13e52b8(runtimeScene);

}


};gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDresourceNameObjects1Objects = Hashtable.newFrom({"resourceName": gdjs.resourcesCode.GDresourceNameObjects1});
gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDresourceNameObjects2Objects = Hashtable.newFrom({"resourceName": gdjs.resourcesCode.GDresourceNameObjects2});
gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects2Objects = Hashtable.newFrom({"rd": gdjs.resourcesCode.GDrdObjects2});
gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects2Objects = Hashtable.newFrom({"rd": gdjs.resourcesCode.GDrdObjects2});
gdjs.resourcesCode.eventsList3 = function(runtimeScene) {

};gdjs.resourcesCode.eventsList4 = function(runtimeScene) {

{


const keyIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(1);
const valueIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(0);
const iterableReference2 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("list");
if(!iterableReference2.isPrimitive()) {
for(
    const iteratorKey2 in 
    iterableReference2.getType() === "structure"
      ? iterableReference2.getAllChildren()
      : iterableReference2.getType() === "array"
        ? iterableReference2.getAllChildrenArray()
        : []
) {
    if(iterableReference2.getType() === "structure")
        keyIteratorReference2.setString(iteratorKey2);
    else if(iterableReference2.getType() === "array")
        keyIteratorReference2.setNumber(iteratorKey2);
    const structureChildVariable2 = iterableReference2.getChild(iteratorKey2)
    valueIteratorReference2.castTo(structureChildVariable2.getType())
    if(structureChildVariable2.isPrimitive()) {
        valueIteratorReference2.setValue(structureChildVariable2.getValue());
    } else if (structureChildVariable2.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference2.replaceChildren(structureChildVariable2.getAllChildren());
    } else if (structureChildVariable2.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference2.replaceChildrenArray(structureChildVariable2.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(gdjs.resourcesCode.GDrdObjects1, gdjs.resourcesCode.GDrdObjects2);

gdjs.copyArray(gdjs.resourcesCode.GDresourceNameObjects1, gdjs.resourcesCode.GDresourceNameObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDresourceNameObjects2Objects, 0, gdjs.resourcesCode.localVariables[0].getFromIndex(0).getAsNumber() * 32, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects2Objects, 400, gdjs.resourcesCode.localVariables[0].getFromIndex(0).getAsNumber() * 32, "");
}{for(var i = 0, len = gdjs.resourcesCode.GDresourceNameObjects2.length ;i < len;++i) {
    gdjs.resourcesCode.GDresourceNameObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}{for(var i = 0, len = gdjs.resourcesCode.GDresourceNameObjects2.length ;i < len;++i) {
    gdjs.resourcesCode.GDresourceNameObjects2[i].returnVariable(gdjs.resourcesCode.GDresourceNameObjects2[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}{for(var i = 0, len = gdjs.resourcesCode.GDrdObjects2.length ;i < len;++i) {
    gdjs.resourcesCode.GDrdObjects2[i].returnVariable(gdjs.resourcesCode.GDrdObjects2[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}{gdjs.resourcesCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("list").getChild(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString()).getAsString(), gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects2Objects, false, 64, 64, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.resourcesCode.GDrdObjects2.length ;i < len;++i) {
    gdjs.resourcesCode.GDrdObjects2[i].getBehavior("Resizable").setSize(32, 32);
}
}}
}
}

}


};gdjs.resourcesCode.eventsList5 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.resourcesCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("rd"), gdjs.resourcesCode.GDrdObjects1);
/* Reuse gdjs.resourcesCode.GDresourceNameObjects1 */
{for(var i = 0, len = gdjs.resourcesCode.GDresourceNameObjects1.length ;i < len;++i) {
    gdjs.resourcesCode.GDresourceNameObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.resourcesCode.GDrdObjects1.length ;i < len;++i) {
    gdjs.resourcesCode.GDrdObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.resourcesCode.eventsList4(runtimeScene);} //End of subevents
}
gdjs.resourcesCode.localVariables.pop();

}


};gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects1Objects = Hashtable.newFrom({"rd": gdjs.resourcesCode.GDrdObjects1});
gdjs.resourcesCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(4).getAsString()) > 2);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.resourcesCode.eventsList7 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climb", variable);
}
gdjs.resourcesCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = ((runtimeScene.getScene().getVariables().getFromIndex(3).getAsString()).includes("data"));
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = runtimeScene.getOnceTriggers().triggerOnce(24429588);
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("rd"), gdjs.resourcesCode.GDrdObjects1);
gdjs.copyArray(runtimeScene.getObjects("resourceName"), gdjs.resourcesCode.GDresourceNameObjects1);
{for(var i = 0, len = gdjs.resourcesCode.GDresourceNameObjects1.length ;i < len;++i) {
    gdjs.resourcesCode.GDresourceNameObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.resourcesCode.GDrdObjects1.length ;i < len;++i) {
    gdjs.resourcesCode.GDrdObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.resourcesCode.eventsList1(runtimeScene);} //End of subevents
}
gdjs.resourcesCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.resourcesCode.GDbuttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("nameInput"), gdjs.resourcesCode.GDnameInputObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDbuttonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.resourcesCode.GDnameInputObjects1.length === 0 ) ? "" :gdjs.resourcesCode.GDnameInputObjects1[0].getBehavior("Text").getText())) > 0);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.resourcesCode.GDnameInputObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(4).setString((( gdjs.resourcesCode.GDnameInputObjects1.length === 0 ) ? "" :gdjs.resourcesCode.GDnameInputObjects1[0].getBehavior("Text").getText()));
}{runtimeScene.getScene().getVariables().getFromIndex(3).setString("");
}
{ //Subevents
gdjs.resourcesCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("resourceName"), gdjs.resourcesCode.GDresourceNameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDresourceNameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
}
if (isConditionTrue_0) {
/* Reuse gdjs.resourcesCode.GDresourceNameObjects1 */
{gdjs.evtTools.variable.variableRemoveChild(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("list"), ((gdjs.resourcesCode.GDresourceNameObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.resourcesCode.GDresourceNameObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
{ //Subevents
gdjs.resourcesCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("rd"), gdjs.resourcesCode.GDrdObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.resourcesCode.mapOfGDgdjs_9546resourcesCode_9546GDrdObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.resourcesCode.GDrdObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(4).setString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("list").getChild(((gdjs.resourcesCode.GDrdObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.resourcesCode.GDrdObjects1[0].getVariables()).getFromIndex(0).getAsString()).getAsString());
}
{ //Subevents
gdjs.resourcesCode.eventsList6(runtimeScene);} //End of subevents
}

}


};

gdjs.resourcesCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.resourcesCode.GDresourceNameObjects1.length = 0;
gdjs.resourcesCode.GDresourceNameObjects2.length = 0;
gdjs.resourcesCode.GDrdObjects1.length = 0;
gdjs.resourcesCode.GDrdObjects2.length = 0;
gdjs.resourcesCode.GDnameInputObjects1.length = 0;
gdjs.resourcesCode.GDnameInputObjects2.length = 0;
gdjs.resourcesCode.GDbuttonObjects1.length = 0;
gdjs.resourcesCode.GDbuttonObjects2.length = 0;
gdjs.resourcesCode.GDaddObjects1.length = 0;
gdjs.resourcesCode.GDaddObjects2.length = 0;

gdjs.resourcesCode.eventsList7(runtimeScene);
gdjs.resourcesCode.GDresourceNameObjects1.length = 0;
gdjs.resourcesCode.GDresourceNameObjects2.length = 0;
gdjs.resourcesCode.GDrdObjects1.length = 0;
gdjs.resourcesCode.GDrdObjects2.length = 0;
gdjs.resourcesCode.GDnameInputObjects1.length = 0;
gdjs.resourcesCode.GDnameInputObjects2.length = 0;
gdjs.resourcesCode.GDbuttonObjects1.length = 0;
gdjs.resourcesCode.GDbuttonObjects2.length = 0;
gdjs.resourcesCode.GDaddObjects1.length = 0;
gdjs.resourcesCode.GDaddObjects2.length = 0;


return;

}

gdjs['resourcesCode'] = gdjs.resourcesCode;
