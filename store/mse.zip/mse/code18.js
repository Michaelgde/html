gdjs.pluginSceneCode = {};
gdjs.pluginSceneCode.localVariables = [];
gdjs.pluginSceneCode.GDnameObjects1= [];
gdjs.pluginSceneCode.GDnameObjects2= [];
gdjs.pluginSceneCode.GDNewSpriteObjects1= [];
gdjs.pluginSceneCode.GDNewSpriteObjects2= [];
gdjs.pluginSceneCode.GDdiscordObjects1= [];
gdjs.pluginSceneCode.GDdiscordObjects2= [];
gdjs.pluginSceneCode.GDnewsObjects1= [];
gdjs.pluginSceneCode.GDnewsObjects2= [];
gdjs.pluginSceneCode.GDDiscordObjects1= [];
gdjs.pluginSceneCode.GDDiscordObjects2= [];
gdjs.pluginSceneCode.GDbackObjects1= [];
gdjs.pluginSceneCode.GDbackObjects2= [];


gdjs.pluginSceneCode.mapOfGDgdjs_9546pluginSceneCode_9546GDbackObjects1Objects = Hashtable.newFrom({"back": gdjs.pluginSceneCode.GDbackObjects1});
gdjs.pluginSceneCode.mapOfGDgdjs_9546pluginSceneCode_9546GDDiscordObjects1Objects = Hashtable.newFrom({"Discord": gdjs.pluginSceneCode.GDDiscordObjects1});
gdjs.pluginSceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(6).getAsString()) > 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("news"), gdjs.pluginSceneCode.GDnewsObjects1);
{for(var i = 0, len = gdjs.pluginSceneCode.GDnewsObjects1.length ;i < len;++i) {
    gdjs.pluginSceneCode.GDnewsObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(6).getAsString()) < 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("news"), gdjs.pluginSceneCode.GDnewsObjects1);
{for(var i = 0, len = gdjs.pluginSceneCode.GDnewsObjects1.length ;i < len;++i) {
    gdjs.pluginSceneCode.GDnewsObjects1[i].getBehavior("Text").setText("no news yet 🔍\n\nmight be a network or server err or maybe no news");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.pluginSceneCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginSceneCode.mapOfGDgdjs_9546pluginSceneCode_9546GDbackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Discord"), gdjs.pluginSceneCode.GDDiscordObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginSceneCode.mapOfGDgdjs_9546pluginSceneCode_9546GDDiscordObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://michaelgde.github.io/info/", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("discord"), gdjs.pluginSceneCode.GDdiscordObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.pluginSceneCode.GDdiscordObjects1.length;i<l;++i) {
    if ( gdjs.pluginSceneCode.GDdiscordObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.pluginSceneCode.GDdiscordObjects1[k] = gdjs.pluginSceneCode.GDdiscordObjects1[i];
        ++k;
    }
}
gdjs.pluginSceneCode.GDdiscordObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://michaelgde.github.io/info/", runtimeScene);
}}

}


};

gdjs.pluginSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.pluginSceneCode.GDnameObjects1.length = 0;
gdjs.pluginSceneCode.GDnameObjects2.length = 0;
gdjs.pluginSceneCode.GDNewSpriteObjects1.length = 0;
gdjs.pluginSceneCode.GDNewSpriteObjects2.length = 0;
gdjs.pluginSceneCode.GDdiscordObjects1.length = 0;
gdjs.pluginSceneCode.GDdiscordObjects2.length = 0;
gdjs.pluginSceneCode.GDnewsObjects1.length = 0;
gdjs.pluginSceneCode.GDnewsObjects2.length = 0;
gdjs.pluginSceneCode.GDDiscordObjects1.length = 0;
gdjs.pluginSceneCode.GDDiscordObjects2.length = 0;
gdjs.pluginSceneCode.GDbackObjects1.length = 0;
gdjs.pluginSceneCode.GDbackObjects2.length = 0;

gdjs.pluginSceneCode.eventsList0(runtimeScene);
gdjs.pluginSceneCode.GDnameObjects1.length = 0;
gdjs.pluginSceneCode.GDnameObjects2.length = 0;
gdjs.pluginSceneCode.GDNewSpriteObjects1.length = 0;
gdjs.pluginSceneCode.GDNewSpriteObjects2.length = 0;
gdjs.pluginSceneCode.GDdiscordObjects1.length = 0;
gdjs.pluginSceneCode.GDdiscordObjects2.length = 0;
gdjs.pluginSceneCode.GDnewsObjects1.length = 0;
gdjs.pluginSceneCode.GDnewsObjects2.length = 0;
gdjs.pluginSceneCode.GDDiscordObjects1.length = 0;
gdjs.pluginSceneCode.GDDiscordObjects2.length = 0;
gdjs.pluginSceneCode.GDbackObjects1.length = 0;
gdjs.pluginSceneCode.GDbackObjects2.length = 0;


return;

}

gdjs['pluginSceneCode'] = gdjs.pluginSceneCode;
