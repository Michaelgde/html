gdjs.project_95manager_95htmlCode = {};
gdjs.project_95manager_95htmlCode.localVariables = [];
gdjs.project_95manager_95htmlCode.GDnameObjects1= [];
gdjs.project_95manager_95htmlCode.GDnameObjects2= [];
gdjs.project_95manager_95htmlCode.GDnameObjects3= [];
gdjs.project_95manager_95htmlCode.GDnameObjects4= [];
gdjs.project_95manager_95htmlCode.GDinfoObjects1= [];
gdjs.project_95manager_95htmlCode.GDinfoObjects2= [];
gdjs.project_95manager_95htmlCode.GDinfoObjects3= [];
gdjs.project_95manager_95htmlCode.GDinfoObjects4= [];
gdjs.project_95manager_95htmlCode.GDaddObjects1= [];
gdjs.project_95manager_95htmlCode.GDaddObjects2= [];
gdjs.project_95manager_95htmlCode.GDaddObjects3= [];
gdjs.project_95manager_95htmlCode.GDaddObjects4= [];
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects1= [];
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects2= [];
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects3= [];
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects4= [];
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects1= [];
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects2= [];
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects3= [];
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects4= [];
gdjs.project_95manager_95htmlCode.GDname2Objects1= [];
gdjs.project_95manager_95htmlCode.GDname2Objects2= [];
gdjs.project_95manager_95htmlCode.GDname2Objects3= [];
gdjs.project_95manager_95htmlCode.GDname2Objects4= [];
gdjs.project_95manager_95htmlCode.GDioiObjects1= [];
gdjs.project_95manager_95htmlCode.GDioiObjects2= [];
gdjs.project_95manager_95htmlCode.GDioiObjects3= [];
gdjs.project_95manager_95htmlCode.GDioiObjects4= [];
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects1= [];
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects2= [];
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects3= [];
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects4= [];
gdjs.project_95manager_95htmlCode.GDokObjects1= [];
gdjs.project_95manager_95htmlCode.GDokObjects2= [];
gdjs.project_95manager_95htmlCode.GDokObjects3= [];
gdjs.project_95manager_95htmlCode.GDokObjects4= [];
gdjs.project_95manager_95htmlCode.GDcancObjects1= [];
gdjs.project_95manager_95htmlCode.GDcancObjects2= [];
gdjs.project_95manager_95htmlCode.GDcancObjects3= [];
gdjs.project_95manager_95htmlCode.GDcancObjects4= [];
gdjs.project_95manager_95htmlCode.GDpaintObjects1= [];
gdjs.project_95manager_95htmlCode.GDpaintObjects2= [];
gdjs.project_95manager_95htmlCode.GDpaintObjects3= [];
gdjs.project_95manager_95htmlCode.GDpaintObjects4= [];
gdjs.project_95manager_95htmlCode.GDname3Objects1= [];
gdjs.project_95manager_95htmlCode.GDname3Objects2= [];
gdjs.project_95manager_95htmlCode.GDname3Objects3= [];
gdjs.project_95manager_95htmlCode.GDname3Objects4= [];
gdjs.project_95manager_95htmlCode.GDpanelObjects1= [];
gdjs.project_95manager_95htmlCode.GDpanelObjects2= [];
gdjs.project_95manager_95htmlCode.GDpanelObjects3= [];
gdjs.project_95manager_95htmlCode.GDpanelObjects4= [];
gdjs.project_95manager_95htmlCode.GDsprrObjects1= [];
gdjs.project_95manager_95htmlCode.GDsprrObjects2= [];
gdjs.project_95manager_95htmlCode.GDsprrObjects3= [];
gdjs.project_95manager_95htmlCode.GDsprrObjects4= [];
gdjs.project_95manager_95htmlCode.GDpanel2Objects1= [];
gdjs.project_95manager_95htmlCode.GDpanel2Objects2= [];
gdjs.project_95manager_95htmlCode.GDpanel2Objects3= [];
gdjs.project_95manager_95htmlCode.GDpanel2Objects4= [];
gdjs.project_95manager_95htmlCode.GDfkObjects1= [];
gdjs.project_95manager_95htmlCode.GDfkObjects2= [];
gdjs.project_95manager_95htmlCode.GDfkObjects3= [];
gdjs.project_95manager_95htmlCode.GDfkObjects4= [];
gdjs.project_95manager_95htmlCode.GDjjObjects1= [];
gdjs.project_95manager_95htmlCode.GDjjObjects2= [];
gdjs.project_95manager_95htmlCode.GDjjObjects3= [];
gdjs.project_95manager_95htmlCode.GDjjObjects4= [];
gdjs.project_95manager_95htmlCode.GDlogoObjects1= [];
gdjs.project_95manager_95htmlCode.GDlogoObjects2= [];
gdjs.project_95manager_95htmlCode.GDlogoObjects3= [];
gdjs.project_95manager_95htmlCode.GDlogoObjects4= [];
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1= [];
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2= [];
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects3= [];
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects4= [];
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1= [];
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects2= [];
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects3= [];
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects4= [];
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects1= [];
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects2= [];
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects3= [];
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects4= [];
gdjs.project_95manager_95htmlCode.GDNewTextObjects1= [];
gdjs.project_95manager_95htmlCode.GDNewTextObjects2= [];
gdjs.project_95manager_95htmlCode.GDNewTextObjects3= [];
gdjs.project_95manager_95htmlCode.GDNewTextObjects4= [];
gdjs.project_95manager_95htmlCode.GDloadingObjects1= [];
gdjs.project_95manager_95htmlCode.GDloadingObjects2= [];
gdjs.project_95manager_95htmlCode.GDloadingObjects3= [];
gdjs.project_95manager_95htmlCode.GDloadingObjects4= [];
gdjs.project_95manager_95htmlCode.GDNewText2Objects1= [];
gdjs.project_95manager_95htmlCode.GDNewText2Objects2= [];
gdjs.project_95manager_95htmlCode.GDNewText2Objects3= [];
gdjs.project_95manager_95htmlCode.GDNewText2Objects4= [];
gdjs.project_95manager_95htmlCode.GDdebugObjects1= [];
gdjs.project_95manager_95htmlCode.GDdebugObjects2= [];
gdjs.project_95manager_95htmlCode.GDdebugObjects3= [];
gdjs.project_95manager_95htmlCode.GDdebugObjects4= [];
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects1= [];
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects2= [];
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects3= [];
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects4= [];
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects1= [];
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects2= [];
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects3= [];
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects4= [];
gdjs.project_95manager_95htmlCode.GDfppObjects1= [];
gdjs.project_95manager_95htmlCode.GDfppObjects2= [];
gdjs.project_95manager_95htmlCode.GDfppObjects3= [];
gdjs.project_95manager_95htmlCode.GDfppObjects4= [];
gdjs.project_95manager_95htmlCode.GDfpp2Objects1= [];
gdjs.project_95manager_95htmlCode.GDfpp2Objects2= [];
gdjs.project_95manager_95htmlCode.GDfpp2Objects3= [];
gdjs.project_95manager_95htmlCode.GDfpp2Objects4= [];
gdjs.project_95manager_95htmlCode.GDfpp3Objects1= [];
gdjs.project_95manager_95htmlCode.GDfpp3Objects2= [];
gdjs.project_95manager_95htmlCode.GDfpp3Objects3= [];
gdjs.project_95manager_95htmlCode.GDfpp3Objects4= [];
gdjs.project_95manager_95htmlCode.GDexportObjects1= [];
gdjs.project_95manager_95htmlCode.GDexportObjects2= [];
gdjs.project_95manager_95htmlCode.GDexportObjects3= [];
gdjs.project_95manager_95htmlCode.GDexportObjects4= [];
gdjs.project_95manager_95htmlCode.GDimportObjects1= [];
gdjs.project_95manager_95htmlCode.GDimportObjects2= [];
gdjs.project_95manager_95htmlCode.GDimportObjects3= [];
gdjs.project_95manager_95htmlCode.GDimportObjects4= [];
gdjs.project_95manager_95htmlCode.GDadd2Objects1= [];
gdjs.project_95manager_95htmlCode.GDadd2Objects2= [];
gdjs.project_95manager_95htmlCode.GDadd2Objects3= [];
gdjs.project_95manager_95htmlCode.GDadd2Objects4= [];
gdjs.project_95manager_95htmlCode.GDgearObjects1= [];
gdjs.project_95manager_95htmlCode.GDgearObjects2= [];
gdjs.project_95manager_95htmlCode.GDgearObjects3= [];
gdjs.project_95manager_95htmlCode.GDgearObjects4= [];
gdjs.project_95manager_95htmlCode.GDNbellObjects1= [];
gdjs.project_95manager_95htmlCode.GDNbellObjects2= [];
gdjs.project_95manager_95htmlCode.GDNbellObjects3= [];
gdjs.project_95manager_95htmlCode.GDNbellObjects4= [];


gdjs.project_95manager_95htmlCode.userFunc0xdc87c8 = function GDJSInlineCode(runtimeScene) {
"use strict";
const url = "https://raw.githubusercontent.com/Michaelgde/info/main/mse/info";


fetch(url)
  .then(response => {
    if (!response.ok) {
      throw new Error("Network response was not ok " + response.statusText);
    }
    return response.text();
  })
  .then(text => {
    console.log("File content:", text);

    // You can store the text in a GDevelop variable, or process it further
    var data = runtimeScene.getGame().getVariables().get("notification").setString(text)
    
  })
  .catch(error => {
    console.error("There was a problem with the fetch operation:", error);
  });


};
gdjs.project_95manager_95htmlCode.eventsList0 = function(runtimeScene) {

{


gdjs.project_95manager_95htmlCode.userFunc0xdc87c8(runtimeScene);

}


};gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDNbellObjects1Objects = Hashtable.newFrom({"Nbell": gdjs.project_95manager_95htmlCode.GDNbellObjects1});
gdjs.project_95manager_95htmlCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("MSEnotify", "MSEnotify");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MSEnotify", "MSEnotify", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(6));
}{gdjs.evtTools.storage.readStringFromJSONFile("MSEnotify", "MSEnotify", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(7));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23458764);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(6).getAsString()) > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23445332);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("MSEnotify", "MSEnotify", runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(7).getAsString() != runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nbell"), gdjs.project_95manager_95htmlCode.GDNbellObjects2);
{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDNbellObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDNbellObjects2[i].getBehavior("Animation").setAnimationName("yes");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(7).getAsString() == runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nbell"), gdjs.project_95manager_95htmlCode.GDNbellObjects2);
{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDNbellObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDNbellObjects2[i].getBehavior("Animation").setAnimationName("no");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Nbell"), gdjs.project_95manager_95htmlCode.GDNbellObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDNbellObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "pluginScene");
}}

}


};gdjs.project_95manager_95htmlCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.hideLayer(runtimeScene, "loader");
}}

}


};gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDaddObjects1Objects = Hashtable.newFrom({"add": gdjs.project_95manager_95htmlCode.GDaddObjects1});
gdjs.project_95manager_95htmlCode.mapOfEmptyGDproject_9595selectObjects = Hashtable.newFrom({"project_select": []});
gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDproject_95959595selectObjects2Objects = Hashtable.newFrom({"project_select": gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2});
gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDexportObjects2Objects = Hashtable.newFrom({"export": gdjs.project_95manager_95htmlCode.GDexportObjects2});
gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDproject_95959595namesObjects2Objects = Hashtable.newFrom({"project_names": gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects2});
gdjs.project_95manager_95htmlCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95htmlCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.project_95manager_95htmlCode.GDexportObjects1, gdjs.project_95manager_95htmlCode.GDexportObjects2);

gdjs.copyArray(gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects1, gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects2);

gdjs.copyArray(gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1, gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDproject_95959595selectObjects2Objects, 10, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDexportObjects2Objects, 412, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDproject_95959595namesObjects2Objects, 25, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 5, "");
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects2[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("name").getAsString());
}
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2[i].returnVariable(gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDexportObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDexportObjects2[i].returnVariable(gdjs.project_95manager_95htmlCode.GDexportObjects2[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(64);
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2[i].getBehavior("Resizable").setWidth(400);
}
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDexportObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDexportObjects2[i].getBehavior("Resizable").setWidth(45);
}
}
{ //Subevents: 
gdjs.project_95manager_95htmlCode.eventsList3(runtimeScene);} //Subevents end.
}
}

}


};gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDproject_95959595selectObjects1Objects = Hashtable.newFrom({"project_select": gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1});
gdjs.project_95manager_95htmlCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "audio_manager_win", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95htmlCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("audio").getAsString()) < 7);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "loader");
}
{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(1);
}}

}


};gdjs.project_95manager_95htmlCode.userFunc0xdccf68 = function GDJSInlineCode(runtimeScene) {
"use strict";
const audio = new Audio();
audio.src = runtimeScene.getGame().getVariables().get("data").getChildNamed("audio").getAsString()
audio.addEventListener('loadedmetadata', () => {
    console.log(`Duration: ${audio.duration} seconds`);
    runtimeScene.getGame().getVariables().get("audio_len").setNumber(audio.duration)
    runtimeScene.getVariables().get("change").setNumber(3)
});





};
gdjs.project_95manager_95htmlCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23469996);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 1, 0);
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio.ogg", 1, false, 0, 1000);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{



}


{



}


{


gdjs.project_95manager_95htmlCode.userFunc0xdccf68(runtimeScene);

}


};gdjs.project_95manager_95htmlCode.userFunc0xd69080 = function GDJSInlineCode(runtimeScene) {
"use strict";
if(runtimeScene.getSoundManager()._resourceLoader.getResource("audio.ogg").file = runtimeScene.getGame().getVariables().get("data").getChildNamed("audio").getAsString()){
    runtimeScene.getVariables().get("change").setNumber(1)

}

};
gdjs.project_95manager_95htmlCode.eventsList8 = function(runtimeScene) {

{


gdjs.project_95manager_95htmlCode.userFunc0xd69080(runtimeScene);

}


};gdjs.project_95manager_95htmlCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() == 3);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "loader");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mse_win", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() == 1);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber() == 0);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDproject_95959595selectObjects1Objects = Hashtable.newFrom({"project_select": gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1});
gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDexportObjects1Objects = Hashtable.newFrom({"export": gdjs.project_95manager_95htmlCode.GDexportObjects1});
gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDimportObjects1Objects = Hashtable.newFrom({"import": gdjs.project_95manager_95htmlCode.GDimportObjects1});
gdjs.project_95manager_95htmlCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(19).setString("");
}}

}


};gdjs.project_95manager_95htmlCode.eventsList11 = function(runtimeScene) {

{



}


{



}


{



}


{


gdjs.project_95manager_95htmlCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MSE(STATE)", "MSE(STATE)", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(18));
}{gdjs.evtTools.camera.showLayer(runtimeScene, "loader");
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(18).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(1));
}{runtimeScene.getGame().getVariables().getFromIndex(14).setBoolean(false);
}
{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.project_95manager_95htmlCode.GDaddObjects1);
gdjs.copyArray(runtimeScene.getObjects("project_namer"), gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("arrayy", variable);
}
gdjs.project_95manager_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDaddObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1.length;i<l;++i) {
    if ( gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1[i].getBehavior("Text").getText() != "" ) {
        isConditionTrue_0 = true;
        gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1[k] = gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1[i];
        ++k;
    }
}
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !((gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8))).includes((( gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1.length === 0 ) ? "" :gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1[0].getText())));
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1 */
{gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1)));
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(1), runtimeScene.getGame().getVariables().getFromIndex(13));
}{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("name").setString((( gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1.length === 0 ) ? "" :gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1[0].getText()));
}}
gdjs.project_95manager_95htmlCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1)) != gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95htmlCode.mapOfEmptyGDproject_9595selectObjects));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("export"), gdjs.project_95manager_95htmlCode.GDexportObjects1);
gdjs.copyArray(runtimeScene.getObjects("path_display"), gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects1);
gdjs.copyArray(runtimeScene.getObjects("project_names"), gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects1);
gdjs.copyArray(runtimeScene.getObjects("project_select"), gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(64);
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDexportObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDexportObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("project_select"), gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("ids", variable);
}
gdjs.project_95manager_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDproject_95959595selectObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(14).setBoolean(false);
}{gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).setNumber(((gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1[0].getVariables()).getFromIndex(0).getAsNumber());
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber());
}{runtimeScene.getScene().getVariables().getFromIndex(12).setString(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("name").getAsString());
}{gdjs.evtTools.camera.showLayer(runtimeScene, "loader");
}{runtimeScene.getGame().getVariables().getFromIndex(11).setString(runtimeScene.getScene().getVariables().getFromIndex(12).getAsString());
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("json").getAsString(), runtimeScene.getGame().getVariables().getFromIndex(3));
}
{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList6(runtimeScene);} //End of subevents
}
gdjs.project_95manager_95htmlCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("audio").getAsString()) > 7);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "loader");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber() == 1);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.deleteElementFromJSONFile("MSE(V)", "MSE(V)");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("project_select"), gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.project_95manager_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDproject_95959595selectObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1 */
{gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).setNumber(((gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1[0].getVariables()).getFromIndex(0).getAsNumber());
}{gdjs.evtTools.variable.variableRemoveAt(runtimeScene.getGame().getVariables().getFromIndex(1), gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber());
}}
gdjs.project_95manager_95htmlCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("export"), gdjs.project_95manager_95htmlCode.GDexportObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.project_95manager_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDexportObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95htmlCode.GDexportObjects1 */
{gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).setNumber(((gdjs.project_95manager_95htmlCode.GDexportObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.project_95manager_95htmlCode.GDexportObjects1[0].getVariables()).getFromIndex(0).getAsNumber());
}{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber()).getChild("name").getAsString() + ".json", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber())), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}
gdjs.project_95manager_95htmlCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("import"), gdjs.project_95manager_95htmlCode.GDimportObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95htmlCode.mapOfGDgdjs_9546project_959595manager_959595htmlCode_9546GDimportObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtsExt__UploadDownloadTextFile__UploadTextFile.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(19), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("index", variable);
}
gdjs.project_95manager_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(19).getAsString()) > 10);
}
if (isConditionTrue_0) {
{gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(1)));
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(1), runtimeScene.getGame().getVariables().getFromIndex(13));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(19).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(1).getChild(gdjs.project_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber()));
}
{ //Subevents
gdjs.project_95manager_95htmlCode.eventsList10(runtimeScene);} //End of subevents
}
gdjs.project_95manager_95htmlCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.project_95manager_95htmlCode.GDgearObjects1);
{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDgearObjects1[i].SetMaxValue(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 320, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.project_95manager_95htmlCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95htmlCode.GDgearObjects1[i].SetStepSize(0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.project_95manager_95htmlCode.GDgearObjects1);
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.project_95manager_95htmlCode.GDgearObjects1.length === 0 ) ? 0 :gdjs.project_95manager_95htmlCode.GDgearObjects1[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) + 360, "", 0);
}}

}


};

gdjs.project_95manager_95htmlCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.project_95manager_95htmlCode.GDnameObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDnameObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDnameObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDnameObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDinfoObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDinfoObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDinfoObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDinfoObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDaddObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDaddObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDaddObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDaddObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDname2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDname2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDname2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDname2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDioiObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDioiObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDioiObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDioiObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDokObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDokObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDokObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDokObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDcancObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDcancObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDcancObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDcancObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDpaintObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDpaintObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDpaintObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDpaintObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDname3Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDname3Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDname3Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDname3Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDpanelObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDpanelObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDpanelObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDpanelObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDsprrObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDsprrObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDsprrObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDsprrObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDpanel2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDpanel2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDpanel2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDpanel2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDfkObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDfkObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDfkObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDfkObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDjjObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDjjObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDjjObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDjjObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDlogoObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDlogoObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDlogoObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDlogoObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDNewTextObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDNewTextObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDNewTextObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDNewTextObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDloadingObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDloadingObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDloadingObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDloadingObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDNewText2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDNewText2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDNewText2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDNewText2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDdebugObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDdebugObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDdebugObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDdebugObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDfppObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDfppObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDfppObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDfppObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp3Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp3Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp3Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp3Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDexportObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDexportObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDexportObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDexportObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDimportObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDimportObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDimportObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDimportObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDadd2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDadd2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDadd2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDadd2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDgearObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDgearObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDgearObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDgearObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDNbellObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDNbellObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDNbellObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDNbellObjects4.length = 0;

gdjs.project_95manager_95htmlCode.eventsList11(runtimeScene);
gdjs.project_95manager_95htmlCode.GDnameObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDnameObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDnameObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDnameObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDinfoObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDinfoObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDinfoObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDinfoObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDaddObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDaddObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDaddObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDaddObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595txtObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDsave_9595iconObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDname2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDname2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDname2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDname2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDioiObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDioiObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDioiObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDioiObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDadd_9595eveObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDokObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDokObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDokObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDokObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDcancObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDcancObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDcancObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDcancObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDpaintObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDpaintObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDpaintObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDpaintObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDname3Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDname3Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDname3Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDname3Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDpanelObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDpanelObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDpanelObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDpanelObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDsprrObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDsprrObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDsprrObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDsprrObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDpanel2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDpanel2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDpanel2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDpanel2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDfkObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDfkObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDfkObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDfkObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDjjObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDjjObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDjjObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDjjObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDlogoObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDlogoObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDlogoObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDlogoObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595selectObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namerObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDproject_9595namesObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDNewTextObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDNewTextObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDNewTextObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDNewTextObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDloadingObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDloadingObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDloadingObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDloadingObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDNewText2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDNewText2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDNewText2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDNewText2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDdebugObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDdebugObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDdebugObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDdebugObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDpath_9595displayObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDNewSpriteObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDfppObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDfppObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDfppObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDfppObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp3Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp3Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp3Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDfpp3Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDexportObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDexportObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDexportObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDexportObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDimportObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDimportObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDimportObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDimportObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDadd2Objects1.length = 0;
gdjs.project_95manager_95htmlCode.GDadd2Objects2.length = 0;
gdjs.project_95manager_95htmlCode.GDadd2Objects3.length = 0;
gdjs.project_95manager_95htmlCode.GDadd2Objects4.length = 0;
gdjs.project_95manager_95htmlCode.GDgearObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDgearObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDgearObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDgearObjects4.length = 0;
gdjs.project_95manager_95htmlCode.GDNbellObjects1.length = 0;
gdjs.project_95manager_95htmlCode.GDNbellObjects2.length = 0;
gdjs.project_95manager_95htmlCode.GDNbellObjects3.length = 0;
gdjs.project_95manager_95htmlCode.GDNbellObjects4.length = 0;


return;

}

gdjs['project_95manager_95htmlCode'] = gdjs.project_95manager_95htmlCode;
