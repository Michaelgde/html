gdjs.bassCode = {};
gdjs.bassCode.localVariables = [];
gdjs.bassCode.GDbar1Objects1= [];
gdjs.bassCode.GDbar1Objects2= [];
gdjs.bassCode.GDbar2Objects1= [];
gdjs.bassCode.GDbar2Objects2= [];
gdjs.bassCode.GDinfoObjects1= [];
gdjs.bassCode.GDinfoObjects2= [];
gdjs.bassCode.GDYoutubeObjects1= [];
gdjs.bassCode.GDYoutubeObjects2= [];
gdjs.bassCode.GDinfo2Objects1= [];
gdjs.bassCode.GDinfo2Objects2= [];
gdjs.bassCode.GDblancoObjects1= [];
gdjs.bassCode.GDblancoObjects2= [];
gdjs.bassCode.GDNew3DModelObjects1= [];
gdjs.bassCode.GDNew3DModelObjects2= [];
gdjs.bassCode.GDbar3Objects1= [];
gdjs.bassCode.GDbar3Objects2= [];
gdjs.bassCode.GDbar4Objects1= [];
gdjs.bassCode.GDbar4Objects2= [];
gdjs.bassCode.GDbar5Objects1= [];
gdjs.bassCode.GDbar5Objects2= [];
gdjs.bassCode.GDbar6Objects1= [];
gdjs.bassCode.GDbar6Objects2= [];
gdjs.bassCode.GDbar7Objects1= [];
gdjs.bassCode.GDbar7Objects2= [];
gdjs.bassCode.GDbar8Objects1= [];
gdjs.bassCode.GDbar8Objects2= [];
gdjs.bassCode.GDbar9Objects1= [];
gdjs.bassCode.GDbar9Objects2= [];
gdjs.bassCode.GDbar10Objects1= [];
gdjs.bassCode.GDbar10Objects2= [];
gdjs.bassCode.GDdebugObjects1= [];
gdjs.bassCode.GDdebugObjects2= [];
gdjs.bassCode.GDtiiObjects1= [];
gdjs.bassCode.GDtiiObjects2= [];
gdjs.bassCode.GDinfo3Objects1= [];
gdjs.bassCode.GDinfo3Objects2= [];
gdjs.bassCode.GDiiiiObjects1= [];
gdjs.bassCode.GDiiiiObjects2= [];
gdjs.bassCode.GDNewPanelSpriteObjects1= [];
gdjs.bassCode.GDNewPanelSpriteObjects2= [];


gdjs.bassCode.userFunc0x1165240 = function GDJSInlineCode(runtimeScene) {
"use strict";
const ausio = new Audio('audio.ogg')
function playAudio(){ ausio.play()}
function stopAudio(){
    if(runtimeScene.getVariables().get('state').getAsString() === 's'){
        ausio.pause()
    }
    if(runtimeScene.getVariables().get('state').getAsString() === 'p'){
        ausio.play()
        runtimeScene.getVariables().get('state').setString('')
    }
    requestAnimationFrame(stopAudio)
}
playAudio()
stopAudio()
};
gdjs.bassCode.eventsList0 = function(runtimeScene) {

{



}


{



}


{


gdjs.bassCode.userFunc0x1165240(runtimeScene);

}


};gdjs.bassCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.bassCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.bassCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("p");
}
{ //Subevents
gdjs.bassCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("s");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("bar1"), gdjs.bassCode.GDbar1Objects1);
{for(var i = 0, len = gdjs.bassCode.GDbar1Objects1.length ;i < len;++i) {
    gdjs.bassCode.GDbar1Objects1[i].getBehavior("Resizable").setHeight(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() / 2);
}
}}

}


};

gdjs.bassCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.bassCode.GDbar1Objects1.length = 0;
gdjs.bassCode.GDbar1Objects2.length = 0;
gdjs.bassCode.GDbar2Objects1.length = 0;
gdjs.bassCode.GDbar2Objects2.length = 0;
gdjs.bassCode.GDinfoObjects1.length = 0;
gdjs.bassCode.GDinfoObjects2.length = 0;
gdjs.bassCode.GDYoutubeObjects1.length = 0;
gdjs.bassCode.GDYoutubeObjects2.length = 0;
gdjs.bassCode.GDinfo2Objects1.length = 0;
gdjs.bassCode.GDinfo2Objects2.length = 0;
gdjs.bassCode.GDblancoObjects1.length = 0;
gdjs.bassCode.GDblancoObjects2.length = 0;
gdjs.bassCode.GDNew3DModelObjects1.length = 0;
gdjs.bassCode.GDNew3DModelObjects2.length = 0;
gdjs.bassCode.GDbar3Objects1.length = 0;
gdjs.bassCode.GDbar3Objects2.length = 0;
gdjs.bassCode.GDbar4Objects1.length = 0;
gdjs.bassCode.GDbar4Objects2.length = 0;
gdjs.bassCode.GDbar5Objects1.length = 0;
gdjs.bassCode.GDbar5Objects2.length = 0;
gdjs.bassCode.GDbar6Objects1.length = 0;
gdjs.bassCode.GDbar6Objects2.length = 0;
gdjs.bassCode.GDbar7Objects1.length = 0;
gdjs.bassCode.GDbar7Objects2.length = 0;
gdjs.bassCode.GDbar8Objects1.length = 0;
gdjs.bassCode.GDbar8Objects2.length = 0;
gdjs.bassCode.GDbar9Objects1.length = 0;
gdjs.bassCode.GDbar9Objects2.length = 0;
gdjs.bassCode.GDbar10Objects1.length = 0;
gdjs.bassCode.GDbar10Objects2.length = 0;
gdjs.bassCode.GDdebugObjects1.length = 0;
gdjs.bassCode.GDdebugObjects2.length = 0;
gdjs.bassCode.GDtiiObjects1.length = 0;
gdjs.bassCode.GDtiiObjects2.length = 0;
gdjs.bassCode.GDinfo3Objects1.length = 0;
gdjs.bassCode.GDinfo3Objects2.length = 0;
gdjs.bassCode.GDiiiiObjects1.length = 0;
gdjs.bassCode.GDiiiiObjects2.length = 0;
gdjs.bassCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.bassCode.GDNewPanelSpriteObjects2.length = 0;

gdjs.bassCode.eventsList2(runtimeScene);
gdjs.bassCode.GDbar1Objects1.length = 0;
gdjs.bassCode.GDbar1Objects2.length = 0;
gdjs.bassCode.GDbar2Objects1.length = 0;
gdjs.bassCode.GDbar2Objects2.length = 0;
gdjs.bassCode.GDinfoObjects1.length = 0;
gdjs.bassCode.GDinfoObjects2.length = 0;
gdjs.bassCode.GDYoutubeObjects1.length = 0;
gdjs.bassCode.GDYoutubeObjects2.length = 0;
gdjs.bassCode.GDinfo2Objects1.length = 0;
gdjs.bassCode.GDinfo2Objects2.length = 0;
gdjs.bassCode.GDblancoObjects1.length = 0;
gdjs.bassCode.GDblancoObjects2.length = 0;
gdjs.bassCode.GDNew3DModelObjects1.length = 0;
gdjs.bassCode.GDNew3DModelObjects2.length = 0;
gdjs.bassCode.GDbar3Objects1.length = 0;
gdjs.bassCode.GDbar3Objects2.length = 0;
gdjs.bassCode.GDbar4Objects1.length = 0;
gdjs.bassCode.GDbar4Objects2.length = 0;
gdjs.bassCode.GDbar5Objects1.length = 0;
gdjs.bassCode.GDbar5Objects2.length = 0;
gdjs.bassCode.GDbar6Objects1.length = 0;
gdjs.bassCode.GDbar6Objects2.length = 0;
gdjs.bassCode.GDbar7Objects1.length = 0;
gdjs.bassCode.GDbar7Objects2.length = 0;
gdjs.bassCode.GDbar8Objects1.length = 0;
gdjs.bassCode.GDbar8Objects2.length = 0;
gdjs.bassCode.GDbar9Objects1.length = 0;
gdjs.bassCode.GDbar9Objects2.length = 0;
gdjs.bassCode.GDbar10Objects1.length = 0;
gdjs.bassCode.GDbar10Objects2.length = 0;
gdjs.bassCode.GDdebugObjects1.length = 0;
gdjs.bassCode.GDdebugObjects2.length = 0;
gdjs.bassCode.GDtiiObjects1.length = 0;
gdjs.bassCode.GDtiiObjects2.length = 0;
gdjs.bassCode.GDinfo3Objects1.length = 0;
gdjs.bassCode.GDinfo3Objects2.length = 0;
gdjs.bassCode.GDiiiiObjects1.length = 0;
gdjs.bassCode.GDiiiiObjects2.length = 0;
gdjs.bassCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.bassCode.GDNewPanelSpriteObjects2.length = 0;


return;

}

gdjs['bassCode'] = gdjs.bassCode;
