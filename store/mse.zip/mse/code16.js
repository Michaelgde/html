gdjs.layoutsCode = {};
gdjs.layoutsCode.localVariables = [];
gdjs.layoutsCode.forEachIndex2 = 0;

gdjs.layoutsCode.forEachObjects2 = [];

gdjs.layoutsCode.forEachTemporary2 = null;

gdjs.layoutsCode.forEachTotalCount2 = 0;

gdjs.layoutsCode.GDnameObjects1= [];
gdjs.layoutsCode.GDnameObjects2= [];
gdjs.layoutsCode.GDnameObjects3= [];
gdjs.layoutsCode.GDnameObjects4= [];
gdjs.layoutsCode.GDnameObjects5= [];
gdjs.layoutsCode.GDbackgroundObjects1= [];
gdjs.layoutsCode.GDbackgroundObjects2= [];
gdjs.layoutsCode.GDbackgroundObjects3= [];
gdjs.layoutsCode.GDbackgroundObjects4= [];
gdjs.layoutsCode.GDbackgroundObjects5= [];
gdjs.layoutsCode.GDbuttonObjects1= [];
gdjs.layoutsCode.GDbuttonObjects2= [];
gdjs.layoutsCode.GDbuttonObjects3= [];
gdjs.layoutsCode.GDbuttonObjects4= [];
gdjs.layoutsCode.GDbuttonObjects5= [];
gdjs.layoutsCode.GDopaObjects1= [];
gdjs.layoutsCode.GDopaObjects2= [];
gdjs.layoutsCode.GDopaObjects3= [];
gdjs.layoutsCode.GDopaObjects4= [];
gdjs.layoutsCode.GDopaObjects5= [];
gdjs.layoutsCode.GDbackground2Objects1= [];
gdjs.layoutsCode.GDbackground2Objects2= [];
gdjs.layoutsCode.GDbackground2Objects3= [];
gdjs.layoutsCode.GDbackground2Objects4= [];
gdjs.layoutsCode.GDbackground2Objects5= [];
gdjs.layoutsCode.GDinfoObjects1= [];
gdjs.layoutsCode.GDinfoObjects2= [];
gdjs.layoutsCode.GDinfoObjects3= [];
gdjs.layoutsCode.GDinfoObjects4= [];
gdjs.layoutsCode.GDinfoObjects5= [];
gdjs.layoutsCode.GDbutton2Objects1= [];
gdjs.layoutsCode.GDbutton2Objects2= [];
gdjs.layoutsCode.GDbutton2Objects3= [];
gdjs.layoutsCode.GDbutton2Objects4= [];
gdjs.layoutsCode.GDbutton2Objects5= [];
gdjs.layoutsCode.GDimObjects1= [];
gdjs.layoutsCode.GDimObjects2= [];
gdjs.layoutsCode.GDimObjects3= [];
gdjs.layoutsCode.GDimObjects4= [];
gdjs.layoutsCode.GDimObjects5= [];
gdjs.layoutsCode.GDgearObjects1= [];
gdjs.layoutsCode.GDgearObjects2= [];
gdjs.layoutsCode.GDgearObjects3= [];
gdjs.layoutsCode.GDgearObjects4= [];
gdjs.layoutsCode.GDgearObjects5= [];
gdjs.layoutsCode.GDselectLayerButtonObjects1= [];
gdjs.layoutsCode.GDselectLayerButtonObjects2= [];
gdjs.layoutsCode.GDselectLayerButtonObjects3= [];
gdjs.layoutsCode.GDselectLayerButtonObjects4= [];
gdjs.layoutsCode.GDselectLayerButtonObjects5= [];
gdjs.layoutsCode.GDpathInputObjects1= [];
gdjs.layoutsCode.GDpathInputObjects2= [];
gdjs.layoutsCode.GDpathInputObjects3= [];
gdjs.layoutsCode.GDpathInputObjects4= [];
gdjs.layoutsCode.GDpathInputObjects5= [];
gdjs.layoutsCode.GDinstructionObjects1= [];
gdjs.layoutsCode.GDinstructionObjects2= [];
gdjs.layoutsCode.GDinstructionObjects3= [];
gdjs.layoutsCode.GDinstructionObjects4= [];
gdjs.layoutsCode.GDinstructionObjects5= [];
gdjs.layoutsCode.GDdoneObjects1= [];
gdjs.layoutsCode.GDdoneObjects2= [];
gdjs.layoutsCode.GDdoneObjects3= [];
gdjs.layoutsCode.GDdoneObjects4= [];
gdjs.layoutsCode.GDdoneObjects5= [];
gdjs.layoutsCode.GDtxtObjects1= [];
gdjs.layoutsCode.GDtxtObjects2= [];
gdjs.layoutsCode.GDtxtObjects3= [];
gdjs.layoutsCode.GDtxtObjects4= [];
gdjs.layoutsCode.GDtxtObjects5= [];
gdjs.layoutsCode.GDpathDObjects1= [];
gdjs.layoutsCode.GDpathDObjects2= [];
gdjs.layoutsCode.GDpathDObjects3= [];
gdjs.layoutsCode.GDpathDObjects4= [];
gdjs.layoutsCode.GDpathDObjects5= [];


gdjs.layoutsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.layoutsCode.userFunc0x1618ff8 = function GDJSInlineCode(runtimeScene) {
"use strict";
var lvlJson = JSON.parse(runtimeScene.getGame().getVariables().get("data").getChildNamed("lvlData").getAsString())
//var layouts = JSON.parse(lvlJson)
var lay = []
lvlJson.layouts.forEach(regg=> {lay.push(regg.name); runtimeScene.getVariables().get("layouts").fromJSON(JSON.stringify(lay))})

};
gdjs.layoutsCode.eventsList1 = function(runtimeScene) {

{


gdjs.layoutsCode.userFunc0x1618ff8(runtimeScene);

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDbutton2Objects1Objects = Hashtable.newFrom({"button2": gdjs.layoutsCode.GDbutton2Objects1});
gdjs.layoutsCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.layoutsCode.GDpathInputObjects2, gdjs.layoutsCode.GDpathInputObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strAt((( gdjs.layoutsCode.GDpathInputObjects4.length === 0 ) ? "" :gdjs.layoutsCode.GDpathInputObjects4[0].getBehavior("Text").getText()), gdjs.layoutsCode.localVariables[0].getFromIndex(0).getAsNumber()) != gdjs.layoutsCode.localVariables[0].getFromIndex(1).getAsString());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.layoutsCode.GDpathDObjects1, gdjs.layoutsCode.GDpathDObjects4);

/* Reuse gdjs.layoutsCode.GDpathInputObjects4 */
{for(var i = 0, len = gdjs.layoutsCode.GDpathDObjects4.length ;i < len;++i) {
    gdjs.layoutsCode.GDpathDObjects4[i].getBehavior("Text").setText(gdjs.layoutsCode.GDpathDObjects4[i].getBehavior("Text").getText() + (gdjs.evtTools.string.strAt((( gdjs.layoutsCode.GDpathInputObjects4.length === 0 ) ? "" :gdjs.layoutsCode.GDpathInputObjects4[0].getBehavior("Text").getText()), gdjs.layoutsCode.localVariables[0].getFromIndex(0).getAsNumber())));
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("project_path").concatenateString(gdjs.evtTools.string.strAt((( gdjs.layoutsCode.GDpathInputObjects4.length === 0 ) ? "" :gdjs.layoutsCode.GDpathInputObjects4[0].getBehavior("Text").getText()), gdjs.layoutsCode.localVariables[0].getFromIndex(0).getAsNumber()));
}{gdjs.layoutsCode.localVariables[0].getFromIndex(0).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(true);
}}

}


{

gdjs.copyArray(gdjs.layoutsCode.GDpathInputObjects2, gdjs.layoutsCode.GDpathInputObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strAt((( gdjs.layoutsCode.GDpathInputObjects4.length === 0 ) ? "" :gdjs.layoutsCode.GDpathInputObjects4[0].getBehavior("Text").getText()), gdjs.layoutsCode.localVariables[0].getFromIndex(0).getAsNumber()) == gdjs.layoutsCode.localVariables[0].getFromIndex(1).getAsString());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.layoutsCode.GDpathDObjects1, gdjs.layoutsCode.GDpathDObjects4);

{for(var i = 0, len = gdjs.layoutsCode.GDpathDObjects4.length ;i < len;++i) {
    gdjs.layoutsCode.GDpathDObjects4[i].getBehavior("Text").setText(gdjs.layoutsCode.GDpathDObjects4[i].getBehavior("Text").getText() + ("/"));
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("project_path").concatenateString("/");
}{gdjs.layoutsCode.localVariables[0].getFromIndex(0).add(1);
}}

}


};gdjs.layoutsCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("pathInput"), gdjs.layoutsCode.GDpathInputObjects2);

const repeatCount3 = gdjs.evtTools.string.strLen((( gdjs.layoutsCode.GDpathInputObjects2.length === 0 ) ? "" :gdjs.layoutsCode.GDpathInputObjects2[0].getBehavior("Text").getText()));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(false);
}
{ //Subevents: 
gdjs.layoutsCode.eventsList2(runtimeScene);} //Subevents end.
}
}

}


{



}


};gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDselectLayerButtonObjects2Objects = Hashtable.newFrom({"selectLayerButton": gdjs.layoutsCode.GDselectLayerButtonObjects2});
gdjs.layoutsCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvl_editor", false);
}}

}


};gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.layoutsCode.GDbuttonObjects1});
gdjs.layoutsCode.userFunc0x1165578 = function GDJSInlineCode(runtimeScene) {
"use strict";
var lvlJson = JSON.parse(runtimeScene.getGame().getVariables().get("data").getChildNamed("lvlData").getAsString())
//var layouts = JSON.parse(lvlJson)
var lay = []
var id = runtimeScene.getGame().getVariables().get('selected_layout').getAsNumber()
lvlJson.layouts[id].layers.forEach(regg=> {lay.push(regg.name); runtimeScene.getVariables().get("layers").fromJSON(JSON.stringify(lay))})

};
gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDselectLayerButtonObjects2Objects = Hashtable.newFrom({"selectLayerButton": gdjs.layoutsCode.GDselectLayerButtonObjects2});
gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDnameObjects2Objects = Hashtable.newFrom({"name": gdjs.layoutsCode.GDnameObjects2});
gdjs.layoutsCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.layoutsCode.GDgearObjects3);
{for(var i = 0, len = gdjs.layoutsCode.GDgearObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDgearObjects3[i].SetMaxValue((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1)) * 44), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.layoutsCode.GDgearObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDgearObjects3[i].SetStepSize(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1)) / 44, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString()) < 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.layoutsCode.GDnameObjects2, gdjs.layoutsCode.GDnameObjects3);

gdjs.copyArray(gdjs.layoutsCode.GDselectLayerButtonObjects2, gdjs.layoutsCode.GDselectLayerButtonObjects3);

{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects3[i].getBehavior("Text").setText("''");
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects3[i].setCenterXInScene((( gdjs.layoutsCode.GDselectLayerButtonObjects3.length === 0 ) ? 0 :gdjs.layoutsCode.GDselectLayerButtonObjects3[0].getCenterXInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString()) > 12);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.layoutsCode.GDnameObjects2, gdjs.layoutsCode.GDnameObjects3);

gdjs.copyArray(gdjs.layoutsCode.GDselectLayerButtonObjects2, gdjs.layoutsCode.GDselectLayerButtonObjects3);

{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects3[i].getBehavior("Text").setText(gdjs.evtTools.string.subStr(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString(), 0, 13) + "..");
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects3[i].setCenterXInScene((( gdjs.layoutsCode.GDselectLayerButtonObjects3.length === 0 ) ? 0 :gdjs.layoutsCode.GDselectLayerButtonObjects3[0].getCenterXInScene()));
}
}}

}


};gdjs.layoutsCode.eventsList6 = function(runtimeScene) {

{


gdjs.layoutsCode.userFunc0x1165578(runtimeScene);

}


{


const keyIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(3);
const valueIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(2);
const iterableReference2 = runtimeScene.getScene().getVariables().getFromIndex(1);
if(!iterableReference2.isPrimitive()) {
for(
    const iteratorKey2 in 
    iterableReference2.getType() === "structure"
      ? iterableReference2.getAllChildren()
      : iterableReference2.getType() === "array"
        ? iterableReference2.getAllChildrenArray()
        : []
) {
    if(iterableReference2.getType() === "structure")
        keyIteratorReference2.setString(iteratorKey2);
    else if(iterableReference2.getType() === "array")
        keyIteratorReference2.setNumber(iteratorKey2);
    const structureChildVariable2 = iterableReference2.getChild(iteratorKey2)
    valueIteratorReference2.castTo(structureChildVariable2.getType())
    if(structureChildVariable2.isPrimitive()) {
        valueIteratorReference2.setValue(structureChildVariable2.getValue());
    } else if (structureChildVariable2.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference2.replaceChildren(structureChildVariable2.getAllChildren());
    } else if (structureChildVariable2.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference2.replaceChildrenArray(structureChildVariable2.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.layoutsCode.GDbackgroundObjects2);
gdjs.layoutsCode.GDnameObjects2.length = 0;

gdjs.layoutsCode.GDselectLayerButtonObjects2.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDselectLayerButtonObjects2Objects, (( gdjs.layoutsCode.GDbackgroundObjects2.length === 0 ) ? 0 :gdjs.layoutsCode.GDbackgroundObjects2[0].getPointX("")), (44 * runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()) + 16, "layerSelect");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDnameObjects2Objects, (( gdjs.layoutsCode.GDbackgroundObjects2.length === 0 ) ? 0 :gdjs.layoutsCode.GDbackgroundObjects2[0].getPointX("")), (44 * runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()) + 16, "layerSelect");
}{for(var i = 0, len = gdjs.layoutsCode.GDselectLayerButtonObjects2.length ;i < len;++i) {
    gdjs.layoutsCode.GDselectLayerButtonObjects2[i].returnVariable(gdjs.layoutsCode.GDselectLayerButtonObjects2[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects2.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.layoutsCode.GDselectLayerButtonObjects2.length ;i < len;++i) {
    gdjs.layoutsCode.GDselectLayerButtonObjects2[i].getBehavior("Resizable").setSize(160, 40);
}
}{for(var i = 0, len = gdjs.layoutsCode.GDselectLayerButtonObjects2.length ;i < len;++i) {
    gdjs.layoutsCode.GDselectLayerButtonObjects2[i].setCenterXInScene((( gdjs.layoutsCode.GDbackgroundObjects2.length === 0 ) ? 0 :gdjs.layoutsCode.GDbackgroundObjects2[0].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects2.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects2[i].setCenterXInScene((( gdjs.layoutsCode.GDselectLayerButtonObjects2.length === 0 ) ? 0 :gdjs.layoutsCode.GDselectLayerButtonObjects2[0].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects2.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects2[i].setCenterYInScene((( gdjs.layoutsCode.GDselectLayerButtonObjects2.length === 0 ) ? 0 :gdjs.layoutsCode.GDselectLayerButtonObjects2[0].getCenterYInScene()));
}
}
{ //Subevents: 
gdjs.layoutsCode.eventsList5(runtimeScene);} //Subevents end.
}
}
}

}


};gdjs.layoutsCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDbuttonObjects3Objects = Hashtable.newFrom({"button": gdjs.layoutsCode.GDbuttonObjects3});
gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDnameObjects3Objects = Hashtable.newFrom({"name": gdjs.layoutsCode.GDnameObjects3});
gdjs.layoutsCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.layoutsCode.GDgearObjects4);
{for(var i = 0, len = gdjs.layoutsCode.GDgearObjects4.length ;i < len;++i) {
    gdjs.layoutsCode.GDgearObjects4[i].SetMaxValue((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) * 44), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.layoutsCode.GDgearObjects4.length ;i < len;++i) {
    gdjs.layoutsCode.GDgearObjects4[i].SetStepSize(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) / 44, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString()) > 12);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.layoutsCode.GDbuttonObjects3, gdjs.layoutsCode.GDbuttonObjects4);

gdjs.copyArray(gdjs.layoutsCode.GDnameObjects3, gdjs.layoutsCode.GDnameObjects4);

{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects4.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects4[i].getBehavior("Text").setText(gdjs.evtTools.string.subStr(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString(), 0, 13) + "..");
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects4.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects4[i].setCenterXInScene((( gdjs.layoutsCode.GDbuttonObjects4.length === 0 ) ? 0 :gdjs.layoutsCode.GDbuttonObjects4[0].getCenterXInScene()));
}
}}

}


};gdjs.layoutsCode.eventsList9 = function(runtimeScene) {

{



}


{


const keyIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(3);
const valueIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(2);
const iterableReference3 = runtimeScene.getScene().getVariables().getFromIndex(0);
if(!iterableReference3.isPrimitive()) {
for(
    const iteratorKey3 in 
    iterableReference3.getType() === "structure"
      ? iterableReference3.getAllChildren()
      : iterableReference3.getType() === "array"
        ? iterableReference3.getAllChildrenArray()
        : []
) {
    if(iterableReference3.getType() === "structure")
        keyIteratorReference3.setString(iteratorKey3);
    else if(iterableReference3.getType() === "array")
        keyIteratorReference3.setNumber(iteratorKey3);
    const structureChildVariable3 = iterableReference3.getChild(iteratorKey3)
    valueIteratorReference3.castTo(structureChildVariable3.getType())
    if(structureChildVariable3.isPrimitive()) {
        valueIteratorReference3.setValue(structureChildVariable3.getValue());
    } else if (structureChildVariable3.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference3.replaceChildren(structureChildVariable3.getAllChildren());
    } else if (structureChildVariable3.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference3.replaceChildrenArray(structureChildVariable3.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.layoutsCode.GDbackgroundObjects3);
gdjs.layoutsCode.GDbuttonObjects3.length = 0;

gdjs.layoutsCode.GDnameObjects3.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDbuttonObjects3Objects, (( gdjs.layoutsCode.GDbackgroundObjects3.length === 0 ) ? 0 :gdjs.layoutsCode.GDbackgroundObjects3[0].getPointX("")), (44 * runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()) + 16, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDnameObjects3Objects, (( gdjs.layoutsCode.GDbackgroundObjects3.length === 0 ) ? 0 :gdjs.layoutsCode.GDbackgroundObjects3[0].getPointX("")), (44 * runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()) + 16, "");
}{for(var i = 0, len = gdjs.layoutsCode.GDbuttonObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDbuttonObjects3[i].returnVariable(gdjs.layoutsCode.GDbuttonObjects3[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.layoutsCode.GDbuttonObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDbuttonObjects3[i].getBehavior("Resizable").setSize(160, 40);
}
}{for(var i = 0, len = gdjs.layoutsCode.GDbuttonObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDbuttonObjects3[i].setCenterXInScene((( gdjs.layoutsCode.GDbackgroundObjects3.length === 0 ) ? 0 :gdjs.layoutsCode.GDbackgroundObjects3[0].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects3[i].setCenterXInScene((( gdjs.layoutsCode.GDbuttonObjects3.length === 0 ) ? 0 :gdjs.layoutsCode.GDbuttonObjects3[0].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.layoutsCode.GDnameObjects3.length ;i < len;++i) {
    gdjs.layoutsCode.GDnameObjects3[i].setCenterYInScene((( gdjs.layoutsCode.GDbuttonObjects3.length === 0 ) ? 0 :gdjs.layoutsCode.GDbuttonObjects3[0].getCenterYInScene()));
}
}
{ //Subevents: 
gdjs.layoutsCode.eventsList8(runtimeScene);} //Subevents end.
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.layoutsCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.layoutsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvlData").getAsString()) > 5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23971700);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("background2"), gdjs.layoutsCode.GDbackground2Objects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "import");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "");
}{for(var i = 0, len = gdjs.layoutsCode.GDbackground2Objects1.length ;i < len;++i) {
    gdjs.layoutsCode.GDbackground2Objects1[i].hide();
}
}
{ //Subevents
gdjs.layoutsCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("button2"), gdjs.layoutsCode.GDbutton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvlData").getAsString()) < 5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDbutton2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__UploadDownloadTextFile__UploadTextFile.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(4), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("pos", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\\");
variables._declare("slash", variable);
}
gdjs.layoutsCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("pathD"), gdjs.layoutsCode.GDpathDObjects1);
{for(var i = 0, len = gdjs.layoutsCode.GDpathDObjects1.length ;i < len;++i) {
    gdjs.layoutsCode.GDpathDObjects1[i].getBehavior("Text").setText("file://");
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("resources").getChild("resourcesURL").setString("file://");
}
{ //Subevents
gdjs.layoutsCode.eventsList3(runtimeScene);} //End of subevents
}
gdjs.layoutsCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("selectLayerButton"), gdjs.layoutsCode.GDselectLayerButtonObjects1);

for (gdjs.layoutsCode.forEachIndex2 = 0;gdjs.layoutsCode.forEachIndex2 < gdjs.layoutsCode.GDselectLayerButtonObjects1.length;++gdjs.layoutsCode.forEachIndex2) {
gdjs.layoutsCode.GDselectLayerButtonObjects2.length = 0;


gdjs.layoutsCode.forEachTemporary2 = gdjs.layoutsCode.GDselectLayerButtonObjects1[gdjs.layoutsCode.forEachIndex2];
gdjs.layoutsCode.GDselectLayerButtonObjects2.push(gdjs.layoutsCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDselectLayerButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(16).setString(((gdjs.layoutsCode.GDselectLayerButtonObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.layoutsCode.GDselectLayerButtonObjects2[0].getVariables()).getFromIndex(0).getAsString());
}
{ //Subevents: 
gdjs.layoutsCode.eventsList4(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.layoutsCode.GDbuttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.layoutsCode.mapOfGDgdjs_9546layoutsCode_9546GDbuttonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.layoutsCode.GDbuttonObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(((gdjs.layoutsCode.GDbuttonObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.layoutsCode.GDbuttonObjects1[0].getVariables()).getFromIndex(0).getAsNumber());
}{gdjs.evtTools.debuggerTools.log(((gdjs.layoutsCode.GDbuttonObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.layoutsCode.GDbuttonObjects1[0].getVariables()).getFromIndex(0).getAsString(), "info", "layer id");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}
{ //Subevents
gdjs.layoutsCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.layoutsCode.GDbuttonObjects1);

for (gdjs.layoutsCode.forEachIndex2 = 0;gdjs.layoutsCode.forEachIndex2 < gdjs.layoutsCode.GDbuttonObjects1.length;++gdjs.layoutsCode.forEachIndex2) {
gdjs.layoutsCode.GDbuttonObjects2.length = 0;


gdjs.layoutsCode.forEachTemporary2 = gdjs.layoutsCode.GDbuttonObjects1[gdjs.layoutsCode.forEachIndex2];
gdjs.layoutsCode.GDbuttonObjects2.push(gdjs.layoutsCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.layoutsCode.eventsList7(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24001484);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.layoutsCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__UploadDownloadTextFile__UploadFinished.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvlData").setString(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString());
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.layoutsCode.GDgearObjects1);
{gdjs.evtTools.camera.setCameraY(runtimeScene, ((( gdjs.layoutsCode.GDgearObjects1.length === 0 ) ? 0 :gdjs.layoutsCode.GDgearObjects1[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) + 360, "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, ((( gdjs.layoutsCode.GDgearObjects1.length === 0 ) ? 0 :gdjs.layoutsCode.GDgearObjects1[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) + 360, "layerSelect", 0);
}}

}


};

gdjs.layoutsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.layoutsCode.GDnameObjects1.length = 0;
gdjs.layoutsCode.GDnameObjects2.length = 0;
gdjs.layoutsCode.GDnameObjects3.length = 0;
gdjs.layoutsCode.GDnameObjects4.length = 0;
gdjs.layoutsCode.GDnameObjects5.length = 0;
gdjs.layoutsCode.GDbackgroundObjects1.length = 0;
gdjs.layoutsCode.GDbackgroundObjects2.length = 0;
gdjs.layoutsCode.GDbackgroundObjects3.length = 0;
gdjs.layoutsCode.GDbackgroundObjects4.length = 0;
gdjs.layoutsCode.GDbackgroundObjects5.length = 0;
gdjs.layoutsCode.GDbuttonObjects1.length = 0;
gdjs.layoutsCode.GDbuttonObjects2.length = 0;
gdjs.layoutsCode.GDbuttonObjects3.length = 0;
gdjs.layoutsCode.GDbuttonObjects4.length = 0;
gdjs.layoutsCode.GDbuttonObjects5.length = 0;
gdjs.layoutsCode.GDopaObjects1.length = 0;
gdjs.layoutsCode.GDopaObjects2.length = 0;
gdjs.layoutsCode.GDopaObjects3.length = 0;
gdjs.layoutsCode.GDopaObjects4.length = 0;
gdjs.layoutsCode.GDopaObjects5.length = 0;
gdjs.layoutsCode.GDbackground2Objects1.length = 0;
gdjs.layoutsCode.GDbackground2Objects2.length = 0;
gdjs.layoutsCode.GDbackground2Objects3.length = 0;
gdjs.layoutsCode.GDbackground2Objects4.length = 0;
gdjs.layoutsCode.GDbackground2Objects5.length = 0;
gdjs.layoutsCode.GDinfoObjects1.length = 0;
gdjs.layoutsCode.GDinfoObjects2.length = 0;
gdjs.layoutsCode.GDinfoObjects3.length = 0;
gdjs.layoutsCode.GDinfoObjects4.length = 0;
gdjs.layoutsCode.GDinfoObjects5.length = 0;
gdjs.layoutsCode.GDbutton2Objects1.length = 0;
gdjs.layoutsCode.GDbutton2Objects2.length = 0;
gdjs.layoutsCode.GDbutton2Objects3.length = 0;
gdjs.layoutsCode.GDbutton2Objects4.length = 0;
gdjs.layoutsCode.GDbutton2Objects5.length = 0;
gdjs.layoutsCode.GDimObjects1.length = 0;
gdjs.layoutsCode.GDimObjects2.length = 0;
gdjs.layoutsCode.GDimObjects3.length = 0;
gdjs.layoutsCode.GDimObjects4.length = 0;
gdjs.layoutsCode.GDimObjects5.length = 0;
gdjs.layoutsCode.GDgearObjects1.length = 0;
gdjs.layoutsCode.GDgearObjects2.length = 0;
gdjs.layoutsCode.GDgearObjects3.length = 0;
gdjs.layoutsCode.GDgearObjects4.length = 0;
gdjs.layoutsCode.GDgearObjects5.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects1.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects2.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects3.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects4.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects5.length = 0;
gdjs.layoutsCode.GDpathInputObjects1.length = 0;
gdjs.layoutsCode.GDpathInputObjects2.length = 0;
gdjs.layoutsCode.GDpathInputObjects3.length = 0;
gdjs.layoutsCode.GDpathInputObjects4.length = 0;
gdjs.layoutsCode.GDpathInputObjects5.length = 0;
gdjs.layoutsCode.GDinstructionObjects1.length = 0;
gdjs.layoutsCode.GDinstructionObjects2.length = 0;
gdjs.layoutsCode.GDinstructionObjects3.length = 0;
gdjs.layoutsCode.GDinstructionObjects4.length = 0;
gdjs.layoutsCode.GDinstructionObjects5.length = 0;
gdjs.layoutsCode.GDdoneObjects1.length = 0;
gdjs.layoutsCode.GDdoneObjects2.length = 0;
gdjs.layoutsCode.GDdoneObjects3.length = 0;
gdjs.layoutsCode.GDdoneObjects4.length = 0;
gdjs.layoutsCode.GDdoneObjects5.length = 0;
gdjs.layoutsCode.GDtxtObjects1.length = 0;
gdjs.layoutsCode.GDtxtObjects2.length = 0;
gdjs.layoutsCode.GDtxtObjects3.length = 0;
gdjs.layoutsCode.GDtxtObjects4.length = 0;
gdjs.layoutsCode.GDtxtObjects5.length = 0;
gdjs.layoutsCode.GDpathDObjects1.length = 0;
gdjs.layoutsCode.GDpathDObjects2.length = 0;
gdjs.layoutsCode.GDpathDObjects3.length = 0;
gdjs.layoutsCode.GDpathDObjects4.length = 0;
gdjs.layoutsCode.GDpathDObjects5.length = 0;

gdjs.layoutsCode.eventsList10(runtimeScene);
gdjs.layoutsCode.GDnameObjects1.length = 0;
gdjs.layoutsCode.GDnameObjects2.length = 0;
gdjs.layoutsCode.GDnameObjects3.length = 0;
gdjs.layoutsCode.GDnameObjects4.length = 0;
gdjs.layoutsCode.GDnameObjects5.length = 0;
gdjs.layoutsCode.GDbackgroundObjects1.length = 0;
gdjs.layoutsCode.GDbackgroundObjects2.length = 0;
gdjs.layoutsCode.GDbackgroundObjects3.length = 0;
gdjs.layoutsCode.GDbackgroundObjects4.length = 0;
gdjs.layoutsCode.GDbackgroundObjects5.length = 0;
gdjs.layoutsCode.GDbuttonObjects1.length = 0;
gdjs.layoutsCode.GDbuttonObjects2.length = 0;
gdjs.layoutsCode.GDbuttonObjects3.length = 0;
gdjs.layoutsCode.GDbuttonObjects4.length = 0;
gdjs.layoutsCode.GDbuttonObjects5.length = 0;
gdjs.layoutsCode.GDopaObjects1.length = 0;
gdjs.layoutsCode.GDopaObjects2.length = 0;
gdjs.layoutsCode.GDopaObjects3.length = 0;
gdjs.layoutsCode.GDopaObjects4.length = 0;
gdjs.layoutsCode.GDopaObjects5.length = 0;
gdjs.layoutsCode.GDbackground2Objects1.length = 0;
gdjs.layoutsCode.GDbackground2Objects2.length = 0;
gdjs.layoutsCode.GDbackground2Objects3.length = 0;
gdjs.layoutsCode.GDbackground2Objects4.length = 0;
gdjs.layoutsCode.GDbackground2Objects5.length = 0;
gdjs.layoutsCode.GDinfoObjects1.length = 0;
gdjs.layoutsCode.GDinfoObjects2.length = 0;
gdjs.layoutsCode.GDinfoObjects3.length = 0;
gdjs.layoutsCode.GDinfoObjects4.length = 0;
gdjs.layoutsCode.GDinfoObjects5.length = 0;
gdjs.layoutsCode.GDbutton2Objects1.length = 0;
gdjs.layoutsCode.GDbutton2Objects2.length = 0;
gdjs.layoutsCode.GDbutton2Objects3.length = 0;
gdjs.layoutsCode.GDbutton2Objects4.length = 0;
gdjs.layoutsCode.GDbutton2Objects5.length = 0;
gdjs.layoutsCode.GDimObjects1.length = 0;
gdjs.layoutsCode.GDimObjects2.length = 0;
gdjs.layoutsCode.GDimObjects3.length = 0;
gdjs.layoutsCode.GDimObjects4.length = 0;
gdjs.layoutsCode.GDimObjects5.length = 0;
gdjs.layoutsCode.GDgearObjects1.length = 0;
gdjs.layoutsCode.GDgearObjects2.length = 0;
gdjs.layoutsCode.GDgearObjects3.length = 0;
gdjs.layoutsCode.GDgearObjects4.length = 0;
gdjs.layoutsCode.GDgearObjects5.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects1.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects2.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects3.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects4.length = 0;
gdjs.layoutsCode.GDselectLayerButtonObjects5.length = 0;
gdjs.layoutsCode.GDpathInputObjects1.length = 0;
gdjs.layoutsCode.GDpathInputObjects2.length = 0;
gdjs.layoutsCode.GDpathInputObjects3.length = 0;
gdjs.layoutsCode.GDpathInputObjects4.length = 0;
gdjs.layoutsCode.GDpathInputObjects5.length = 0;
gdjs.layoutsCode.GDinstructionObjects1.length = 0;
gdjs.layoutsCode.GDinstructionObjects2.length = 0;
gdjs.layoutsCode.GDinstructionObjects3.length = 0;
gdjs.layoutsCode.GDinstructionObjects4.length = 0;
gdjs.layoutsCode.GDinstructionObjects5.length = 0;
gdjs.layoutsCode.GDdoneObjects1.length = 0;
gdjs.layoutsCode.GDdoneObjects2.length = 0;
gdjs.layoutsCode.GDdoneObjects3.length = 0;
gdjs.layoutsCode.GDdoneObjects4.length = 0;
gdjs.layoutsCode.GDdoneObjects5.length = 0;
gdjs.layoutsCode.GDtxtObjects1.length = 0;
gdjs.layoutsCode.GDtxtObjects2.length = 0;
gdjs.layoutsCode.GDtxtObjects3.length = 0;
gdjs.layoutsCode.GDtxtObjects4.length = 0;
gdjs.layoutsCode.GDtxtObjects5.length = 0;
gdjs.layoutsCode.GDpathDObjects1.length = 0;
gdjs.layoutsCode.GDpathDObjects2.length = 0;
gdjs.layoutsCode.GDpathDObjects3.length = 0;
gdjs.layoutsCode.GDpathDObjects4.length = 0;
gdjs.layoutsCode.GDpathDObjects5.length = 0;


return;

}

gdjs['layoutsCode'] = gdjs.layoutsCode;
