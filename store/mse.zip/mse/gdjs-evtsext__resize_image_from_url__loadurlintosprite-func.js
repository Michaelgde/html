
if (typeof gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite !== "undefined") {
  gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite = {};
gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.GDObjectObjects1= [];


gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.userFunc0x145ded8 = function GDJSInlineCode(runtimeScene, objects, eventsFunctionContext) {
"use strict";
var img = new Image()

img.src = eventsFunctionContext.getArgument("URL")
img.onload = function(){
    var canvas = document.createElement('canvas');
    canvas.width = eventsFunctionContext.getArgument('w')
    canvas.height = eventsFunctionContext.getArgument('h')
    var ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    var resizedDataUrl = canvas.toDataURL();
    if (eventsFunctionContext.getArgument("ChangeResource")) {
    const texture = PIXI.BaseTexture.from(resizedDataUrl);
    for (const obj of objects) obj.getRendererObject().texture.baseTexture = texture;
    } else {
    const texture = PIXI.Texture.from(resizedDataUrl);
    for (const obj of objects) obj.getRendererObject().texture = texture;
}
    
}




};
gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.GDObjectObjects1);

var objects = [];
objects.push.apply(objects,gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.GDObjectObjects1);
gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.userFunc0x145ded8(runtimeScene, objects, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func = function(runtimeScene, URL, Object, ChangeResource, w, h, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
},
  _objectArraysMap: {
"Object": gdjs.objectsListsToArray(Object)
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("resize_image_from_url"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("resize_image_from_url"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "URL") return URL;
if (argName === "ChangeResource") return ChangeResource;
if (argName === "w") return w;
if (argName === "h") return h;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.GDObjectObjects1.length = 0;

gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.GDObjectObjects1.length = 0;


return;
}

gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.registeredGdjsCallbacks = [];