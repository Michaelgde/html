gdjs.ai_32rythm_32placerCode = {};
gdjs.ai_32rythm_32placerCode.localVariables = [];
gdjs.ai_32rythm_32placerCode.GDbarObjects1= [];
gdjs.ai_32rythm_32placerCode.GDbarObjects2= [];
gdjs.ai_32rythm_32placerCode.GDbar1Objects1= [];
gdjs.ai_32rythm_32placerCode.GDbar1Objects2= [];
gdjs.ai_32rythm_32placerCode.GDbar2Objects1= [];
gdjs.ai_32rythm_32placerCode.GDbar2Objects2= [];
gdjs.ai_32rythm_32placerCode.GDbar3Objects1= [];
gdjs.ai_32rythm_32placerCode.GDbar3Objects2= [];


gdjs.ai_32rythm_32placerCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.ai_32rythm_32placerCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ai_32rythm_32placerCode.GDbarObjects1.length = 0;
gdjs.ai_32rythm_32placerCode.GDbarObjects2.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar1Objects1.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar1Objects2.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar2Objects1.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar2Objects2.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar3Objects1.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar3Objects2.length = 0;

gdjs.ai_32rythm_32placerCode.eventsList0(runtimeScene);
gdjs.ai_32rythm_32placerCode.GDbarObjects1.length = 0;
gdjs.ai_32rythm_32placerCode.GDbarObjects2.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar1Objects1.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar1Objects2.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar2Objects1.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar2Objects2.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar3Objects1.length = 0;
gdjs.ai_32rythm_32placerCode.GDbar3Objects2.length = 0;


return;

}

gdjs['ai_32rythm_32placerCode'] = gdjs.ai_32rythm_32placerCode;
