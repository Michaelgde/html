gdjs.audio_95manager_95win2Code = {};
gdjs.audio_95manager_95win2Code.localVariables = [];
gdjs.audio_95manager_95win2Code.forEachIndex3 = 0;

gdjs.audio_95manager_95win2Code.forEachObjects3 = [];

gdjs.audio_95manager_95win2Code.forEachTemporary3 = null;

gdjs.audio_95manager_95win2Code.forEachTotalCount3 = 0;

gdjs.audio_95manager_95win2Code.GDnameObjects1= [];
gdjs.audio_95manager_95win2Code.GDnameObjects2= [];
gdjs.audio_95manager_95win2Code.GDnameObjects3= [];
gdjs.audio_95manager_95win2Code.GDinfoObjects1= [];
gdjs.audio_95manager_95win2Code.GDinfoObjects2= [];
gdjs.audio_95manager_95win2Code.GDinfoObjects3= [];
gdjs.audio_95manager_95win2Code.GDaddObjects1= [];
gdjs.audio_95manager_95win2Code.GDaddObjects2= [];
gdjs.audio_95manager_95win2Code.GDaddObjects3= [];
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects1= [];
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects2= [];
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects3= [];
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects1= [];
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects2= [];
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects3= [];
gdjs.audio_95manager_95win2Code.GDname2Objects1= [];
gdjs.audio_95manager_95win2Code.GDname2Objects2= [];
gdjs.audio_95manager_95win2Code.GDname2Objects3= [];
gdjs.audio_95manager_95win2Code.GDioiObjects1= [];
gdjs.audio_95manager_95win2Code.GDioiObjects2= [];
gdjs.audio_95manager_95win2Code.GDioiObjects3= [];
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects1= [];
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects2= [];
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects3= [];
gdjs.audio_95manager_95win2Code.GDokObjects1= [];
gdjs.audio_95manager_95win2Code.GDokObjects2= [];
gdjs.audio_95manager_95win2Code.GDokObjects3= [];
gdjs.audio_95manager_95win2Code.GDcancObjects1= [];
gdjs.audio_95manager_95win2Code.GDcancObjects2= [];
gdjs.audio_95manager_95win2Code.GDcancObjects3= [];
gdjs.audio_95manager_95win2Code.GDpaintObjects1= [];
gdjs.audio_95manager_95win2Code.GDpaintObjects2= [];
gdjs.audio_95manager_95win2Code.GDpaintObjects3= [];
gdjs.audio_95manager_95win2Code.GDname3Objects1= [];
gdjs.audio_95manager_95win2Code.GDname3Objects2= [];
gdjs.audio_95manager_95win2Code.GDname3Objects3= [];
gdjs.audio_95manager_95win2Code.GDpanelObjects1= [];
gdjs.audio_95manager_95win2Code.GDpanelObjects2= [];
gdjs.audio_95manager_95win2Code.GDpanelObjects3= [];
gdjs.audio_95manager_95win2Code.GDsprrObjects1= [];
gdjs.audio_95manager_95win2Code.GDsprrObjects2= [];
gdjs.audio_95manager_95win2Code.GDsprrObjects3= [];
gdjs.audio_95manager_95win2Code.GDpanel2Objects1= [];
gdjs.audio_95manager_95win2Code.GDpanel2Objects2= [];
gdjs.audio_95manager_95win2Code.GDpanel2Objects3= [];
gdjs.audio_95manager_95win2Code.GDfkObjects1= [];
gdjs.audio_95manager_95win2Code.GDfkObjects2= [];
gdjs.audio_95manager_95win2Code.GDfkObjects3= [];
gdjs.audio_95manager_95win2Code.GDjjObjects1= [];
gdjs.audio_95manager_95win2Code.GDjjObjects2= [];
gdjs.audio_95manager_95win2Code.GDjjObjects3= [];
gdjs.audio_95manager_95win2Code.GDlogoObjects1= [];
gdjs.audio_95manager_95win2Code.GDlogoObjects2= [];
gdjs.audio_95manager_95win2Code.GDlogoObjects3= [];
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects1= [];
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects2= [];
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects3= [];
gdjs.audio_95manager_95win2Code.GDbackObjects1= [];
gdjs.audio_95manager_95win2Code.GDbackObjects2= [];
gdjs.audio_95manager_95win2Code.GDbackObjects3= [];
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects1= [];
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects2= [];
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects3= [];
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects1= [];
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects2= [];
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects3= [];
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects1= [];
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects2= [];
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects3= [];


gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDaddObjects2Objects = Hashtable.newFrom({"add": gdjs.audio_95manager_95win2Code.GDaddObjects2});
gdjs.audio_95manager_95win2Code.eventsList0 = function(runtimeScene) {

{



}


};gdjs.audio_95manager_95win2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "prompt"));
}
if (isConditionTrue_0) {
{gdjs.evtsExt__load_audio__file_loader.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.audio_95manager_95win2Code.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.audio_95manager_95win2Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.audio_95manager_95win2Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.audio_95manager_95win2Code.GDaddObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDaddObjects2Objects, runtimeScene, false, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95win2Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.audio_95manager_95win2Code.localVariables[0].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95win2Code.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


};gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDname2Objects1Objects = Hashtable.newFrom({"name2": gdjs.audio_95manager_95win2Code.GDname2Objects1});
gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDokObjects1Objects = Hashtable.newFrom({"ok": gdjs.audio_95manager_95win2Code.GDokObjects1});
gdjs.audio_95manager_95win2Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mse_win", false);
}}

}


};gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDcancObjects1Objects = Hashtable.newFrom({"canc": gdjs.audio_95manager_95win2Code.GDcancObjects1});
gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDpanel2Objects3Objects = Hashtable.newFrom({"panel2": gdjs.audio_95manager_95win2Code.GDpanel2Objects3});
gdjs.audio_95manager_95win2Code.eventsList5 = function(runtimeScene) {

};gdjs.audio_95manager_95win2Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.audio_95manager_95win2Code.GDname2Objects2);

for (gdjs.audio_95manager_95win2Code.forEachIndex3 = 0;gdjs.audio_95manager_95win2Code.forEachIndex3 < gdjs.audio_95manager_95win2Code.GDname2Objects2.length;++gdjs.audio_95manager_95win2Code.forEachIndex3) {
gdjs.audio_95manager_95win2Code.GDpanel2Objects3.length = 0;

gdjs.audio_95manager_95win2Code.GDname2Objects3.length = 0;


gdjs.audio_95manager_95win2Code.forEachTemporary3 = gdjs.audio_95manager_95win2Code.GDname2Objects2[gdjs.audio_95manager_95win2Code.forEachIndex3];
gdjs.audio_95manager_95win2Code.GDname2Objects3.push(gdjs.audio_95manager_95win2Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDpanel2Objects3Objects, (( gdjs.audio_95manager_95win2Code.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects3[0].getX()), (( gdjs.audio_95manager_95win2Code.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects3[0].getY()), "prompt");
}{for(var i = 0, len = gdjs.audio_95manager_95win2Code.GDpanel2Objects3.length ;i < len;++i) {
    gdjs.audio_95manager_95win2Code.GDpanel2Objects3[i].getBehavior("Resizable").setSize((( gdjs.audio_95manager_95win2Code.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects3[0].getWidth()), (( gdjs.audio_95manager_95win2Code.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects3[0].getHeight()));
}
}{for(var i = 0, len = gdjs.audio_95manager_95win2Code.GDpanel2Objects3.length ;i < len;++i) {
    gdjs.audio_95manager_95win2Code.GDpanel2Objects3[i].setZOrder((( gdjs.audio_95manager_95win2Code.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects3[0].getZOrder()) + 1);
}
}}
}

}


{



}


};gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDbackObjects1Objects = Hashtable.newFrom({"back": gdjs.audio_95manager_95win2Code.GDbackObjects1});
gdjs.audio_95manager_95win2Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.audio_95manager_95win2Code.GDaddObjects1);
gdjs.copyArray(runtimeScene.getObjects("add_txt"), gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects1);
{for(var i = 0, len = gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects1.length ;i < len;++i) {
    gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects1[i].setCenterPositionInScene((( gdjs.audio_95manager_95win2Code.GDaddObjects1.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDaddObjects1[0].getCenterXInScene()),(( gdjs.audio_95manager_95win2Code.GDaddObjects1.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDaddObjects1[0].getCenterYInScene()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("temp", variable);
}
gdjs.audio_95manager_95win2Code.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.audio_95manager_95win2Code.eventsList3(runtimeScene);} //End of subevents
}
gdjs.audio_95manager_95win2Code.localVariables.pop();

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.audio_95manager_95win2Code.GDname2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDname2Objects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
/* Reuse gdjs.audio_95manager_95win2Code.GDname2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("paint"), gdjs.audio_95manager_95win2Code.GDpaintObjects1);
{for(var i = 0, len = gdjs.audio_95manager_95win2Code.GDpaintObjects1.length ;i < len;++i) {
    gdjs.audio_95manager_95win2Code.GDpaintObjects1[i].drawRectangle((( gdjs.audio_95manager_95win2Code.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects1[0].getX()), (( gdjs.audio_95manager_95win2Code.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects1[0].getY()), (( gdjs.audio_95manager_95win2Code.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects1[0].getX()) + (( gdjs.audio_95manager_95win2Code.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects1[0].getWidth()), (( gdjs.audio_95manager_95win2Code.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects1[0].getY()) + (( gdjs.audio_95manager_95win2Code.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95win2Code.GDname2Objects1[0].getHeight()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ok"), gdjs.audio_95manager_95win2Code.GDokObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDokObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95win2Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("canc"), gdjs.audio_95manager_95win2Code.GDcancObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDcancObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "audio_manager_win2", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString()) > 20);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "prompt");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95win2Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.audio_95manager_95win2Code.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95win2Code.mapOfGDgdjs_9546audio_959595manager_959595win2Code_9546GDbackObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "prompt"));
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};

gdjs.audio_95manager_95win2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.audio_95manager_95win2Code.GDnameObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDnameObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDnameObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDinfoObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDinfoObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDinfoObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDaddObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDaddObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDaddObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDname2Objects1.length = 0;
gdjs.audio_95manager_95win2Code.GDname2Objects2.length = 0;
gdjs.audio_95manager_95win2Code.GDname2Objects3.length = 0;
gdjs.audio_95manager_95win2Code.GDioiObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDioiObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDioiObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDokObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDokObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDokObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDcancObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDcancObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDcancObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDpaintObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDpaintObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDpaintObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDname3Objects1.length = 0;
gdjs.audio_95manager_95win2Code.GDname3Objects2.length = 0;
gdjs.audio_95manager_95win2Code.GDname3Objects3.length = 0;
gdjs.audio_95manager_95win2Code.GDpanelObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDpanelObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDpanelObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDsprrObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDsprrObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDsprrObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDpanel2Objects1.length = 0;
gdjs.audio_95manager_95win2Code.GDpanel2Objects2.length = 0;
gdjs.audio_95manager_95win2Code.GDpanel2Objects3.length = 0;
gdjs.audio_95manager_95win2Code.GDfkObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDfkObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDfkObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDjjObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDjjObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDjjObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDlogoObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDlogoObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDlogoObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects1.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects2.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects3.length = 0;
gdjs.audio_95manager_95win2Code.GDbackObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDbackObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDbackObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects3.length = 0;

gdjs.audio_95manager_95win2Code.eventsList7(runtimeScene);
gdjs.audio_95manager_95win2Code.GDnameObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDnameObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDnameObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDinfoObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDinfoObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDinfoObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDaddObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDaddObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDaddObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595txtObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDsave_9595iconObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDname2Objects1.length = 0;
gdjs.audio_95manager_95win2Code.GDname2Objects2.length = 0;
gdjs.audio_95manager_95win2Code.GDname2Objects3.length = 0;
gdjs.audio_95manager_95win2Code.GDioiObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDioiObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDioiObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eveObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDokObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDokObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDokObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDcancObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDcancObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDcancObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDpaintObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDpaintObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDpaintObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDname3Objects1.length = 0;
gdjs.audio_95manager_95win2Code.GDname3Objects2.length = 0;
gdjs.audio_95manager_95win2Code.GDname3Objects3.length = 0;
gdjs.audio_95manager_95win2Code.GDpanelObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDpanelObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDpanelObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDsprrObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDsprrObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDsprrObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDpanel2Objects1.length = 0;
gdjs.audio_95manager_95win2Code.GDpanel2Objects2.length = 0;
gdjs.audio_95manager_95win2Code.GDpanel2Objects3.length = 0;
gdjs.audio_95manager_95win2Code.GDfkObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDfkObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDfkObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDjjObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDjjObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDjjObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDlogoObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDlogoObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDlogoObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects1.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects2.length = 0;
gdjs.audio_95manager_95win2Code.GDadd_9595eve2Objects3.length = 0;
gdjs.audio_95manager_95win2Code.GDbackObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDbackObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDbackObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDbutton_9595bgObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDNewSpriteObjects3.length = 0;
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects1.length = 0;
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects2.length = 0;
gdjs.audio_95manager_95win2Code.GDaudio_9595selectorObjects3.length = 0;


return;

}

gdjs['audio_95manager_95win2Code'] = gdjs.audio_95manager_95win2Code;
