
if (typeof gdjs.evtsExt__load_audio__file_loader !== "undefined") {
  gdjs.evtsExt__load_audio__file_loader.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__load_audio__file_loader = {};


gdjs.evtsExt__load_audio__file_loader.userFunc0x144bee8 = function GDJSInlineCode(runtimeScene, eventsFunctionContext) {
"use strict";
const fileinput = document.createElement('input');
fileinput.type = 'file';
fileinput.accept = 'audio/';
fileinput.style.display = 'none';
fileinput.addEventListener('change',(event) => {
    const file = event.target.files[0];
    if (file){
        const reader = new FileReader();
        reader.onload = (e)=> {
            const audioData = e.target.result;
            const audio = new Audio(audioData);
            runtimeScene.getSoundManager().unloadAll
            runtimeScene
    .getGame()
    .getSoundManager()._resourceLoader.getResource("audio.ogg").file = audioData
            
            runtimeScene.getVariables().get("musicData").setString(audioData)
            runtimeScene.getGame().getVariables().get("data").getChildNamed("audio").setString(audioData)
            
            runtimeScene.getVariables().get("loadedMusic").setValue(audio);
            
        }
        reader.readAsDataURL(file);
    }
});
fileinput.click()        
};
gdjs.evtsExt__load_audio__file_loader.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__load_audio__file_loader.userFunc0x144bee8(runtimeScene, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__load_audio__file_loader.func = function(runtimeScene, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("load_audio"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("load_audio"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__load_audio__file_loader.eventsList0(runtimeScene, eventsFunctionContext);


return;
}

gdjs.evtsExt__load_audio__file_loader.registeredGdjsCallbacks = [];