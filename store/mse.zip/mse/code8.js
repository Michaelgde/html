gdjs.splashCode = {};
gdjs.splashCode.localVariables = [];
gdjs.splashCode.GDNewTiledSpriteObjects1= [];
gdjs.splashCode.GDNewTiledSpriteObjects2= [];
gdjs.splashCode.GDlogoObjects1= [];
gdjs.splashCode.GDlogoObjects2= [];
gdjs.splashCode.GDlogo2Objects1= [];
gdjs.splashCode.GDlogo2Objects2= [];
gdjs.splashCode.GDNewTextObjects1= [];
gdjs.splashCode.GDNewTextObjects2= [];


gdjs.splashCode.asyncCallback23571292 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.splashCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "project_manager_html", true);
}gdjs.splashCode.localVariables.length = 0;
}
gdjs.splashCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.splashCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.splashCode.asyncCallback23571292(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.splashCode.asyncCallback23572036 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.splashCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.splashCode.GDNewTiledSpriteObjects2);
{for(var i = 0, len = gdjs.splashCode.GDNewTiledSpriteObjects2.length ;i < len;++i) {
    gdjs.splashCode.GDNewTiledSpriteObjects2[i].getBehavior("Opacity").setOpacity(gdjs.splashCode.GDNewTiledSpriteObjects2[i].getBehavior("Opacity").getOpacity() + (5));
}
}gdjs.splashCode.localVariables.length = 0;
}
gdjs.splashCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.splashCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.splashCode.asyncCallback23572036(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.splashCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23570740);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.splashCode.GDNewTiledSpriteObjects1);
{for(var i = 0, len = gdjs.splashCode.GDNewTiledSpriteObjects1.length ;i < len;++i) {
    gdjs.splashCode.GDNewTiledSpriteObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}
{ //Subevents
gdjs.splashCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.splashCode.eventsList1(runtimeScene);} //End of subevents
}

}


};

gdjs.splashCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.splashCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.splashCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.splashCode.GDlogoObjects1.length = 0;
gdjs.splashCode.GDlogoObjects2.length = 0;
gdjs.splashCode.GDlogo2Objects1.length = 0;
gdjs.splashCode.GDlogo2Objects2.length = 0;
gdjs.splashCode.GDNewTextObjects1.length = 0;
gdjs.splashCode.GDNewTextObjects2.length = 0;

gdjs.splashCode.eventsList2(runtimeScene);
gdjs.splashCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.splashCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.splashCode.GDlogoObjects1.length = 0;
gdjs.splashCode.GDlogoObjects2.length = 0;
gdjs.splashCode.GDlogo2Objects1.length = 0;
gdjs.splashCode.GDlogo2Objects2.length = 0;
gdjs.splashCode.GDNewTextObjects1.length = 0;
gdjs.splashCode.GDNewTextObjects2.length = 0;


return;

}

gdjs['splashCode'] = gdjs.splashCode;
