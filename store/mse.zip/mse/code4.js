gdjs.audio_95manager_95winCode = {};
gdjs.audio_95manager_95winCode.localVariables = [];
gdjs.audio_95manager_95winCode.forEachIndex3 = 0;

gdjs.audio_95manager_95winCode.forEachObjects3 = [];

gdjs.audio_95manager_95winCode.forEachTemporary3 = null;

gdjs.audio_95manager_95winCode.forEachTotalCount3 = 0;

gdjs.audio_95manager_95winCode.GDnameObjects1= [];
gdjs.audio_95manager_95winCode.GDnameObjects2= [];
gdjs.audio_95manager_95winCode.GDnameObjects3= [];
gdjs.audio_95manager_95winCode.GDinfoObjects1= [];
gdjs.audio_95manager_95winCode.GDinfoObjects2= [];
gdjs.audio_95manager_95winCode.GDinfoObjects3= [];
gdjs.audio_95manager_95winCode.GDaddObjects1= [];
gdjs.audio_95manager_95winCode.GDaddObjects2= [];
gdjs.audio_95manager_95winCode.GDaddObjects3= [];
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects1= [];
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects2= [];
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects3= [];
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects1= [];
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects2= [];
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects3= [];
gdjs.audio_95manager_95winCode.GDname2Objects1= [];
gdjs.audio_95manager_95winCode.GDname2Objects2= [];
gdjs.audio_95manager_95winCode.GDname2Objects3= [];
gdjs.audio_95manager_95winCode.GDioiObjects1= [];
gdjs.audio_95manager_95winCode.GDioiObjects2= [];
gdjs.audio_95manager_95winCode.GDioiObjects3= [];
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects1= [];
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects2= [];
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects3= [];
gdjs.audio_95manager_95winCode.GDokObjects1= [];
gdjs.audio_95manager_95winCode.GDokObjects2= [];
gdjs.audio_95manager_95winCode.GDokObjects3= [];
gdjs.audio_95manager_95winCode.GDcancObjects1= [];
gdjs.audio_95manager_95winCode.GDcancObjects2= [];
gdjs.audio_95manager_95winCode.GDcancObjects3= [];
gdjs.audio_95manager_95winCode.GDpaintObjects1= [];
gdjs.audio_95manager_95winCode.GDpaintObjects2= [];
gdjs.audio_95manager_95winCode.GDpaintObjects3= [];
gdjs.audio_95manager_95winCode.GDname3Objects1= [];
gdjs.audio_95manager_95winCode.GDname3Objects2= [];
gdjs.audio_95manager_95winCode.GDname3Objects3= [];
gdjs.audio_95manager_95winCode.GDpanelObjects1= [];
gdjs.audio_95manager_95winCode.GDpanelObjects2= [];
gdjs.audio_95manager_95winCode.GDpanelObjects3= [];
gdjs.audio_95manager_95winCode.GDsprrObjects1= [];
gdjs.audio_95manager_95winCode.GDsprrObjects2= [];
gdjs.audio_95manager_95winCode.GDsprrObjects3= [];
gdjs.audio_95manager_95winCode.GDpanel2Objects1= [];
gdjs.audio_95manager_95winCode.GDpanel2Objects2= [];
gdjs.audio_95manager_95winCode.GDpanel2Objects3= [];
gdjs.audio_95manager_95winCode.GDfkObjects1= [];
gdjs.audio_95manager_95winCode.GDfkObjects2= [];
gdjs.audio_95manager_95winCode.GDfkObjects3= [];
gdjs.audio_95manager_95winCode.GDjjObjects1= [];
gdjs.audio_95manager_95winCode.GDjjObjects2= [];
gdjs.audio_95manager_95winCode.GDjjObjects3= [];
gdjs.audio_95manager_95winCode.GDlogoObjects1= [];
gdjs.audio_95manager_95winCode.GDlogoObjects2= [];
gdjs.audio_95manager_95winCode.GDlogoObjects3= [];
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects1= [];
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects2= [];
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects3= [];
gdjs.audio_95manager_95winCode.GDbackObjects1= [];
gdjs.audio_95manager_95winCode.GDbackObjects2= [];
gdjs.audio_95manager_95winCode.GDbackObjects3= [];
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects1= [];
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects2= [];
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects3= [];
gdjs.audio_95manager_95winCode.GDNewSpriteObjects1= [];
gdjs.audio_95manager_95winCode.GDNewSpriteObjects2= [];
gdjs.audio_95manager_95winCode.GDNewSpriteObjects3= [];
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects1= [];
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects2= [];
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects3= [];


gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDaddObjects2Objects = Hashtable.newFrom({"add": gdjs.audio_95manager_95winCode.GDaddObjects2});
gdjs.audio_95manager_95winCode.eventsList0 = function(runtimeScene) {

{



}


};gdjs.audio_95manager_95winCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "prompt"));
}
if (isConditionTrue_0) {
{gdjs.evtsExt__load_audio__file_loader.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.audio_95manager_95winCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.audio_95manager_95winCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.audio_95manager_95winCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.audio_95manager_95winCode.GDaddObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDaddObjects2Objects, runtimeScene, false, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95winCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.audio_95manager_95winCode.localVariables[0].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95winCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


};gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDname2Objects1Objects = Hashtable.newFrom({"name2": gdjs.audio_95manager_95winCode.GDname2Objects1});
gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDokObjects1Objects = Hashtable.newFrom({"ok": gdjs.audio_95manager_95winCode.GDokObjects1});
gdjs.audio_95manager_95winCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mse_win", false);
}}

}


};gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDcancObjects1Objects = Hashtable.newFrom({"canc": gdjs.audio_95manager_95winCode.GDcancObjects1});
gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDpanel2Objects3Objects = Hashtable.newFrom({"panel2": gdjs.audio_95manager_95winCode.GDpanel2Objects3});
gdjs.audio_95manager_95winCode.eventsList5 = function(runtimeScene) {

};gdjs.audio_95manager_95winCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.audio_95manager_95winCode.GDname2Objects2);

for (gdjs.audio_95manager_95winCode.forEachIndex3 = 0;gdjs.audio_95manager_95winCode.forEachIndex3 < gdjs.audio_95manager_95winCode.GDname2Objects2.length;++gdjs.audio_95manager_95winCode.forEachIndex3) {
gdjs.audio_95manager_95winCode.GDpanel2Objects3.length = 0;

gdjs.audio_95manager_95winCode.GDname2Objects3.length = 0;


gdjs.audio_95manager_95winCode.forEachTemporary3 = gdjs.audio_95manager_95winCode.GDname2Objects2[gdjs.audio_95manager_95winCode.forEachIndex3];
gdjs.audio_95manager_95winCode.GDname2Objects3.push(gdjs.audio_95manager_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDpanel2Objects3Objects, (( gdjs.audio_95manager_95winCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects3[0].getX()), (( gdjs.audio_95manager_95winCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects3[0].getY()), "prompt");
}{for(var i = 0, len = gdjs.audio_95manager_95winCode.GDpanel2Objects3.length ;i < len;++i) {
    gdjs.audio_95manager_95winCode.GDpanel2Objects3[i].getBehavior("Resizable").setSize((( gdjs.audio_95manager_95winCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects3[0].getWidth()), (( gdjs.audio_95manager_95winCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects3[0].getHeight()));
}
}{for(var i = 0, len = gdjs.audio_95manager_95winCode.GDpanel2Objects3.length ;i < len;++i) {
    gdjs.audio_95manager_95winCode.GDpanel2Objects3[i].setZOrder((( gdjs.audio_95manager_95winCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects3[0].getZOrder()) + 1);
}
}}
}

}


{



}


};gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDbackObjects1Objects = Hashtable.newFrom({"back": gdjs.audio_95manager_95winCode.GDbackObjects1});
gdjs.audio_95manager_95winCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.audio_95manager_95winCode.GDaddObjects1);
gdjs.copyArray(runtimeScene.getObjects("add_txt"), gdjs.audio_95manager_95winCode.GDadd_9595txtObjects1);
{for(var i = 0, len = gdjs.audio_95manager_95winCode.GDadd_9595txtObjects1.length ;i < len;++i) {
    gdjs.audio_95manager_95winCode.GDadd_9595txtObjects1[i].setCenterPositionInScene((( gdjs.audio_95manager_95winCode.GDaddObjects1.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDaddObjects1[0].getCenterXInScene()),(( gdjs.audio_95manager_95winCode.GDaddObjects1.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDaddObjects1[0].getCenterYInScene()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("temp", variable);
}
gdjs.audio_95manager_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.audio_95manager_95winCode.eventsList3(runtimeScene);} //End of subevents
}
gdjs.audio_95manager_95winCode.localVariables.pop();

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.audio_95manager_95winCode.GDname2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDname2Objects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
/* Reuse gdjs.audio_95manager_95winCode.GDname2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("paint"), gdjs.audio_95manager_95winCode.GDpaintObjects1);
{for(var i = 0, len = gdjs.audio_95manager_95winCode.GDpaintObjects1.length ;i < len;++i) {
    gdjs.audio_95manager_95winCode.GDpaintObjects1[i].drawRectangle((( gdjs.audio_95manager_95winCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects1[0].getX()), (( gdjs.audio_95manager_95winCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects1[0].getY()), (( gdjs.audio_95manager_95winCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects1[0].getX()) + (( gdjs.audio_95manager_95winCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects1[0].getWidth()), (( gdjs.audio_95manager_95winCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects1[0].getY()) + (( gdjs.audio_95manager_95winCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95winCode.GDname2Objects1[0].getHeight()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ok"), gdjs.audio_95manager_95winCode.GDokObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDokObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95winCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("canc"), gdjs.audio_95manager_95winCode.GDcancObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDcancObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "audio_manager_win", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString()) > 20);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "prompt");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95winCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.audio_95manager_95winCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95winCode.mapOfGDgdjs_9546audio_959595manager_959595winCode_9546GDbackObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "prompt"));
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};

gdjs.audio_95manager_95winCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.audio_95manager_95winCode.GDnameObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDnameObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDnameObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDinfoObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDinfoObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDinfoObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDaddObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDaddObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDaddObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDname2Objects1.length = 0;
gdjs.audio_95manager_95winCode.GDname2Objects2.length = 0;
gdjs.audio_95manager_95winCode.GDname2Objects3.length = 0;
gdjs.audio_95manager_95winCode.GDioiObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDioiObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDioiObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDokObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDokObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDokObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDcancObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDcancObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDcancObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDpaintObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDpaintObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDpaintObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDname3Objects1.length = 0;
gdjs.audio_95manager_95winCode.GDname3Objects2.length = 0;
gdjs.audio_95manager_95winCode.GDname3Objects3.length = 0;
gdjs.audio_95manager_95winCode.GDpanelObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDpanelObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDpanelObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDsprrObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDsprrObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDsprrObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDpanel2Objects1.length = 0;
gdjs.audio_95manager_95winCode.GDpanel2Objects2.length = 0;
gdjs.audio_95manager_95winCode.GDpanel2Objects3.length = 0;
gdjs.audio_95manager_95winCode.GDfkObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDfkObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDfkObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDjjObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDjjObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDjjObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDlogoObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDlogoObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDlogoObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects1.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects2.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects3.length = 0;
gdjs.audio_95manager_95winCode.GDbackObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDbackObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDbackObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDNewSpriteObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDNewSpriteObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDNewSpriteObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects3.length = 0;

gdjs.audio_95manager_95winCode.eventsList7(runtimeScene);
gdjs.audio_95manager_95winCode.GDnameObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDnameObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDnameObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDinfoObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDinfoObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDinfoObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDaddObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDaddObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDaddObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595txtObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDsave_9595iconObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDname2Objects1.length = 0;
gdjs.audio_95manager_95winCode.GDname2Objects2.length = 0;
gdjs.audio_95manager_95winCode.GDname2Objects3.length = 0;
gdjs.audio_95manager_95winCode.GDioiObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDioiObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDioiObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eveObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDokObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDokObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDokObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDcancObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDcancObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDcancObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDpaintObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDpaintObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDpaintObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDname3Objects1.length = 0;
gdjs.audio_95manager_95winCode.GDname3Objects2.length = 0;
gdjs.audio_95manager_95winCode.GDname3Objects3.length = 0;
gdjs.audio_95manager_95winCode.GDpanelObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDpanelObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDpanelObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDsprrObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDsprrObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDsprrObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDpanel2Objects1.length = 0;
gdjs.audio_95manager_95winCode.GDpanel2Objects2.length = 0;
gdjs.audio_95manager_95winCode.GDpanel2Objects3.length = 0;
gdjs.audio_95manager_95winCode.GDfkObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDfkObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDfkObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDjjObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDjjObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDjjObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDlogoObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDlogoObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDlogoObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects1.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects2.length = 0;
gdjs.audio_95manager_95winCode.GDadd_9595eve2Objects3.length = 0;
gdjs.audio_95manager_95winCode.GDbackObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDbackObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDbackObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDbutton_9595bgObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDNewSpriteObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDNewSpriteObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDNewSpriteObjects3.length = 0;
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects1.length = 0;
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects2.length = 0;
gdjs.audio_95manager_95winCode.GDaudio_9595selectorObjects3.length = 0;


return;

}

gdjs['audio_95manager_95winCode'] = gdjs.audio_95manager_95winCode;
