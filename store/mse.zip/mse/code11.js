gdjs.equalizadorCode = {};
gdjs.equalizadorCode.localVariables = [];
gdjs.equalizadorCode.forEachIndex4 = 0;

gdjs.equalizadorCode.forEachObjects4 = [];

gdjs.equalizadorCode.forEachTemporary4 = null;

gdjs.equalizadorCode.forEachTotalCount4 = 0;

gdjs.equalizadorCode.GDbar1Objects1= [];
gdjs.equalizadorCode.GDbar1Objects2= [];
gdjs.equalizadorCode.GDbar1Objects3= [];
gdjs.equalizadorCode.GDbar1Objects4= [];
gdjs.equalizadorCode.GDbar1Objects5= [];
gdjs.equalizadorCode.GDbar1Objects6= [];
gdjs.equalizadorCode.GDbar2Objects1= [];
gdjs.equalizadorCode.GDbar2Objects2= [];
gdjs.equalizadorCode.GDbar2Objects3= [];
gdjs.equalizadorCode.GDbar2Objects4= [];
gdjs.equalizadorCode.GDbar2Objects5= [];
gdjs.equalizadorCode.GDbar2Objects6= [];
gdjs.equalizadorCode.GDinfoObjects1= [];
gdjs.equalizadorCode.GDinfoObjects2= [];
gdjs.equalizadorCode.GDinfoObjects3= [];
gdjs.equalizadorCode.GDinfoObjects4= [];
gdjs.equalizadorCode.GDinfoObjects5= [];
gdjs.equalizadorCode.GDinfoObjects6= [];
gdjs.equalizadorCode.GDYoutubeObjects1= [];
gdjs.equalizadorCode.GDYoutubeObjects2= [];
gdjs.equalizadorCode.GDYoutubeObjects3= [];
gdjs.equalizadorCode.GDYoutubeObjects4= [];
gdjs.equalizadorCode.GDYoutubeObjects5= [];
gdjs.equalizadorCode.GDYoutubeObjects6= [];
gdjs.equalizadorCode.GDinfo2Objects1= [];
gdjs.equalizadorCode.GDinfo2Objects2= [];
gdjs.equalizadorCode.GDinfo2Objects3= [];
gdjs.equalizadorCode.GDinfo2Objects4= [];
gdjs.equalizadorCode.GDinfo2Objects5= [];
gdjs.equalizadorCode.GDinfo2Objects6= [];
gdjs.equalizadorCode.GDblancoObjects1= [];
gdjs.equalizadorCode.GDblancoObjects2= [];
gdjs.equalizadorCode.GDblancoObjects3= [];
gdjs.equalizadorCode.GDblancoObjects4= [];
gdjs.equalizadorCode.GDblancoObjects5= [];
gdjs.equalizadorCode.GDblancoObjects6= [];
gdjs.equalizadorCode.GDNew3DModelObjects1= [];
gdjs.equalizadorCode.GDNew3DModelObjects2= [];
gdjs.equalizadorCode.GDNew3DModelObjects3= [];
gdjs.equalizadorCode.GDNew3DModelObjects4= [];
gdjs.equalizadorCode.GDNew3DModelObjects5= [];
gdjs.equalizadorCode.GDNew3DModelObjects6= [];
gdjs.equalizadorCode.GDbar3Objects1= [];
gdjs.equalizadorCode.GDbar3Objects2= [];
gdjs.equalizadorCode.GDbar3Objects3= [];
gdjs.equalizadorCode.GDbar3Objects4= [];
gdjs.equalizadorCode.GDbar3Objects5= [];
gdjs.equalizadorCode.GDbar3Objects6= [];
gdjs.equalizadorCode.GDbar4Objects1= [];
gdjs.equalizadorCode.GDbar4Objects2= [];
gdjs.equalizadorCode.GDbar4Objects3= [];
gdjs.equalizadorCode.GDbar4Objects4= [];
gdjs.equalizadorCode.GDbar4Objects5= [];
gdjs.equalizadorCode.GDbar4Objects6= [];
gdjs.equalizadorCode.GDbar5Objects1= [];
gdjs.equalizadorCode.GDbar5Objects2= [];
gdjs.equalizadorCode.GDbar5Objects3= [];
gdjs.equalizadorCode.GDbar5Objects4= [];
gdjs.equalizadorCode.GDbar5Objects5= [];
gdjs.equalizadorCode.GDbar5Objects6= [];
gdjs.equalizadorCode.GDbar6Objects1= [];
gdjs.equalizadorCode.GDbar6Objects2= [];
gdjs.equalizadorCode.GDbar6Objects3= [];
gdjs.equalizadorCode.GDbar6Objects4= [];
gdjs.equalizadorCode.GDbar6Objects5= [];
gdjs.equalizadorCode.GDbar6Objects6= [];
gdjs.equalizadorCode.GDbar7Objects1= [];
gdjs.equalizadorCode.GDbar7Objects2= [];
gdjs.equalizadorCode.GDbar7Objects3= [];
gdjs.equalizadorCode.GDbar7Objects4= [];
gdjs.equalizadorCode.GDbar7Objects5= [];
gdjs.equalizadorCode.GDbar7Objects6= [];
gdjs.equalizadorCode.GDbar8Objects1= [];
gdjs.equalizadorCode.GDbar8Objects2= [];
gdjs.equalizadorCode.GDbar8Objects3= [];
gdjs.equalizadorCode.GDbar8Objects4= [];
gdjs.equalizadorCode.GDbar8Objects5= [];
gdjs.equalizadorCode.GDbar8Objects6= [];
gdjs.equalizadorCode.GDbar9Objects1= [];
gdjs.equalizadorCode.GDbar9Objects2= [];
gdjs.equalizadorCode.GDbar9Objects3= [];
gdjs.equalizadorCode.GDbar9Objects4= [];
gdjs.equalizadorCode.GDbar9Objects5= [];
gdjs.equalizadorCode.GDbar9Objects6= [];
gdjs.equalizadorCode.GDbar10Objects1= [];
gdjs.equalizadorCode.GDbar10Objects2= [];
gdjs.equalizadorCode.GDbar10Objects3= [];
gdjs.equalizadorCode.GDbar10Objects4= [];
gdjs.equalizadorCode.GDbar10Objects5= [];
gdjs.equalizadorCode.GDbar10Objects6= [];
gdjs.equalizadorCode.GDdebugObjects1= [];
gdjs.equalizadorCode.GDdebugObjects2= [];
gdjs.equalizadorCode.GDdebugObjects3= [];
gdjs.equalizadorCode.GDdebugObjects4= [];
gdjs.equalizadorCode.GDdebugObjects5= [];
gdjs.equalizadorCode.GDdebugObjects6= [];
gdjs.equalizadorCode.GDtiiObjects1= [];
gdjs.equalizadorCode.GDtiiObjects2= [];
gdjs.equalizadorCode.GDtiiObjects3= [];
gdjs.equalizadorCode.GDtiiObjects4= [];
gdjs.equalizadorCode.GDtiiObjects5= [];
gdjs.equalizadorCode.GDtiiObjects6= [];
gdjs.equalizadorCode.GDinfo3Objects1= [];
gdjs.equalizadorCode.GDinfo3Objects2= [];
gdjs.equalizadorCode.GDinfo3Objects3= [];
gdjs.equalizadorCode.GDinfo3Objects4= [];
gdjs.equalizadorCode.GDinfo3Objects5= [];
gdjs.equalizadorCode.GDinfo3Objects6= [];
gdjs.equalizadorCode.GDiiiiObjects1= [];
gdjs.equalizadorCode.GDiiiiObjects2= [];
gdjs.equalizadorCode.GDiiiiObjects3= [];
gdjs.equalizadorCode.GDiiiiObjects4= [];
gdjs.equalizadorCode.GDiiiiObjects5= [];
gdjs.equalizadorCode.GDiiiiObjects6= [];
gdjs.equalizadorCode.GDNewPanelSpriteObjects1= [];
gdjs.equalizadorCode.GDNewPanelSpriteObjects2= [];
gdjs.equalizadorCode.GDNewPanelSpriteObjects3= [];
gdjs.equalizadorCode.GDNewPanelSpriteObjects4= [];
gdjs.equalizadorCode.GDNewPanelSpriteObjects5= [];
gdjs.equalizadorCode.GDNewPanelSpriteObjects6= [];
gdjs.equalizadorCode.GDleastObjects1= [];
gdjs.equalizadorCode.GDleastObjects2= [];
gdjs.equalizadorCode.GDleastObjects3= [];
gdjs.equalizadorCode.GDleastObjects4= [];
gdjs.equalizadorCode.GDleastObjects5= [];
gdjs.equalizadorCode.GDleastObjects6= [];
gdjs.equalizadorCode.GDmaxObjects1= [];
gdjs.equalizadorCode.GDmaxObjects2= [];
gdjs.equalizadorCode.GDmaxObjects3= [];
gdjs.equalizadorCode.GDmaxObjects4= [];
gdjs.equalizadorCode.GDmaxObjects5= [];
gdjs.equalizadorCode.GDmaxObjects6= [];


gdjs.equalizadorCode.userFunc0x11f9a00 = function GDJSInlineCode(runtimeScene) {
"use strict";
// Create an Audio Context
var audioContext = new (window.AudioContext || window.webkitAudioContext)();
var audio = new Audio(runtimeScene.getGame().getVariables().get("data").getChildNamed('audio').getAsString());
var track = audioContext.createMediaElementSource(audio);

// Create an AnalyserNode
var analyser = audioContext.createAnalyser();
track.connect(analyser);
analyser.connect(audioContext.destination);

// Set up frequency data array
analyser.fftSize = 256;
var bufferLength = analyser.frequencyBinCount;
var dataArray = new Uint8Array(bufferLength);


// Analyze and update GDevelop variable
function updateVisualization() {
    analyser.getByteFrequencyData(dataArray);
    var waveHeight = dataArray[0];  // Use the first frequency bin (or average)
    runtimeScene.getVariables().get("WaveHeight").setNumber(waveHeight);
    
    // Call this function repeatedly
    requestAnimationFrame(updateVisualization);
}
function playAndPause(){
    if(runtimeScene.getVariables().get("state").getAsString() === "p"){
    audio.play()
    runtimeScene.getVariables().get("state").setString("")
    }
    if(runtimeScene.getVariables().get("state").getAsString() === "n"){
    audio.pause()
    }
    runtimeScene.getVariables().get('ct').setNumber(audio.currentTime)
    requestAnimationFrame(playAndPause)
}
playAndPause()
updateVisualization()




var ssss = "file:///C:/Users/jijijm/Music/Alan_Walker_-_Darkside_(Jesusful.com).mp3"
};
gdjs.equalizadorCode.eventsList0 = function(runtimeScene) {

{


gdjs.equalizadorCode.userFunc0x11f9a00(runtimeScene);

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("tii"), gdjs.equalizadorCode.GDtiiObjects1);
{for(var i = 0, len = gdjs.equalizadorCode.GDtiiObjects1.length ;i < len;++i) {
    gdjs.equalizadorCode.GDtiiObjects1[i].getBehavior("Resizable").setWidth(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber());
}
}}

}


};gdjs.equalizadorCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDtiiObjects1Objects = Hashtable.newFrom({"tii": gdjs.equalizadorCode.GDtiiObjects1});
gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects1Objects = Hashtable.newFrom({"bar10": gdjs.equalizadorCode.GDbar10Objects1});
gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects1Objects = Hashtable.newFrom({"bar10": gdjs.equalizadorCode.GDbar10Objects1});
gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects1Objects = Hashtable.newFrom({"bar10": gdjs.equalizadorCode.GDbar10Objects1});
gdjs.equalizadorCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("least"), gdjs.equalizadorCode.GDleastObjects1);
gdjs.copyArray(runtimeScene.getObjects("max"), gdjs.equalizadorCode.GDmaxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > gdjs.evtTools.common.toNumber((( gdjs.equalizadorCode.GDleastObjects1.length === 0 ) ? "" :gdjs.equalizadorCode.GDleastObjects1[0].getBehavior("Text").getText())));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() < gdjs.evtTools.common.toNumber((( gdjs.equalizadorCode.GDmaxObjects1.length === 0 ) ? "" :gdjs.equalizadorCode.GDmaxObjects1[0].getBehavior("Text").getText())));
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.equalizadorCode.GDtiiObjects1 */
/* Reuse gdjs.equalizadorCode.GDbar10Objects1 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects1Objects, (( gdjs.equalizadorCode.GDtiiObjects1.length === 0 ) ? 0 :gdjs.equalizadorCode.GDtiiObjects1[0].getPointX("")), (( gdjs.equalizadorCode.GDtiiObjects1.length === 0 ) ? 0 :gdjs.equalizadorCode.GDtiiObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.equalizadorCode.GDbar10Objects1.length ;i < len;++i) {
    gdjs.equalizadorCode.GDbar10Objects1[i].getBehavior("Resizable").setWidth(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber());
}
}{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects1Objects, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber(), 96, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects1Objects = Hashtable.newFrom({"bar10": gdjs.equalizadorCode.GDbar10Objects1});
gdjs.equalizadorCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mse_win", false);
}}

}


};gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects4Objects = Hashtable.newFrom({"bar10": gdjs.equalizadorCode.GDbar10Objects4});
gdjs.equalizadorCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects4Objects) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(2));
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.equalizadorCode.eventsList5 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(runtimeScene.getObjects("bar10"), gdjs.equalizadorCode.GDbar10Objects3);

for (gdjs.equalizadorCode.forEachIndex4 = 0;gdjs.equalizadorCode.forEachIndex4 < gdjs.equalizadorCode.GDbar10Objects3.length;++gdjs.equalizadorCode.forEachIndex4) {
gdjs.equalizadorCode.GDbar10Objects4.length = 0;


gdjs.equalizadorCode.forEachTemporary4 = gdjs.equalizadorCode.GDbar10Objects3[gdjs.equalizadorCode.forEachIndex4];
gdjs.equalizadorCode.GDbar10Objects4.push(gdjs.equalizadorCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getGame().getVariables().getFromIndex(2), (( gdjs.equalizadorCode.GDbar10Objects4.length === 0 ) ? 0 :gdjs.equalizadorCode.GDbar10Objects4[0].getPointX("")));
}
{ //Subevents: 
gdjs.equalizadorCode.eventsList4(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.equalizadorCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() == gdjs.equalizadorCode.localVariables[0].getFromIndex(0).getAsNumber());
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "process");
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(2));
}{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(true);
}
{ //Subevents
gdjs.equalizadorCode.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.equalizadorCode.asyncCallback23643628 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.equalizadorCode.localVariables);

{ //Subevents
gdjs.equalizadorCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.equalizadorCode.localVariables.length = 0;
}
gdjs.equalizadorCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.equalizadorCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.equalizadorCode.asyncCallback23643628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.equalizadorCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.equalizadorCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("n");
}
{ //Subevents
gdjs.equalizadorCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("bar1"), gdjs.equalizadorCode.GDbar1Objects1);
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.equalizadorCode.GDdebugObjects1);
{for(var i = 0, len = gdjs.equalizadorCode.GDbar1Objects1.length ;i < len;++i) {
    gdjs.equalizadorCode.GDbar1Objects1[i].getBehavior("Resizable").setHeight(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}{for(var i = 0, len = gdjs.equalizadorCode.GDbar1Objects1.length ;i < len;++i) {
    gdjs.equalizadorCode.GDbar1Objects1[i].setY(463 - (gdjs.equalizadorCode.GDbar1Objects1[i].getHeight()));
}
}{for(var i = 0, len = gdjs.equalizadorCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.equalizadorCode.GDdebugObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(2).getAsString() + gdjs.evtTools.string.newLine() + gdjs.evtTools.common.toString(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bar10"), gdjs.equalizadorCode.GDbar10Objects1);
gdjs.copyArray(runtimeScene.getObjects("tii"), gdjs.equalizadorCode.GDtiiObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDtiiObjects1Objects, gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.equalizadorCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("bar10"), gdjs.equalizadorCode.GDbar10Objects1);
gdjs.copyArray(runtimeScene.getObjects("tii"), gdjs.equalizadorCode.GDtiiObjects1);
{for(var i = 0, len = gdjs.equalizadorCode.GDtiiObjects1.length ;i < len;++i) {
    gdjs.equalizadorCode.GDtiiObjects1[i].setX(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() * 50);
}
}{for(var i = 0, len = gdjs.equalizadorCode.GDtiiObjects1.length ;i < len;++i) {
    gdjs.equalizadorCode.GDtiiObjects1[i].getBehavior("Resizable").setWidth(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber());
}
}{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.equalizadorCode.mapOfGDgdjs_9546equalizadorCode_9546GDbar10Objects1Objects, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber(), 96, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.equalizadorCode.GDtiiObjects1.length !== 0 ? gdjs.equalizadorCode.GDtiiObjects1[0] : null), true, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setString("n");
}
{ //Subevents
gdjs.equalizadorCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("rct", variable);
}
gdjs.equalizadorCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() > gdjs.equalizadorCode.localVariables[0].getFromIndex(0).getAsNumber());
}
if (isConditionTrue_0) {
{gdjs.equalizadorCode.localVariables[0].getFromIndex(0).setNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber());
}
{ //Subevents
gdjs.equalizadorCode.eventsList7(runtimeScene);} //End of subevents
}
gdjs.equalizadorCode.localVariables.pop();

}


};

gdjs.equalizadorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.equalizadorCode.GDbar1Objects1.length = 0;
gdjs.equalizadorCode.GDbar1Objects2.length = 0;
gdjs.equalizadorCode.GDbar1Objects3.length = 0;
gdjs.equalizadorCode.GDbar1Objects4.length = 0;
gdjs.equalizadorCode.GDbar1Objects5.length = 0;
gdjs.equalizadorCode.GDbar1Objects6.length = 0;
gdjs.equalizadorCode.GDbar2Objects1.length = 0;
gdjs.equalizadorCode.GDbar2Objects2.length = 0;
gdjs.equalizadorCode.GDbar2Objects3.length = 0;
gdjs.equalizadorCode.GDbar2Objects4.length = 0;
gdjs.equalizadorCode.GDbar2Objects5.length = 0;
gdjs.equalizadorCode.GDbar2Objects6.length = 0;
gdjs.equalizadorCode.GDinfoObjects1.length = 0;
gdjs.equalizadorCode.GDinfoObjects2.length = 0;
gdjs.equalizadorCode.GDinfoObjects3.length = 0;
gdjs.equalizadorCode.GDinfoObjects4.length = 0;
gdjs.equalizadorCode.GDinfoObjects5.length = 0;
gdjs.equalizadorCode.GDinfoObjects6.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects1.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects2.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects3.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects4.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects5.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects6.length = 0;
gdjs.equalizadorCode.GDinfo2Objects1.length = 0;
gdjs.equalizadorCode.GDinfo2Objects2.length = 0;
gdjs.equalizadorCode.GDinfo2Objects3.length = 0;
gdjs.equalizadorCode.GDinfo2Objects4.length = 0;
gdjs.equalizadorCode.GDinfo2Objects5.length = 0;
gdjs.equalizadorCode.GDinfo2Objects6.length = 0;
gdjs.equalizadorCode.GDblancoObjects1.length = 0;
gdjs.equalizadorCode.GDblancoObjects2.length = 0;
gdjs.equalizadorCode.GDblancoObjects3.length = 0;
gdjs.equalizadorCode.GDblancoObjects4.length = 0;
gdjs.equalizadorCode.GDblancoObjects5.length = 0;
gdjs.equalizadorCode.GDblancoObjects6.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects1.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects2.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects3.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects4.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects5.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects6.length = 0;
gdjs.equalizadorCode.GDbar3Objects1.length = 0;
gdjs.equalizadorCode.GDbar3Objects2.length = 0;
gdjs.equalizadorCode.GDbar3Objects3.length = 0;
gdjs.equalizadorCode.GDbar3Objects4.length = 0;
gdjs.equalizadorCode.GDbar3Objects5.length = 0;
gdjs.equalizadorCode.GDbar3Objects6.length = 0;
gdjs.equalizadorCode.GDbar4Objects1.length = 0;
gdjs.equalizadorCode.GDbar4Objects2.length = 0;
gdjs.equalizadorCode.GDbar4Objects3.length = 0;
gdjs.equalizadorCode.GDbar4Objects4.length = 0;
gdjs.equalizadorCode.GDbar4Objects5.length = 0;
gdjs.equalizadorCode.GDbar4Objects6.length = 0;
gdjs.equalizadorCode.GDbar5Objects1.length = 0;
gdjs.equalizadorCode.GDbar5Objects2.length = 0;
gdjs.equalizadorCode.GDbar5Objects3.length = 0;
gdjs.equalizadorCode.GDbar5Objects4.length = 0;
gdjs.equalizadorCode.GDbar5Objects5.length = 0;
gdjs.equalizadorCode.GDbar5Objects6.length = 0;
gdjs.equalizadorCode.GDbar6Objects1.length = 0;
gdjs.equalizadorCode.GDbar6Objects2.length = 0;
gdjs.equalizadorCode.GDbar6Objects3.length = 0;
gdjs.equalizadorCode.GDbar6Objects4.length = 0;
gdjs.equalizadorCode.GDbar6Objects5.length = 0;
gdjs.equalizadorCode.GDbar6Objects6.length = 0;
gdjs.equalizadorCode.GDbar7Objects1.length = 0;
gdjs.equalizadorCode.GDbar7Objects2.length = 0;
gdjs.equalizadorCode.GDbar7Objects3.length = 0;
gdjs.equalizadorCode.GDbar7Objects4.length = 0;
gdjs.equalizadorCode.GDbar7Objects5.length = 0;
gdjs.equalizadorCode.GDbar7Objects6.length = 0;
gdjs.equalizadorCode.GDbar8Objects1.length = 0;
gdjs.equalizadorCode.GDbar8Objects2.length = 0;
gdjs.equalizadorCode.GDbar8Objects3.length = 0;
gdjs.equalizadorCode.GDbar8Objects4.length = 0;
gdjs.equalizadorCode.GDbar8Objects5.length = 0;
gdjs.equalizadorCode.GDbar8Objects6.length = 0;
gdjs.equalizadorCode.GDbar9Objects1.length = 0;
gdjs.equalizadorCode.GDbar9Objects2.length = 0;
gdjs.equalizadorCode.GDbar9Objects3.length = 0;
gdjs.equalizadorCode.GDbar9Objects4.length = 0;
gdjs.equalizadorCode.GDbar9Objects5.length = 0;
gdjs.equalizadorCode.GDbar9Objects6.length = 0;
gdjs.equalizadorCode.GDbar10Objects1.length = 0;
gdjs.equalizadorCode.GDbar10Objects2.length = 0;
gdjs.equalizadorCode.GDbar10Objects3.length = 0;
gdjs.equalizadorCode.GDbar10Objects4.length = 0;
gdjs.equalizadorCode.GDbar10Objects5.length = 0;
gdjs.equalizadorCode.GDbar10Objects6.length = 0;
gdjs.equalizadorCode.GDdebugObjects1.length = 0;
gdjs.equalizadorCode.GDdebugObjects2.length = 0;
gdjs.equalizadorCode.GDdebugObjects3.length = 0;
gdjs.equalizadorCode.GDdebugObjects4.length = 0;
gdjs.equalizadorCode.GDdebugObjects5.length = 0;
gdjs.equalizadorCode.GDdebugObjects6.length = 0;
gdjs.equalizadorCode.GDtiiObjects1.length = 0;
gdjs.equalizadorCode.GDtiiObjects2.length = 0;
gdjs.equalizadorCode.GDtiiObjects3.length = 0;
gdjs.equalizadorCode.GDtiiObjects4.length = 0;
gdjs.equalizadorCode.GDtiiObjects5.length = 0;
gdjs.equalizadorCode.GDtiiObjects6.length = 0;
gdjs.equalizadorCode.GDinfo3Objects1.length = 0;
gdjs.equalizadorCode.GDinfo3Objects2.length = 0;
gdjs.equalizadorCode.GDinfo3Objects3.length = 0;
gdjs.equalizadorCode.GDinfo3Objects4.length = 0;
gdjs.equalizadorCode.GDinfo3Objects5.length = 0;
gdjs.equalizadorCode.GDinfo3Objects6.length = 0;
gdjs.equalizadorCode.GDiiiiObjects1.length = 0;
gdjs.equalizadorCode.GDiiiiObjects2.length = 0;
gdjs.equalizadorCode.GDiiiiObjects3.length = 0;
gdjs.equalizadorCode.GDiiiiObjects4.length = 0;
gdjs.equalizadorCode.GDiiiiObjects5.length = 0;
gdjs.equalizadorCode.GDiiiiObjects6.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects3.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects4.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects5.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects6.length = 0;
gdjs.equalizadorCode.GDleastObjects1.length = 0;
gdjs.equalizadorCode.GDleastObjects2.length = 0;
gdjs.equalizadorCode.GDleastObjects3.length = 0;
gdjs.equalizadorCode.GDleastObjects4.length = 0;
gdjs.equalizadorCode.GDleastObjects5.length = 0;
gdjs.equalizadorCode.GDleastObjects6.length = 0;
gdjs.equalizadorCode.GDmaxObjects1.length = 0;
gdjs.equalizadorCode.GDmaxObjects2.length = 0;
gdjs.equalizadorCode.GDmaxObjects3.length = 0;
gdjs.equalizadorCode.GDmaxObjects4.length = 0;
gdjs.equalizadorCode.GDmaxObjects5.length = 0;
gdjs.equalizadorCode.GDmaxObjects6.length = 0;

gdjs.equalizadorCode.eventsList8(runtimeScene);
gdjs.equalizadorCode.GDbar1Objects1.length = 0;
gdjs.equalizadorCode.GDbar1Objects2.length = 0;
gdjs.equalizadorCode.GDbar1Objects3.length = 0;
gdjs.equalizadorCode.GDbar1Objects4.length = 0;
gdjs.equalizadorCode.GDbar1Objects5.length = 0;
gdjs.equalizadorCode.GDbar1Objects6.length = 0;
gdjs.equalizadorCode.GDbar2Objects1.length = 0;
gdjs.equalizadorCode.GDbar2Objects2.length = 0;
gdjs.equalizadorCode.GDbar2Objects3.length = 0;
gdjs.equalizadorCode.GDbar2Objects4.length = 0;
gdjs.equalizadorCode.GDbar2Objects5.length = 0;
gdjs.equalizadorCode.GDbar2Objects6.length = 0;
gdjs.equalizadorCode.GDinfoObjects1.length = 0;
gdjs.equalizadorCode.GDinfoObjects2.length = 0;
gdjs.equalizadorCode.GDinfoObjects3.length = 0;
gdjs.equalizadorCode.GDinfoObjects4.length = 0;
gdjs.equalizadorCode.GDinfoObjects5.length = 0;
gdjs.equalizadorCode.GDinfoObjects6.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects1.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects2.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects3.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects4.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects5.length = 0;
gdjs.equalizadorCode.GDYoutubeObjects6.length = 0;
gdjs.equalizadorCode.GDinfo2Objects1.length = 0;
gdjs.equalizadorCode.GDinfo2Objects2.length = 0;
gdjs.equalizadorCode.GDinfo2Objects3.length = 0;
gdjs.equalizadorCode.GDinfo2Objects4.length = 0;
gdjs.equalizadorCode.GDinfo2Objects5.length = 0;
gdjs.equalizadorCode.GDinfo2Objects6.length = 0;
gdjs.equalizadorCode.GDblancoObjects1.length = 0;
gdjs.equalizadorCode.GDblancoObjects2.length = 0;
gdjs.equalizadorCode.GDblancoObjects3.length = 0;
gdjs.equalizadorCode.GDblancoObjects4.length = 0;
gdjs.equalizadorCode.GDblancoObjects5.length = 0;
gdjs.equalizadorCode.GDblancoObjects6.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects1.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects2.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects3.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects4.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects5.length = 0;
gdjs.equalizadorCode.GDNew3DModelObjects6.length = 0;
gdjs.equalizadorCode.GDbar3Objects1.length = 0;
gdjs.equalizadorCode.GDbar3Objects2.length = 0;
gdjs.equalizadorCode.GDbar3Objects3.length = 0;
gdjs.equalizadorCode.GDbar3Objects4.length = 0;
gdjs.equalizadorCode.GDbar3Objects5.length = 0;
gdjs.equalizadorCode.GDbar3Objects6.length = 0;
gdjs.equalizadorCode.GDbar4Objects1.length = 0;
gdjs.equalizadorCode.GDbar4Objects2.length = 0;
gdjs.equalizadorCode.GDbar4Objects3.length = 0;
gdjs.equalizadorCode.GDbar4Objects4.length = 0;
gdjs.equalizadorCode.GDbar4Objects5.length = 0;
gdjs.equalizadorCode.GDbar4Objects6.length = 0;
gdjs.equalizadorCode.GDbar5Objects1.length = 0;
gdjs.equalizadorCode.GDbar5Objects2.length = 0;
gdjs.equalizadorCode.GDbar5Objects3.length = 0;
gdjs.equalizadorCode.GDbar5Objects4.length = 0;
gdjs.equalizadorCode.GDbar5Objects5.length = 0;
gdjs.equalizadorCode.GDbar5Objects6.length = 0;
gdjs.equalizadorCode.GDbar6Objects1.length = 0;
gdjs.equalizadorCode.GDbar6Objects2.length = 0;
gdjs.equalizadorCode.GDbar6Objects3.length = 0;
gdjs.equalizadorCode.GDbar6Objects4.length = 0;
gdjs.equalizadorCode.GDbar6Objects5.length = 0;
gdjs.equalizadorCode.GDbar6Objects6.length = 0;
gdjs.equalizadorCode.GDbar7Objects1.length = 0;
gdjs.equalizadorCode.GDbar7Objects2.length = 0;
gdjs.equalizadorCode.GDbar7Objects3.length = 0;
gdjs.equalizadorCode.GDbar7Objects4.length = 0;
gdjs.equalizadorCode.GDbar7Objects5.length = 0;
gdjs.equalizadorCode.GDbar7Objects6.length = 0;
gdjs.equalizadorCode.GDbar8Objects1.length = 0;
gdjs.equalizadorCode.GDbar8Objects2.length = 0;
gdjs.equalizadorCode.GDbar8Objects3.length = 0;
gdjs.equalizadorCode.GDbar8Objects4.length = 0;
gdjs.equalizadorCode.GDbar8Objects5.length = 0;
gdjs.equalizadorCode.GDbar8Objects6.length = 0;
gdjs.equalizadorCode.GDbar9Objects1.length = 0;
gdjs.equalizadorCode.GDbar9Objects2.length = 0;
gdjs.equalizadorCode.GDbar9Objects3.length = 0;
gdjs.equalizadorCode.GDbar9Objects4.length = 0;
gdjs.equalizadorCode.GDbar9Objects5.length = 0;
gdjs.equalizadorCode.GDbar9Objects6.length = 0;
gdjs.equalizadorCode.GDbar10Objects1.length = 0;
gdjs.equalizadorCode.GDbar10Objects2.length = 0;
gdjs.equalizadorCode.GDbar10Objects3.length = 0;
gdjs.equalizadorCode.GDbar10Objects4.length = 0;
gdjs.equalizadorCode.GDbar10Objects5.length = 0;
gdjs.equalizadorCode.GDbar10Objects6.length = 0;
gdjs.equalizadorCode.GDdebugObjects1.length = 0;
gdjs.equalizadorCode.GDdebugObjects2.length = 0;
gdjs.equalizadorCode.GDdebugObjects3.length = 0;
gdjs.equalizadorCode.GDdebugObjects4.length = 0;
gdjs.equalizadorCode.GDdebugObjects5.length = 0;
gdjs.equalizadorCode.GDdebugObjects6.length = 0;
gdjs.equalizadorCode.GDtiiObjects1.length = 0;
gdjs.equalizadorCode.GDtiiObjects2.length = 0;
gdjs.equalizadorCode.GDtiiObjects3.length = 0;
gdjs.equalizadorCode.GDtiiObjects4.length = 0;
gdjs.equalizadorCode.GDtiiObjects5.length = 0;
gdjs.equalizadorCode.GDtiiObjects6.length = 0;
gdjs.equalizadorCode.GDinfo3Objects1.length = 0;
gdjs.equalizadorCode.GDinfo3Objects2.length = 0;
gdjs.equalizadorCode.GDinfo3Objects3.length = 0;
gdjs.equalizadorCode.GDinfo3Objects4.length = 0;
gdjs.equalizadorCode.GDinfo3Objects5.length = 0;
gdjs.equalizadorCode.GDinfo3Objects6.length = 0;
gdjs.equalizadorCode.GDiiiiObjects1.length = 0;
gdjs.equalizadorCode.GDiiiiObjects2.length = 0;
gdjs.equalizadorCode.GDiiiiObjects3.length = 0;
gdjs.equalizadorCode.GDiiiiObjects4.length = 0;
gdjs.equalizadorCode.GDiiiiObjects5.length = 0;
gdjs.equalizadorCode.GDiiiiObjects6.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects3.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects4.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects5.length = 0;
gdjs.equalizadorCode.GDNewPanelSpriteObjects6.length = 0;
gdjs.equalizadorCode.GDleastObjects1.length = 0;
gdjs.equalizadorCode.GDleastObjects2.length = 0;
gdjs.equalizadorCode.GDleastObjects3.length = 0;
gdjs.equalizadorCode.GDleastObjects4.length = 0;
gdjs.equalizadorCode.GDleastObjects5.length = 0;
gdjs.equalizadorCode.GDleastObjects6.length = 0;
gdjs.equalizadorCode.GDmaxObjects1.length = 0;
gdjs.equalizadorCode.GDmaxObjects2.length = 0;
gdjs.equalizadorCode.GDmaxObjects3.length = 0;
gdjs.equalizadorCode.GDmaxObjects4.length = 0;
gdjs.equalizadorCode.GDmaxObjects5.length = 0;
gdjs.equalizadorCode.GDmaxObjects6.length = 0;


return;

}

gdjs['equalizadorCode'] = gdjs.equalizadorCode;
