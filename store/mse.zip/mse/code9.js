gdjs.helpCode = {};
gdjs.helpCode.localVariables = [];
gdjs.helpCode.GDfjfObjects1= [];
gdjs.helpCode.GDfjfObjects2= [];
gdjs.helpCode.GDpanel3Objects1= [];
gdjs.helpCode.GDpanel3Objects2= [];
gdjs.helpCode.GDbackObjects1= [];
gdjs.helpCode.GDbackObjects2= [];
gdjs.helpCode.GDsprrObjects1= [];
gdjs.helpCode.GDsprrObjects2= [];
gdjs.helpCode.GDtutObjects1= [];
gdjs.helpCode.GDtutObjects2= [];
gdjs.helpCode.GDproject_9595selectObjects1= [];
gdjs.helpCode.GDproject_9595selectObjects2= [];
gdjs.helpCode.GDbackground_9595boxObjects1= [];
gdjs.helpCode.GDbackground_9595boxObjects2= [];
gdjs.helpCode.GDdoc_9595linkObjects1= [];
gdjs.helpCode.GDdoc_9595linkObjects2= [];
gdjs.helpCode.GDdetailed_9595guide_9595pointerObjects1= [];
gdjs.helpCode.GDdetailed_9595guide_9595pointerObjects2= [];
gdjs.helpCode.GDGUIDEObjects1= [];
gdjs.helpCode.GDGUIDEObjects2= [];
gdjs.helpCode.GDWelcomeObjects1= [];
gdjs.helpCode.GDWelcomeObjects2= [];


gdjs.helpCode.mapOfGDgdjs_9546helpCode_9546GDbackObjects1Objects = Hashtable.newFrom({"back": gdjs.helpCode.GDbackObjects1});
gdjs.helpCode.mapOfGDgdjs_9546helpCode_9546GDdoc_95959595linkObjects1Objects = Hashtable.newFrom({"doc_link": gdjs.helpCode.GDdoc_9595linkObjects1});
gdjs.helpCode.mapOfGDgdjs_9546helpCode_9546GDdoc_95959595linkObjects1Objects = Hashtable.newFrom({"doc_link": gdjs.helpCode.GDdoc_9595linkObjects1});
gdjs.helpCode.userFunc0x1073dc0 = function GDJSInlineCode(runtimeScene) {
"use strict";
document.body.style.cursor = "pointer";
};
gdjs.helpCode.eventsList0 = function(runtimeScene) {

{


gdjs.helpCode.userFunc0x1073dc0(runtimeScene);

}


};gdjs.helpCode.mapOfGDgdjs_9546helpCode_9546GDdoc_95959595linkObjects1Objects = Hashtable.newFrom({"doc_link": gdjs.helpCode.GDdoc_9595linkObjects1});
gdjs.helpCode.userFunc0xae4d68 = function GDJSInlineCode(runtimeScene) {
"use strict";
document.body.style.cursor = "default";
};
gdjs.helpCode.eventsList1 = function(runtimeScene) {

{


gdjs.helpCode.userFunc0xae4d68(runtimeScene);

}


};gdjs.helpCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.tween.tweenVariableNumber3(runtimeScene, "vv", runtimeScene.getScene().getVariables().getFromIndex(0), 4, "easeOutQuad", 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 4);
}
if (isConditionTrue_0) {
{gdjs.evtTools.tween.tweenVariableNumber3(runtimeScene, "v", runtimeScene.getScene().getVariables().getFromIndex(0), 0, "easeOutQuad", 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.helpCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.helpCode.mapOfGDgdjs_9546helpCode_9546GDbackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doc_link"), gdjs.helpCode.GDdoc_9595linkObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.helpCode.mapOfGDgdjs_9546helpCode_9546GDdoc_95959595linkObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://michaelgd.itch.io/mse/devlog/912836/documentation", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doc_link"), gdjs.helpCode.GDdoc_9595linkObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.helpCode.mapOfGDgdjs_9546helpCode_9546GDdoc_95959595linkObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.helpCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doc_link"), gdjs.helpCode.GDdoc_9595linkObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.helpCode.mapOfGDgdjs_9546helpCode_9546GDdoc_95959595linkObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.helpCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.helpCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.helpCode.GDfjfObjects1.length = 0;
gdjs.helpCode.GDfjfObjects2.length = 0;
gdjs.helpCode.GDpanel3Objects1.length = 0;
gdjs.helpCode.GDpanel3Objects2.length = 0;
gdjs.helpCode.GDbackObjects1.length = 0;
gdjs.helpCode.GDbackObjects2.length = 0;
gdjs.helpCode.GDsprrObjects1.length = 0;
gdjs.helpCode.GDsprrObjects2.length = 0;
gdjs.helpCode.GDtutObjects1.length = 0;
gdjs.helpCode.GDtutObjects2.length = 0;
gdjs.helpCode.GDproject_9595selectObjects1.length = 0;
gdjs.helpCode.GDproject_9595selectObjects2.length = 0;
gdjs.helpCode.GDbackground_9595boxObjects1.length = 0;
gdjs.helpCode.GDbackground_9595boxObjects2.length = 0;
gdjs.helpCode.GDdoc_9595linkObjects1.length = 0;
gdjs.helpCode.GDdoc_9595linkObjects2.length = 0;
gdjs.helpCode.GDdetailed_9595guide_9595pointerObjects1.length = 0;
gdjs.helpCode.GDdetailed_9595guide_9595pointerObjects2.length = 0;
gdjs.helpCode.GDGUIDEObjects1.length = 0;
gdjs.helpCode.GDGUIDEObjects2.length = 0;
gdjs.helpCode.GDWelcomeObjects1.length = 0;
gdjs.helpCode.GDWelcomeObjects2.length = 0;

gdjs.helpCode.eventsList2(runtimeScene);
gdjs.helpCode.GDfjfObjects1.length = 0;
gdjs.helpCode.GDfjfObjects2.length = 0;
gdjs.helpCode.GDpanel3Objects1.length = 0;
gdjs.helpCode.GDpanel3Objects2.length = 0;
gdjs.helpCode.GDbackObjects1.length = 0;
gdjs.helpCode.GDbackObjects2.length = 0;
gdjs.helpCode.GDsprrObjects1.length = 0;
gdjs.helpCode.GDsprrObjects2.length = 0;
gdjs.helpCode.GDtutObjects1.length = 0;
gdjs.helpCode.GDtutObjects2.length = 0;
gdjs.helpCode.GDproject_9595selectObjects1.length = 0;
gdjs.helpCode.GDproject_9595selectObjects2.length = 0;
gdjs.helpCode.GDbackground_9595boxObjects1.length = 0;
gdjs.helpCode.GDbackground_9595boxObjects2.length = 0;
gdjs.helpCode.GDdoc_9595linkObjects1.length = 0;
gdjs.helpCode.GDdoc_9595linkObjects2.length = 0;
gdjs.helpCode.GDdetailed_9595guide_9595pointerObjects1.length = 0;
gdjs.helpCode.GDdetailed_9595guide_9595pointerObjects2.length = 0;
gdjs.helpCode.GDGUIDEObjects1.length = 0;
gdjs.helpCode.GDGUIDEObjects2.length = 0;
gdjs.helpCode.GDWelcomeObjects1.length = 0;
gdjs.helpCode.GDWelcomeObjects2.length = 0;


return;

}

gdjs['helpCode'] = gdjs.helpCode;
