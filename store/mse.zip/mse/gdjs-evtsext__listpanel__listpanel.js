
gdjs.evtsExt__ListPanel__ListPanel = gdjs.evtsExt__ListPanel__ListPanel || {};

/**
 * Object generated from 
 */
gdjs.evtsExt__ListPanel__ListPanel.ListPanel = class ListPanel extends gdjs.CustomRuntimeObject2D {
  constructor(parentInstanceContainer, objectData) {
    super(parentInstanceContainer, objectData);
    this._parentInstanceContainer = parentInstanceContainer;

    this._onceTriggers = new gdjs.OnceTriggers();
    this._objectData = {};
    
    this._objectData.difference_between_buttons = objectData.content.difference_between_buttons !== undefined ? objectData.content.difference_between_buttons : Number("8") || 0;
    

    // It calls the onCreated super implementation at the end.
    this.onCreated();
  }

  // Hot-reload:
  updateFromObjectData(oldObjectData, newObjectData) {
    super.updateFromObjectData(oldObjectData, newObjectData);
    if (oldObjectData.content.difference_between_buttons !== newObjectData.content.difference_between_buttons)
      this._objectData.difference_between_buttons = newObjectData.content.difference_between_buttons;

    this.onHotReloading(this._parentInstanceContainer);
    return true;
  }

  // Properties:
  
  _getdifference_between_buttons() {
    return this._objectData.difference_between_buttons !== undefined ? this._objectData.difference_between_buttons : Number("8") || 0;
  }
  _setdifference_between_buttons(newValue) {
    this._objectData.difference_between_buttons = newValue;
  }

  

  
  // gdjs.TextContainer interface implementation
  _text = '';
  getText() {
    return this._text;
  }
  setText(text) {
    this._text = text;
  }

}

// Methods:
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext = {};
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDObjectObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDObjectObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDobject_9595txtObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDobject_9595txtObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbackgroundObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbackgroundObjects2= [];


gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.mapOfGDgdjs_9546evtsExt_9595_9595ListPanel_9595_9595ListPanel_9546ListPanel_9546prototype_9546if_9595_9595button_9595is_9595clickedContext_9546GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1});
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("button"), gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.mapOfGDgdjs_9546evtsExt_9595_9595ListPanel_9595_9595ListPanel_9546ListPanel_9546prototype_9546if_9595_9595button_9595is_9595clickedContext_9546GDbuttonObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1[i].getVariableNumber(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1[i].getVariables().get("id")) == eventsFunctionContext.getArgument("get_id") ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1[k] = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(21652476);
}
}
}
}
if (isConditionTrue_0) {
{if (typeof eventsFunctionContext !== 'undefined') { eventsFunctionContext.returnValue = true; }}}

}


};

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clicked = function(get_id, parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._instanceContainer;
var thisObjectList = [this];
var Object = Hashtable.newFrom({Object: thisObjectList});
var thisGDobject_9595txtObjectsList = [...runtimeScene.getObjects("object_txt")];
var GDobject_9595txtObjects = Hashtable.newFrom({"object_txt": thisGDobject_9595txtObjectsList});
var thisGDbuttonObjectsList = [...runtimeScene.getObjects("button")];
var GDbuttonObjects = Hashtable.newFrom({"button": thisGDbuttonObjectsList});
var thisGDbackgroundObjectsList = [...runtimeScene.getObjects("background")];
var GDbackgroundObjects = Hashtable.newFrom({"background": thisGDbackgroundObjectsList});
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
, "object_txt": GDobject_9595txtObjects
, "button": GDbuttonObjects
, "background": GDbackgroundObjects
},
  _objectArraysMap: {
"Object": thisObjectList
, "object_txt": thisGDobject_9595txtObjectsList
, "button": thisGDbuttonObjectsList
, "background": thisGDbackgroundObjectsList
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("ListPanel"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("ListPanel"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "get_id") return get_id;
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDobject_9595txtObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDobject_9595txtObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbackgroundObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbackgroundObjects2.length = 0;

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDobject_9595txtObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDobject_9595txtObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbuttonObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbackgroundObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.if__button_is_clickedContext.GDbackgroundObjects2.length = 0;


return !!eventsFunctionContext.returnValue;
}
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext = {};
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDObjectObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDObjectObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbuttonObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbuttonObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbackgroundObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbackgroundObjects2= [];


gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("object_txt"), gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1[i].getVariableNumber(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1[i].getVariables().get("id")) == eventsFunctionContext.getArgument("id_getter") ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1[k] = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1 */
{for(var i = 0, len = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1.length ;i < len;++i) {
    gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Text")).setText(eventsFunctionContext.getArgument("txt"));
}
}}

}


};

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_text = function(id_getter, txt, parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._instanceContainer;
var thisObjectList = [this];
var Object = Hashtable.newFrom({Object: thisObjectList});
var thisGDobject_9595txtObjectsList = [...runtimeScene.getObjects("object_txt")];
var GDobject_9595txtObjects = Hashtable.newFrom({"object_txt": thisGDobject_9595txtObjectsList});
var thisGDbuttonObjectsList = [...runtimeScene.getObjects("button")];
var GDbuttonObjects = Hashtable.newFrom({"button": thisGDbuttonObjectsList});
var thisGDbackgroundObjectsList = [...runtimeScene.getObjects("background")];
var GDbackgroundObjects = Hashtable.newFrom({"background": thisGDbackgroundObjectsList});
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
, "object_txt": GDobject_9595txtObjects
, "button": GDbuttonObjects
, "background": GDbackgroundObjects
},
  _objectArraysMap: {
"Object": thisObjectList
, "object_txt": thisGDobject_9595txtObjectsList
, "button": thisGDbuttonObjectsList
, "background": thisGDbackgroundObjectsList
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("ListPanel"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("ListPanel"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "id_getter") return id_getter;
if (argName === "txt") return txt;
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbuttonObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbuttonObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbackgroundObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbackgroundObjects2.length = 0;

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDobject_9595txtObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbuttonObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbuttonObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbackgroundObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.set_button_textContext.GDbackgroundObjects2.length = 0;


return;
}
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext = {};
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDObjectObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDObjectObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDobject_9595txtObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDobject_9595txtObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects2= [];


gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.mapOfGDgdjs_9546evtsExt_9595_9595ListPanel_9595_9595ListPanel_9546ListPanel_9546prototype_9546add_9595objectContext_9546GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1});
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("background"), gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1);
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.mapOfGDgdjs_9546evtsExt_9595_9595ListPanel_9595_9595ListPanel_9546ListPanel_9546prototype_9546add_9595objectContext_9546GDbuttonObjects1Objects, (( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1.length === 0 ) ? 0 :gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1[0].getPointX("")) + 12, (( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1.length === 0 ) ? 0 :gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1[0].getPointY("")) + eventsFunctionContext.getObjects("Object")[0]._getdifference_between_buttons(), "");
}{for(var i = 0, len = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1.length ;i < len;++i) {
    gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Resizable")).setHeight(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Resizable")).getHeight() + ((( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1.length === 0 ) ? 0 :gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1[0].getHeight())));
}
}{for(var i = 0, len = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1.length ;i < len;++i) {
    gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1[i].valuePush(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1[i].getVariables().get("list"), "new object");
}
}}

}


};

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_object = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._instanceContainer;
var thisObjectList = [this];
var Object = Hashtable.newFrom({Object: thisObjectList});
var thisGDobject_9595txtObjectsList = [...runtimeScene.getObjects("object_txt")];
var GDobject_9595txtObjects = Hashtable.newFrom({"object_txt": thisGDobject_9595txtObjectsList});
var thisGDbuttonObjectsList = [...runtimeScene.getObjects("button")];
var GDbuttonObjects = Hashtable.newFrom({"button": thisGDbuttonObjectsList});
var thisGDbackgroundObjectsList = [...runtimeScene.getObjects("background")];
var GDbackgroundObjects = Hashtable.newFrom({"background": thisGDbackgroundObjectsList});
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
, "object_txt": GDobject_9595txtObjects
, "button": GDbuttonObjects
, "background": GDbackgroundObjects
},
  _objectArraysMap: {
"Object": thisObjectList
, "object_txt": thisGDobject_9595txtObjectsList
, "button": thisGDbuttonObjectsList
, "background": thisGDbackgroundObjectsList
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("ListPanel"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("ListPanel"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDobject_9595txtObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDobject_9595txtObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects2.length = 0;

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDobject_9595txtObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDobject_9595txtObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbuttonObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.add_objectContext.GDbackgroundObjects2.length = 0;


return;
}
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext = {};
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDObjectObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDObjectObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDobject_9595txtObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDobject_9595txtObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1= [];
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2= [];


gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.mapOfGDgdjs_9546evtsExt_9595_9595ListPanel_9595_9595ListPanel_9546ListPanel_9546prototype_9546doStepPostEventsContext_9546GDbuttonObjects2Objects = Hashtable.newFrom({"button": gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2});
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{

/* Reuse gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1 */

const repeatCount2 = ((gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1[0].getVariables()).get("listNum").getAsNumber();
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1, gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2);

gdjs.copyArray(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects1, gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.mapOfGDgdjs_9546evtsExt_9595_9595ListPanel_9595_9595ListPanel_9546ListPanel_9546prototype_9546doStepPostEventsContext_9546GDbuttonObjects2Objects, (( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2.length === 0 ) ? 0 :gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2[0].getPointX("")) + 12, eventsFunctionContext.localVariables[0].getFromIndex(0).getAsNumber() * ((( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2.length === 0 ) ? 0 :gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2[0].getPointY("")) + 81 + eventsFunctionContext.getObjects("Object")[0]._getdifference_between_buttons()), "");
}{for(var i = 0, len = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2.length ;i < len;++i) {
    gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Resizable")).setHeight(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2[i].getBehavior(eventsFunctionContext.getBehaviorName("Resizable")).getHeight() + ((( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2.length === 0 ) ? 0 :gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2[0].getHeight())));
}
}{eventsFunctionContext.localVariables[0].getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2.length ;i < len;++i) {
    gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2[i].returnVariable(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2[i].getVariables().get("listNum")).add(1);
}
}}
}

}


};gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("climb123e", variable);
}
eventsFunctionContext.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.eventsList1(runtimeScene, eventsFunctionContext);} //End of subevents
}
eventsFunctionContext.localVariables.pop();

}


};gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("background"), gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1.length;i<l;++i) {
    if ( gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1[i].getVariableNumber(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1[i].getVariables().get("listNum")) != (gdjs.RuntimeObject.getVariableChildCount(gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1[i].getVariables().get("list"))) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1[k] = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1[i];
        ++k;
    }
}
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("button"), gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects1);
{for(var i = 0, len = gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects1.length ;i < len;++i) {
    gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEvents = function(parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._instanceContainer;
var thisObjectList = [this];
var Object = Hashtable.newFrom({Object: thisObjectList});
var thisGDobject_9595txtObjectsList = [...runtimeScene.getObjects("object_txt")];
var GDobject_9595txtObjects = Hashtable.newFrom({"object_txt": thisGDobject_9595txtObjectsList});
var thisGDbuttonObjectsList = [...runtimeScene.getObjects("button")];
var GDbuttonObjects = Hashtable.newFrom({"button": thisGDbuttonObjectsList});
var thisGDbackgroundObjectsList = [...runtimeScene.getObjects("background")];
var GDbackgroundObjects = Hashtable.newFrom({"background": thisGDbackgroundObjectsList});
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
, "object_txt": GDobject_9595txtObjects
, "button": GDbuttonObjects
, "background": GDbackgroundObjects
},
  _objectArraysMap: {
"Object": thisObjectList
, "object_txt": thisGDobject_9595txtObjectsList
, "button": thisGDbuttonObjectsList
, "background": thisGDbackgroundObjectsList
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("ListPanel"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("ListPanel"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDobject_9595txtObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDobject_9595txtObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2.length = 0;

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.eventsList3(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDobject_9595txtObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDobject_9595txtObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbuttonObjects2.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects1.length = 0;
gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPostEventsContext.GDbackgroundObjects2.length = 0;


return;
}

gdjs.evtsExt__ListPanel__ListPanel.ListPanel.prototype.doStepPreEvents = function() {
  this._onceTriggers.startNewFrame();
};


gdjs.registerObject("ListPanel::ListPanel", gdjs.evtsExt__ListPanel__ListPanel.ListPanel);
