gdjs.mse_95winCode = {};
gdjs.mse_95winCode.localVariables = [];
gdjs.mse_95winCode.GDcropObjects2_1final = [];

gdjs.mse_95winCode.GDmusic_9595containerObjects2_1final = [];

gdjs.mse_95winCode.forEachIndex3 = 0;

gdjs.mse_95winCode.forEachIndex4 = 0;

gdjs.mse_95winCode.forEachObjects3 = [];

gdjs.mse_95winCode.forEachObjects4 = [];

gdjs.mse_95winCode.forEachTemporary3 = null;

gdjs.mse_95winCode.forEachTemporary4 = null;

gdjs.mse_95winCode.forEachTotalCount3 = 0;

gdjs.mse_95winCode.forEachTotalCount4 = 0;

gdjs.mse_95winCode.GDpanelObjects1= [];
gdjs.mse_95winCode.GDpanelObjects2= [];
gdjs.mse_95winCode.GDpanelObjects3= [];
gdjs.mse_95winCode.GDpanelObjects4= [];
gdjs.mse_95winCode.GDpanelObjects5= [];
gdjs.mse_95winCode.GDpanelObjects6= [];
gdjs.mse_95winCode.GDpanel2Objects1= [];
gdjs.mse_95winCode.GDpanel2Objects2= [];
gdjs.mse_95winCode.GDpanel2Objects3= [];
gdjs.mse_95winCode.GDpanel2Objects4= [];
gdjs.mse_95winCode.GDpanel2Objects5= [];
gdjs.mse_95winCode.GDpanel2Objects6= [];
gdjs.mse_95winCode.GDsound_9595nameObjects1= [];
gdjs.mse_95winCode.GDsound_9595nameObjects2= [];
gdjs.mse_95winCode.GDsound_9595nameObjects3= [];
gdjs.mse_95winCode.GDsound_9595nameObjects4= [];
gdjs.mse_95winCode.GDsound_9595nameObjects5= [];
gdjs.mse_95winCode.GDsound_9595nameObjects6= [];
gdjs.mse_95winCode.GDdrawObjects1= [];
gdjs.mse_95winCode.GDdrawObjects2= [];
gdjs.mse_95winCode.GDdrawObjects3= [];
gdjs.mse_95winCode.GDdrawObjects4= [];
gdjs.mse_95winCode.GDdrawObjects5= [];
gdjs.mse_95winCode.GDdrawObjects6= [];
gdjs.mse_95winCode.GDnameObjects1= [];
gdjs.mse_95winCode.GDnameObjects2= [];
gdjs.mse_95winCode.GDnameObjects3= [];
gdjs.mse_95winCode.GDnameObjects4= [];
gdjs.mse_95winCode.GDnameObjects5= [];
gdjs.mse_95winCode.GDnameObjects6= [];
gdjs.mse_95winCode.GDmusic_9595containerObjects1= [];
gdjs.mse_95winCode.GDmusic_9595containerObjects2= [];
gdjs.mse_95winCode.GDmusic_9595containerObjects3= [];
gdjs.mse_95winCode.GDmusic_9595containerObjects4= [];
gdjs.mse_95winCode.GDmusic_9595containerObjects5= [];
gdjs.mse_95winCode.GDmusic_9595containerObjects6= [];
gdjs.mse_95winCode.GDplay_9595nodeObjects1= [];
gdjs.mse_95winCode.GDplay_9595nodeObjects2= [];
gdjs.mse_95winCode.GDplay_9595nodeObjects3= [];
gdjs.mse_95winCode.GDplay_9595nodeObjects4= [];
gdjs.mse_95winCode.GDplay_9595nodeObjects5= [];
gdjs.mse_95winCode.GDplay_9595nodeObjects6= [];
gdjs.mse_95winCode.GDplayObjects1= [];
gdjs.mse_95winCode.GDplayObjects2= [];
gdjs.mse_95winCode.GDplayObjects3= [];
gdjs.mse_95winCode.GDplayObjects4= [];
gdjs.mse_95winCode.GDplayObjects5= [];
gdjs.mse_95winCode.GDplayObjects6= [];
gdjs.mse_95winCode.GDdebugObjects1= [];
gdjs.mse_95winCode.GDdebugObjects2= [];
gdjs.mse_95winCode.GDdebugObjects3= [];
gdjs.mse_95winCode.GDdebugObjects4= [];
gdjs.mse_95winCode.GDdebugObjects5= [];
gdjs.mse_95winCode.GDdebugObjects6= [];
gdjs.mse_95winCode.GDstopObjects1= [];
gdjs.mse_95winCode.GDstopObjects2= [];
gdjs.mse_95winCode.GDstopObjects3= [];
gdjs.mse_95winCode.GDstopObjects4= [];
gdjs.mse_95winCode.GDstopObjects5= [];
gdjs.mse_95winCode.GDstopObjects6= [];
gdjs.mse_95winCode.GDfast_9595forwardObjects1= [];
gdjs.mse_95winCode.GDfast_9595forwardObjects2= [];
gdjs.mse_95winCode.GDfast_9595forwardObjects3= [];
gdjs.mse_95winCode.GDfast_9595forwardObjects4= [];
gdjs.mse_95winCode.GDfast_9595forwardObjects5= [];
gdjs.mse_95winCode.GDfast_9595forwardObjects6= [];
gdjs.mse_95winCode.GDfast_9595backwardObjects1= [];
gdjs.mse_95winCode.GDfast_9595backwardObjects2= [];
gdjs.mse_95winCode.GDfast_9595backwardObjects3= [];
gdjs.mse_95winCode.GDfast_9595backwardObjects4= [];
gdjs.mse_95winCode.GDfast_9595backwardObjects5= [];
gdjs.mse_95winCode.GDfast_9595backwardObjects6= [];
gdjs.mse_95winCode.GDgearObjects1= [];
gdjs.mse_95winCode.GDgearObjects2= [];
gdjs.mse_95winCode.GDgearObjects3= [];
gdjs.mse_95winCode.GDgearObjects4= [];
gdjs.mse_95winCode.GDgearObjects5= [];
gdjs.mse_95winCode.GDgearObjects6= [];
gdjs.mse_95winCode.GDbar1Objects1= [];
gdjs.mse_95winCode.GDbar1Objects2= [];
gdjs.mse_95winCode.GDbar1Objects3= [];
gdjs.mse_95winCode.GDbar1Objects4= [];
gdjs.mse_95winCode.GDbar1Objects5= [];
gdjs.mse_95winCode.GDbar1Objects6= [];
gdjs.mse_95winCode.GDyyyObjects1= [];
gdjs.mse_95winCode.GDyyyObjects2= [];
gdjs.mse_95winCode.GDyyyObjects3= [];
gdjs.mse_95winCode.GDyyyObjects4= [];
gdjs.mse_95winCode.GDyyyObjects5= [];
gdjs.mse_95winCode.GDyyyObjects6= [];
gdjs.mse_95winCode.GDcacaObjects1= [];
gdjs.mse_95winCode.GDcacaObjects2= [];
gdjs.mse_95winCode.GDcacaObjects3= [];
gdjs.mse_95winCode.GDcacaObjects4= [];
gdjs.mse_95winCode.GDcacaObjects5= [];
gdjs.mse_95winCode.GDcacaObjects6= [];
gdjs.mse_95winCode.GDdraw2Objects1= [];
gdjs.mse_95winCode.GDdraw2Objects2= [];
gdjs.mse_95winCode.GDdraw2Objects3= [];
gdjs.mse_95winCode.GDdraw2Objects4= [];
gdjs.mse_95winCode.GDdraw2Objects5= [];
gdjs.mse_95winCode.GDdraw2Objects6= [];
gdjs.mse_95winCode.GDddObjects1= [];
gdjs.mse_95winCode.GDddObjects2= [];
gdjs.mse_95winCode.GDddObjects3= [];
gdjs.mse_95winCode.GDddObjects4= [];
gdjs.mse_95winCode.GDddObjects5= [];
gdjs.mse_95winCode.GDddObjects6= [];
gdjs.mse_95winCode.GDjson_9595iconObjects1= [];
gdjs.mse_95winCode.GDjson_9595iconObjects2= [];
gdjs.mse_95winCode.GDjson_9595iconObjects3= [];
gdjs.mse_95winCode.GDjson_9595iconObjects4= [];
gdjs.mse_95winCode.GDjson_9595iconObjects5= [];
gdjs.mse_95winCode.GDjson_9595iconObjects6= [];
gdjs.mse_95winCode.GDavObjects1= [];
gdjs.mse_95winCode.GDavObjects2= [];
gdjs.mse_95winCode.GDavObjects3= [];
gdjs.mse_95winCode.GDavObjects4= [];
gdjs.mse_95winCode.GDavObjects5= [];
gdjs.mse_95winCode.GDavObjects6= [];
gdjs.mse_95winCode.GDexportObjects1= [];
gdjs.mse_95winCode.GDexportObjects2= [];
gdjs.mse_95winCode.GDexportObjects3= [];
gdjs.mse_95winCode.GDexportObjects4= [];
gdjs.mse_95winCode.GDexportObjects5= [];
gdjs.mse_95winCode.GDexportObjects6= [];
gdjs.mse_95winCode.GDbadObjects1= [];
gdjs.mse_95winCode.GDbadObjects2= [];
gdjs.mse_95winCode.GDbadObjects3= [];
gdjs.mse_95winCode.GDbadObjects4= [];
gdjs.mse_95winCode.GDbadObjects5= [];
gdjs.mse_95winCode.GDbadObjects6= [];
gdjs.mse_95winCode.GDpaintObjects1= [];
gdjs.mse_95winCode.GDpaintObjects2= [];
gdjs.mse_95winCode.GDpaintObjects3= [];
gdjs.mse_95winCode.GDpaintObjects4= [];
gdjs.mse_95winCode.GDpaintObjects5= [];
gdjs.mse_95winCode.GDpaintObjects6= [];
gdjs.mse_95winCode.GDproject_9595nameObjects1= [];
gdjs.mse_95winCode.GDproject_9595nameObjects2= [];
gdjs.mse_95winCode.GDproject_9595nameObjects3= [];
gdjs.mse_95winCode.GDproject_9595nameObjects4= [];
gdjs.mse_95winCode.GDproject_9595nameObjects5= [];
gdjs.mse_95winCode.GDproject_9595nameObjects6= [];
gdjs.mse_95winCode.GDinffofoObjects1= [];
gdjs.mse_95winCode.GDinffofoObjects2= [];
gdjs.mse_95winCode.GDinffofoObjects3= [];
gdjs.mse_95winCode.GDinffofoObjects4= [];
gdjs.mse_95winCode.GDinffofoObjects5= [];
gdjs.mse_95winCode.GDinffofoObjects6= [];
gdjs.mse_95winCode.GDlogoObjects1= [];
gdjs.mse_95winCode.GDlogoObjects2= [];
gdjs.mse_95winCode.GDlogoObjects3= [];
gdjs.mse_95winCode.GDlogoObjects4= [];
gdjs.mse_95winCode.GDlogoObjects5= [];
gdjs.mse_95winCode.GDlogoObjects6= [];
gdjs.mse_95winCode.GDasdObjects1= [];
gdjs.mse_95winCode.GDasdObjects2= [];
gdjs.mse_95winCode.GDasdObjects3= [];
gdjs.mse_95winCode.GDasdObjects4= [];
gdjs.mse_95winCode.GDasdObjects5= [];
gdjs.mse_95winCode.GDasdObjects6= [];
gdjs.mse_95winCode.GDmenuObjects1= [];
gdjs.mse_95winCode.GDmenuObjects2= [];
gdjs.mse_95winCode.GDmenuObjects3= [];
gdjs.mse_95winCode.GDmenuObjects4= [];
gdjs.mse_95winCode.GDmenuObjects5= [];
gdjs.mse_95winCode.GDmenuObjects6= [];
gdjs.mse_95winCode.GDpanel3Objects1= [];
gdjs.mse_95winCode.GDpanel3Objects2= [];
gdjs.mse_95winCode.GDpanel3Objects3= [];
gdjs.mse_95winCode.GDpanel3Objects4= [];
gdjs.mse_95winCode.GDpanel3Objects5= [];
gdjs.mse_95winCode.GDpanel3Objects6= [];
gdjs.mse_95winCode.GDhelpObjects1= [];
gdjs.mse_95winCode.GDhelpObjects2= [];
gdjs.mse_95winCode.GDhelpObjects3= [];
gdjs.mse_95winCode.GDhelpObjects4= [];
gdjs.mse_95winCode.GDhelpObjects5= [];
gdjs.mse_95winCode.GDhelpObjects6= [];
gdjs.mse_95winCode.GDexObjects1= [];
gdjs.mse_95winCode.GDexObjects2= [];
gdjs.mse_95winCode.GDexObjects3= [];
gdjs.mse_95winCode.GDexObjects4= [];
gdjs.mse_95winCode.GDexObjects5= [];
gdjs.mse_95winCode.GDexObjects6= [];
gdjs.mse_95winCode.GDinfoObjects1= [];
gdjs.mse_95winCode.GDinfoObjects2= [];
gdjs.mse_95winCode.GDinfoObjects3= [];
gdjs.mse_95winCode.GDinfoObjects4= [];
gdjs.mse_95winCode.GDinfoObjects5= [];
gdjs.mse_95winCode.GDinfoObjects6= [];
gdjs.mse_95winCode.GDbackObjects1= [];
gdjs.mse_95winCode.GDbackObjects2= [];
gdjs.mse_95winCode.GDbackObjects3= [];
gdjs.mse_95winCode.GDbackObjects4= [];
gdjs.mse_95winCode.GDbackObjects5= [];
gdjs.mse_95winCode.GDbackObjects6= [];
gdjs.mse_95winCode.GDpanel4Objects1= [];
gdjs.mse_95winCode.GDpanel4Objects2= [];
gdjs.mse_95winCode.GDpanel4Objects3= [];
gdjs.mse_95winCode.GDpanel4Objects4= [];
gdjs.mse_95winCode.GDpanel4Objects5= [];
gdjs.mse_95winCode.GDpanel4Objects6= [];
gdjs.mse_95winCode.GDerrObjects1= [];
gdjs.mse_95winCode.GDerrObjects2= [];
gdjs.mse_95winCode.GDerrObjects3= [];
gdjs.mse_95winCode.GDerrObjects4= [];
gdjs.mse_95winCode.GDerrObjects5= [];
gdjs.mse_95winCode.GDerrObjects6= [];
gdjs.mse_95winCode.GDai_9595placerkObjects1= [];
gdjs.mse_95winCode.GDai_9595placerkObjects2= [];
gdjs.mse_95winCode.GDai_9595placerkObjects3= [];
gdjs.mse_95winCode.GDai_9595placerkObjects4= [];
gdjs.mse_95winCode.GDai_9595placerkObjects5= [];
gdjs.mse_95winCode.GDai_9595placerkObjects6= [];
gdjs.mse_95winCode.GDhoverObjects1= [];
gdjs.mse_95winCode.GDhoverObjects2= [];
gdjs.mse_95winCode.GDhoverObjects3= [];
gdjs.mse_95winCode.GDhoverObjects4= [];
gdjs.mse_95winCode.GDhoverObjects5= [];
gdjs.mse_95winCode.GDhoverObjects6= [];
gdjs.mse_95winCode.GDsub_9595audObjects1= [];
gdjs.mse_95winCode.GDsub_9595audObjects2= [];
gdjs.mse_95winCode.GDsub_9595audObjects3= [];
gdjs.mse_95winCode.GDsub_9595audObjects4= [];
gdjs.mse_95winCode.GDsub_9595audObjects5= [];
gdjs.mse_95winCode.GDsub_9595audObjects6= [];
gdjs.mse_95winCode.GDaudio_9595idObjects1= [];
gdjs.mse_95winCode.GDaudio_9595idObjects2= [];
gdjs.mse_95winCode.GDaudio_9595idObjects3= [];
gdjs.mse_95winCode.GDaudio_9595idObjects4= [];
gdjs.mse_95winCode.GDaudio_9595idObjects5= [];
gdjs.mse_95winCode.GDaudio_9595idObjects6= [];
gdjs.mse_95winCode.GDexport_9595aObjects1= [];
gdjs.mse_95winCode.GDexport_9595aObjects2= [];
gdjs.mse_95winCode.GDexport_9595aObjects3= [];
gdjs.mse_95winCode.GDexport_9595aObjects4= [];
gdjs.mse_95winCode.GDexport_9595aObjects5= [];
gdjs.mse_95winCode.GDexport_9595aObjects6= [];
gdjs.mse_95winCode.GDidObjects1= [];
gdjs.mse_95winCode.GDidObjects2= [];
gdjs.mse_95winCode.GDidObjects3= [];
gdjs.mse_95winCode.GDidObjects4= [];
gdjs.mse_95winCode.GDidObjects5= [];
gdjs.mse_95winCode.GDidObjects6= [];
gdjs.mse_95winCode.GDname2Objects1= [];
gdjs.mse_95winCode.GDname2Objects2= [];
gdjs.mse_95winCode.GDname2Objects3= [];
gdjs.mse_95winCode.GDname2Objects4= [];
gdjs.mse_95winCode.GDname2Objects5= [];
gdjs.mse_95winCode.GDname2Objects6= [];
gdjs.mse_95winCode.GDeventObjects1= [];
gdjs.mse_95winCode.GDeventObjects2= [];
gdjs.mse_95winCode.GDeventObjects3= [];
gdjs.mse_95winCode.GDeventObjects4= [];
gdjs.mse_95winCode.GDeventObjects5= [];
gdjs.mse_95winCode.GDeventObjects6= [];
gdjs.mse_95winCode.GDshow_9595eventObjects1= [];
gdjs.mse_95winCode.GDshow_9595eventObjects2= [];
gdjs.mse_95winCode.GDshow_9595eventObjects3= [];
gdjs.mse_95winCode.GDshow_9595eventObjects4= [];
gdjs.mse_95winCode.GDshow_9595eventObjects5= [];
gdjs.mse_95winCode.GDshow_9595eventObjects6= [];
gdjs.mse_95winCode.GDsearchObjects1= [];
gdjs.mse_95winCode.GDsearchObjects2= [];
gdjs.mse_95winCode.GDsearchObjects3= [];
gdjs.mse_95winCode.GDsearchObjects4= [];
gdjs.mse_95winCode.GDsearchObjects5= [];
gdjs.mse_95winCode.GDsearchObjects6= [];
gdjs.mse_95winCode.GDenterObjects1= [];
gdjs.mse_95winCode.GDenterObjects2= [];
gdjs.mse_95winCode.GDenterObjects3= [];
gdjs.mse_95winCode.GDenterObjects4= [];
gdjs.mse_95winCode.GDenterObjects5= [];
gdjs.mse_95winCode.GDenterObjects6= [];
gdjs.mse_95winCode.GDsaveObjects1= [];
gdjs.mse_95winCode.GDsaveObjects2= [];
gdjs.mse_95winCode.GDsaveObjects3= [];
gdjs.mse_95winCode.GDsaveObjects4= [];
gdjs.mse_95winCode.GDsaveObjects5= [];
gdjs.mse_95winCode.GDsaveObjects6= [];
gdjs.mse_95winCode.GDspeedObjects1= [];
gdjs.mse_95winCode.GDspeedObjects2= [];
gdjs.mse_95winCode.GDspeedObjects3= [];
gdjs.mse_95winCode.GDspeedObjects4= [];
gdjs.mse_95winCode.GDspeedObjects5= [];
gdjs.mse_95winCode.GDspeedObjects6= [];
gdjs.mse_95winCode.GDhomeObjects1= [];
gdjs.mse_95winCode.GDhomeObjects2= [];
gdjs.mse_95winCode.GDhomeObjects3= [];
gdjs.mse_95winCode.GDhomeObjects4= [];
gdjs.mse_95winCode.GDhomeObjects5= [];
gdjs.mse_95winCode.GDhomeObjects6= [];
gdjs.mse_95winCode.GDcropObjects1= [];
gdjs.mse_95winCode.GDcropObjects2= [];
gdjs.mse_95winCode.GDcropObjects3= [];
gdjs.mse_95winCode.GDcropObjects4= [];
gdjs.mse_95winCode.GDcropObjects5= [];
gdjs.mse_95winCode.GDcropObjects6= [];
gdjs.mse_95winCode.GDsettings_9595icObjects1= [];
gdjs.mse_95winCode.GDsettings_9595icObjects2= [];
gdjs.mse_95winCode.GDsettings_9595icObjects3= [];
gdjs.mse_95winCode.GDsettings_9595icObjects4= [];
gdjs.mse_95winCode.GDsettings_9595icObjects5= [];
gdjs.mse_95winCode.GDsettings_9595icObjects6= [];
gdjs.mse_95winCode.GDsetObjects1= [];
gdjs.mse_95winCode.GDsetObjects2= [];
gdjs.mse_95winCode.GDsetObjects3= [];
gdjs.mse_95winCode.GDsetObjects4= [];
gdjs.mse_95winCode.GDsetObjects5= [];
gdjs.mse_95winCode.GDsetObjects6= [];
gdjs.mse_95winCode.GDsnap_9595boolObjects1= [];
gdjs.mse_95winCode.GDsnap_9595boolObjects2= [];
gdjs.mse_95winCode.GDsnap_9595boolObjects3= [];
gdjs.mse_95winCode.GDsnap_9595boolObjects4= [];
gdjs.mse_95winCode.GDsnap_9595boolObjects5= [];
gdjs.mse_95winCode.GDsnap_9595boolObjects6= [];
gdjs.mse_95winCode.GDshow_9595boolObjects1= [];
gdjs.mse_95winCode.GDshow_9595boolObjects2= [];
gdjs.mse_95winCode.GDshow_9595boolObjects3= [];
gdjs.mse_95winCode.GDshow_9595boolObjects4= [];
gdjs.mse_95winCode.GDshow_9595boolObjects5= [];
gdjs.mse_95winCode.GDshow_9595boolObjects6= [];
gdjs.mse_95winCode.GDset_9595snapObjects1= [];
gdjs.mse_95winCode.GDset_9595snapObjects2= [];
gdjs.mse_95winCode.GDset_9595snapObjects3= [];
gdjs.mse_95winCode.GDset_9595snapObjects4= [];
gdjs.mse_95winCode.GDset_9595snapObjects5= [];
gdjs.mse_95winCode.GDset_9595snapObjects6= [];
gdjs.mse_95winCode.GDdebug2Objects1= [];
gdjs.mse_95winCode.GDdebug2Objects2= [];
gdjs.mse_95winCode.GDdebug2Objects3= [];
gdjs.mse_95winCode.GDdebug2Objects4= [];
gdjs.mse_95winCode.GDdebug2Objects5= [];
gdjs.mse_95winCode.GDdebug2Objects6= [];
gdjs.mse_95winCode.GDbuttonObjects1= [];
gdjs.mse_95winCode.GDbuttonObjects2= [];
gdjs.mse_95winCode.GDbuttonObjects3= [];
gdjs.mse_95winCode.GDbuttonObjects4= [];
gdjs.mse_95winCode.GDbuttonObjects5= [];
gdjs.mse_95winCode.GDbuttonObjects6= [];
gdjs.mse_95winCode.GDUnnamedObjects1= [];
gdjs.mse_95winCode.GDUnnamedObjects2= [];
gdjs.mse_95winCode.GDUnnamedObjects3= [];
gdjs.mse_95winCode.GDUnnamedObjects4= [];
gdjs.mse_95winCode.GDUnnamedObjects5= [];
gdjs.mse_95winCode.GDUnnamedObjects6= [];
gdjs.mse_95winCode.GDUnnamed2Objects1= [];
gdjs.mse_95winCode.GDUnnamed2Objects2= [];
gdjs.mse_95winCode.GDUnnamed2Objects3= [];
gdjs.mse_95winCode.GDUnnamed2Objects4= [];
gdjs.mse_95winCode.GDUnnamed2Objects5= [];
gdjs.mse_95winCode.GDUnnamed2Objects6= [];
gdjs.mse_95winCode.GDUnnamed3Objects1= [];
gdjs.mse_95winCode.GDUnnamed3Objects2= [];
gdjs.mse_95winCode.GDUnnamed3Objects3= [];
gdjs.mse_95winCode.GDUnnamed3Objects4= [];
gdjs.mse_95winCode.GDUnnamed3Objects5= [];
gdjs.mse_95winCode.GDUnnamed3Objects6= [];
gdjs.mse_95winCode.GDUnnamed4Objects1= [];
gdjs.mse_95winCode.GDUnnamed4Objects2= [];
gdjs.mse_95winCode.GDUnnamed4Objects3= [];
gdjs.mse_95winCode.GDUnnamed4Objects4= [];
gdjs.mse_95winCode.GDUnnamed4Objects5= [];
gdjs.mse_95winCode.GDUnnamed4Objects6= [];
gdjs.mse_95winCode.GDscriptObjects1= [];
gdjs.mse_95winCode.GDscriptObjects2= [];
gdjs.mse_95winCode.GDscriptObjects3= [];
gdjs.mse_95winCode.GDscriptObjects4= [];
gdjs.mse_95winCode.GDscriptObjects5= [];
gdjs.mse_95winCode.GDscriptObjects6= [];
gdjs.mse_95winCode.GDcoderObjects1= [];
gdjs.mse_95winCode.GDcoderObjects2= [];
gdjs.mse_95winCode.GDcoderObjects3= [];
gdjs.mse_95winCode.GDcoderObjects4= [];
gdjs.mse_95winCode.GDcoderObjects5= [];
gdjs.mse_95winCode.GDcoderObjects6= [];
gdjs.mse_95winCode.GDfuncObjects1= [];
gdjs.mse_95winCode.GDfuncObjects2= [];
gdjs.mse_95winCode.GDfuncObjects3= [];
gdjs.mse_95winCode.GDfuncObjects4= [];
gdjs.mse_95winCode.GDfuncObjects5= [];
gdjs.mse_95winCode.GDfuncObjects6= [];
gdjs.mse_95winCode.GDspeakerObjects1= [];
gdjs.mse_95winCode.GDspeakerObjects2= [];
gdjs.mse_95winCode.GDspeakerObjects3= [];
gdjs.mse_95winCode.GDspeakerObjects4= [];
gdjs.mse_95winCode.GDspeakerObjects5= [];
gdjs.mse_95winCode.GDspeakerObjects6= [];
gdjs.mse_95winCode.GDexport_9595adObjects1= [];
gdjs.mse_95winCode.GDexport_9595adObjects2= [];
gdjs.mse_95winCode.GDexport_9595adObjects3= [];
gdjs.mse_95winCode.GDexport_9595adObjects4= [];
gdjs.mse_95winCode.GDexport_9595adObjects5= [];
gdjs.mse_95winCode.GDexport_9595adObjects6= [];
gdjs.mse_95winCode.GDdepreciatedObjects1= [];
gdjs.mse_95winCode.GDdepreciatedObjects2= [];
gdjs.mse_95winCode.GDdepreciatedObjects3= [];
gdjs.mse_95winCode.GDdepreciatedObjects4= [];
gdjs.mse_95winCode.GDdepreciatedObjects5= [];
gdjs.mse_95winCode.GDdepreciatedObjects6= [];
gdjs.mse_95winCode.GDsoundObjects1= [];
gdjs.mse_95winCode.GDsoundObjects2= [];
gdjs.mse_95winCode.GDsoundObjects3= [];
gdjs.mse_95winCode.GDsoundObjects4= [];
gdjs.mse_95winCode.GDsoundObjects5= [];
gdjs.mse_95winCode.GDsoundObjects6= [];
gdjs.mse_95winCode.GDpluginObjects1= [];
gdjs.mse_95winCode.GDpluginObjects2= [];
gdjs.mse_95winCode.GDpluginObjects3= [];
gdjs.mse_95winCode.GDpluginObjects4= [];
gdjs.mse_95winCode.GDpluginObjects5= [];
gdjs.mse_95winCode.GDpluginObjects6= [];
gdjs.mse_95winCode.GDNewSpriteObjects1= [];
gdjs.mse_95winCode.GDNewSpriteObjects2= [];
gdjs.mse_95winCode.GDNewSpriteObjects3= [];
gdjs.mse_95winCode.GDNewSpriteObjects4= [];
gdjs.mse_95winCode.GDNewSpriteObjects5= [];
gdjs.mse_95winCode.GDNewSpriteObjects6= [];
gdjs.mse_95winCode.GDproperties_9595textObjects1= [];
gdjs.mse_95winCode.GDproperties_9595textObjects2= [];
gdjs.mse_95winCode.GDproperties_9595textObjects3= [];
gdjs.mse_95winCode.GDproperties_9595textObjects4= [];
gdjs.mse_95winCode.GDproperties_9595textObjects5= [];
gdjs.mse_95winCode.GDproperties_9595textObjects6= [];
gdjs.mse_95winCode.GDNewSprite2Objects1= [];
gdjs.mse_95winCode.GDNewSprite2Objects2= [];
gdjs.mse_95winCode.GDNewSprite2Objects3= [];
gdjs.mse_95winCode.GDNewSprite2Objects4= [];
gdjs.mse_95winCode.GDNewSprite2Objects5= [];
gdjs.mse_95winCode.GDNewSprite2Objects6= [];
gdjs.mse_95winCode.GDjustPurpleObjects1= [];
gdjs.mse_95winCode.GDjustPurpleObjects2= [];
gdjs.mse_95winCode.GDjustPurpleObjects3= [];
gdjs.mse_95winCode.GDjustPurpleObjects4= [];
gdjs.mse_95winCode.GDjustPurpleObjects5= [];
gdjs.mse_95winCode.GDjustPurpleObjects6= [];
gdjs.mse_95winCode.GDInfoObjects1= [];
gdjs.mse_95winCode.GDInfoObjects2= [];
gdjs.mse_95winCode.GDInfoObjects3= [];
gdjs.mse_95winCode.GDInfoObjects4= [];
gdjs.mse_95winCode.GDInfoObjects5= [];
gdjs.mse_95winCode.GDInfoObjects6= [];
gdjs.mse_95winCode.GDinfoETObjects1= [];
gdjs.mse_95winCode.GDinfoETObjects2= [];
gdjs.mse_95winCode.GDinfoETObjects3= [];
gdjs.mse_95winCode.GDinfoETObjects4= [];
gdjs.mse_95winCode.GDinfoETObjects5= [];
gdjs.mse_95winCode.GDinfoETObjects6= [];
gdjs.mse_95winCode.GDinfoEAObjects1= [];
gdjs.mse_95winCode.GDinfoEAObjects2= [];
gdjs.mse_95winCode.GDinfoEAObjects3= [];
gdjs.mse_95winCode.GDinfoEAObjects4= [];
gdjs.mse_95winCode.GDinfoEAObjects5= [];
gdjs.mse_95winCode.GDinfoEAObjects6= [];
gdjs.mse_95winCode.GDinfoEDObjects1= [];
gdjs.mse_95winCode.GDinfoEDObjects2= [];
gdjs.mse_95winCode.GDinfoEDObjects3= [];
gdjs.mse_95winCode.GDinfoEDObjects4= [];
gdjs.mse_95winCode.GDinfoEDObjects5= [];
gdjs.mse_95winCode.GDinfoEDObjects6= [];
gdjs.mse_95winCode.GDpanel5Objects1= [];
gdjs.mse_95winCode.GDpanel5Objects2= [];
gdjs.mse_95winCode.GDpanel5Objects3= [];
gdjs.mse_95winCode.GDpanel5Objects4= [];
gdjs.mse_95winCode.GDpanel5Objects5= [];
gdjs.mse_95winCode.GDpanel5Objects6= [];
gdjs.mse_95winCode.GDtxtObjects1= [];
gdjs.mse_95winCode.GDtxtObjects2= [];
gdjs.mse_95winCode.GDtxtObjects3= [];
gdjs.mse_95winCode.GDtxtObjects4= [];
gdjs.mse_95winCode.GDtxtObjects5= [];
gdjs.mse_95winCode.GDtxtObjects6= [];
gdjs.mse_95winCode.GDbuttonGNObjects1= [];
gdjs.mse_95winCode.GDbuttonGNObjects2= [];
gdjs.mse_95winCode.GDbuttonGNObjects3= [];
gdjs.mse_95winCode.GDbuttonGNObjects4= [];
gdjs.mse_95winCode.GDbuttonGNObjects5= [];
gdjs.mse_95winCode.GDbuttonGNObjects6= [];
gdjs.mse_95winCode.GDtxt2Objects1= [];
gdjs.mse_95winCode.GDtxt2Objects2= [];
gdjs.mse_95winCode.GDtxt2Objects3= [];
gdjs.mse_95winCode.GDtxt2Objects4= [];
gdjs.mse_95winCode.GDtxt2Objects5= [];
gdjs.mse_95winCode.GDtxt2Objects6= [];
gdjs.mse_95winCode.GDshow_9595onlyObjects1= [];
gdjs.mse_95winCode.GDshow_9595onlyObjects2= [];
gdjs.mse_95winCode.GDshow_9595onlyObjects3= [];
gdjs.mse_95winCode.GDshow_9595onlyObjects4= [];
gdjs.mse_95winCode.GDshow_9595onlyObjects5= [];
gdjs.mse_95winCode.GDshow_9595onlyObjects6= [];
gdjs.mse_95winCode.GDhideObjects1= [];
gdjs.mse_95winCode.GDhideObjects2= [];
gdjs.mse_95winCode.GDhideObjects3= [];
gdjs.mse_95winCode.GDhideObjects4= [];
gdjs.mse_95winCode.GDhideObjects5= [];
gdjs.mse_95winCode.GDhideObjects6= [];
gdjs.mse_95winCode.GDnodeLengthObjects1= [];
gdjs.mse_95winCode.GDnodeLengthObjects2= [];
gdjs.mse_95winCode.GDnodeLengthObjects3= [];
gdjs.mse_95winCode.GDnodeLengthObjects4= [];
gdjs.mse_95winCode.GDnodeLengthObjects5= [];
gdjs.mse_95winCode.GDnodeLengthObjects6= [];
gdjs.mse_95winCode.GDsavingObjects1= [];
gdjs.mse_95winCode.GDsavingObjects2= [];
gdjs.mse_95winCode.GDsavingObjects3= [];
gdjs.mse_95winCode.GDsavingObjects4= [];
gdjs.mse_95winCode.GDsavingObjects5= [];
gdjs.mse_95winCode.GDsavingObjects6= [];


gdjs.mse_95winCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95winCode.GDgearObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDgearObjects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDgearObjects3[i].MaxValue((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDgearObjects3[k] = gdjs.mse_95winCode.GDgearObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDgearObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDgearObjects3 */
{for(var i = 0, len = gdjs.mse_95winCode.GDgearObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDgearObjects3[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95winCode.GDgearObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDgearObjects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDgearObjects3[i].MaxValue((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDgearObjects3[k] = gdjs.mse_95winCode.GDgearObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDgearObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDgearObjects3 */
{for(var i = 0, len = gdjs.mse_95winCode.GDgearObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDgearObjects3[i].Activate(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95winCode.GDgearObjects3);
{for(var i = 0, len = gdjs.mse_95winCode.GDgearObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDgearObjects3[i].SetMaxValue(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95winCode.GDgearObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDgearObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDgearObjects2[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDgearObjects2[k] = gdjs.mse_95winCode.GDgearObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDgearObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDgearObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{gdjs.evtTools.sound.setMusicOnChannelPlayingOffset(runtimeScene, 1, (( gdjs.mse_95winCode.GDgearObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDgearObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


};gdjs.mse_95winCode.asyncCallback22313260 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("info"), gdjs.mse_95winCode.GDinfoObjects3);

{for(var i = 0, len = gdjs.mse_95winCode.GDinfoObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoObjects3[i].getBehavior("Text").setText("");
}
}gdjs.mse_95winCode.localVariables.length = 0;
}
gdjs.mse_95winCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
for (const obj of gdjs.mse_95winCode.GDinfoObjects2) asyncObjectsList.addObject("info", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.mse_95winCode.asyncCallback22313260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95winCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDfast_95959595forwardObjects2Objects = Hashtable.newFrom({"fast_forward": gdjs.mse_95winCode.GDfast_9595forwardObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDfast_95959595backwardObjects2Objects = Hashtable.newFrom({"fast_backward": gdjs.mse_95winCode.GDfast_9595backwardObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDstopObjects2Objects = Hashtable.newFrom({"stop": gdjs.mse_95winCode.GDstopObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplayObjects2Objects = Hashtable.newFrom({"play": gdjs.mse_95winCode.GDplayObjects2});
gdjs.mse_95winCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.mse_95winCode.GDplayObjects2, gdjs.mse_95winCode.GDplayObjects3);

{for(var i = 0, len = gdjs.mse_95winCode.GDplayObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplayObjects3[i].getBehavior("Animation").setAnimationName("pausef");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDplayObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDplayObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplayObjects2[i].getBehavior("Animation").setAnimationName("playing");
}
}}

}


};gdjs.mse_95winCode.eventsList4 = function(runtimeScene) {

{


gdjs.mse_95winCode.eventsList0(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95winCode.GDplayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDplayObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDplayObjects2[i].getBehavior("Animation").getAnimationName() == "playing" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDplayObjects2[k] = gdjs.mse_95winCode.GDplayObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDplayObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.mse_95winCode.GDinfoObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDinfoObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoObjects2[i].getBehavior("Text").setText("no audio being played press the spuare button");
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDinfoObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoObjects2[i].setCenterXInScene(gdjs.evtTools.window.getWindowInnerWidth() / 2);
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95winCode.GDplayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDplayObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDplayObjects2[i].getBehavior("Animation").getAnimationName() == "playing" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDplayObjects2[k] = gdjs.mse_95winCode.GDplayObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDplayObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22314348);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}
{ //Subevents
gdjs.mse_95winCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22315588);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22316932);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPaused(runtimeScene, 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("speed"), gdjs.mse_95winCode.GDspeedObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber() != gdjs.evtTools.common.toNumber((( gdjs.mse_95winCode.GDspeedObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDspeedObjects2[0].getText())));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDspeedObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDspeedObjects2[i].getBehavior("Text").getText() != "0" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDspeedObjects2[k] = gdjs.mse_95winCode.GDspeedObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDspeedObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.mse_95winCode.GDspeedObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDspeedObjects2[0].getText())) > 0);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDspeedObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(17).setNumber(gdjs.evtTools.common.toNumber((( gdjs.mse_95winCode.GDspeedObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDspeedObjects2[0].getText())));
}{gdjs.evtTools.sound.setMusicOnChannelPitch(runtimeScene, 1, runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber());
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fast_forward"), gdjs.mse_95winCode.GDfast_9595forwardObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDfast_95959595forwardObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setMusicOnChannelPlayingOffset(runtimeScene, 1, gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) + (0.5));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fast_backward"), gdjs.mse_95winCode.GDfast_9595backwardObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDfast_95959595backwardObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.setMusicOnChannelPlayingOffset(runtimeScene, 1, gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) - (0.5));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95winCode.GDstopObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDstopObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDstopObjects2[i].getVariableBoolean(gdjs.mse_95winCode.GDstopObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDstopObjects2[k] = gdjs.mse_95winCode.GDstopObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDstopObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelPaused(runtimeScene, 1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio.ogg", 1, false, 60, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95winCode.GDstopObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDstopObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDstopObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDstopObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDstopObjects2[i].returnVariable(gdjs.mse_95winCode.GDstopObjects2[i].getVariables().getFromIndex(0)).toggle();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95winCode.GDplayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplayObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4));
}
{ //Subevents
gdjs.mse_95winCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95winCode.GDplayObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDplayObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDplayObjects2[i].getBehavior("Animation").getAnimationName() == "pausef" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDplayObjects2[k] = gdjs.mse_95winCode.GDplayObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDplayObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95winCode.GDstopObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDstopObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDstopObjects2[i].getVariableBoolean(gdjs.mse_95winCode.GDstopObjects2[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDstopObjects2[k] = gdjs.mse_95winCode.GDstopObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDstopObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95winCode.GDstopObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDstopObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDstopObjects2[i].getVariableBoolean(gdjs.mse_95winCode.GDstopObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDstopObjects2[k] = gdjs.mse_95winCode.GDstopObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDstopObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDstopObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDstopObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDstopObjects2[i].getBehavior("Animation").setAnimationName("play");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95winCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDstopObjects1.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDstopObjects1[i].getVariableBoolean(gdjs.mse_95winCode.GDstopObjects1[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDstopObjects1[k] = gdjs.mse_95winCode.GDstopObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDstopObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDstopObjects1 */
{for(var i = 0, len = gdjs.mse_95winCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDstopObjects1[i].getBehavior("Animation").setAnimationName("stop");
}
}}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplay_95959595nodeObjects2Objects = Hashtable.newFrom({"play_node": gdjs.mse_95winCode.GDplay_9595nodeObjects2});
gdjs.mse_95winCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplay_95959595nodeObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDplay_9595nodeObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplay_9595nodeObjects2[i].setX(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "g");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "f");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects1);
{gdjs.evtTools.sound.setMusicOnChannelPlayingOffset(runtimeScene, 1, (( gdjs.mse_95winCode.GDplay_9595nodeObjects1.length === 0 ) ? 0 :gdjs.mse_95winCode.GDplay_9595nodeObjects1[0].getPointX("")) / 50);
}}

}


};gdjs.mse_95winCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Num9");
if (isConditionTrue_0) {
}

}


};gdjs.mse_95winCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDplay_9595nodeObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplay_9595nodeObjects2[i].setX(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) * 50);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95winCode.GDgearObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDgearObjects1.length;i<l;++i) {
    if ( !(gdjs.mse_95winCode.GDgearObjects1[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDgearObjects1[k] = gdjs.mse_95winCode.GDgearObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDgearObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDgearObjects1 */
{for(var i = 0, len = gdjs.mse_95winCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDgearObjects1[i].SetValue(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.mse_95winCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) <= 0;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "error");
}}

}


};gdjs.mse_95winCode.asyncCallback22345220 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95winCode.localVariables);

{ //Subevents
gdjs.mse_95winCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.mse_95winCode.localVariables.length = 0;
}
gdjs.mse_95winCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.mse_95winCode.asyncCallback22345220(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects3Objects = Hashtable.newFrom({"crop": gdjs.mse_95winCode.GDcropObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects3Objects = Hashtable.newFrom({"crop": gdjs.mse_95winCode.GDcropObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects3Objects = Hashtable.newFrom({"crop": gdjs.mse_95winCode.GDcropObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22353228);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95winCode.GDcropObjects3);
{for(var i = 0, len = gdjs.mse_95winCode.GDcropObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcropObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects3Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.mse_95winCode.GDcropObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcropObjects3[i].getBehavior("Opacity").setOpacity(100);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95winCode.GDcropObjects3);
{for(var i = 0, len = gdjs.mse_95winCode.GDcropObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcropObjects3[i].getBehavior("Resizable").setSize(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - (gdjs.mse_95winCode.GDcropObjects3[i].getX()), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - (gdjs.mse_95winCode.GDcropObjects3[i].getY()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95winCode.GDcropObjects3);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects3Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects, true, runtimeScene, true);
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDcropObjects3 */
{for(var i = 0, len = gdjs.mse_95winCode.GDcropObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcropObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95winCode.GDcropObjects3);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects3Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects, true, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right"));
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDcropObjects3 */
{for(var i = 0, len = gdjs.mse_95winCode.GDcropObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcropObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95winCode.GDcropObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDcropObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcropObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects2Objects = Hashtable.newFrom({"crop": gdjs.mse_95winCode.GDcropObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDnodeLengthObjects2Objects = Hashtable.newFrom({"nodeLength": gdjs.mse_95winCode.GDnodeLengthObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDnodeLengthObjects2Objects = Hashtable.newFrom({"nodeLength": gdjs.mse_95winCode.GDnodeLengthObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplay_95959595nodeObjects2Objects = Hashtable.newFrom({"play_node": gdjs.mse_95winCode.GDplay_9595nodeObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplay_95959595nodeObjects2Objects = Hashtable.newFrom({"play_node": gdjs.mse_95winCode.GDplay_9595nodeObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects3Objects = Hashtable.newFrom({"crop": gdjs.mse_95winCode.GDcropObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDshow_95959595onlyObjects3Objects = Hashtable.newFrom({"show_only": gdjs.mse_95winCode.GDshow_9595onlyObjects3});
gdjs.mse_95winCode.eventsList11 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects3);

for (gdjs.mse_95winCode.forEachIndex4 = 0;gdjs.mse_95winCode.forEachIndex4 < gdjs.mse_95winCode.GDmusic_9595containerObjects3.length;++gdjs.mse_95winCode.forEachIndex4) {
gdjs.copyArray(gdjs.mse_95winCode.GDeventObjects3, gdjs.mse_95winCode.GDeventObjects4);

gdjs.mse_95winCode.GDmusic_9595containerObjects4.length = 0;


gdjs.mse_95winCode.forEachTemporary4 = gdjs.mse_95winCode.GDmusic_9595containerObjects3[gdjs.mse_95winCode.forEachIndex4];
gdjs.mse_95winCode.GDmusic_9595containerObjects4.push(gdjs.mse_95winCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects4.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects4[i].getVariableString(gdjs.mse_95winCode.GDmusic_9595containerObjects4[i].getVariables().getFromIndex(0)) != (( gdjs.mse_95winCode.GDeventObjects4.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects4[0].getBehavior("Text").getText()) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects4[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects4[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects4.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects4[i].hide();
}
}}
}

}


};gdjs.mse_95winCode.eventsList13 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.mse_95winCode.GDmusic_9595containerObjects2, gdjs.mse_95winCode.GDmusic_9595containerObjects3);


for (gdjs.mse_95winCode.forEachIndex4 = 0;gdjs.mse_95winCode.forEachIndex4 < gdjs.mse_95winCode.GDmusic_9595containerObjects3.length;++gdjs.mse_95winCode.forEachIndex4) {
gdjs.copyArray(gdjs.mse_95winCode.GDeventObjects2, gdjs.mse_95winCode.GDeventObjects4);

gdjs.mse_95winCode.GDmusic_9595containerObjects4.length = 0;


gdjs.mse_95winCode.forEachTemporary4 = gdjs.mse_95winCode.GDmusic_9595containerObjects3[gdjs.mse_95winCode.forEachIndex4];
gdjs.mse_95winCode.GDmusic_9595containerObjects4.push(gdjs.mse_95winCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects4.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects4[i].getVariableString(gdjs.mse_95winCode.GDmusic_9595containerObjects4[i].getVariables().getFromIndex(0)) != (( gdjs.mse_95winCode.GDeventObjects4.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects4[0].getBehavior("Text").getText()) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects4[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects4[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects4.length = k;
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects4[i].hide();
}
}}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.mse_95winCode.GDeventObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(36).setString((( gdjs.mse_95winCode.GDeventObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects2[0].getBehavior("Text").getText()));
}}

}


};gdjs.mse_95winCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22377116);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(36).setString((( gdjs.mse_95winCode.GDeventObjects3.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects3[0].getBehavior("Text").getText()));
}
{ //Subevents
gdjs.mse_95winCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDeventObjects2.length;i<l;++i) {
    if ( !(gdjs.mse_95winCode.GDeventObjects2[i].isFocused()) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDeventObjects2[k] = gdjs.mse_95winCode.GDeventObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDeventObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(36).getAsString() != (( gdjs.mse_95winCode.GDeventObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects2[0].getBehavior("Text").getText()));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22378668);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("show_only"), gdjs.mse_95winCode.GDshow_9595onlyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDshow_95959595onlyObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22374748);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDshow_9595onlyObjects3 */
{for(var i = 0, len = gdjs.mse_95winCode.GDshow_9595onlyObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDshow_9595onlyObjects3[i].returnVariable(gdjs.mse_95winCode.GDshow_9595onlyObjects3[i].getVariables().getFromIndex(0)).toggle();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("show_only"), gdjs.mse_95winCode.GDshow_9595onlyObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDshow_9595onlyObjects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDshow_9595onlyObjects3[i].getVariableBoolean(gdjs.mse_95winCode.GDshow_9595onlyObjects3[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDshow_9595onlyObjects3[k] = gdjs.mse_95winCode.GDshow_9595onlyObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDshow_9595onlyObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects3);
/* Reuse gdjs.mse_95winCode.GDshow_9595onlyObjects3 */
{for(var i = 0, len = gdjs.mse_95winCode.GDshow_9595onlyObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDshow_9595onlyObjects3[i].getBehavior("Animation").setAnimationName("false");
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("show_only"), gdjs.mse_95winCode.GDshow_9595onlyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDshow_9595onlyObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDshow_9595onlyObjects2[i].getVariableBoolean(gdjs.mse_95winCode.GDshow_9595onlyObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDshow_9595onlyObjects2[k] = gdjs.mse_95winCode.GDshow_9595onlyObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDshow_9595onlyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDshow_9595onlyObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDshow_9595onlyObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDshow_9595onlyObjects2[i].getBehavior("Animation").setAnimationName("true");
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplay_95959595nodeObjects1Objects = Hashtable.newFrom({"play_node": gdjs.mse_95winCode.GDplay_9595nodeObjects1});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects1});
gdjs.mse_95winCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplay_95959595nodeObjects1Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects1);
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects1 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects1[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects1[i].getVariables().getFromIndex(0)).setString((( gdjs.mse_95winCode.GDeventObjects1.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects1[0].getText()));
}
}}

}


};gdjs.mse_95winCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getX() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects2[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (gdjs.evtTools.window.getWindowInnerWidth() / 2) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects2[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").getWidth() < runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects2[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").setWidth(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getX() < gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects2[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getX() > gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.window.getWindowInnerWidth() / 2) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects2[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").getWidth() < runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects2[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").setWidth(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber());
}
}}

}


{


gdjs.mse_95winCode.eventsList10(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95winCode.GDcropObjects2);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects2Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, false, runtimeScene, true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects2);
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getVariables().getFromIndex(0)).setString((( gdjs.mse_95winCode.GDeventObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects2[0].getText()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects2);
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getVariables().getFromIndex(0)).setString((( gdjs.mse_95winCode.GDeventObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects2[0].getText()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("caca"), gdjs.mse_95winCode.GDcacaObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDcacaObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcacaObjects2[i].setCenterXInScene(Math.round(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 16) * 16);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "v");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22360284);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);
gdjs.mse_95winCode.GDnodeLengthObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDnodeLengthObjects2Objects, (( gdjs.mse_95winCode.GDplay_9595nodeObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDplay_9595nodeObjects2[0].getPointX("")), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - 48, "");
}{for(var i = 0, len = gdjs.mse_95winCode.GDnodeLengthObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDnodeLengthObjects2[i].getBehavior("Opacity").setOpacity(100);
}
}{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDnodeLengthObjects2Objects, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber(), 96, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "v");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("nodeLength"), gdjs.mse_95winCode.GDnodeLengthObjects2);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(34).setNumber(Math.round(((( gdjs.mse_95winCode.GDplay_9595nodeObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDplay_9595nodeObjects2[0].getPointX("")) - (( gdjs.mse_95winCode.GDnodeLengthObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDnodeLengthObjects2[0].getX())) / runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber()) * runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber());
}{for(var i = 0, len = gdjs.mse_95winCode.GDnodeLengthObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDnodeLengthObjects2[i].getBehavior("Resizable").setSize(runtimeScene.getScene().getVariables().getFromIndex(34).getAsNumber(), 96);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "v");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95winCode.GDdraw2Objects2);
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects2);
gdjs.copyArray(runtimeScene.getObjects("nodeLength"), gdjs.mse_95winCode.GDnodeLengthObjects2);
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, (( gdjs.mse_95winCode.GDnodeLengthObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDnodeLengthObjects2[0].getX()), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - 48, "");
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").setSize((( gdjs.mse_95winCode.GDnodeLengthObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDnodeLengthObjects2[0].getWidth()), 96);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getVariables().getFromIndex(2)).setNumber((gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getX()) / 50);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getVariables().getFromIndex(0)).setString((( gdjs.mse_95winCode.GDeventObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects2[0].getBehavior("Text").getText()));
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDnodeLengthObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDnodeLengthObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDdraw2Objects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdraw2Objects2[i].setZOrder((( gdjs.mse_95winCode.GDmusic_9595containerObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects2[0].getZOrder()) + 1);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "c");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22363988);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95winCode.GDdraw2Objects2);
gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects2);
gdjs.copyArray(runtimeScene.getObjects("nodeLength"), gdjs.mse_95winCode.GDnodeLengthObjects2);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, (( gdjs.mse_95winCode.GDplay_9595nodeObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDplay_9595nodeObjects2[0].getPointX("")), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - 48, "");
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").setSize(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber(), 96);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getVariables().getFromIndex(2)).setNumber((gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getX()) / 50);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getVariables().getFromIndex(0)).setString((( gdjs.mse_95winCode.GDeventObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDeventObjects2[0].getBehavior("Text").getText()));
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDnodeLengthObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDnodeLengthObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDdraw2Objects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdraw2Objects2[i].setZOrder((( gdjs.mse_95winCode.GDmusic_9595containerObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects2[0].getZOrder()) + 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "n");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22367028);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").setWidth(gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").getWidth() + (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "b");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22368164);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").setWidth(gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].getBehavior("Resizable").getWidth() - (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber()));
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplay_95959595nodeObjects2Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("speaker"), gdjs.mse_95winCode.GDspeakerObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDspeakerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDspeakerObjects2[i].getBehavior("Tween").addObjectScaleTween3("sps", 0.5, "linear", 0.03, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDplay_95959595nodeObjects2Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, true, runtimeScene, true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("speaker"), gdjs.mse_95winCode.GDspeakerObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDspeakerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDspeakerObjects2[i].getBehavior("Tween").addObjectScaleTween3("ps", 0.25, "linear", 0.03, false, true);
}
}}

}


{

gdjs.mse_95winCode.GDcropObjects2.length = 0;

gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.mse_95winCode.GDcropObjects2_1final.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.mse_95winCode.GDmusic_9595containerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.mse_95winCode.GDmusic_9595containerObjects2_1final.indexOf(gdjs.mse_95winCode.GDmusic_9595containerObjects3[j]) === -1 )
            gdjs.mse_95winCode.GDmusic_9595containerObjects2_1final.push(gdjs.mse_95winCode.GDmusic_9595containerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("crop"), gdjs.mse_95winCode.GDcropObjects3);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects3);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDcropObjects3Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects, false, runtimeScene, true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.mse_95winCode.GDcropObjects3.length; j < jLen ; ++j) {
        if ( gdjs.mse_95winCode.GDcropObjects2_1final.indexOf(gdjs.mse_95winCode.GDcropObjects3[j]) === -1 )
            gdjs.mse_95winCode.GDcropObjects2_1final.push(gdjs.mse_95winCode.GDcropObjects3[j]);
    }
    for (let j = 0, jLen = gdjs.mse_95winCode.GDmusic_9595containerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.mse_95winCode.GDmusic_9595containerObjects2_1final.indexOf(gdjs.mse_95winCode.GDmusic_9595containerObjects3[j]) === -1 )
            gdjs.mse_95winCode.GDmusic_9595containerObjects2_1final.push(gdjs.mse_95winCode.GDmusic_9595containerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.mse_95winCode.GDcropObjects2_1final, gdjs.mse_95winCode.GDcropObjects2);
gdjs.copyArray(gdjs.mse_95winCode.GDmusic_9595containerObjects2_1final, gdjs.mse_95winCode.GDmusic_9595containerObjects2);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDplay_9595nodeObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDplay_9595nodeObjects2[i].getX() > 638 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDplay_9595nodeObjects2[k] = gdjs.mse_95winCode.GDplay_9595nodeObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDplay_9595nodeObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDplay_9595nodeObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.mse_95winCode.GDplay_9595nodeObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDplay_9595nodeObjects2[0].getPointX("")), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDplay_9595nodeObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDplay_9595nodeObjects2[i].getX() <= 638 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDplay_9595nodeObjects2[k] = gdjs.mse_95winCode.GDplay_9595nodeObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDplay_9595nodeObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 638, "", 0);
}}

}


{


gdjs.mse_95winCode.eventsList16(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "j");
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmenuObjects2Objects = Hashtable.newFrom({"menu": gdjs.mse_95winCode.GDmenuObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDexObjects3Objects = Hashtable.newFrom({"ex": gdjs.mse_95winCode.GDexObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDhelpObjects3Objects = Hashtable.newFrom({"help": gdjs.mse_95winCode.GDhelpObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpluginObjects3Objects = Hashtable.newFrom({"plugin": gdjs.mse_95winCode.GDpluginObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDai_95959595placerkObjects3Objects = Hashtable.newFrom({"ai_placerk": gdjs.mse_95winCode.GDai_9595placerkObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDbackObjects3Objects = Hashtable.newFrom({"back": gdjs.mse_95winCode.GDbackObjects3});
gdjs.mse_95winCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "audio_manager_win", true);
}}

}


};gdjs.mse_95winCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ex"), gdjs.mse_95winCode.GDexObjects3);
gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95winCode.GDpanel3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDpanel3Objects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDpanel3Objects3[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDpanel3Objects3[k] = gdjs.mse_95winCode.GDpanel3Objects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDpanel3Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDexObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "pop_up");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("help"), gdjs.mse_95winCode.GDhelpObjects3);
gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95winCode.GDpanel3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDpanel3Objects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDpanel3Objects3[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDpanel3Objects3[k] = gdjs.mse_95winCode.GDpanel3Objects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDpanel3Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDhelpObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "help");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95winCode.GDpanel3Objects3);
gdjs.copyArray(runtimeScene.getObjects("plugin"), gdjs.mse_95winCode.GDpluginObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDpanel3Objects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDpanel3Objects3[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDpanel3Objects3[k] = gdjs.mse_95winCode.GDpanel3Objects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDpanel3Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpluginObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "plugins");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ai_placerk"), gdjs.mse_95winCode.GDai_9595placerkObjects3);
gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95winCode.GDpanel3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDpanel3Objects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDpanel3Objects3[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDpanel3Objects3[k] = gdjs.mse_95winCode.GDpanel3Objects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDpanel3Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDai_95959595placerkObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(true);
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "equalizador");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.mse_95winCode.GDbackObjects3);
gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95winCode.GDpanel3Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDpanel3Objects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDpanel3Objects3[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDpanel3Objects3[k] = gdjs.mse_95winCode.GDpanel3Objects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDpanel3Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects3Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDbackObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.unloadMusic(runtimeScene, "audio.ogg");
}
{ //Subevents
gdjs.mse_95winCode.eventsList19(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95winCode.GDavObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95winCode.GDavObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDexport_95959595aObjects2Objects = Hashtable.newFrom({"export_a": gdjs.mse_95winCode.GDexport_9595aObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("project_name"), gdjs.mse_95winCode.GDproject_9595nameObjects5);
{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, (( gdjs.mse_95winCode.GDproject_9595nameObjects5.length === 0 ) ? "" :gdjs.mse_95winCode.GDproject_9595nameObjects5[0].getText()) + ".json", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(3)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


};gdjs.mse_95winCode.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(3)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects);
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDmusic_9595containerObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDmusic_9595containerObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("x").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getX()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("y").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getY()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("time").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getX()) / 50);
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("length").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getWidth()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("event").setString(((gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getScene().getVariables().getFromIndex(3), gdjs.mse_95winCode.localVariables[0].getFromIndex(0));
}
{ //Subevents: 
gdjs.mse_95winCode.eventsList22(runtimeScene);} //Subevents end.
}
}

}


};gdjs.mse_95winCode.eventsList24 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("");
variable.addChild("event", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("time", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("x", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("y", variable1);
}
variables._declare("NodeData", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(3));
}
{ //Subevents
gdjs.mse_95winCode.eventsList23(runtimeScene);} //End of subevents
}
gdjs.mse_95winCode.localVariables.pop();

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95winCode.GDavObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95winCode.GDavObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDexport_95959595adObjects2Objects = Hashtable.newFrom({"export_ad": gdjs.mse_95winCode.GDexport_9595adObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("project_name"), gdjs.mse_95winCode.GDproject_9595nameObjects5);
{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, (( gdjs.mse_95winCode.GDproject_9595nameObjects5.length === 0 ) ? "" :gdjs.mse_95winCode.GDproject_9595nameObjects5[0].getText()) + ".json", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(3)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


};gdjs.mse_95winCode.eventsList26 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(3)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects) * 3;
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDmusic_9595containerObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDmusic_9595containerObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(3), (( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getX()));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(3), (( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getY()));
}{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(3), ((gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getVariables()).getFromIndex(0).getAsString());
}
{ //Subevents: 
gdjs.mse_95winCode.eventsList26(runtimeScene);} //Subevents end.
}
}

}


};gdjs.mse_95winCode.eventsList28 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("");
variable.addChild("event", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("x", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("y", variable1);
}
variables._declare("NodeData", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(3));
}
{ //Subevents
gdjs.mse_95winCode.eventsList27(runtimeScene);} //End of subevents
}
gdjs.mse_95winCode.localVariables.pop();

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95winCode.GDavObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95winCode.GDavObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDexportObjects2Objects = Hashtable.newFrom({"export": gdjs.mse_95winCode.GDexportObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("project_name"), gdjs.mse_95winCode.GDproject_9595nameObjects4);
{gdjs.evtsExt__UploadDownloadTextFile__DownloadTextFile.func(runtimeScene, (( gdjs.mse_95winCode.GDproject_9595nameObjects4.length === 0 ) ? "" :gdjs.mse_95winCode.GDproject_9595nameObjects4[0].getText()) + ".json", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(3)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.mse_95winCode.eventsList30 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(3)) == gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects);
if (isConditionTrue_0) {
{gdjs.evtsExt__ArrayTools__Sort.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.mse_95winCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDmusic_9595containerObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDmusic_9595containerObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(3), (( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getX()) / 50);
}
{ //Subevents: 
gdjs.mse_95winCode.eventsList30(runtimeScene);} //Subevents end.
}
}

}


};gdjs.mse_95winCode.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(3));
}
{ //Subevents
gdjs.mse_95winCode.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95winCode.GDavObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects = Hashtable.newFrom({"av": gdjs.mse_95winCode.GDavObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDbadObjects2Objects = Hashtable.newFrom({"bad": gdjs.mse_95winCode.GDbadObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects3Objects = Hashtable.newFrom({"Info": gdjs.mse_95winCode.GDInfoObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects = Hashtable.newFrom({"Info": gdjs.mse_95winCode.GDInfoObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoEDObjects4Objects = Hashtable.newFrom({"infoED": gdjs.mse_95winCode.GDinfoEDObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects = Hashtable.newFrom({"Info": gdjs.mse_95winCode.GDInfoObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoEAObjects4Objects = Hashtable.newFrom({"infoEA": gdjs.mse_95winCode.GDinfoEAObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects = Hashtable.newFrom({"Info": gdjs.mse_95winCode.GDInfoObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoETObjects4Objects = Hashtable.newFrom({"infoET": gdjs.mse_95winCode.GDinfoETObjects4});
gdjs.mse_95winCode.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.mse_95winCode.GDInfoObjects3, gdjs.mse_95winCode.GDInfoObjects4);

gdjs.copyArray(runtimeScene.getObjects("infoED"), gdjs.mse_95winCode.GDinfoEDObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoEDObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDinfoEDObjects4 */
{for(var i = 0, len = gdjs.mse_95winCode.GDinfoEDObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoEDObjects4[i].hide(false);
}
}}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDInfoObjects3, gdjs.mse_95winCode.GDInfoObjects4);

gdjs.copyArray(runtimeScene.getObjects("infoEA"), gdjs.mse_95winCode.GDinfoEAObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoEAObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDinfoEAObjects4 */
{for(var i = 0, len = gdjs.mse_95winCode.GDinfoEAObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoEAObjects4[i].hide(false);
}
}}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDInfoObjects3, gdjs.mse_95winCode.GDInfoObjects4);

gdjs.copyArray(runtimeScene.getObjects("infoET"), gdjs.mse_95winCode.GDinfoETObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoETObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDinfoETObjects4 */
{for(var i = 0, len = gdjs.mse_95winCode.GDinfoETObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoETObjects4[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects3Objects = Hashtable.newFrom({"Info": gdjs.mse_95winCode.GDInfoObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects = Hashtable.newFrom({"Info": gdjs.mse_95winCode.GDInfoObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoEDObjects4Objects = Hashtable.newFrom({"infoED": gdjs.mse_95winCode.GDinfoEDObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects = Hashtable.newFrom({"Info": gdjs.mse_95winCode.GDInfoObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoEAObjects4Objects = Hashtable.newFrom({"infoEA": gdjs.mse_95winCode.GDinfoEAObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects = Hashtable.newFrom({"Info": gdjs.mse_95winCode.GDInfoObjects4});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoETObjects4Objects = Hashtable.newFrom({"infoET": gdjs.mse_95winCode.GDinfoETObjects4});
gdjs.mse_95winCode.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.mse_95winCode.GDInfoObjects3, gdjs.mse_95winCode.GDInfoObjects4);

gdjs.copyArray(runtimeScene.getObjects("infoED"), gdjs.mse_95winCode.GDinfoEDObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoEDObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDinfoEDObjects4 */
{for(var i = 0, len = gdjs.mse_95winCode.GDinfoEDObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoEDObjects4[i].hide();
}
}}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDInfoObjects3, gdjs.mse_95winCode.GDInfoObjects4);

gdjs.copyArray(runtimeScene.getObjects("infoEA"), gdjs.mse_95winCode.GDinfoEAObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoEAObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDinfoEAObjects4 */
{for(var i = 0, len = gdjs.mse_95winCode.GDinfoEAObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoEAObjects4[i].hide();
}
}}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDInfoObjects3, gdjs.mse_95winCode.GDInfoObjects4);

gdjs.copyArray(runtimeScene.getObjects("infoET"), gdjs.mse_95winCode.GDinfoETObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects4Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDinfoETObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDinfoETObjects4 */
{for(var i = 0, len = gdjs.mse_95winCode.GDinfoETObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoETObjects4[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95winCode.GDavObjects2);
gdjs.copyArray(runtimeScene.getObjects("export_a"), gdjs.mse_95winCode.GDexport_9595aObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDavObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDavObjects2[i].getZOrder() != 17 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDavObjects2[k] = gdjs.mse_95winCode.GDavObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDavObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDexport_95959595aObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList24(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95winCode.GDavObjects2);
gdjs.copyArray(runtimeScene.getObjects("export_ad"), gdjs.mse_95winCode.GDexport_9595adObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDavObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDavObjects2[i].getZOrder() != 17 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDavObjects2[k] = gdjs.mse_95winCode.GDavObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDavObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDexport_95959595adObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95winCode.GDavObjects2);
gdjs.copyArray(runtimeScene.getObjects("export"), gdjs.mse_95winCode.GDexportObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDavObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDavObjects2[i].getZOrder() != 17 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDavObjects2[k] = gdjs.mse_95winCode.GDavObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDavObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDexportObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95winCode.GDavObjects2);
gdjs.copyArray(runtimeScene.getObjects("bad"), gdjs.mse_95winCode.GDbadObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDavObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDavObjects2[i].getZOrder() != 17 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDavObjects2[k] = gdjs.mse_95winCode.GDavObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDavObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDavObjects2Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDbadObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "pop_up");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Info"), gdjs.mse_95winCode.GDInfoObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDInfoObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDInfoObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDInfoObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDInfoObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.mse_95winCode.eventsList33(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Info"), gdjs.mse_95winCode.GDInfoObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDInfoObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDInfoObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDInfoObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDInfoObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDInfoObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.mse_95winCode.eventsList34(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95winCode.GDmenuObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmenuObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmenuObjects2[i].getVariableBoolean(gdjs.mse_95winCode.GDmenuObjects2[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmenuObjects2[k] = gdjs.mse_95winCode.GDmenuObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmenuObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "drop_down");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95winCode.GDmenuObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmenuObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmenuObjects2[i].getVariableBoolean(gdjs.mse_95winCode.GDmenuObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmenuObjects2[k] = gdjs.mse_95winCode.GDmenuObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmenuObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "drop_down");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95winCode.GDmenuObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmenuObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDmenuObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDmenuObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmenuObjects2[i].returnVariable(gdjs.mse_95winCode.GDmenuObjects2[i].getVariables().getFromIndex(0)).toggle();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "drop_down");
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pop_up");
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList37 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount3 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(2));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects, runtimeScene.getGame().getVariables().getFromIndex(2).getChild(runtimeScene.getScene().getVariables().getFromIndex(8).getAsNumber()).getAsNumber(), 300, "");
}{runtimeScene.getScene().getVariables().getFromIndex(8).add(1);
}}
}

}


};gdjs.mse_95winCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22415748);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(8).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(11).setBoolean(false);
}
{ //Subevents
gdjs.mse_95winCode.eventsList38(runtimeScene);} //End of subevents
}

}


{



}


{



}


{



}


{



}


{



}


{



}


{



}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList40 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount3 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node")) / 3;
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(gdjs.mse_95winCode.GDmusic_9595containerObjects1, gdjs.mse_95winCode.GDmusic_9595containerObjects3);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() + 1).getAsNumber(), "");
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].getVariables().getFromIndex(0)).setString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() + 2).getAsString());
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].getVariables().getFromIndex(2)).setNumber((gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].getX()) / 50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(3);
}}
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList42 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList43 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount3 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(gdjs.mse_95winCode.GDmusic_9595containerObjects1, gdjs.mse_95winCode.GDmusic_9595containerObjects3);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("x").getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("y").getAsNumber(), "");
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].getVariables().getFromIndex(0)).setString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("data").getAsString());
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].returnVariable(gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].getVariables().getFromIndex(2)).setNumber((gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].getX()) / 50);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects3[i].getBehavior("Resizable").setWidth(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData").getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getChild("width").getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}}
}

}


};gdjs.mse_95winCode.eventsList44 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("set_snap"), gdjs.mse_95winCode.GDset_9595snapObjects3);
{for(var i = 0, len = gdjs.mse_95winCode.GDset_9595snapObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDset_9595snapObjects3[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber() < 4);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("set_snap"), gdjs.mse_95winCode.GDset_9595snapObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").setNumber(4);
}{for(var i = 0, len = gdjs.mse_95winCode.GDset_9595snapObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDset_9595snapObjects2[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsString());
}
}}

}


};gdjs.mse_95winCode.eventsList45 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData")) < 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList41(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData")) > 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList43(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("MSE(set)", "MSE(set)");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber() < 4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MSE(set)", "MSE(set)", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(20));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(20).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(18));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(20).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings"));
}
{ //Subevents
gdjs.mse_95winCode.eventsList44(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22438876);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("set_snap"), gdjs.mse_95winCode.GDset_9595snapObjects2);
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings")), runtimeScene.getScene().getVariables().getFromIndex(18));
}{for(var i = 0, len = gdjs.mse_95winCode.GDset_9595snapObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDset_9595snapObjects2[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsNumber() < 4);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.storage.elementExistsInJSONFile("MSE(set)", "MSE(set)"));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("set_snap"), gdjs.mse_95winCode.GDset_9595snapObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").setNumber(4);
}{for(var i = 0, len = gdjs.mse_95winCode.GDset_9595snapObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDset_9595snapObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").getAsString());
}
}}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDsaveObjects2Objects = Hashtable.newFrom({"save": gdjs.mse_95winCode.GDsaveObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects4Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects4});
gdjs.mse_95winCode.eventsList46 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.mse_95winCode.GDsavingObjects2, gdjs.mse_95winCode.GDsavingObjects5);

{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects5.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects5[i].hide();
}
}}

}


};gdjs.mse_95winCode.eventsList47 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(STATE)", "MSE(STATE)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
{ //Subevents
gdjs.mse_95winCode.eventsList46(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList48 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("hhh", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects4Objects) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"));
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber()).getChild("json").setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
{ //Subevents
gdjs.mse_95winCode.eventsList47(runtimeScene);} //End of subevents
}
gdjs.mse_95winCode.localVariables.pop();

}


};gdjs.mse_95winCode.eventsList49 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects3);

for (gdjs.mse_95winCode.forEachIndex4 = 0;gdjs.mse_95winCode.forEachIndex4 < gdjs.mse_95winCode.GDmusic_9595containerObjects3.length;++gdjs.mse_95winCode.forEachIndex4) {
gdjs.mse_95winCode.GDmusic_9595containerObjects4.length = 0;


gdjs.mse_95winCode.forEachTemporary4 = gdjs.mse_95winCode.GDmusic_9595containerObjects3[gdjs.mse_95winCode.forEachIndex4];
gdjs.mse_95winCode.GDmusic_9595containerObjects4.push(gdjs.mse_95winCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {
{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("x").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects4.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects4[0].getX()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("y").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects4.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects4[0].getY()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("width").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects4.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects4[0].getWidth()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("data").setString(((gdjs.mse_95winCode.GDmusic_9595containerObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95winCode.GDmusic_9595containerObjects4[0].getVariables()).getFromIndex(0).getAsString());
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"), gdjs.mse_95winCode.localVariables[0].getFromIndex(0));
}
{ //Subevents: 
gdjs.mse_95winCode.eventsList48(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDhomeObjects1Objects = Hashtable.newFrom({"home": gdjs.mse_95winCode.GDhomeObjects1});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList50 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.mse_95winCode.GDsavingObjects1, gdjs.mse_95winCode.GDsavingObjects4);

{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects4[i].hide();
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "project_manager_html", true);
}}

}


};gdjs.mse_95winCode.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(STATE)", "MSE(STATE)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
{ //Subevents
gdjs.mse_95winCode.eventsList50(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList52 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("hhh", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"));
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber()).getChild("json").setString(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
{ //Subevents
gdjs.mse_95winCode.eventsList51(runtimeScene);} //End of subevents
}
gdjs.mse_95winCode.localVariables.pop();

}


};gdjs.mse_95winCode.mapOfEmptyGDmusic_9595containerObjects = Hashtable.newFrom({"music_container": []});
gdjs.mse_95winCode.eventsList53 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDmusic_9595containerObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDmusic_9595containerObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("x").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getX()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("y").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getY()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("width").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getWidth()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("data").setString(((gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"), gdjs.mse_95winCode.localVariables[0].getFromIndex(0));
}
{ //Subevents: 
gdjs.mse_95winCode.eventsList52(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfEmptyGDmusic_9595containerObjects) < 1;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "project_manager_html", true);
}}

}


};gdjs.mse_95winCode.eventsList54 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("save"), gdjs.mse_95winCode.GDsaveObjects2);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("");
variable.addChild("data", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("width", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("x", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("y", variable1);
}
variables._declare("nodeDatas", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDsaveObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("saving"), gdjs.mse_95winCode.GDsavingObjects2);
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings"));
}{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList49(runtimeScene);} //End of subevents
}
gdjs.mse_95winCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.mse_95winCode.GDhomeObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("");
variable.addChild("data", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("width", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("x", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("y", variable1);
}
variables._declare("nodeDatas", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDhomeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("saving"), gdjs.mse_95winCode.GDsavingObjects1);
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings"));
}{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList53(runtimeScene);} //End of subevents
}
gdjs.mse_95winCode.localVariables.pop();

}


};gdjs.mse_95winCode.eventsList55 = function(runtimeScene) {

{


gdjs.mse_95winCode.eventsList54(runtimeScene);
}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDsaveObjects2Objects = Hashtable.newFrom({"save": gdjs.mse_95winCode.GDsaveObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.asyncCallback22469652 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.mse_95winCode.GDdebugObjects5);
gdjs.copyArray(asyncObjectsList.getObjects("saving"), gdjs.mse_95winCode.GDsavingObjects5);

{for(var i = 0, len = gdjs.mse_95winCode.GDdebugObjects5.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdebugObjects5[i].getBehavior("Text").setText(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getGame().getVariables().getFromIndex(11).getAsString());
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects5.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects5[i].hide();
}
}gdjs.mse_95winCode.localVariables.length = 0;
}
gdjs.mse_95winCode.eventsList56 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
for (const obj of gdjs.mse_95winCode.GDsavingObjects4) asyncObjectsList.addObject("saving", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.fileSystem.saveStringToFileAsyncTask(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(3)), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getGame().getVariables().getFromIndex(11).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(15)), (runtimeScene) => (gdjs.mse_95winCode.asyncCallback22469652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95winCode.eventsList57 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("saving"), gdjs.mse_95winCode.GDsavingObjects4);
{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList56(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList58 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDmusic_9595containerObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDmusic_9595containerObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("x").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getX()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("y").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getY()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("width").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getWidth()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("data").setString(((gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"), gdjs.mse_95winCode.localVariables[0].getFromIndex(0));
}
{ //Subevents: 
gdjs.mse_95winCode.eventsList57(runtimeScene);} //Subevents end.
}
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDhomeObjects1Objects = Hashtable.newFrom({"home": gdjs.mse_95winCode.GDhomeObjects1});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects3});
gdjs.mse_95winCode.eventsList59 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "project_manager_win", true);
}}

}


};gdjs.mse_95winCode.asyncCallback22474436 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.mse_95winCode.GDdebugObjects5);
gdjs.copyArray(asyncObjectsList.getObjects("saving"), gdjs.mse_95winCode.GDsavingObjects5);

{for(var i = 0, len = gdjs.mse_95winCode.GDdebugObjects5.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdebugObjects5[i].getBehavior("Text").setText(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getGame().getVariables().getFromIndex(11).getAsString());
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects5.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects5[i].hide();
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList59(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.mse_95winCode.localVariables.length = 0;
}
gdjs.mse_95winCode.eventsList60 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
for (const obj of gdjs.mse_95winCode.GDsavingObjects4) asyncObjectsList.addObject("saving", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.fileSystem.saveStringToFileAsyncTask(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(3)), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getGame().getVariables().getFromIndex(11).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(15)), (runtimeScene) => (gdjs.mse_95winCode.asyncCallback22474436(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95winCode.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects3Objects) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("saving"), gdjs.mse_95winCode.GDsavingObjects4);
{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList60(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.mapOfEmptyGDmusic_9595containerObjects = Hashtable.newFrom({"music_container": []});
gdjs.mse_95winCode.eventsList62 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDmusic_9595containerObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDmusic_9595containerObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDmusic_9595containerObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("x").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getX()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("y").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getY()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("width").setNumber((( gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getWidth()));
}{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getChild("data").setString(((gdjs.mse_95winCode.GDmusic_9595containerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95winCode.GDmusic_9595containerObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"), gdjs.mse_95winCode.localVariables[0].getFromIndex(0));
}
{ //Subevents: 
gdjs.mse_95winCode.eventsList61(runtimeScene);} //Subevents end.
}
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfEmptyGDmusic_9595containerObjects) < 1;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "project_manager_win", true);
}}

}


};gdjs.mse_95winCode.eventsList63 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("save"), gdjs.mse_95winCode.GDsaveObjects2);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("");
variable.addChild("data", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("width", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("x", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("y", variable1);
}
variables._declare("nodeDatas", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDsaveObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("node"));
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings"));
}
{ //Subevents
gdjs.mse_95winCode.eventsList58(runtimeScene);} //End of subevents
}
gdjs.mse_95winCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.mse_95winCode.GDhomeObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("");
variable.addChild("data", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("width", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("x", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setNumber(0);
variable.addChild("y", variable1);
}
variables._declare("nodeDatas", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDhomeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("nodeData"));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings"));
}
{ //Subevents
gdjs.mse_95winCode.eventsList62(runtimeScene);} //End of subevents
}
gdjs.mse_95winCode.localVariables.pop();

}


};gdjs.mse_95winCode.eventsList64 = function(runtimeScene) {

{


gdjs.mse_95winCode.eventsList63(runtimeScene);
}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects1});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDenterObjects1Objects = Hashtable.newFrom({"enter": gdjs.mse_95winCode.GDenterObjects1});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects1});
gdjs.mse_95winCode.eventsList65 = function(runtimeScene) {

{

/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects1 */
/* Reuse gdjs.mse_95winCode.GDsearchObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDmusic_9595containerObjects1.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDmusic_9595containerObjects1[i].getVariableString(gdjs.mse_95winCode.GDmusic_9595containerObjects1[i].getVariables().getFromIndex(0)) == (( gdjs.mse_95winCode.GDsearchObjects1.length === 0 ) ? "" :gdjs.mse_95winCode.GDsearchObjects1[0].getText()) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDmusic_9595containerObjects1[k] = gdjs.mse_95winCode.GDmusic_9595containerObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDmusic_9595containerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects1);
{for(var i = 0, len = gdjs.mse_95winCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplay_9595nodeObjects1[i].setX((( gdjs.mse_95winCode.GDmusic_9595containerObjects1.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects1[0].getX()));
}
}}

}


};gdjs.mse_95winCode.eventsList66 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("enter"), gdjs.mse_95winCode.GDenterObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("search"), gdjs.mse_95winCode.GDsearchObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDenterObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDsearchObjects1.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDsearchObjects1[i].getBehavior("Text").getText() != "" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDsearchObjects1[k] = gdjs.mse_95winCode.GDsearchObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDsearchObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects1Objects);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDsnap_95959595boolObjects3Objects = Hashtable.newFrom({"snap_bool": gdjs.mse_95winCode.GDsnap_9595boolObjects3});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDshow_95959595boolObjects3Objects = Hashtable.newFrom({"show_bool": gdjs.mse_95winCode.GDshow_9595boolObjects3});
gdjs.mse_95winCode.eventsList67 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("snap_bool"), gdjs.mse_95winCode.GDsnap_9595boolObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDsnap_95959595boolObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9852260);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("snap"));
}{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s");
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("snap"));
}{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("show_bool"), gdjs.mse_95winCode.GDshow_9595boolObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDshow_95959595boolObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14575636);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid"));
}{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("set_snap"), gdjs.mse_95winCode.GDset_9595snapObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDset_9595snapObjects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDset_9595snapObjects3[i].isFocused() ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDset_9595snapObjects3[k] = gdjs.mse_95winCode.GDset_9595snapObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDset_9595snapObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.mse_95winCode.GDset_9595snapObjects3.length === 0 ) ? "" :gdjs.mse_95winCode.GDset_9595snapObjects3[0].getText())) > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.mse_95winCode.GDset_9595snapObjects3.length === 0 ) ? "" :gdjs.mse_95winCode.GDset_9595snapObjects3[0].getText())) != runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber());
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDset_9595snapObjects3 */
{runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").setNumber(gdjs.evtTools.common.toNumber((( gdjs.mse_95winCode.GDset_9595snapObjects3.length === 0 ) ? "" :gdjs.mse_95winCode.GDset_9595snapObjects3[0].getText())));
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("settings").getChild("grid").setNumber(gdjs.evtTools.common.toNumber((( gdjs.mse_95winCode.GDset_9595snapObjects3.length === 0 ) ? "" :gdjs.mse_95winCode.GDset_9595snapObjects3[0].getText())));
}{gdjs.evtTools.storage.writeStringInJSONFile("MSE(set)", "MSE(set)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(18)));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("show_bool"), gdjs.mse_95winCode.GDshow_9595boolObjects3);
gdjs.copyArray(runtimeScene.getObjects("snap_bool"), gdjs.mse_95winCode.GDsnap_9595boolObjects3);
{for(var i = 0, len = gdjs.mse_95winCode.GDsnap_9595boolObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsnap_9595boolObjects3[i].getBehavior("Animation").setAnimationName(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("snap").getAsString());
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDshow_9595boolObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDshow_9595boolObjects3[i].getBehavior("Animation").setAnimationName(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid").getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDsettings_95959595icObjects2Objects = Hashtable.newFrom({"settings_ic": gdjs.mse_95winCode.GDsettings_9595icObjects2});
gdjs.mse_95winCode.eventsList68 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95winCode.GDdrawObjects4);
gdjs.copyArray(gdjs.mse_95winCode.GDnameObjects3, gdjs.mse_95winCode.GDnameObjects4);

{for(var i = 0, len = gdjs.mse_95winCode.GDdrawObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdrawObjects4[i].drawLineV2(gdjs.evtTools.camera.getCameraX(runtimeScene, "Layer", 0) - (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.mse_95winCode.GDnameObjects4.length === 0 ) ? 0 :gdjs.mse_95winCode.GDnameObjects4[0].getY()) + 64, gdjs.evtTools.camera.getCameraX(runtimeScene, "Layer", 0) + (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.mse_95winCode.GDnameObjects4.length === 0 ) ? 0 :gdjs.mse_95winCode.GDnameObjects4[0].getY()) + 64, 1);
}
}}

}


};gdjs.mse_95winCode.eventsList69 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95winCode.GDdraw2Objects4);
gdjs.copyArray(gdjs.mse_95winCode.GDyyyObjects3, gdjs.mse_95winCode.GDyyyObjects4);

{for(var i = 0, len = gdjs.mse_95winCode.GDdraw2Objects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdraw2Objects4[i].drawLineV2(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) - (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.mse_95winCode.GDyyyObjects4.length === 0 ) ? 0 :gdjs.mse_95winCode.GDyyyObjects4[0].getPointY("")) + 96, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) + (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.mse_95winCode.GDyyyObjects4.length === 0 ) ? 0 :gdjs.mse_95winCode.GDyyyObjects4[0].getPointY("")) + 96, 1);
}
}}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects = Hashtable.newFrom({"music_container": gdjs.mse_95winCode.GDmusic_9595containerObjects2});
gdjs.mse_95winCode.eventsList70 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList71 = function(runtimeScene) {

{


const repeatCount4 = gdjs.evtTools.window.getWindowInnerWidth() / 4;
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95winCode.GDdrawObjects4);

let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.mse_95winCode.GDdrawObjects4.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdrawObjects4[i].drawLineV2(runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), -(10), runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), gdjs.evtTools.window.getWindowInnerHeight() + 500, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(7).add(4);
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.eventsList72 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList73 = function(runtimeScene) {

{


const repeatCount3 = gdjs.evtTools.window.getWindowInnerWidth() / runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber();
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95winCode.GDdrawObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0)
{
{for(var i = 0, len = gdjs.mse_95winCode.GDdrawObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdrawObjects3[i].drawLineV2(runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), -(10), runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber(), gdjs.evtTools.window.getWindowInnerHeight() + 500, 1);
}
}{runtimeScene.getScene().getVariables().getFromIndex(7).add(runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber());
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.eventsList74 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "settings");
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList67(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95winCode.GDsettings_9595icObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDsettings_9595icObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDsettings_9595icObjects2[i].getVariableBoolean(gdjs.mse_95winCode.GDsettings_9595icObjects2[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDsettings_9595icObjects2[k] = gdjs.mse_95winCode.GDsettings_9595icObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDsettings_9595icObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "settings");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95winCode.GDsettings_9595icObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDsettings_9595icObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDsettings_9595icObjects2[i].getVariableBoolean(gdjs.mse_95winCode.GDsettings_9595icObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDsettings_9595icObjects2[k] = gdjs.mse_95winCode.GDsettings_9595icObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDsettings_9595icObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "settings");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95winCode.GDsettings_9595icObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDsettings_95959595icObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDsettings_9595icObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDsettings_9595icObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsettings_9595icObjects2[i].returnVariable(gdjs.mse_95winCode.GDsettings_9595icObjects2[i].getVariables().getFromIndex(0)).toggle();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.mse_95winCode.GDnameObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDnameObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDnameObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDnameObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDnameObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid").getAsBoolean();
}
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.mse_95winCode.eventsList68(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("yyy"), gdjs.mse_95winCode.GDyyyObjects2);

for (gdjs.mse_95winCode.forEachIndex3 = 0;gdjs.mse_95winCode.forEachIndex3 < gdjs.mse_95winCode.GDyyyObjects2.length;++gdjs.mse_95winCode.forEachIndex3) {
gdjs.mse_95winCode.GDyyyObjects3.length = 0;


gdjs.mse_95winCode.forEachTemporary3 = gdjs.mse_95winCode.GDyyyObjects2[gdjs.mse_95winCode.forEachIndex3];
gdjs.mse_95winCode.GDyyyObjects3.push(gdjs.mse_95winCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.mse_95winCode.eventsList69(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(18).getChild("snap").getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.mse_95winCode.GDdebugObjects2);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);
{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber(), 96, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.mse_95winCode.GDdebugObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdebugObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(18).getChild("snap").getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.mse_95winCode.GDdebugObjects2);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects2);
{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects2Objects, 1, 96, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.mse_95winCode.GDdebugObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdebugObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() < 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid").getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("caca"), gdjs.mse_95winCode.GDcacaObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber((( gdjs.mse_95winCode.GDcacaObjects2.length === 0 ) ? 0 :gdjs.mse_95winCode.GDcacaObjects2[0].getPointX("")));
}
{ //Subevents
gdjs.mse_95winCode.eventsList71(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(18).getChild("grid").getAsNumber() > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(18).getChild("show_grid").getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("caca"), gdjs.mse_95winCode.GDcacaObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber((( gdjs.mse_95winCode.GDcacaObjects1.length === 0 ) ? 0 :gdjs.mse_95winCode.GDcacaObjects1[0].getPointX("")));
}
{ //Subevents
gdjs.mse_95winCode.eventsList73(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDUnnamedObjects1Objects = Hashtable.newFrom({"Unnamed": gdjs.mse_95winCode.GDUnnamedObjects1});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDUnnamedObjects1Objects = Hashtable.newFrom({"Unnamed": gdjs.mse_95winCode.GDUnnamedObjects1});
gdjs.mse_95winCode.userFunc0x10adf28 = function GDJSInlineCode(runtimeScene) {
"use strict";
var keyPressed = runtimeScene.getVariables().get('keyPressed')
function registerTxt(na,bold,italic,size){
    runtimeScene.registerObject({
    "assetStoreId": "",
    "bold": bold,
    "italic": italic,
    "name": na,
    "smoothed": true,
    "type": "TextObject::Text",
    "underlined": false,
    "variables": [],
    "effects": [],
    "behaviors": [
        {
            "name": "Effect",
            "type": "EffectCapability::EffectBehavior"
        },
        {
            "name": "Opacity",
            "type": "OpacityCapability::OpacityBehavior"
        },
        {
            "name": "Scale",
            "type": "ScalableCapability::ScalableBehavior"
        },
        {
            "name": "Text",
            "type": "TextContainerCapability::TextContainerBehavior"
        }
    ],
    "string": "Text",
    "font": "",
    "textAlignment": "left",
    "characterSize": size,
    "color": {
        "b": 0,
        "g": 0,
        "r": 0
    },
    "content": {
        "bold": false,
        "isOutlineEnabled": false,
        "isShadowEnabled": false,
        "italic": false,
        "outlineColor": "255;255;255",
        "outlineThickness": 2,
        "shadowAngle": 90,
        "shadowBlurRadius": 2,
        "shadowColor": "0;0;0",
        "shadowDistance": 4,
        "shadowOpacity": 127,
        "smoothed": true,
        "underlined": false,
        "text": "Text",
        "font": "",
        "textAlignment": "left",
        "verticalTextAlignment": "top",
        "characterSize": size,
        "color": "255;255;255"
    }
})
}
function getSetting(pluginName,setting){
    var set = runtimeScene.getGame().getVariables().get('data').getChildNamed('plugins').getChildNamed(pluginName).getChildNamed('settings').getChildNamed(setting)
    if(set.getChildNamed('type').getAsString() === 'bool'){
        return set.getChildNamed('true').getAsBoolean()
    }else{
        return set.getChildNamed('value').getAsNumberOrString()
    }
    
}
function createNode(posY){
    runtimeScene.createObject('music_container').setPosition(runtimeScene.getObjects('play_node')[0].getX(),posY)
}
try {
    eval(runtimeScene.getVariables().get("func2").getAsString()+runtimeScene.getGame().getVariables().get("data").getChildNamed("script").getAsString());
} catch (e) {
    var entreee = `
    `
    console.log(e)
    if (runtimeScene.getVariables().get('devMode').getAsString() === 'true'){
        runtimeScene.getVariables().get('devConsole').setString('//#####console#####//'+entreee+runtimeScene.getVariables().get('devconsole').getAsString()+entreee+e)
    }
    

}

};
gdjs.mse_95winCode.eventsList75 = function(runtimeScene) {

{


gdjs.mse_95winCode.userFunc0x10adf28(runtimeScene);

}


};gdjs.mse_95winCode.eventsList76 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.fileSystem.saveStringToFileAsync(runtimeScene.getScene().getVariables().getFromIndex(31).getAsString(), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug" + gdjs.fileSystem.getPathDelimiter() + "console.txt", gdjs.VariablesContainer.badVariable);
}}

}


};gdjs.mse_95winCode.asyncCallback22510100 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95winCode.localVariables);

{ //Subevents
gdjs.mse_95winCode.eventsList76(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.mse_95winCode.localVariables.length = 0;
}
gdjs.mse_95winCode.eventsList77 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.fileSystem.makeDirectoryAsync(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug", gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.mse_95winCode.asyncCallback22510100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95winCode.eventsList78 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.fileSystem.pathExists(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug");
if (isConditionTrue_0) {
{gdjs.fileSystem.saveStringToFileAsync(runtimeScene.getScene().getVariables().getFromIndex(31).getAsString(), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug" + gdjs.fileSystem.getPathDelimiter() + "console.txt", gdjs.VariablesContainer.badVariable);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.fileSystem.pathExists(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug"));
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList77(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList79 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.mse_95winCode.GDcoderObjects2, gdjs.mse_95winCode.GDcoderObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(14).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").getText() == "-/print console" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects3[k] = gdjs.mse_95winCode.GDcoderObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDcoderObjects3 */
{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").setText("");
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList78(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDcoderObjects2, gdjs.mse_95winCode.GDcoderObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").getText() == "-/de-activate dev mode" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects3[k] = gdjs.mse_95winCode.GDcoderObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDcoderObjects3 */
{runtimeScene.getScene().getVariables().getFromIndex(29).setString("");
}{gdjs.evtTools.storage.clearJSONFile("devMode1");
}{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").setText("");
}
}}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDcoderObjects2, gdjs.mse_95winCode.GDcoderObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").getText() == "-/lvl edit" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects3[k] = gdjs.mse_95winCode.GDcoderObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDcoderObjects3 */
{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").setText("");
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lvlEDIT", false);
}}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDcoderObjects2, gdjs.mse_95winCode.GDcoderObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects3.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").getText() == "-/activate dev mode" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects3[k] = gdjs.mse_95winCode.GDcoderObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDcoderObjects3 */
{runtimeScene.getScene().getVariables().getFromIndex(29).setString("true");
}{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").setText("");
}
}{runtimeScene.getScene().getVariables().getFromIndex(30).setString("");
}}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDcoderObjects2, gdjs.mse_95winCode.GDcoderObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects3.length;i<l;++i) {
    if ( (gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").getText()).startsWith("-/imp") ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects3[k] = gdjs.mse_95winCode.GDcoderObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects3.length;i<l;++i) {
    if ( (gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").getText()).endsWith("-") ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects3[k] = gdjs.mse_95winCode.GDcoderObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "F4");
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__UploadDownloadTextFile__UploadTextFile.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(32), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(gdjs.mse_95winCode.GDcoderObjects2, gdjs.mse_95winCode.GDcoderObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects3.length;i<l;++i) {
    if ( (gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").getText()).startsWith("-/ims") ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects3[k] = gdjs.mse_95winCode.GDcoderObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects3.length;i<l;++i) {
    if ( (gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").getText()).endsWith("-") ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects3[k] = gdjs.mse_95winCode.GDcoderObjects3[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "F4");
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__UploadDownloadTextFile__UploadTextFile.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(37), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("nameOfScr", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("{\"costom colour\":{    \"type\":\"bool\",    \"text\":\"costom colour\"  },  \"r\":{    \"type\":\"num_input\",    \"text\":\"R\",    \"max\":255,    \"min\":0  },  \"g\":{    \"type\":\"num_input\",    \"text\":\"G\",    \"max\":255,    \"min\":0  },  \"b\":{    \"type\":\"num_input\",    \"text\":\"B\",    \"max\":255,    \"min\":0  }}");
variables._declare("json", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__UploadDownloadTextFile__UploadFinished.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(32).getAsString()) > 4);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22520756);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.mse_95winCode.GDcoderObjects2, gdjs.mse_95winCode.GDcoderObjects3);

{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).setString(gdjs.evtTools.string.subStr((( gdjs.mse_95winCode.GDcoderObjects3.length === 0 ) ? "" :gdjs.mse_95winCode.GDcoderObjects3[0].getBehavior("Text").getText()), 6, gdjs.evtTools.string.strLen((( gdjs.mse_95winCode.GDcoderObjects3.length === 0 ) ? "" :gdjs.mse_95winCode.GDcoderObjects3[0].getBehavior("Text").getText())) - 7));
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getAsString()).getChild("script").setString(runtimeScene.getScene().getVariables().getFromIndex(32).getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getAsString()).getChild("enable").setBoolean(false);
}{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects3.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects3[i].getBehavior("Text").setText("");
}
}{runtimeScene.getScene().getVariables().getFromIndex(32).setString("");
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.mse_95winCode.localVariables[0].getFromIndex(1).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(gdjs.mse_95winCode.localVariables[0].getFromIndex(0).getAsString()).getChild("settings"));
}}
gdjs.mse_95winCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setString("");
variables._declare("nameOfScr", variable);
}
gdjs.mse_95winCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__UploadDownloadTextFile__UploadFinished.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(37).getAsString()) > 4);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22524172);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDcoderObjects2 */
{gdjs.mse_95winCode.localVariables[0].getFromIndex(0).setString(gdjs.evtTools.string.subStr((( gdjs.mse_95winCode.GDcoderObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDcoderObjects2[0].getBehavior("Text").getText()), 6, gdjs.evtTools.string.strLen((( gdjs.mse_95winCode.GDcoderObjects2.length === 0 ) ? "" :gdjs.mse_95winCode.GDcoderObjects2[0].getBehavior("Text").getText())) - 7));
}{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects2[i].getBehavior("Text").setText("");
}
}{runtimeScene.getScene().getVariables().getFromIndex(37).setString("");
}}
gdjs.mse_95winCode.localVariables.pop();

}


};gdjs.mse_95winCode.eventsList80 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95winCode.GDcoderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects2.length;i<l;++i) {
    if ( (gdjs.mse_95winCode.GDcoderObjects2[i].getBehavior("Text").getText()).startsWith("-/") ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects2[k] = gdjs.mse_95winCode.GDcoderObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList79(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList81 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.fileSystem.saveStringToFileAsync(runtimeScene.getScene().getVariables().getFromIndex(31).getAsString(), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug" + gdjs.fileSystem.getPathDelimiter() + "console.txt", gdjs.VariablesContainer.badVariable);
}{runtimeScene.getScene().getVariables().getFromIndex(30).setString("");
}}

}


};gdjs.mse_95winCode.asyncCallback22530596 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95winCode.localVariables);

{ //Subevents
gdjs.mse_95winCode.eventsList81(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.mse_95winCode.localVariables.length = 0;
}
gdjs.mse_95winCode.eventsList82 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.fileSystem.makeDirectoryAsync(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug", gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.mse_95winCode.asyncCallback22530596(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95winCode.eventsList83 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.fileSystem.pathExists(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug");
if (isConditionTrue_0) {
{gdjs.fileSystem.saveStringToFileAsync(runtimeScene.getScene().getVariables().getFromIndex(31).getAsString(), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug" + gdjs.fileSystem.getPathDelimiter() + "console.txt", gdjs.VariablesContainer.badVariable);
}{runtimeScene.getScene().getVariables().getFromIndex(30).setString("");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.fileSystem.pathExists(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + "debug"));
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList82(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects2Objects = Hashtable.newFrom({"panel3": gdjs.mse_95winCode.GDpanel3Objects2});
gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDscriptObjects2Objects = Hashtable.newFrom({"script": gdjs.mse_95winCode.GDscriptObjects2});
gdjs.mse_95winCode.eventsList84 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList85 = function(runtimeScene) {

{



}


{


const keyIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(28);
const valueIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(26);
const iterableReference3 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins");
if(!iterableReference3.isPrimitive()) {
for(
    const iteratorKey3 in 
    iterableReference3.getType() === "structure"
      ? iterableReference3.getAllChildren()
      : iterableReference3.getType() === "array"
        ? iterableReference3.getAllChildrenArray()
        : []
) {
    if(iterableReference3.getType() === "structure")
        keyIteratorReference3.setString(iteratorKey3);
    else if(iterableReference3.getType() === "array")
        keyIteratorReference3.setNumber(iteratorKey3);
    const structureChildVariable3 = iterableReference3.getChild(iteratorKey3)
    valueIteratorReference3.castTo(structureChildVariable3.getType())
    if(structureChildVariable3.isPrimitive()) {
        valueIteratorReference3.setValue(structureChildVariable3.getValue());
    } else if (structureChildVariable3.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference3.replaceChildren(structureChildVariable3.getAllChildren());
    } else if (structureChildVariable3.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference3.replaceChildrenArray(structureChildVariable3.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(28).getAsString()).getChild("enable").getAsBoolean();
}
if (isConditionTrue_0)
{
{runtimeScene.getScene().getVariables().getFromIndex(27).concatenateString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(28).getAsString()).getChild("script").getAsString() + gdjs.evtTools.string.newLine());
}}
}
}

}


};gdjs.mse_95winCode.eventsList86 = function(runtimeScene) {

};gdjs.mse_95winCode.eventsList87 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const keyIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(28);
const valueIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(26);
const iterableReference3 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins");
if(!iterableReference3.isPrimitive()) {
for(
    const iteratorKey3 in 
    iterableReference3.getType() === "structure"
      ? iterableReference3.getAllChildren()
      : iterableReference3.getType() === "array"
        ? iterableReference3.getAllChildrenArray()
        : []
) {
    if(iterableReference3.getType() === "structure")
        keyIteratorReference3.setString(iteratorKey3);
    else if(iterableReference3.getType() === "array")
        keyIteratorReference3.setNumber(iteratorKey3);
    const structureChildVariable3 = iterableReference3.getChild(iteratorKey3)
    valueIteratorReference3.castTo(structureChildVariable3.getType())
    if(structureChildVariable3.isPrimitive()) {
        valueIteratorReference3.setValue(structureChildVariable3.getValue());
    } else if (structureChildVariable3.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference3.replaceChildren(structureChildVariable3.getAllChildren());
    } else if (structureChildVariable3.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference3.replaceChildrenArray(structureChildVariable3.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(28).getAsString()).getChild("enable").getAsBoolean();
}
if (isConditionTrue_0)
{
{runtimeScene.getScene().getVariables().getFromIndex(27).concatenateString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(28).getAsString()).getChild("script").getAsString() + gdjs.evtTools.string.newLine());
}}
}
}

}


};gdjs.mse_95winCode.userFunc0x1219ef8 = function GDJSInlineCode(runtimeScene) {
"use strict";
const audio = new Audio();
audio.src = runtimeScene.getGame().getVariables().get("data").getChildNamed("audio").getAsString()
audio.addEventListener('loadedmetadata', () => {
    console.log(`Duration: ${audio.duration} seconds`);
    runtimeScene.getGame().getVariables().get("audio_len").setNumber(audio.duration)
    
});





};
gdjs.mse_95winCode.eventsList88 = function(runtimeScene) {

{


gdjs.mse_95winCode.userFunc0x1219ef8(runtimeScene);

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.mse_95winCode.userFunc0xcfc940 = function GDJSInlineCode(runtimeScene) {
"use strict";
var keyPressed = runtimeScene.getVariables().get('keyPressed')
function registerTxt(na,bold,italic,size){
    runtimeScene.registerObject({
    "assetStoreId": "",
    "bold": bold,
    "italic": italic,
    "name": na,
    "smoothed": true,
    "type": "TextObject::Text",
    "underlined": false,
    "variables": [],
    "effects": [],
    "behaviors": [
        {
            "name": "Effect",
            "type": "EffectCapability::EffectBehavior"
        },
        {
            "name": "Opacity",
            "type": "OpacityCapability::OpacityBehavior"
        },
        {
            "name": "Scale",
            "type": "ScalableCapability::ScalableBehavior"
        },
        {
            "name": "Text",
            "type": "TextContainerCapability::TextContainerBehavior"
        }
    ],
    "string": "Text",
    "font": "",
    "textAlignment": "left",
    "characterSize": size,
    "color": {
        "b": 0,
        "g": 0,
        "r": 0
    },
    "content": {
        "bold": false,
        "isOutlineEnabled": false,
        "isShadowEnabled": false,
        "italic": false,
        "outlineColor": "255;255;255",
        "outlineThickness": 2,
        "shadowAngle": 90,
        "shadowBlurRadius": 2,
        "shadowColor": "0;0;0",
        "shadowDistance": 4,
        "shadowOpacity": 127,
        "smoothed": true,
        "underlined": false,
        "text": "Text",
        "font": "",
        "textAlignment": "left",
        "verticalTextAlignment": "top",
        "characterSize": size,
        "color": "255;255;255"
    }
})
}
function getSetting(pluginName,setting){
    var set = runtimeScene.getGame().getVariables().get('data').getChildNamed('plugins').getChildNamed(pluginName).getChildNamed('settings').getChildNamed(setting)
    if(set.getChildNamed('type').getAsString() === 'bool'){
        return set.getChildNamed('true').getAsBoolean()
    }else{
        return set.getChildNamed('value').getAsNumberOrString()
    }
    
}
function createNode(posY){
    runtimeScene.createObject('music_container').setPosition(runtimeScene.getObjects('play_node')[0].getX(),posY)
}
try {
    eval(runtimeScene.getVariables().get("func2").getAsString()+runtimeScene.getVariables().get("PluginScript").getAsString());
} catch (e) {
    console.log(e)
}








};
gdjs.mse_95winCode.eventsList89 = function(runtimeScene) {

{


gdjs.mse_95winCode.userFunc0xcfc940(runtimeScene);

}


};gdjs.mse_95winCode.eventsList90 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95winCode.GDcoderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects2.length;i<l;++i) {
    if ( !(gdjs.mse_95winCode.GDcoderObjects2[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects2[k] = gdjs.mse_95winCode.GDcoderObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDcoderObjects2.length;i<l;++i) {
    if ( !((gdjs.mse_95winCode.GDcoderObjects2[i].getBehavior("Text").getText()).startsWith("-/")) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDcoderObjects2[k] = gdjs.mse_95winCode.GDcoderObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDcoderObjects2.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList75(runtimeScene);} //End of subevents
}

}


{


gdjs.mse_95winCode.eventsList80(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(21).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95winCode.GDcoderObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects2[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(21).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95winCode.GDcoderObjects2);
{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(29).getAsString() == "true");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22526484);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(30).setString("");
}{gdjs.evtTools.storage.writeStringInJSONFile("devMode1", "devMode1", "true");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("devMode1", "devMode1");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22527964);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(29).setString("true");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(14).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "F1");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList83(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("panel3"), gdjs.mse_95winCode.GDpanel3Objects2);
gdjs.copyArray(runtimeScene.getObjects("script"), gdjs.mse_95winCode.GDscriptObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDpanel3Objects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDpanel3Objects2[i].getZOrder() != 29 ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDpanel3Objects2[k] = gdjs.mse_95winCode.GDpanel3Objects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDpanel3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDpanel3Objects2Objects, gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDscriptObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "drop_down");
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(21));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList85(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(27).setString("");
}
{ //Subevents
gdjs.mse_95winCode.eventsList87(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("audio").getAsString()) > 6);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22537772);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList88(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(27).getAsString()) > 1);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList89(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDproperties_95959595textObjects1Objects = Hashtable.newFrom({"properties_text": gdjs.mse_95winCode.GDproperties_9595textObjects1});
gdjs.mse_95winCode.asyncCallback22540636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
{gdjs.evtTools.camera.showLayer(runtimeScene, "properties");
}gdjs.mse_95winCode.localVariables.length = 0;
}
gdjs.mse_95winCode.eventsList91 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.mse_95winCode.asyncCallback22540636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95winCode.asyncCallback22542988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "properties");
}gdjs.mse_95winCode.localVariables.length = 0;
}
gdjs.mse_95winCode.eventsList92 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.mse_95winCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.mse_95winCode.asyncCallback22542988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.mse_95winCode.eventsList93 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "properties"));
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList91(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "properties");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList92(runtimeScene);} //End of subevents
}

}


};gdjs.mse_95winCode.eventsList94 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDeventObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDeventObjects2[i].getBehavior("Text").getText() == "add event" ) {
        isConditionTrue_1 = true;
        gdjs.mse_95winCode.GDeventObjects2[k] = gdjs.mse_95winCode.GDeventObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDeventObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDeventObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDeventObjects2[i].isFocused() ) {
        isConditionTrue_1 = true;
        gdjs.mse_95winCode.GDeventObjects2[k] = gdjs.mse_95winCode.GDeventObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDeventObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(35).getChild("input-1").getAsNumber() == 0);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22550892);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDeventObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDeventObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDeventObjects2[i].setTextColor("255;255;255");
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDeventObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDeventObjects2[i].getBehavior("Text").setText("");
}
}{runtimeScene.getScene().getVariables().getFromIndex(35).getChild("input-1").setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("event"), gdjs.mse_95winCode.GDeventObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDeventObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDeventObjects2[i].getBehavior("Text").getText() == "" ) {
        isConditionTrue_1 = true;
        gdjs.mse_95winCode.GDeventObjects2[k] = gdjs.mse_95winCode.GDeventObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDeventObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDeventObjects2.length;i<l;++i) {
    if ( !(gdjs.mse_95winCode.GDeventObjects2[i].isFocused()) ) {
        isConditionTrue_1 = true;
        gdjs.mse_95winCode.GDeventObjects2[k] = gdjs.mse_95winCode.GDeventObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDeventObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22553276);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDeventObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDeventObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDeventObjects2[i].setTextColor("200;200;200");
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDeventObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDeventObjects2[i].getBehavior("Text").setText("add event");
}
}{runtimeScene.getScene().getVariables().getFromIndex(35).getChild("input-1").setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("search"), gdjs.mse_95winCode.GDsearchObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDsearchObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDsearchObjects2[i].getBehavior("Text").getText() == "search" ) {
        isConditionTrue_1 = true;
        gdjs.mse_95winCode.GDsearchObjects2[k] = gdjs.mse_95winCode.GDsearchObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDsearchObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDsearchObjects2.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDsearchObjects2[i].isFocused() ) {
        isConditionTrue_1 = true;
        gdjs.mse_95winCode.GDsearchObjects2[k] = gdjs.mse_95winCode.GDsearchObjects2[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDsearchObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(35).getChild("input-2").getAsNumber() == 0);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22555484);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDsearchObjects2 */
{for(var i = 0, len = gdjs.mse_95winCode.GDsearchObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsearchObjects2[i].setTextColor("255;255;255");
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDsearchObjects2.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsearchObjects2[i].getBehavior("Text").setText("");
}
}{runtimeScene.getScene().getVariables().getFromIndex(35).getChild("input-2").setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("search"), gdjs.mse_95winCode.GDsearchObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDsearchObjects1.length;i<l;++i) {
    if ( !(gdjs.mse_95winCode.GDsearchObjects1[i].isFocused()) ) {
        isConditionTrue_1 = true;
        gdjs.mse_95winCode.GDsearchObjects1[k] = gdjs.mse_95winCode.GDsearchObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDsearchObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDsearchObjects1.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDsearchObjects1[i].getBehavior("Text").getText() == "" ) {
        isConditionTrue_1 = true;
        gdjs.mse_95winCode.GDsearchObjects1[k] = gdjs.mse_95winCode.GDsearchObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDsearchObjects1.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22557388);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDsearchObjects1 */
{for(var i = 0, len = gdjs.mse_95winCode.GDsearchObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsearchObjects1[i].setTextColor("200;200;200");
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDsearchObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsearchObjects1[i].getBehavior("Text").setText("search");
}
}{runtimeScene.getScene().getVariables().getFromIndex(35).getChild("input-2").setNumber(0);
}}

}


};gdjs.mse_95winCode.eventsList95 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22308212);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95winCode.GDavObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95winCode.GDdrawObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95winCode.GDdraw2Objects1);
gdjs.copyArray(runtimeScene.getObjects("fast_backward"), gdjs.mse_95winCode.GDfast_9595backwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("fast_forward"), gdjs.mse_95winCode.GDfast_9595forwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95winCode.GDgearObjects1);
gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.mse_95winCode.GDhomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("json_icon"), gdjs.mse_95winCode.GDjson_9595iconObjects1);
gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95winCode.GDmenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.mse_95winCode.GDnameObjects1);
gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95winCode.GDplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects1);
gdjs.copyArray(runtimeScene.getObjects("save"), gdjs.mse_95winCode.GDsaveObjects1);
gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95winCode.GDsettings_9595icObjects1);
gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95winCode.GDstopObjects1);
gdjs.copyArray(runtimeScene.getObjects("yyy"), gdjs.mse_95winCode.GDyyyObjects1);
{for(var i = 0, len = gdjs.mse_95winCode.GDyyyObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDyyyObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdrawObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDnameObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplayObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDfast_9595forwardObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDfast_9595forwardObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDfast_9595backwardObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDfast_9595backwardObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDstopObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdraw2Objects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDjson_9595iconObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDjson_9595iconObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDavObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDhomeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDhomeObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDsaveObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsaveObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDgearObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmenuObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplay_9595nodeObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
for(var i = 0, len = gdjs.mse_95winCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsettings_9595icObjects1[i].getBehavior("Effect").setEffectStringParameter("Effect", "Outline", "92;0;172");
}
}}

}


{


gdjs.mse_95winCode.eventsList4(runtimeScene);
}


{


gdjs.mse_95winCode.eventsList5(runtimeScene);
}


{



}


{


gdjs.mse_95winCode.eventsList6(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("dd"), gdjs.mse_95winCode.GDddObjects1);
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.mse_95winCode.GDdebugObjects1);
gdjs.copyArray(runtimeScene.getObjects("debug2"), gdjs.mse_95winCode.GDdebug2Objects1);
{for(var i = 0, len = gdjs.mse_95winCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdebugObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0))));
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDddObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDddObjects1[i].setCenterXInScene(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) * 50);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDdebug2Objects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdebug2Objects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.round(runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber())) + " sec");
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1);
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "error");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) > 0;
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "error");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95winCode.GDplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95winCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "playing" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDplayObjects1[k] = gdjs.mse_95winCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDstopObjects1.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDstopObjects1[i].getVariableBoolean(gdjs.mse_95winCode.GDstopObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDstopObjects1[k] = gdjs.mse_95winCode.GDstopObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDstopObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) <= 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.sound.isMusicOnChannelStopped(runtimeScene, 1));
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95winCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.mse_95winCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.mse_95winCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "pausef" ) {
        isConditionTrue_0 = true;
        gdjs.mse_95winCode.GDplayObjects1[k] = gdjs.mse_95winCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.mse_95winCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22346460);
}
}
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{



}


{



}


{


gdjs.mse_95winCode.eventsList18(runtimeScene);
}


{


gdjs.mse_95winCode.eventsList36(runtimeScene);
}


{


gdjs.mse_95winCode.eventsList39(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.mse_95winCode.GDinfoObjects1);
{for(var i = 0, len = gdjs.mse_95winCode.GDinfoObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDinfoObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(437 - 360));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("av"), gdjs.mse_95winCode.GDavObjects1);
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95winCode.GDcoderObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95winCode.GDdrawObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95winCode.GDdraw2Objects1);
gdjs.copyArray(runtimeScene.getObjects("fast_backward"), gdjs.mse_95winCode.GDfast_9595backwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("fast_forward"), gdjs.mse_95winCode.GDfast_9595forwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.mse_95winCode.GDgearObjects1);
gdjs.copyArray(runtimeScene.getObjects("home"), gdjs.mse_95winCode.GDhomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("json_icon"), gdjs.mse_95winCode.GDjson_9595iconObjects1);
gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.mse_95winCode.GDmenuObjects1);
gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.mse_95winCode.GDnameObjects1);
gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.mse_95winCode.GDname2Objects1);
gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.mse_95winCode.GDplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.mse_95winCode.GDplay_9595nodeObjects1);
gdjs.copyArray(runtimeScene.getObjects("save"), gdjs.mse_95winCode.GDsaveObjects1);
gdjs.copyArray(runtimeScene.getObjects("saving"), gdjs.mse_95winCode.GDsavingObjects1);
gdjs.copyArray(runtimeScene.getObjects("settings_ic"), gdjs.mse_95winCode.GDsettings_9595icObjects1);
gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.mse_95winCode.GDstopObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{for(var i = 0, len = gdjs.mse_95winCode.GDname2Objects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDname2Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(11).getAsString());
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("script").getAsString());
}
}{gdjs.evtTools.sound.setMusicOnChannelPitch(runtimeScene, 1, 1);
}{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 1, 70);
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdrawObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDnameObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplayObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDfast_9595forwardObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDfast_9595forwardObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDfast_9595backwardObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDfast_9595backwardObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDstopObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdraw2Objects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDjson_9595iconObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDjson_9595iconObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDavObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDhomeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDhomeObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDsaveObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsaveObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDgearObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmenuObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplay_9595nodeObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsettings_9595icObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdrawObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDnameObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplayObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDfast_9595forwardObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDfast_9595forwardObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDfast_9595backwardObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDfast_9595backwardObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDstopObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdraw2Objects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDjson_9595iconObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDjson_9595iconObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDavObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDhomeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDhomeObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDsaveObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsaveObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDgearObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmenuObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplay_9595nodeObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsettings_9595icObjects1[i].getBehavior("Effect").enableEffect("hh", false);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmusic_9595containerObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdrawObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDnameObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplayObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDfast_9595forwardObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDfast_9595forwardObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDfast_9595backwardObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDfast_9595backwardObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDstopObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDstopObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdraw2Objects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDjson_9595iconObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDjson_9595iconObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDavObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDavObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDhomeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDhomeObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDsaveObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsaveObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDgearObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDmenuObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDmenuObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDplay_9595nodeObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
for(var i = 0, len = gdjs.mse_95winCode.GDsettings_9595icObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsettings_9595icObjects1[i].getBehavior("Effect").enableEffect("Effectol", false);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDsavingObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDsavingObjects1[i].hide();
}
}
{ //Subevents
gdjs.mse_95winCode.eventsList45(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(14).getAsBoolean();
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList55(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(14).getAsBoolean();
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList64(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.mse_95winCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDmusic_95959595containerObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDmusic_9595containerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("show_event"), gdjs.mse_95winCode.GDshow_9595eventObjects1);
{for(var i = 0, len = gdjs.mse_95winCode.GDshow_9595eventObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDshow_9595eventObjects1[i].getBehavior("Text").setText("properties\nevents: " + ((gdjs.mse_95winCode.GDmusic_9595containerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95winCode.GDmusic_9595containerObjects1[0].getVariables()).getFromIndex(0).getAsString() + "\nX: " + gdjs.evtTools.common.toString((( gdjs.mse_95winCode.GDmusic_9595containerObjects1.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects1[0].getX())) + "\nY: " + gdjs.evtTools.common.toString((( gdjs.mse_95winCode.GDmusic_9595containerObjects1.length === 0 ) ? 0 :gdjs.mse_95winCode.GDmusic_9595containerObjects1[0].getY())) + "\nTime: " + gdjs.evtTools.common.toString(((gdjs.mse_95winCode.GDmusic_9595containerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.mse_95winCode.GDmusic_9595containerObjects1[0].getVariables()).getFromIndex(2).getAsNumber()));
}
}}

}


{


gdjs.mse_95winCode.eventsList66(runtimeScene);
}


{


gdjs.mse_95winCode.eventsList74(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Unnamed"), gdjs.mse_95winCode.GDUnnamedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDUnnamedObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDUnnamedObjects1 */
{for(var i = 0, len = gdjs.mse_95winCode.GDUnnamedObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDUnnamedObjects1[i].getBehavior("Effect").enableEffect("Effect2", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Unnamed"), gdjs.mse_95winCode.GDUnnamedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDUnnamedObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.mse_95winCode.GDUnnamedObjects1 */
{for(var i = 0, len = gdjs.mse_95winCode.GDUnnamedObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDUnnamedObjects1[i].getBehavior("Effect").enableEffect("Effect2", false);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95winCode.GDcoderObjects1);
gdjs.copyArray(runtimeScene.getObjects("func"), gdjs.mse_95winCode.GDfuncObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(19).setString((( gdjs.mse_95winCode.GDfuncObjects1.length === 0 ) ? "" :gdjs.mse_95winCode.GDfuncObjects1[0].getBehavior("Text").getText()) + gdjs.evtTools.string.newLine());
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("script").setString((( gdjs.mse_95winCode.GDcoderObjects1.length === 0 ) ? "" :gdjs.mse_95winCode.GDcoderObjects1[0].getBehavior("Text").getText()));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22504612);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(22).setString(gdjs.evtTools.input.lastPressedKey(runtimeScene));
}}

}


{


gdjs.mse_95winCode.eventsList90(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.mse_95winCode.GDdrawObjects1);
gdjs.copyArray(runtimeScene.getObjects("draw2"), gdjs.mse_95winCode.GDdraw2Objects1);
{for(var i = 0, len = gdjs.mse_95winCode.GDdrawObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdrawObjects1[i].setOutlineOpacity(100);
}
}{for(var i = 0, len = gdjs.mse_95winCode.GDdraw2Objects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDdraw2Objects1[i].setOutlineOpacity(100);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("properties_text"), gdjs.mse_95winCode.GDproperties_9595textObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.mse_95winCode.mapOfGDgdjs_9546mse_959595winCode_9546GDproperties_95959595textObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.mse_95winCode.eventsList93(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "properties");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95winCode.GDcoderObjects1);
{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects1[i].getBehavior("Resizable").setWidth(1069);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "properties"));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("coder"), gdjs.mse_95winCode.GDcoderObjects1);
{for(var i = 0, len = gdjs.mse_95winCode.GDcoderObjects1.length ;i < len;++i) {
    gdjs.mse_95winCode.GDcoderObjects1[i].getBehavior("Resizable").setWidth(1280);
}
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.mse_95winCode.eventsList94(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.mse_95winCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.mse_95winCode.GDpanelObjects1.length = 0;
gdjs.mse_95winCode.GDpanelObjects2.length = 0;
gdjs.mse_95winCode.GDpanelObjects3.length = 0;
gdjs.mse_95winCode.GDpanelObjects4.length = 0;
gdjs.mse_95winCode.GDpanelObjects5.length = 0;
gdjs.mse_95winCode.GDpanelObjects6.length = 0;
gdjs.mse_95winCode.GDpanel2Objects1.length = 0;
gdjs.mse_95winCode.GDpanel2Objects2.length = 0;
gdjs.mse_95winCode.GDpanel2Objects3.length = 0;
gdjs.mse_95winCode.GDpanel2Objects4.length = 0;
gdjs.mse_95winCode.GDpanel2Objects5.length = 0;
gdjs.mse_95winCode.GDpanel2Objects6.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects1.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects2.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects3.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects4.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects5.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects6.length = 0;
gdjs.mse_95winCode.GDdrawObjects1.length = 0;
gdjs.mse_95winCode.GDdrawObjects2.length = 0;
gdjs.mse_95winCode.GDdrawObjects3.length = 0;
gdjs.mse_95winCode.GDdrawObjects4.length = 0;
gdjs.mse_95winCode.GDdrawObjects5.length = 0;
gdjs.mse_95winCode.GDdrawObjects6.length = 0;
gdjs.mse_95winCode.GDnameObjects1.length = 0;
gdjs.mse_95winCode.GDnameObjects2.length = 0;
gdjs.mse_95winCode.GDnameObjects3.length = 0;
gdjs.mse_95winCode.GDnameObjects4.length = 0;
gdjs.mse_95winCode.GDnameObjects5.length = 0;
gdjs.mse_95winCode.GDnameObjects6.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects1.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects4.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects5.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects6.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects1.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects2.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects3.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects4.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects5.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects6.length = 0;
gdjs.mse_95winCode.GDplayObjects1.length = 0;
gdjs.mse_95winCode.GDplayObjects2.length = 0;
gdjs.mse_95winCode.GDplayObjects3.length = 0;
gdjs.mse_95winCode.GDplayObjects4.length = 0;
gdjs.mse_95winCode.GDplayObjects5.length = 0;
gdjs.mse_95winCode.GDplayObjects6.length = 0;
gdjs.mse_95winCode.GDdebugObjects1.length = 0;
gdjs.mse_95winCode.GDdebugObjects2.length = 0;
gdjs.mse_95winCode.GDdebugObjects3.length = 0;
gdjs.mse_95winCode.GDdebugObjects4.length = 0;
gdjs.mse_95winCode.GDdebugObjects5.length = 0;
gdjs.mse_95winCode.GDdebugObjects6.length = 0;
gdjs.mse_95winCode.GDstopObjects1.length = 0;
gdjs.mse_95winCode.GDstopObjects2.length = 0;
gdjs.mse_95winCode.GDstopObjects3.length = 0;
gdjs.mse_95winCode.GDstopObjects4.length = 0;
gdjs.mse_95winCode.GDstopObjects5.length = 0;
gdjs.mse_95winCode.GDstopObjects6.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects1.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects2.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects3.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects4.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects5.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects6.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects1.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects2.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects3.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects4.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects5.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects6.length = 0;
gdjs.mse_95winCode.GDgearObjects1.length = 0;
gdjs.mse_95winCode.GDgearObjects2.length = 0;
gdjs.mse_95winCode.GDgearObjects3.length = 0;
gdjs.mse_95winCode.GDgearObjects4.length = 0;
gdjs.mse_95winCode.GDgearObjects5.length = 0;
gdjs.mse_95winCode.GDgearObjects6.length = 0;
gdjs.mse_95winCode.GDbar1Objects1.length = 0;
gdjs.mse_95winCode.GDbar1Objects2.length = 0;
gdjs.mse_95winCode.GDbar1Objects3.length = 0;
gdjs.mse_95winCode.GDbar1Objects4.length = 0;
gdjs.mse_95winCode.GDbar1Objects5.length = 0;
gdjs.mse_95winCode.GDbar1Objects6.length = 0;
gdjs.mse_95winCode.GDyyyObjects1.length = 0;
gdjs.mse_95winCode.GDyyyObjects2.length = 0;
gdjs.mse_95winCode.GDyyyObjects3.length = 0;
gdjs.mse_95winCode.GDyyyObjects4.length = 0;
gdjs.mse_95winCode.GDyyyObjects5.length = 0;
gdjs.mse_95winCode.GDyyyObjects6.length = 0;
gdjs.mse_95winCode.GDcacaObjects1.length = 0;
gdjs.mse_95winCode.GDcacaObjects2.length = 0;
gdjs.mse_95winCode.GDcacaObjects3.length = 0;
gdjs.mse_95winCode.GDcacaObjects4.length = 0;
gdjs.mse_95winCode.GDcacaObjects5.length = 0;
gdjs.mse_95winCode.GDcacaObjects6.length = 0;
gdjs.mse_95winCode.GDdraw2Objects1.length = 0;
gdjs.mse_95winCode.GDdraw2Objects2.length = 0;
gdjs.mse_95winCode.GDdraw2Objects3.length = 0;
gdjs.mse_95winCode.GDdraw2Objects4.length = 0;
gdjs.mse_95winCode.GDdraw2Objects5.length = 0;
gdjs.mse_95winCode.GDdraw2Objects6.length = 0;
gdjs.mse_95winCode.GDddObjects1.length = 0;
gdjs.mse_95winCode.GDddObjects2.length = 0;
gdjs.mse_95winCode.GDddObjects3.length = 0;
gdjs.mse_95winCode.GDddObjects4.length = 0;
gdjs.mse_95winCode.GDddObjects5.length = 0;
gdjs.mse_95winCode.GDddObjects6.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects1.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects2.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects3.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects4.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects5.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects6.length = 0;
gdjs.mse_95winCode.GDavObjects1.length = 0;
gdjs.mse_95winCode.GDavObjects2.length = 0;
gdjs.mse_95winCode.GDavObjects3.length = 0;
gdjs.mse_95winCode.GDavObjects4.length = 0;
gdjs.mse_95winCode.GDavObjects5.length = 0;
gdjs.mse_95winCode.GDavObjects6.length = 0;
gdjs.mse_95winCode.GDexportObjects1.length = 0;
gdjs.mse_95winCode.GDexportObjects2.length = 0;
gdjs.mse_95winCode.GDexportObjects3.length = 0;
gdjs.mse_95winCode.GDexportObjects4.length = 0;
gdjs.mse_95winCode.GDexportObjects5.length = 0;
gdjs.mse_95winCode.GDexportObjects6.length = 0;
gdjs.mse_95winCode.GDbadObjects1.length = 0;
gdjs.mse_95winCode.GDbadObjects2.length = 0;
gdjs.mse_95winCode.GDbadObjects3.length = 0;
gdjs.mse_95winCode.GDbadObjects4.length = 0;
gdjs.mse_95winCode.GDbadObjects5.length = 0;
gdjs.mse_95winCode.GDbadObjects6.length = 0;
gdjs.mse_95winCode.GDpaintObjects1.length = 0;
gdjs.mse_95winCode.GDpaintObjects2.length = 0;
gdjs.mse_95winCode.GDpaintObjects3.length = 0;
gdjs.mse_95winCode.GDpaintObjects4.length = 0;
gdjs.mse_95winCode.GDpaintObjects5.length = 0;
gdjs.mse_95winCode.GDpaintObjects6.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects1.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects2.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects3.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects4.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects5.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects6.length = 0;
gdjs.mse_95winCode.GDinffofoObjects1.length = 0;
gdjs.mse_95winCode.GDinffofoObjects2.length = 0;
gdjs.mse_95winCode.GDinffofoObjects3.length = 0;
gdjs.mse_95winCode.GDinffofoObjects4.length = 0;
gdjs.mse_95winCode.GDinffofoObjects5.length = 0;
gdjs.mse_95winCode.GDinffofoObjects6.length = 0;
gdjs.mse_95winCode.GDlogoObjects1.length = 0;
gdjs.mse_95winCode.GDlogoObjects2.length = 0;
gdjs.mse_95winCode.GDlogoObjects3.length = 0;
gdjs.mse_95winCode.GDlogoObjects4.length = 0;
gdjs.mse_95winCode.GDlogoObjects5.length = 0;
gdjs.mse_95winCode.GDlogoObjects6.length = 0;
gdjs.mse_95winCode.GDasdObjects1.length = 0;
gdjs.mse_95winCode.GDasdObjects2.length = 0;
gdjs.mse_95winCode.GDasdObjects3.length = 0;
gdjs.mse_95winCode.GDasdObjects4.length = 0;
gdjs.mse_95winCode.GDasdObjects5.length = 0;
gdjs.mse_95winCode.GDasdObjects6.length = 0;
gdjs.mse_95winCode.GDmenuObjects1.length = 0;
gdjs.mse_95winCode.GDmenuObjects2.length = 0;
gdjs.mse_95winCode.GDmenuObjects3.length = 0;
gdjs.mse_95winCode.GDmenuObjects4.length = 0;
gdjs.mse_95winCode.GDmenuObjects5.length = 0;
gdjs.mse_95winCode.GDmenuObjects6.length = 0;
gdjs.mse_95winCode.GDpanel3Objects1.length = 0;
gdjs.mse_95winCode.GDpanel3Objects2.length = 0;
gdjs.mse_95winCode.GDpanel3Objects3.length = 0;
gdjs.mse_95winCode.GDpanel3Objects4.length = 0;
gdjs.mse_95winCode.GDpanel3Objects5.length = 0;
gdjs.mse_95winCode.GDpanel3Objects6.length = 0;
gdjs.mse_95winCode.GDhelpObjects1.length = 0;
gdjs.mse_95winCode.GDhelpObjects2.length = 0;
gdjs.mse_95winCode.GDhelpObjects3.length = 0;
gdjs.mse_95winCode.GDhelpObjects4.length = 0;
gdjs.mse_95winCode.GDhelpObjects5.length = 0;
gdjs.mse_95winCode.GDhelpObjects6.length = 0;
gdjs.mse_95winCode.GDexObjects1.length = 0;
gdjs.mse_95winCode.GDexObjects2.length = 0;
gdjs.mse_95winCode.GDexObjects3.length = 0;
gdjs.mse_95winCode.GDexObjects4.length = 0;
gdjs.mse_95winCode.GDexObjects5.length = 0;
gdjs.mse_95winCode.GDexObjects6.length = 0;
gdjs.mse_95winCode.GDinfoObjects1.length = 0;
gdjs.mse_95winCode.GDinfoObjects2.length = 0;
gdjs.mse_95winCode.GDinfoObjects3.length = 0;
gdjs.mse_95winCode.GDinfoObjects4.length = 0;
gdjs.mse_95winCode.GDinfoObjects5.length = 0;
gdjs.mse_95winCode.GDinfoObjects6.length = 0;
gdjs.mse_95winCode.GDbackObjects1.length = 0;
gdjs.mse_95winCode.GDbackObjects2.length = 0;
gdjs.mse_95winCode.GDbackObjects3.length = 0;
gdjs.mse_95winCode.GDbackObjects4.length = 0;
gdjs.mse_95winCode.GDbackObjects5.length = 0;
gdjs.mse_95winCode.GDbackObjects6.length = 0;
gdjs.mse_95winCode.GDpanel4Objects1.length = 0;
gdjs.mse_95winCode.GDpanel4Objects2.length = 0;
gdjs.mse_95winCode.GDpanel4Objects3.length = 0;
gdjs.mse_95winCode.GDpanel4Objects4.length = 0;
gdjs.mse_95winCode.GDpanel4Objects5.length = 0;
gdjs.mse_95winCode.GDpanel4Objects6.length = 0;
gdjs.mse_95winCode.GDerrObjects1.length = 0;
gdjs.mse_95winCode.GDerrObjects2.length = 0;
gdjs.mse_95winCode.GDerrObjects3.length = 0;
gdjs.mse_95winCode.GDerrObjects4.length = 0;
gdjs.mse_95winCode.GDerrObjects5.length = 0;
gdjs.mse_95winCode.GDerrObjects6.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects1.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects2.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects3.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects4.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects5.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects6.length = 0;
gdjs.mse_95winCode.GDhoverObjects1.length = 0;
gdjs.mse_95winCode.GDhoverObjects2.length = 0;
gdjs.mse_95winCode.GDhoverObjects3.length = 0;
gdjs.mse_95winCode.GDhoverObjects4.length = 0;
gdjs.mse_95winCode.GDhoverObjects5.length = 0;
gdjs.mse_95winCode.GDhoverObjects6.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects1.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects2.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects3.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects4.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects5.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects6.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects1.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects2.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects3.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects4.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects5.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects6.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects1.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects2.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects3.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects4.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects5.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects6.length = 0;
gdjs.mse_95winCode.GDidObjects1.length = 0;
gdjs.mse_95winCode.GDidObjects2.length = 0;
gdjs.mse_95winCode.GDidObjects3.length = 0;
gdjs.mse_95winCode.GDidObjects4.length = 0;
gdjs.mse_95winCode.GDidObjects5.length = 0;
gdjs.mse_95winCode.GDidObjects6.length = 0;
gdjs.mse_95winCode.GDname2Objects1.length = 0;
gdjs.mse_95winCode.GDname2Objects2.length = 0;
gdjs.mse_95winCode.GDname2Objects3.length = 0;
gdjs.mse_95winCode.GDname2Objects4.length = 0;
gdjs.mse_95winCode.GDname2Objects5.length = 0;
gdjs.mse_95winCode.GDname2Objects6.length = 0;
gdjs.mse_95winCode.GDeventObjects1.length = 0;
gdjs.mse_95winCode.GDeventObjects2.length = 0;
gdjs.mse_95winCode.GDeventObjects3.length = 0;
gdjs.mse_95winCode.GDeventObjects4.length = 0;
gdjs.mse_95winCode.GDeventObjects5.length = 0;
gdjs.mse_95winCode.GDeventObjects6.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects1.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects2.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects3.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects4.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects5.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects6.length = 0;
gdjs.mse_95winCode.GDsearchObjects1.length = 0;
gdjs.mse_95winCode.GDsearchObjects2.length = 0;
gdjs.mse_95winCode.GDsearchObjects3.length = 0;
gdjs.mse_95winCode.GDsearchObjects4.length = 0;
gdjs.mse_95winCode.GDsearchObjects5.length = 0;
gdjs.mse_95winCode.GDsearchObjects6.length = 0;
gdjs.mse_95winCode.GDenterObjects1.length = 0;
gdjs.mse_95winCode.GDenterObjects2.length = 0;
gdjs.mse_95winCode.GDenterObjects3.length = 0;
gdjs.mse_95winCode.GDenterObjects4.length = 0;
gdjs.mse_95winCode.GDenterObjects5.length = 0;
gdjs.mse_95winCode.GDenterObjects6.length = 0;
gdjs.mse_95winCode.GDsaveObjects1.length = 0;
gdjs.mse_95winCode.GDsaveObjects2.length = 0;
gdjs.mse_95winCode.GDsaveObjects3.length = 0;
gdjs.mse_95winCode.GDsaveObjects4.length = 0;
gdjs.mse_95winCode.GDsaveObjects5.length = 0;
gdjs.mse_95winCode.GDsaveObjects6.length = 0;
gdjs.mse_95winCode.GDspeedObjects1.length = 0;
gdjs.mse_95winCode.GDspeedObjects2.length = 0;
gdjs.mse_95winCode.GDspeedObjects3.length = 0;
gdjs.mse_95winCode.GDspeedObjects4.length = 0;
gdjs.mse_95winCode.GDspeedObjects5.length = 0;
gdjs.mse_95winCode.GDspeedObjects6.length = 0;
gdjs.mse_95winCode.GDhomeObjects1.length = 0;
gdjs.mse_95winCode.GDhomeObjects2.length = 0;
gdjs.mse_95winCode.GDhomeObjects3.length = 0;
gdjs.mse_95winCode.GDhomeObjects4.length = 0;
gdjs.mse_95winCode.GDhomeObjects5.length = 0;
gdjs.mse_95winCode.GDhomeObjects6.length = 0;
gdjs.mse_95winCode.GDcropObjects1.length = 0;
gdjs.mse_95winCode.GDcropObjects2.length = 0;
gdjs.mse_95winCode.GDcropObjects3.length = 0;
gdjs.mse_95winCode.GDcropObjects4.length = 0;
gdjs.mse_95winCode.GDcropObjects5.length = 0;
gdjs.mse_95winCode.GDcropObjects6.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects1.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects2.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects3.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects4.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects5.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects6.length = 0;
gdjs.mse_95winCode.GDsetObjects1.length = 0;
gdjs.mse_95winCode.GDsetObjects2.length = 0;
gdjs.mse_95winCode.GDsetObjects3.length = 0;
gdjs.mse_95winCode.GDsetObjects4.length = 0;
gdjs.mse_95winCode.GDsetObjects5.length = 0;
gdjs.mse_95winCode.GDsetObjects6.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects1.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects2.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects3.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects4.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects5.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects6.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects1.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects2.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects3.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects4.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects5.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects6.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects1.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects2.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects3.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects4.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects5.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects6.length = 0;
gdjs.mse_95winCode.GDdebug2Objects1.length = 0;
gdjs.mse_95winCode.GDdebug2Objects2.length = 0;
gdjs.mse_95winCode.GDdebug2Objects3.length = 0;
gdjs.mse_95winCode.GDdebug2Objects4.length = 0;
gdjs.mse_95winCode.GDdebug2Objects5.length = 0;
gdjs.mse_95winCode.GDdebug2Objects6.length = 0;
gdjs.mse_95winCode.GDbuttonObjects1.length = 0;
gdjs.mse_95winCode.GDbuttonObjects2.length = 0;
gdjs.mse_95winCode.GDbuttonObjects3.length = 0;
gdjs.mse_95winCode.GDbuttonObjects4.length = 0;
gdjs.mse_95winCode.GDbuttonObjects5.length = 0;
gdjs.mse_95winCode.GDbuttonObjects6.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects1.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects2.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects3.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects4.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects5.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects6.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects1.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects2.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects3.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects4.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects5.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects6.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects1.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects2.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects3.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects4.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects5.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects6.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects1.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects2.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects3.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects4.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects5.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects6.length = 0;
gdjs.mse_95winCode.GDscriptObjects1.length = 0;
gdjs.mse_95winCode.GDscriptObjects2.length = 0;
gdjs.mse_95winCode.GDscriptObjects3.length = 0;
gdjs.mse_95winCode.GDscriptObjects4.length = 0;
gdjs.mse_95winCode.GDscriptObjects5.length = 0;
gdjs.mse_95winCode.GDscriptObjects6.length = 0;
gdjs.mse_95winCode.GDcoderObjects1.length = 0;
gdjs.mse_95winCode.GDcoderObjects2.length = 0;
gdjs.mse_95winCode.GDcoderObjects3.length = 0;
gdjs.mse_95winCode.GDcoderObjects4.length = 0;
gdjs.mse_95winCode.GDcoderObjects5.length = 0;
gdjs.mse_95winCode.GDcoderObjects6.length = 0;
gdjs.mse_95winCode.GDfuncObjects1.length = 0;
gdjs.mse_95winCode.GDfuncObjects2.length = 0;
gdjs.mse_95winCode.GDfuncObjects3.length = 0;
gdjs.mse_95winCode.GDfuncObjects4.length = 0;
gdjs.mse_95winCode.GDfuncObjects5.length = 0;
gdjs.mse_95winCode.GDfuncObjects6.length = 0;
gdjs.mse_95winCode.GDspeakerObjects1.length = 0;
gdjs.mse_95winCode.GDspeakerObjects2.length = 0;
gdjs.mse_95winCode.GDspeakerObjects3.length = 0;
gdjs.mse_95winCode.GDspeakerObjects4.length = 0;
gdjs.mse_95winCode.GDspeakerObjects5.length = 0;
gdjs.mse_95winCode.GDspeakerObjects6.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects1.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects2.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects3.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects4.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects5.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects6.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects1.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects2.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects3.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects4.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects5.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects6.length = 0;
gdjs.mse_95winCode.GDsoundObjects1.length = 0;
gdjs.mse_95winCode.GDsoundObjects2.length = 0;
gdjs.mse_95winCode.GDsoundObjects3.length = 0;
gdjs.mse_95winCode.GDsoundObjects4.length = 0;
gdjs.mse_95winCode.GDsoundObjects5.length = 0;
gdjs.mse_95winCode.GDsoundObjects6.length = 0;
gdjs.mse_95winCode.GDpluginObjects1.length = 0;
gdjs.mse_95winCode.GDpluginObjects2.length = 0;
gdjs.mse_95winCode.GDpluginObjects3.length = 0;
gdjs.mse_95winCode.GDpluginObjects4.length = 0;
gdjs.mse_95winCode.GDpluginObjects5.length = 0;
gdjs.mse_95winCode.GDpluginObjects6.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects1.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects2.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects3.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects4.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects5.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects6.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects1.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects2.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects3.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects4.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects5.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects6.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects1.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects2.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects3.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects4.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects5.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects6.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects1.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects2.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects3.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects4.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects5.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects6.length = 0;
gdjs.mse_95winCode.GDInfoObjects1.length = 0;
gdjs.mse_95winCode.GDInfoObjects2.length = 0;
gdjs.mse_95winCode.GDInfoObjects3.length = 0;
gdjs.mse_95winCode.GDInfoObjects4.length = 0;
gdjs.mse_95winCode.GDInfoObjects5.length = 0;
gdjs.mse_95winCode.GDInfoObjects6.length = 0;
gdjs.mse_95winCode.GDinfoETObjects1.length = 0;
gdjs.mse_95winCode.GDinfoETObjects2.length = 0;
gdjs.mse_95winCode.GDinfoETObjects3.length = 0;
gdjs.mse_95winCode.GDinfoETObjects4.length = 0;
gdjs.mse_95winCode.GDinfoETObjects5.length = 0;
gdjs.mse_95winCode.GDinfoETObjects6.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects1.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects2.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects3.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects4.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects5.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects6.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects1.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects2.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects3.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects4.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects5.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects6.length = 0;
gdjs.mse_95winCode.GDpanel5Objects1.length = 0;
gdjs.mse_95winCode.GDpanel5Objects2.length = 0;
gdjs.mse_95winCode.GDpanel5Objects3.length = 0;
gdjs.mse_95winCode.GDpanel5Objects4.length = 0;
gdjs.mse_95winCode.GDpanel5Objects5.length = 0;
gdjs.mse_95winCode.GDpanel5Objects6.length = 0;
gdjs.mse_95winCode.GDtxtObjects1.length = 0;
gdjs.mse_95winCode.GDtxtObjects2.length = 0;
gdjs.mse_95winCode.GDtxtObjects3.length = 0;
gdjs.mse_95winCode.GDtxtObjects4.length = 0;
gdjs.mse_95winCode.GDtxtObjects5.length = 0;
gdjs.mse_95winCode.GDtxtObjects6.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects1.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects2.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects3.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects4.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects5.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects6.length = 0;
gdjs.mse_95winCode.GDtxt2Objects1.length = 0;
gdjs.mse_95winCode.GDtxt2Objects2.length = 0;
gdjs.mse_95winCode.GDtxt2Objects3.length = 0;
gdjs.mse_95winCode.GDtxt2Objects4.length = 0;
gdjs.mse_95winCode.GDtxt2Objects5.length = 0;
gdjs.mse_95winCode.GDtxt2Objects6.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects1.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects2.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects3.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects4.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects5.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects6.length = 0;
gdjs.mse_95winCode.GDhideObjects1.length = 0;
gdjs.mse_95winCode.GDhideObjects2.length = 0;
gdjs.mse_95winCode.GDhideObjects3.length = 0;
gdjs.mse_95winCode.GDhideObjects4.length = 0;
gdjs.mse_95winCode.GDhideObjects5.length = 0;
gdjs.mse_95winCode.GDhideObjects6.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects1.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects2.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects3.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects4.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects5.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects6.length = 0;
gdjs.mse_95winCode.GDsavingObjects1.length = 0;
gdjs.mse_95winCode.GDsavingObjects2.length = 0;
gdjs.mse_95winCode.GDsavingObjects3.length = 0;
gdjs.mse_95winCode.GDsavingObjects4.length = 0;
gdjs.mse_95winCode.GDsavingObjects5.length = 0;
gdjs.mse_95winCode.GDsavingObjects6.length = 0;

gdjs.mse_95winCode.eventsList95(runtimeScene);
gdjs.mse_95winCode.GDpanelObjects1.length = 0;
gdjs.mse_95winCode.GDpanelObjects2.length = 0;
gdjs.mse_95winCode.GDpanelObjects3.length = 0;
gdjs.mse_95winCode.GDpanelObjects4.length = 0;
gdjs.mse_95winCode.GDpanelObjects5.length = 0;
gdjs.mse_95winCode.GDpanelObjects6.length = 0;
gdjs.mse_95winCode.GDpanel2Objects1.length = 0;
gdjs.mse_95winCode.GDpanel2Objects2.length = 0;
gdjs.mse_95winCode.GDpanel2Objects3.length = 0;
gdjs.mse_95winCode.GDpanel2Objects4.length = 0;
gdjs.mse_95winCode.GDpanel2Objects5.length = 0;
gdjs.mse_95winCode.GDpanel2Objects6.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects1.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects2.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects3.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects4.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects5.length = 0;
gdjs.mse_95winCode.GDsound_9595nameObjects6.length = 0;
gdjs.mse_95winCode.GDdrawObjects1.length = 0;
gdjs.mse_95winCode.GDdrawObjects2.length = 0;
gdjs.mse_95winCode.GDdrawObjects3.length = 0;
gdjs.mse_95winCode.GDdrawObjects4.length = 0;
gdjs.mse_95winCode.GDdrawObjects5.length = 0;
gdjs.mse_95winCode.GDdrawObjects6.length = 0;
gdjs.mse_95winCode.GDnameObjects1.length = 0;
gdjs.mse_95winCode.GDnameObjects2.length = 0;
gdjs.mse_95winCode.GDnameObjects3.length = 0;
gdjs.mse_95winCode.GDnameObjects4.length = 0;
gdjs.mse_95winCode.GDnameObjects5.length = 0;
gdjs.mse_95winCode.GDnameObjects6.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects1.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects2.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects3.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects4.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects5.length = 0;
gdjs.mse_95winCode.GDmusic_9595containerObjects6.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects1.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects2.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects3.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects4.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects5.length = 0;
gdjs.mse_95winCode.GDplay_9595nodeObjects6.length = 0;
gdjs.mse_95winCode.GDplayObjects1.length = 0;
gdjs.mse_95winCode.GDplayObjects2.length = 0;
gdjs.mse_95winCode.GDplayObjects3.length = 0;
gdjs.mse_95winCode.GDplayObjects4.length = 0;
gdjs.mse_95winCode.GDplayObjects5.length = 0;
gdjs.mse_95winCode.GDplayObjects6.length = 0;
gdjs.mse_95winCode.GDdebugObjects1.length = 0;
gdjs.mse_95winCode.GDdebugObjects2.length = 0;
gdjs.mse_95winCode.GDdebugObjects3.length = 0;
gdjs.mse_95winCode.GDdebugObjects4.length = 0;
gdjs.mse_95winCode.GDdebugObjects5.length = 0;
gdjs.mse_95winCode.GDdebugObjects6.length = 0;
gdjs.mse_95winCode.GDstopObjects1.length = 0;
gdjs.mse_95winCode.GDstopObjects2.length = 0;
gdjs.mse_95winCode.GDstopObjects3.length = 0;
gdjs.mse_95winCode.GDstopObjects4.length = 0;
gdjs.mse_95winCode.GDstopObjects5.length = 0;
gdjs.mse_95winCode.GDstopObjects6.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects1.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects2.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects3.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects4.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects5.length = 0;
gdjs.mse_95winCode.GDfast_9595forwardObjects6.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects1.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects2.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects3.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects4.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects5.length = 0;
gdjs.mse_95winCode.GDfast_9595backwardObjects6.length = 0;
gdjs.mse_95winCode.GDgearObjects1.length = 0;
gdjs.mse_95winCode.GDgearObjects2.length = 0;
gdjs.mse_95winCode.GDgearObjects3.length = 0;
gdjs.mse_95winCode.GDgearObjects4.length = 0;
gdjs.mse_95winCode.GDgearObjects5.length = 0;
gdjs.mse_95winCode.GDgearObjects6.length = 0;
gdjs.mse_95winCode.GDbar1Objects1.length = 0;
gdjs.mse_95winCode.GDbar1Objects2.length = 0;
gdjs.mse_95winCode.GDbar1Objects3.length = 0;
gdjs.mse_95winCode.GDbar1Objects4.length = 0;
gdjs.mse_95winCode.GDbar1Objects5.length = 0;
gdjs.mse_95winCode.GDbar1Objects6.length = 0;
gdjs.mse_95winCode.GDyyyObjects1.length = 0;
gdjs.mse_95winCode.GDyyyObjects2.length = 0;
gdjs.mse_95winCode.GDyyyObjects3.length = 0;
gdjs.mse_95winCode.GDyyyObjects4.length = 0;
gdjs.mse_95winCode.GDyyyObjects5.length = 0;
gdjs.mse_95winCode.GDyyyObjects6.length = 0;
gdjs.mse_95winCode.GDcacaObjects1.length = 0;
gdjs.mse_95winCode.GDcacaObjects2.length = 0;
gdjs.mse_95winCode.GDcacaObjects3.length = 0;
gdjs.mse_95winCode.GDcacaObjects4.length = 0;
gdjs.mse_95winCode.GDcacaObjects5.length = 0;
gdjs.mse_95winCode.GDcacaObjects6.length = 0;
gdjs.mse_95winCode.GDdraw2Objects1.length = 0;
gdjs.mse_95winCode.GDdraw2Objects2.length = 0;
gdjs.mse_95winCode.GDdraw2Objects3.length = 0;
gdjs.mse_95winCode.GDdraw2Objects4.length = 0;
gdjs.mse_95winCode.GDdraw2Objects5.length = 0;
gdjs.mse_95winCode.GDdraw2Objects6.length = 0;
gdjs.mse_95winCode.GDddObjects1.length = 0;
gdjs.mse_95winCode.GDddObjects2.length = 0;
gdjs.mse_95winCode.GDddObjects3.length = 0;
gdjs.mse_95winCode.GDddObjects4.length = 0;
gdjs.mse_95winCode.GDddObjects5.length = 0;
gdjs.mse_95winCode.GDddObjects6.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects1.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects2.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects3.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects4.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects5.length = 0;
gdjs.mse_95winCode.GDjson_9595iconObjects6.length = 0;
gdjs.mse_95winCode.GDavObjects1.length = 0;
gdjs.mse_95winCode.GDavObjects2.length = 0;
gdjs.mse_95winCode.GDavObjects3.length = 0;
gdjs.mse_95winCode.GDavObjects4.length = 0;
gdjs.mse_95winCode.GDavObjects5.length = 0;
gdjs.mse_95winCode.GDavObjects6.length = 0;
gdjs.mse_95winCode.GDexportObjects1.length = 0;
gdjs.mse_95winCode.GDexportObjects2.length = 0;
gdjs.mse_95winCode.GDexportObjects3.length = 0;
gdjs.mse_95winCode.GDexportObjects4.length = 0;
gdjs.mse_95winCode.GDexportObjects5.length = 0;
gdjs.mse_95winCode.GDexportObjects6.length = 0;
gdjs.mse_95winCode.GDbadObjects1.length = 0;
gdjs.mse_95winCode.GDbadObjects2.length = 0;
gdjs.mse_95winCode.GDbadObjects3.length = 0;
gdjs.mse_95winCode.GDbadObjects4.length = 0;
gdjs.mse_95winCode.GDbadObjects5.length = 0;
gdjs.mse_95winCode.GDbadObjects6.length = 0;
gdjs.mse_95winCode.GDpaintObjects1.length = 0;
gdjs.mse_95winCode.GDpaintObjects2.length = 0;
gdjs.mse_95winCode.GDpaintObjects3.length = 0;
gdjs.mse_95winCode.GDpaintObjects4.length = 0;
gdjs.mse_95winCode.GDpaintObjects5.length = 0;
gdjs.mse_95winCode.GDpaintObjects6.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects1.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects2.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects3.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects4.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects5.length = 0;
gdjs.mse_95winCode.GDproject_9595nameObjects6.length = 0;
gdjs.mse_95winCode.GDinffofoObjects1.length = 0;
gdjs.mse_95winCode.GDinffofoObjects2.length = 0;
gdjs.mse_95winCode.GDinffofoObjects3.length = 0;
gdjs.mse_95winCode.GDinffofoObjects4.length = 0;
gdjs.mse_95winCode.GDinffofoObjects5.length = 0;
gdjs.mse_95winCode.GDinffofoObjects6.length = 0;
gdjs.mse_95winCode.GDlogoObjects1.length = 0;
gdjs.mse_95winCode.GDlogoObjects2.length = 0;
gdjs.mse_95winCode.GDlogoObjects3.length = 0;
gdjs.mse_95winCode.GDlogoObjects4.length = 0;
gdjs.mse_95winCode.GDlogoObjects5.length = 0;
gdjs.mse_95winCode.GDlogoObjects6.length = 0;
gdjs.mse_95winCode.GDasdObjects1.length = 0;
gdjs.mse_95winCode.GDasdObjects2.length = 0;
gdjs.mse_95winCode.GDasdObjects3.length = 0;
gdjs.mse_95winCode.GDasdObjects4.length = 0;
gdjs.mse_95winCode.GDasdObjects5.length = 0;
gdjs.mse_95winCode.GDasdObjects6.length = 0;
gdjs.mse_95winCode.GDmenuObjects1.length = 0;
gdjs.mse_95winCode.GDmenuObjects2.length = 0;
gdjs.mse_95winCode.GDmenuObjects3.length = 0;
gdjs.mse_95winCode.GDmenuObjects4.length = 0;
gdjs.mse_95winCode.GDmenuObjects5.length = 0;
gdjs.mse_95winCode.GDmenuObjects6.length = 0;
gdjs.mse_95winCode.GDpanel3Objects1.length = 0;
gdjs.mse_95winCode.GDpanel3Objects2.length = 0;
gdjs.mse_95winCode.GDpanel3Objects3.length = 0;
gdjs.mse_95winCode.GDpanel3Objects4.length = 0;
gdjs.mse_95winCode.GDpanel3Objects5.length = 0;
gdjs.mse_95winCode.GDpanel3Objects6.length = 0;
gdjs.mse_95winCode.GDhelpObjects1.length = 0;
gdjs.mse_95winCode.GDhelpObjects2.length = 0;
gdjs.mse_95winCode.GDhelpObjects3.length = 0;
gdjs.mse_95winCode.GDhelpObjects4.length = 0;
gdjs.mse_95winCode.GDhelpObjects5.length = 0;
gdjs.mse_95winCode.GDhelpObjects6.length = 0;
gdjs.mse_95winCode.GDexObjects1.length = 0;
gdjs.mse_95winCode.GDexObjects2.length = 0;
gdjs.mse_95winCode.GDexObjects3.length = 0;
gdjs.mse_95winCode.GDexObjects4.length = 0;
gdjs.mse_95winCode.GDexObjects5.length = 0;
gdjs.mse_95winCode.GDexObjects6.length = 0;
gdjs.mse_95winCode.GDinfoObjects1.length = 0;
gdjs.mse_95winCode.GDinfoObjects2.length = 0;
gdjs.mse_95winCode.GDinfoObjects3.length = 0;
gdjs.mse_95winCode.GDinfoObjects4.length = 0;
gdjs.mse_95winCode.GDinfoObjects5.length = 0;
gdjs.mse_95winCode.GDinfoObjects6.length = 0;
gdjs.mse_95winCode.GDbackObjects1.length = 0;
gdjs.mse_95winCode.GDbackObjects2.length = 0;
gdjs.mse_95winCode.GDbackObjects3.length = 0;
gdjs.mse_95winCode.GDbackObjects4.length = 0;
gdjs.mse_95winCode.GDbackObjects5.length = 0;
gdjs.mse_95winCode.GDbackObjects6.length = 0;
gdjs.mse_95winCode.GDpanel4Objects1.length = 0;
gdjs.mse_95winCode.GDpanel4Objects2.length = 0;
gdjs.mse_95winCode.GDpanel4Objects3.length = 0;
gdjs.mse_95winCode.GDpanel4Objects4.length = 0;
gdjs.mse_95winCode.GDpanel4Objects5.length = 0;
gdjs.mse_95winCode.GDpanel4Objects6.length = 0;
gdjs.mse_95winCode.GDerrObjects1.length = 0;
gdjs.mse_95winCode.GDerrObjects2.length = 0;
gdjs.mse_95winCode.GDerrObjects3.length = 0;
gdjs.mse_95winCode.GDerrObjects4.length = 0;
gdjs.mse_95winCode.GDerrObjects5.length = 0;
gdjs.mse_95winCode.GDerrObjects6.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects1.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects2.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects3.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects4.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects5.length = 0;
gdjs.mse_95winCode.GDai_9595placerkObjects6.length = 0;
gdjs.mse_95winCode.GDhoverObjects1.length = 0;
gdjs.mse_95winCode.GDhoverObjects2.length = 0;
gdjs.mse_95winCode.GDhoverObjects3.length = 0;
gdjs.mse_95winCode.GDhoverObjects4.length = 0;
gdjs.mse_95winCode.GDhoverObjects5.length = 0;
gdjs.mse_95winCode.GDhoverObjects6.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects1.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects2.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects3.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects4.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects5.length = 0;
gdjs.mse_95winCode.GDsub_9595audObjects6.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects1.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects2.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects3.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects4.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects5.length = 0;
gdjs.mse_95winCode.GDaudio_9595idObjects6.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects1.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects2.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects3.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects4.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects5.length = 0;
gdjs.mse_95winCode.GDexport_9595aObjects6.length = 0;
gdjs.mse_95winCode.GDidObjects1.length = 0;
gdjs.mse_95winCode.GDidObjects2.length = 0;
gdjs.mse_95winCode.GDidObjects3.length = 0;
gdjs.mse_95winCode.GDidObjects4.length = 0;
gdjs.mse_95winCode.GDidObjects5.length = 0;
gdjs.mse_95winCode.GDidObjects6.length = 0;
gdjs.mse_95winCode.GDname2Objects1.length = 0;
gdjs.mse_95winCode.GDname2Objects2.length = 0;
gdjs.mse_95winCode.GDname2Objects3.length = 0;
gdjs.mse_95winCode.GDname2Objects4.length = 0;
gdjs.mse_95winCode.GDname2Objects5.length = 0;
gdjs.mse_95winCode.GDname2Objects6.length = 0;
gdjs.mse_95winCode.GDeventObjects1.length = 0;
gdjs.mse_95winCode.GDeventObjects2.length = 0;
gdjs.mse_95winCode.GDeventObjects3.length = 0;
gdjs.mse_95winCode.GDeventObjects4.length = 0;
gdjs.mse_95winCode.GDeventObjects5.length = 0;
gdjs.mse_95winCode.GDeventObjects6.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects1.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects2.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects3.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects4.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects5.length = 0;
gdjs.mse_95winCode.GDshow_9595eventObjects6.length = 0;
gdjs.mse_95winCode.GDsearchObjects1.length = 0;
gdjs.mse_95winCode.GDsearchObjects2.length = 0;
gdjs.mse_95winCode.GDsearchObjects3.length = 0;
gdjs.mse_95winCode.GDsearchObjects4.length = 0;
gdjs.mse_95winCode.GDsearchObjects5.length = 0;
gdjs.mse_95winCode.GDsearchObjects6.length = 0;
gdjs.mse_95winCode.GDenterObjects1.length = 0;
gdjs.mse_95winCode.GDenterObjects2.length = 0;
gdjs.mse_95winCode.GDenterObjects3.length = 0;
gdjs.mse_95winCode.GDenterObjects4.length = 0;
gdjs.mse_95winCode.GDenterObjects5.length = 0;
gdjs.mse_95winCode.GDenterObjects6.length = 0;
gdjs.mse_95winCode.GDsaveObjects1.length = 0;
gdjs.mse_95winCode.GDsaveObjects2.length = 0;
gdjs.mse_95winCode.GDsaveObjects3.length = 0;
gdjs.mse_95winCode.GDsaveObjects4.length = 0;
gdjs.mse_95winCode.GDsaveObjects5.length = 0;
gdjs.mse_95winCode.GDsaveObjects6.length = 0;
gdjs.mse_95winCode.GDspeedObjects1.length = 0;
gdjs.mse_95winCode.GDspeedObjects2.length = 0;
gdjs.mse_95winCode.GDspeedObjects3.length = 0;
gdjs.mse_95winCode.GDspeedObjects4.length = 0;
gdjs.mse_95winCode.GDspeedObjects5.length = 0;
gdjs.mse_95winCode.GDspeedObjects6.length = 0;
gdjs.mse_95winCode.GDhomeObjects1.length = 0;
gdjs.mse_95winCode.GDhomeObjects2.length = 0;
gdjs.mse_95winCode.GDhomeObjects3.length = 0;
gdjs.mse_95winCode.GDhomeObjects4.length = 0;
gdjs.mse_95winCode.GDhomeObjects5.length = 0;
gdjs.mse_95winCode.GDhomeObjects6.length = 0;
gdjs.mse_95winCode.GDcropObjects1.length = 0;
gdjs.mse_95winCode.GDcropObjects2.length = 0;
gdjs.mse_95winCode.GDcropObjects3.length = 0;
gdjs.mse_95winCode.GDcropObjects4.length = 0;
gdjs.mse_95winCode.GDcropObjects5.length = 0;
gdjs.mse_95winCode.GDcropObjects6.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects1.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects2.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects3.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects4.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects5.length = 0;
gdjs.mse_95winCode.GDsettings_9595icObjects6.length = 0;
gdjs.mse_95winCode.GDsetObjects1.length = 0;
gdjs.mse_95winCode.GDsetObjects2.length = 0;
gdjs.mse_95winCode.GDsetObjects3.length = 0;
gdjs.mse_95winCode.GDsetObjects4.length = 0;
gdjs.mse_95winCode.GDsetObjects5.length = 0;
gdjs.mse_95winCode.GDsetObjects6.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects1.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects2.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects3.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects4.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects5.length = 0;
gdjs.mse_95winCode.GDsnap_9595boolObjects6.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects1.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects2.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects3.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects4.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects5.length = 0;
gdjs.mse_95winCode.GDshow_9595boolObjects6.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects1.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects2.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects3.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects4.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects5.length = 0;
gdjs.mse_95winCode.GDset_9595snapObjects6.length = 0;
gdjs.mse_95winCode.GDdebug2Objects1.length = 0;
gdjs.mse_95winCode.GDdebug2Objects2.length = 0;
gdjs.mse_95winCode.GDdebug2Objects3.length = 0;
gdjs.mse_95winCode.GDdebug2Objects4.length = 0;
gdjs.mse_95winCode.GDdebug2Objects5.length = 0;
gdjs.mse_95winCode.GDdebug2Objects6.length = 0;
gdjs.mse_95winCode.GDbuttonObjects1.length = 0;
gdjs.mse_95winCode.GDbuttonObjects2.length = 0;
gdjs.mse_95winCode.GDbuttonObjects3.length = 0;
gdjs.mse_95winCode.GDbuttonObjects4.length = 0;
gdjs.mse_95winCode.GDbuttonObjects5.length = 0;
gdjs.mse_95winCode.GDbuttonObjects6.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects1.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects2.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects3.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects4.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects5.length = 0;
gdjs.mse_95winCode.GDUnnamedObjects6.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects1.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects2.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects3.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects4.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects5.length = 0;
gdjs.mse_95winCode.GDUnnamed2Objects6.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects1.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects2.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects3.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects4.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects5.length = 0;
gdjs.mse_95winCode.GDUnnamed3Objects6.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects1.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects2.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects3.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects4.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects5.length = 0;
gdjs.mse_95winCode.GDUnnamed4Objects6.length = 0;
gdjs.mse_95winCode.GDscriptObjects1.length = 0;
gdjs.mse_95winCode.GDscriptObjects2.length = 0;
gdjs.mse_95winCode.GDscriptObjects3.length = 0;
gdjs.mse_95winCode.GDscriptObjects4.length = 0;
gdjs.mse_95winCode.GDscriptObjects5.length = 0;
gdjs.mse_95winCode.GDscriptObjects6.length = 0;
gdjs.mse_95winCode.GDcoderObjects1.length = 0;
gdjs.mse_95winCode.GDcoderObjects2.length = 0;
gdjs.mse_95winCode.GDcoderObjects3.length = 0;
gdjs.mse_95winCode.GDcoderObjects4.length = 0;
gdjs.mse_95winCode.GDcoderObjects5.length = 0;
gdjs.mse_95winCode.GDcoderObjects6.length = 0;
gdjs.mse_95winCode.GDfuncObjects1.length = 0;
gdjs.mse_95winCode.GDfuncObjects2.length = 0;
gdjs.mse_95winCode.GDfuncObjects3.length = 0;
gdjs.mse_95winCode.GDfuncObjects4.length = 0;
gdjs.mse_95winCode.GDfuncObjects5.length = 0;
gdjs.mse_95winCode.GDfuncObjects6.length = 0;
gdjs.mse_95winCode.GDspeakerObjects1.length = 0;
gdjs.mse_95winCode.GDspeakerObjects2.length = 0;
gdjs.mse_95winCode.GDspeakerObjects3.length = 0;
gdjs.mse_95winCode.GDspeakerObjects4.length = 0;
gdjs.mse_95winCode.GDspeakerObjects5.length = 0;
gdjs.mse_95winCode.GDspeakerObjects6.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects1.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects2.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects3.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects4.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects5.length = 0;
gdjs.mse_95winCode.GDexport_9595adObjects6.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects1.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects2.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects3.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects4.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects5.length = 0;
gdjs.mse_95winCode.GDdepreciatedObjects6.length = 0;
gdjs.mse_95winCode.GDsoundObjects1.length = 0;
gdjs.mse_95winCode.GDsoundObjects2.length = 0;
gdjs.mse_95winCode.GDsoundObjects3.length = 0;
gdjs.mse_95winCode.GDsoundObjects4.length = 0;
gdjs.mse_95winCode.GDsoundObjects5.length = 0;
gdjs.mse_95winCode.GDsoundObjects6.length = 0;
gdjs.mse_95winCode.GDpluginObjects1.length = 0;
gdjs.mse_95winCode.GDpluginObjects2.length = 0;
gdjs.mse_95winCode.GDpluginObjects3.length = 0;
gdjs.mse_95winCode.GDpluginObjects4.length = 0;
gdjs.mse_95winCode.GDpluginObjects5.length = 0;
gdjs.mse_95winCode.GDpluginObjects6.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects1.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects2.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects3.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects4.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects5.length = 0;
gdjs.mse_95winCode.GDNewSpriteObjects6.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects1.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects2.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects3.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects4.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects5.length = 0;
gdjs.mse_95winCode.GDproperties_9595textObjects6.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects1.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects2.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects3.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects4.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects5.length = 0;
gdjs.mse_95winCode.GDNewSprite2Objects6.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects1.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects2.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects3.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects4.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects5.length = 0;
gdjs.mse_95winCode.GDjustPurpleObjects6.length = 0;
gdjs.mse_95winCode.GDInfoObjects1.length = 0;
gdjs.mse_95winCode.GDInfoObjects2.length = 0;
gdjs.mse_95winCode.GDInfoObjects3.length = 0;
gdjs.mse_95winCode.GDInfoObjects4.length = 0;
gdjs.mse_95winCode.GDInfoObjects5.length = 0;
gdjs.mse_95winCode.GDInfoObjects6.length = 0;
gdjs.mse_95winCode.GDinfoETObjects1.length = 0;
gdjs.mse_95winCode.GDinfoETObjects2.length = 0;
gdjs.mse_95winCode.GDinfoETObjects3.length = 0;
gdjs.mse_95winCode.GDinfoETObjects4.length = 0;
gdjs.mse_95winCode.GDinfoETObjects5.length = 0;
gdjs.mse_95winCode.GDinfoETObjects6.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects1.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects2.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects3.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects4.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects5.length = 0;
gdjs.mse_95winCode.GDinfoEAObjects6.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects1.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects2.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects3.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects4.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects5.length = 0;
gdjs.mse_95winCode.GDinfoEDObjects6.length = 0;
gdjs.mse_95winCode.GDpanel5Objects1.length = 0;
gdjs.mse_95winCode.GDpanel5Objects2.length = 0;
gdjs.mse_95winCode.GDpanel5Objects3.length = 0;
gdjs.mse_95winCode.GDpanel5Objects4.length = 0;
gdjs.mse_95winCode.GDpanel5Objects5.length = 0;
gdjs.mse_95winCode.GDpanel5Objects6.length = 0;
gdjs.mse_95winCode.GDtxtObjects1.length = 0;
gdjs.mse_95winCode.GDtxtObjects2.length = 0;
gdjs.mse_95winCode.GDtxtObjects3.length = 0;
gdjs.mse_95winCode.GDtxtObjects4.length = 0;
gdjs.mse_95winCode.GDtxtObjects5.length = 0;
gdjs.mse_95winCode.GDtxtObjects6.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects1.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects2.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects3.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects4.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects5.length = 0;
gdjs.mse_95winCode.GDbuttonGNObjects6.length = 0;
gdjs.mse_95winCode.GDtxt2Objects1.length = 0;
gdjs.mse_95winCode.GDtxt2Objects2.length = 0;
gdjs.mse_95winCode.GDtxt2Objects3.length = 0;
gdjs.mse_95winCode.GDtxt2Objects4.length = 0;
gdjs.mse_95winCode.GDtxt2Objects5.length = 0;
gdjs.mse_95winCode.GDtxt2Objects6.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects1.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects2.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects3.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects4.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects5.length = 0;
gdjs.mse_95winCode.GDshow_9595onlyObjects6.length = 0;
gdjs.mse_95winCode.GDhideObjects1.length = 0;
gdjs.mse_95winCode.GDhideObjects2.length = 0;
gdjs.mse_95winCode.GDhideObjects3.length = 0;
gdjs.mse_95winCode.GDhideObjects4.length = 0;
gdjs.mse_95winCode.GDhideObjects5.length = 0;
gdjs.mse_95winCode.GDhideObjects6.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects1.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects2.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects3.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects4.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects5.length = 0;
gdjs.mse_95winCode.GDnodeLengthObjects6.length = 0;
gdjs.mse_95winCode.GDsavingObjects1.length = 0;
gdjs.mse_95winCode.GDsavingObjects2.length = 0;
gdjs.mse_95winCode.GDsavingObjects3.length = 0;
gdjs.mse_95winCode.GDsavingObjects4.length = 0;
gdjs.mse_95winCode.GDsavingObjects5.length = 0;
gdjs.mse_95winCode.GDsavingObjects6.length = 0;


return;

}

gdjs['mse_95winCode'] = gdjs.mse_95winCode;
