gdjs.project_95manager_95winCode = {};
gdjs.project_95manager_95winCode.localVariables = [];
gdjs.project_95manager_95winCode.GDjj2Objects1_1final = [];

gdjs.project_95manager_95winCode.GDnameObjects1= [];
gdjs.project_95manager_95winCode.GDnameObjects2= [];
gdjs.project_95manager_95winCode.GDnameObjects3= [];
gdjs.project_95manager_95winCode.GDnameObjects4= [];
gdjs.project_95manager_95winCode.GDnameObjects5= [];
gdjs.project_95manager_95winCode.GDnameObjects6= [];
gdjs.project_95manager_95winCode.GDnameObjects7= [];
gdjs.project_95manager_95winCode.GDinfoObjects1= [];
gdjs.project_95manager_95winCode.GDinfoObjects2= [];
gdjs.project_95manager_95winCode.GDinfoObjects3= [];
gdjs.project_95manager_95winCode.GDinfoObjects4= [];
gdjs.project_95manager_95winCode.GDinfoObjects5= [];
gdjs.project_95manager_95winCode.GDinfoObjects6= [];
gdjs.project_95manager_95winCode.GDinfoObjects7= [];
gdjs.project_95manager_95winCode.GDaddObjects1= [];
gdjs.project_95manager_95winCode.GDaddObjects2= [];
gdjs.project_95manager_95winCode.GDaddObjects3= [];
gdjs.project_95manager_95winCode.GDaddObjects4= [];
gdjs.project_95manager_95winCode.GDaddObjects5= [];
gdjs.project_95manager_95winCode.GDaddObjects6= [];
gdjs.project_95manager_95winCode.GDaddObjects7= [];
gdjs.project_95manager_95winCode.GDadd_9595txtObjects1= [];
gdjs.project_95manager_95winCode.GDadd_9595txtObjects2= [];
gdjs.project_95manager_95winCode.GDadd_9595txtObjects3= [];
gdjs.project_95manager_95winCode.GDadd_9595txtObjects4= [];
gdjs.project_95manager_95winCode.GDadd_9595txtObjects5= [];
gdjs.project_95manager_95winCode.GDadd_9595txtObjects6= [];
gdjs.project_95manager_95winCode.GDadd_9595txtObjects7= [];
gdjs.project_95manager_95winCode.GDsave_9595iconObjects1= [];
gdjs.project_95manager_95winCode.GDsave_9595iconObjects2= [];
gdjs.project_95manager_95winCode.GDsave_9595iconObjects3= [];
gdjs.project_95manager_95winCode.GDsave_9595iconObjects4= [];
gdjs.project_95manager_95winCode.GDsave_9595iconObjects5= [];
gdjs.project_95manager_95winCode.GDsave_9595iconObjects6= [];
gdjs.project_95manager_95winCode.GDsave_9595iconObjects7= [];
gdjs.project_95manager_95winCode.GDname2Objects1= [];
gdjs.project_95manager_95winCode.GDname2Objects2= [];
gdjs.project_95manager_95winCode.GDname2Objects3= [];
gdjs.project_95manager_95winCode.GDname2Objects4= [];
gdjs.project_95manager_95winCode.GDname2Objects5= [];
gdjs.project_95manager_95winCode.GDname2Objects6= [];
gdjs.project_95manager_95winCode.GDname2Objects7= [];
gdjs.project_95manager_95winCode.GDioiObjects1= [];
gdjs.project_95manager_95winCode.GDioiObjects2= [];
gdjs.project_95manager_95winCode.GDioiObjects3= [];
gdjs.project_95manager_95winCode.GDioiObjects4= [];
gdjs.project_95manager_95winCode.GDioiObjects5= [];
gdjs.project_95manager_95winCode.GDioiObjects6= [];
gdjs.project_95manager_95winCode.GDioiObjects7= [];
gdjs.project_95manager_95winCode.GDadd_9595eveObjects1= [];
gdjs.project_95manager_95winCode.GDadd_9595eveObjects2= [];
gdjs.project_95manager_95winCode.GDadd_9595eveObjects3= [];
gdjs.project_95manager_95winCode.GDadd_9595eveObjects4= [];
gdjs.project_95manager_95winCode.GDadd_9595eveObjects5= [];
gdjs.project_95manager_95winCode.GDadd_9595eveObjects6= [];
gdjs.project_95manager_95winCode.GDadd_9595eveObjects7= [];
gdjs.project_95manager_95winCode.GDokObjects1= [];
gdjs.project_95manager_95winCode.GDokObjects2= [];
gdjs.project_95manager_95winCode.GDokObjects3= [];
gdjs.project_95manager_95winCode.GDokObjects4= [];
gdjs.project_95manager_95winCode.GDokObjects5= [];
gdjs.project_95manager_95winCode.GDokObjects6= [];
gdjs.project_95manager_95winCode.GDokObjects7= [];
gdjs.project_95manager_95winCode.GDcancObjects1= [];
gdjs.project_95manager_95winCode.GDcancObjects2= [];
gdjs.project_95manager_95winCode.GDcancObjects3= [];
gdjs.project_95manager_95winCode.GDcancObjects4= [];
gdjs.project_95manager_95winCode.GDcancObjects5= [];
gdjs.project_95manager_95winCode.GDcancObjects6= [];
gdjs.project_95manager_95winCode.GDcancObjects7= [];
gdjs.project_95manager_95winCode.GDpaintObjects1= [];
gdjs.project_95manager_95winCode.GDpaintObjects2= [];
gdjs.project_95manager_95winCode.GDpaintObjects3= [];
gdjs.project_95manager_95winCode.GDpaintObjects4= [];
gdjs.project_95manager_95winCode.GDpaintObjects5= [];
gdjs.project_95manager_95winCode.GDpaintObjects6= [];
gdjs.project_95manager_95winCode.GDpaintObjects7= [];
gdjs.project_95manager_95winCode.GDname3Objects1= [];
gdjs.project_95manager_95winCode.GDname3Objects2= [];
gdjs.project_95manager_95winCode.GDname3Objects3= [];
gdjs.project_95manager_95winCode.GDname3Objects4= [];
gdjs.project_95manager_95winCode.GDname3Objects5= [];
gdjs.project_95manager_95winCode.GDname3Objects6= [];
gdjs.project_95manager_95winCode.GDname3Objects7= [];
gdjs.project_95manager_95winCode.GDpanelObjects1= [];
gdjs.project_95manager_95winCode.GDpanelObjects2= [];
gdjs.project_95manager_95winCode.GDpanelObjects3= [];
gdjs.project_95manager_95winCode.GDpanelObjects4= [];
gdjs.project_95manager_95winCode.GDpanelObjects5= [];
gdjs.project_95manager_95winCode.GDpanelObjects6= [];
gdjs.project_95manager_95winCode.GDpanelObjects7= [];
gdjs.project_95manager_95winCode.GDsprrObjects1= [];
gdjs.project_95manager_95winCode.GDsprrObjects2= [];
gdjs.project_95manager_95winCode.GDsprrObjects3= [];
gdjs.project_95manager_95winCode.GDsprrObjects4= [];
gdjs.project_95manager_95winCode.GDsprrObjects5= [];
gdjs.project_95manager_95winCode.GDsprrObjects6= [];
gdjs.project_95manager_95winCode.GDsprrObjects7= [];
gdjs.project_95manager_95winCode.GDpanel2Objects1= [];
gdjs.project_95manager_95winCode.GDpanel2Objects2= [];
gdjs.project_95manager_95winCode.GDpanel2Objects3= [];
gdjs.project_95manager_95winCode.GDpanel2Objects4= [];
gdjs.project_95manager_95winCode.GDpanel2Objects5= [];
gdjs.project_95manager_95winCode.GDpanel2Objects6= [];
gdjs.project_95manager_95winCode.GDpanel2Objects7= [];
gdjs.project_95manager_95winCode.GDfkObjects1= [];
gdjs.project_95manager_95winCode.GDfkObjects2= [];
gdjs.project_95manager_95winCode.GDfkObjects3= [];
gdjs.project_95manager_95winCode.GDfkObjects4= [];
gdjs.project_95manager_95winCode.GDfkObjects5= [];
gdjs.project_95manager_95winCode.GDfkObjects6= [];
gdjs.project_95manager_95winCode.GDfkObjects7= [];
gdjs.project_95manager_95winCode.GDjjObjects1= [];
gdjs.project_95manager_95winCode.GDjjObjects2= [];
gdjs.project_95manager_95winCode.GDjjObjects3= [];
gdjs.project_95manager_95winCode.GDjjObjects4= [];
gdjs.project_95manager_95winCode.GDjjObjects5= [];
gdjs.project_95manager_95winCode.GDjjObjects6= [];
gdjs.project_95manager_95winCode.GDjjObjects7= [];
gdjs.project_95manager_95winCode.GDlogoObjects1= [];
gdjs.project_95manager_95winCode.GDlogoObjects2= [];
gdjs.project_95manager_95winCode.GDlogoObjects3= [];
gdjs.project_95manager_95winCode.GDlogoObjects4= [];
gdjs.project_95manager_95winCode.GDlogoObjects5= [];
gdjs.project_95manager_95winCode.GDlogoObjects6= [];
gdjs.project_95manager_95winCode.GDlogoObjects7= [];
gdjs.project_95manager_95winCode.GDprojectObjects1= [];
gdjs.project_95manager_95winCode.GDprojectObjects2= [];
gdjs.project_95manager_95winCode.GDprojectObjects3= [];
gdjs.project_95manager_95winCode.GDprojectObjects4= [];
gdjs.project_95manager_95winCode.GDprojectObjects5= [];
gdjs.project_95manager_95winCode.GDprojectObjects6= [];
gdjs.project_95manager_95winCode.GDprojectObjects7= [];
gdjs.project_95manager_95winCode.GDproject_9595namerObjects1= [];
gdjs.project_95manager_95winCode.GDproject_9595namerObjects2= [];
gdjs.project_95manager_95winCode.GDproject_9595namerObjects3= [];
gdjs.project_95manager_95winCode.GDproject_9595namerObjects4= [];
gdjs.project_95manager_95winCode.GDproject_9595namerObjects5= [];
gdjs.project_95manager_95winCode.GDproject_9595namerObjects6= [];
gdjs.project_95manager_95winCode.GDproject_9595namerObjects7= [];
gdjs.project_95manager_95winCode.GDproject_9595namesObjects1= [];
gdjs.project_95manager_95winCode.GDproject_9595namesObjects2= [];
gdjs.project_95manager_95winCode.GDproject_9595namesObjects3= [];
gdjs.project_95manager_95winCode.GDproject_9595namesObjects4= [];
gdjs.project_95manager_95winCode.GDproject_9595namesObjects5= [];
gdjs.project_95manager_95winCode.GDproject_9595namesObjects6= [];
gdjs.project_95manager_95winCode.GDproject_9595namesObjects7= [];
gdjs.project_95manager_95winCode.GDNewTextObjects1= [];
gdjs.project_95manager_95winCode.GDNewTextObjects2= [];
gdjs.project_95manager_95winCode.GDNewTextObjects3= [];
gdjs.project_95manager_95winCode.GDNewTextObjects4= [];
gdjs.project_95manager_95winCode.GDNewTextObjects5= [];
gdjs.project_95manager_95winCode.GDNewTextObjects6= [];
gdjs.project_95manager_95winCode.GDNewTextObjects7= [];
gdjs.project_95manager_95winCode.GDloadingObjects1= [];
gdjs.project_95manager_95winCode.GDloadingObjects2= [];
gdjs.project_95manager_95winCode.GDloadingObjects3= [];
gdjs.project_95manager_95winCode.GDloadingObjects4= [];
gdjs.project_95manager_95winCode.GDloadingObjects5= [];
gdjs.project_95manager_95winCode.GDloadingObjects6= [];
gdjs.project_95manager_95winCode.GDloadingObjects7= [];
gdjs.project_95manager_95winCode.GDNewText2Objects1= [];
gdjs.project_95manager_95winCode.GDNewText2Objects2= [];
gdjs.project_95manager_95winCode.GDNewText2Objects3= [];
gdjs.project_95manager_95winCode.GDNewText2Objects4= [];
gdjs.project_95manager_95winCode.GDNewText2Objects5= [];
gdjs.project_95manager_95winCode.GDNewText2Objects6= [];
gdjs.project_95manager_95winCode.GDNewText2Objects7= [];
gdjs.project_95manager_95winCode.GDdebugObjects1= [];
gdjs.project_95manager_95winCode.GDdebugObjects2= [];
gdjs.project_95manager_95winCode.GDdebugObjects3= [];
gdjs.project_95manager_95winCode.GDdebugObjects4= [];
gdjs.project_95manager_95winCode.GDdebugObjects5= [];
gdjs.project_95manager_95winCode.GDdebugObjects6= [];
gdjs.project_95manager_95winCode.GDdebugObjects7= [];
gdjs.project_95manager_95winCode.GDpath_9595displayObjects1= [];
gdjs.project_95manager_95winCode.GDpath_9595displayObjects2= [];
gdjs.project_95manager_95winCode.GDpath_9595displayObjects3= [];
gdjs.project_95manager_95winCode.GDpath_9595displayObjects4= [];
gdjs.project_95manager_95winCode.GDpath_9595displayObjects5= [];
gdjs.project_95manager_95winCode.GDpath_9595displayObjects6= [];
gdjs.project_95manager_95winCode.GDpath_9595displayObjects7= [];
gdjs.project_95manager_95winCode.GDNewSpriteObjects1= [];
gdjs.project_95manager_95winCode.GDNewSpriteObjects2= [];
gdjs.project_95manager_95winCode.GDNewSpriteObjects3= [];
gdjs.project_95manager_95winCode.GDNewSpriteObjects4= [];
gdjs.project_95manager_95winCode.GDNewSpriteObjects5= [];
gdjs.project_95manager_95winCode.GDNewSpriteObjects6= [];
gdjs.project_95manager_95winCode.GDNewSpriteObjects7= [];
gdjs.project_95manager_95winCode.GDfppObjects1= [];
gdjs.project_95manager_95winCode.GDfppObjects2= [];
gdjs.project_95manager_95winCode.GDfppObjects3= [];
gdjs.project_95manager_95winCode.GDfppObjects4= [];
gdjs.project_95manager_95winCode.GDfppObjects5= [];
gdjs.project_95manager_95winCode.GDfppObjects6= [];
gdjs.project_95manager_95winCode.GDfppObjects7= [];
gdjs.project_95manager_95winCode.GDgearObjects1= [];
gdjs.project_95manager_95winCode.GDgearObjects2= [];
gdjs.project_95manager_95winCode.GDgearObjects3= [];
gdjs.project_95manager_95winCode.GDgearObjects4= [];
gdjs.project_95manager_95winCode.GDgearObjects5= [];
gdjs.project_95manager_95winCode.GDgearObjects6= [];
gdjs.project_95manager_95winCode.GDgearObjects7= [];
gdjs.project_95manager_95winCode.GDNbellObjects1= [];
gdjs.project_95manager_95winCode.GDNbellObjects2= [];
gdjs.project_95manager_95winCode.GDNbellObjects3= [];
gdjs.project_95manager_95winCode.GDNbellObjects4= [];
gdjs.project_95manager_95winCode.GDNbellObjects5= [];
gdjs.project_95manager_95winCode.GDNbellObjects6= [];
gdjs.project_95manager_95winCode.GDNbellObjects7= [];
gdjs.project_95manager_95winCode.GDinfo2Objects1= [];
gdjs.project_95manager_95winCode.GDinfo2Objects2= [];
gdjs.project_95manager_95winCode.GDinfo2Objects3= [];
gdjs.project_95manager_95winCode.GDinfo2Objects4= [];
gdjs.project_95manager_95winCode.GDinfo2Objects5= [];
gdjs.project_95manager_95winCode.GDinfo2Objects6= [];
gdjs.project_95manager_95winCode.GDinfo2Objects7= [];
gdjs.project_95manager_95winCode.GDjj2Objects1= [];
gdjs.project_95manager_95winCode.GDjj2Objects2= [];
gdjs.project_95manager_95winCode.GDjj2Objects3= [];
gdjs.project_95manager_95winCode.GDjj2Objects4= [];
gdjs.project_95manager_95winCode.GDjj2Objects5= [];
gdjs.project_95manager_95winCode.GDjj2Objects6= [];
gdjs.project_95manager_95winCode.GDjj2Objects7= [];
gdjs.project_95manager_95winCode.GDdownloadObjects1= [];
gdjs.project_95manager_95winCode.GDdownloadObjects2= [];
gdjs.project_95manager_95winCode.GDdownloadObjects3= [];
gdjs.project_95manager_95winCode.GDdownloadObjects4= [];
gdjs.project_95manager_95winCode.GDdownloadObjects5= [];
gdjs.project_95manager_95winCode.GDdownloadObjects6= [];
gdjs.project_95manager_95winCode.GDdownloadObjects7= [];
gdjs.project_95manager_95winCode.GDjj3Objects1= [];
gdjs.project_95manager_95winCode.GDjj3Objects2= [];
gdjs.project_95manager_95winCode.GDjj3Objects3= [];
gdjs.project_95manager_95winCode.GDjj3Objects4= [];
gdjs.project_95manager_95winCode.GDjj3Objects5= [];
gdjs.project_95manager_95winCode.GDjj3Objects6= [];
gdjs.project_95manager_95winCode.GDjj3Objects7= [];


gdjs.project_95manager_95winCode.userFunc0xdbbf58 = function GDJSInlineCode(runtimeScene) {
"use strict";
const fs = require("fs")
const path = require("path")
const dir = runtimeScene.getVariables().get("filePath").getAsString()
const fileNames = fs.readdirSync(dir).filter(file => fs.lstatSync(path.join(dir,file)).isFile());
runtimeScene.getVariables().get("project_name").fromJSObject(fileNames)
runtimeScene.getVariables().get("ready").setNumber(1)
console.log(fileNames)

};
gdjs.project_95manager_95winCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.project_95manager_95winCode.userFunc0xdbbf58(runtimeScene);

}


};gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDaddObjects1Objects = Hashtable.newFrom({"add": gdjs.project_95manager_95winCode.GDaddObjects1});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects5Objects = Hashtable.newFrom({"project": gdjs.project_95manager_95winCode.GDprojectObjects5});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDproject_95959595namesObjects5Objects = Hashtable.newFrom({"project_names": gdjs.project_95manager_95winCode.GDproject_9595namesObjects5});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDpath_95959595displayObjects5Objects = Hashtable.newFrom({"path_display": gdjs.project_95manager_95winCode.GDpath_9595displayObjects5});
gdjs.project_95manager_95winCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95winCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


const repeatCount5 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(9));
for (let repeatIndex5 = 0;repeatIndex5 < repeatCount5;++repeatIndex5) {
gdjs.copyArray(gdjs.project_95manager_95winCode.GDpath_9595displayObjects3, gdjs.project_95manager_95winCode.GDpath_9595displayObjects5);

gdjs.copyArray(gdjs.project_95manager_95winCode.GDprojectObjects3, gdjs.project_95manager_95winCode.GDprojectObjects5);

gdjs.copyArray(gdjs.project_95manager_95winCode.GDproject_9595namesObjects3, gdjs.project_95manager_95winCode.GDproject_9595namesObjects5);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects5Objects, 10, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDproject_95959595namesObjects5Objects, 25, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 5, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDpath_95959595displayObjects5Objects, 20, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 32, "");
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDpath_9595displayObjects5.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDpath_9595displayObjects5[i].getBehavior("Text").setText(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getScene().getVariables().getFromIndex(8).getChild((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8)) - 1) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getAsString());
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namesObjects5.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namesObjects5[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(8).getChild((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8)) - 1) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getAsString() + gdjs.evtTools.string.newLine());
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects5.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects5[i].returnVariable(gdjs.project_95manager_95winCode.GDprojectObjects5[i].getVariables().getFromIndex(0)).setNumber((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8)) - 1) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(64);
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects5.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects5[i].getBehavior("Resizable").setWidth(400);
}
}
{ //Subevents: 
gdjs.project_95manager_95winCode.eventsList1(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95winCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("path_display"), gdjs.project_95manager_95winCode.GDpath_9595displayObjects3);
gdjs.copyArray(runtimeScene.getObjects("project"), gdjs.project_95manager_95winCode.GDprojectObjects3);
gdjs.copyArray(runtimeScene.getObjects("project_names"), gdjs.project_95manager_95winCode.GDproject_9595namesObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(128);
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects3.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namesObjects3.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namesObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDpath_9595displayObjects3.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDpath_9595displayObjects3[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95winCode.asyncCallback11089364 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.project_95manager_95winCode.localVariables);
{gdjs.evtTools.storage.writeStringInJSONFile("MSE(V)", "MSE(V)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(0);
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.project_95manager_95winCode.localVariables.length = 0;
}
gdjs.project_95manager_95winCode.eventsList4 = function(runtimeScene) {

{

/* Reuse gdjs.project_95manager_95winCode.GDproject_9595namerObjects1 */

{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.project_95manager_95winCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.fileSystem.saveStringToFileAsyncTask(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString(), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + (( gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length === 0 ) ? "" :gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[0].getBehavior("Text").getText()) + ".json", runtimeScene.getScene().getVariables().getFromIndex(7)), (runtimeScene) => (gdjs.project_95manager_95winCode.asyncCallback11089364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.project_95manager_95winCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(12).getAsNumber() == 1);
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95winCode.GDproject_9595namerObjects1 */
{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(8), (( gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length === 0 ) ? "" :gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[0].getText()));
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.project_95manager_95winCode.mapOfEmptyGDprojectObjects = Hashtable.newFrom({"project": []});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects2Objects = Hashtable.newFrom({"project": gdjs.project_95manager_95winCode.GDprojectObjects2});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDproject_95959595namesObjects2Objects = Hashtable.newFrom({"project_names": gdjs.project_95manager_95winCode.GDproject_9595namesObjects2});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDpath_95959595displayObjects2Objects = Hashtable.newFrom({"path_display": gdjs.project_95manager_95winCode.GDpath_9595displayObjects2});
gdjs.project_95manager_95winCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95winCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.project_95manager_95winCode.GDpath_9595displayObjects1, gdjs.project_95manager_95winCode.GDpath_9595displayObjects2);

gdjs.copyArray(gdjs.project_95manager_95winCode.GDprojectObjects1, gdjs.project_95manager_95winCode.GDprojectObjects2);

gdjs.copyArray(gdjs.project_95manager_95winCode.GDproject_9595namesObjects1, gdjs.project_95manager_95winCode.GDproject_9595namesObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects2Objects, 10, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDproject_95959595namesObjects2Objects, 25, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 5, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDpath_95959595displayObjects2Objects, 20, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 32, "");
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDpath_9595displayObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDpath_9595displayObjects2[i].getBehavior("Text").setText(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getScene().getVariables().getFromIndex(8).getChild((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8)) - 1) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getAsString());
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namesObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namesObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(8).getChild((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8)) - 1) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getAsString() + gdjs.evtTools.string.newLine());
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects2[i].returnVariable(gdjs.project_95manager_95winCode.GDprojectObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8)) - 1) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(64);
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects2[i].getBehavior("Resizable").setWidth(400);
}
}
{ //Subevents: 
gdjs.project_95manager_95winCode.eventsList6(runtimeScene);} //Subevents end.
}
}

}


};gdjs.project_95manager_95winCode.eventsList8 = function(runtimeScene) {

};gdjs.project_95manager_95winCode.eventsList9 = function(runtimeScene) {

{



}


{


const repeatCount3 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().getFromIndex(10).add(1);
}}
}

}


};gdjs.project_95manager_95winCode.eventsList10 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(10).setNumber(0);
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects1Objects = Hashtable.newFrom({"project": gdjs.project_95manager_95winCode.GDprojectObjects1});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects5Objects = Hashtable.newFrom({"project": gdjs.project_95manager_95winCode.GDprojectObjects5});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDproject_95959595namesObjects5Objects = Hashtable.newFrom({"project_names": gdjs.project_95manager_95winCode.GDproject_9595namesObjects5});
gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDpath_95959595displayObjects5Objects = Hashtable.newFrom({"path_display": gdjs.project_95manager_95winCode.GDpath_9595displayObjects5});
gdjs.project_95manager_95winCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95winCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


const repeatCount5 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8));
for (let repeatIndex5 = 0;repeatIndex5 < repeatCount5;++repeatIndex5) {
gdjs.copyArray(gdjs.project_95manager_95winCode.GDpath_9595displayObjects3, gdjs.project_95manager_95winCode.GDpath_9595displayObjects5);

gdjs.copyArray(gdjs.project_95manager_95winCode.GDprojectObjects3, gdjs.project_95manager_95winCode.GDprojectObjects5);

gdjs.copyArray(gdjs.project_95manager_95winCode.GDproject_9595namesObjects3, gdjs.project_95manager_95winCode.GDproject_9595namesObjects5);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects5Objects, 10, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDproject_95959595namesObjects5Objects, 25, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 5, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDpath_95959595displayObjects5Objects, 20, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() + 32, "");
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDpath_9595displayObjects5.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDpath_9595displayObjects5[i].getBehavior("Text").setText(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getScene().getVariables().getFromIndex(8).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getAsString());
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namesObjects5.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namesObjects5[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(8).getChild(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()).getAsString() + gdjs.evtTools.string.newLine());
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects5.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects5[i].returnVariable(gdjs.project_95manager_95winCode.GDprojectObjects5[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(64);
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects5.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects5[i].getBehavior("Resizable").setWidth(400);
}
}
{ //Subevents: 
gdjs.project_95manager_95winCode.eventsList11(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95winCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("path_display"), gdjs.project_95manager_95winCode.GDpath_9595displayObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("project"), gdjs.project_95manager_95winCode.GDprojectObjects3);

gdjs.copyArray(runtimeScene.getObjects("project_names"), gdjs.project_95manager_95winCode.GDproject_9595namesObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(64);
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects3.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namesObjects3.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namesObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDpath_9595displayObjects3.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDpath_9595displayObjects3[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


};gdjs.project_95manager_95winCode.asyncCallback20910380 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.project_95manager_95winCode.localVariables);
{gdjs.evtTools.variable.variableRemoveAt(runtimeScene.getScene().getVariables().getFromIndex(8), runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber());
}{gdjs.evtTools.storage.writeStringInJSONFile("MSE(V)", "MSE(V)", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "loader");
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.project_95manager_95winCode.localVariables.length = 0;
}
gdjs.project_95manager_95winCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.project_95manager_95winCode.localVariables);
for (const obj of gdjs.project_95manager_95winCode.GDprojectObjects1) asyncObjectsList.addObject("project", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.fileSystem.deleteFileAsyncTask(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getScene().getVariables().getFromIndex(8).getChild(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber()).getAsString(), gdjs.VariablesContainer.badVariable), (runtimeScene) => (gdjs.project_95manager_95winCode.asyncCallback20910380(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.project_95manager_95winCode.userFunc0x1159b90 = function GDJSInlineCode(runtimeScene) {
"use strict";
const url = "https://raw.githubusercontent.com/Michaelgde/music-sheet/main/version";


fetch(url)
  .then(response => {
    if (!response.ok) {
      throw new Error("Network response was not ok " + response.statusText);
    }
    return response.text();
  })
  .then(text => {
    console.log("File content:", text);

    // You can store the text in a GDevelop variable, or process it further
    var data = runtimeScene.getVariables().get("v").setString(text)
    
  })
  .catch(error => {
    console.error("There was a problem with the fetch operation:", error);
  });


};
gdjs.project_95manager_95winCode.eventsList15 = function(runtimeScene) {

{


gdjs.project_95manager_95winCode.userFunc0x1159b90(runtimeScene);

}


};gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDjj2Objects2Objects = Hashtable.newFrom({"jj2": gdjs.project_95manager_95winCode.GDjj2Objects2});
gdjs.project_95manager_95winCode.userFunc0xd79dc0 = function GDJSInlineCode(runtimeScene) {
"use strict";
const url = "https://raw.githubusercontent.com/Michaelgde/info/main/mse/info";


fetch(url)
  .then(response => {
    if (!response.ok) {
      throw new Error("Network response was not ok " + response.statusText);
    }
    return response.text();
  })
  .then(text => {
    console.log("File content:", text);

    // You can store the text in a GDevelop variable, or process it further
    var data = runtimeScene.getGame().getVariables().get("notification").setString(text)
    
  })
  .catch(error => {
    console.error("There was a problem with the fetch operation:", error);
  });


};
gdjs.project_95manager_95winCode.eventsList16 = function(runtimeScene) {

{


gdjs.project_95manager_95winCode.userFunc0xd79dc0(runtimeScene);

}


};gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDNbellObjects1Objects = Hashtable.newFrom({"Nbell": gdjs.project_95manager_95winCode.GDNbellObjects1});
gdjs.project_95manager_95winCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("MSEnotify", "MSEnotify");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MSEnotify", "MSEnotify", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(6));
}{gdjs.evtTools.storage.readStringFromJSONFile("MSEnotify", "MSEnotify", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(7));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23315868);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95winCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(6).getAsString()) > 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23306132);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("MSEnotify", "MSEnotify", runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(7).getAsString() != runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nbell"), gdjs.project_95manager_95winCode.GDNbellObjects2);
{for(var i = 0, len = gdjs.project_95manager_95winCode.GDNbellObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDNbellObjects2[i].getBehavior("Animation").setAnimationName("yes");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(7).getAsString() == runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Nbell"), gdjs.project_95manager_95winCode.GDNbellObjects2);
{for(var i = 0, len = gdjs.project_95manager_95winCode.GDNbellObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDNbellObjects2[i].getBehavior("Animation").setAnimationName("no");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Nbell"), gdjs.project_95manager_95winCode.GDNbellObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDNbellObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "pluginScene");
}}

}


};gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects1Objects = Hashtable.newFrom({"project": gdjs.project_95manager_95winCode.GDprojectObjects1});
gdjs.project_95manager_95winCode.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "audio_manager_win2");
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.project_95manager_95winCode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("audio").getAsString()) < 7);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "loader");
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(11).setNumber(1);
}}

}


};gdjs.project_95manager_95winCode.asyncCallback23315444 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.project_95manager_95winCode.localVariables);

{ //Subevents
gdjs.project_95manager_95winCode.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.project_95manager_95winCode.localVariables.length = 0;
}
gdjs.project_95manager_95winCode.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.project_95manager_95winCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.project_95manager_95winCode.asyncCallback23315444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.project_95manager_95winCode.asyncCallback23304292 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.project_95manager_95winCode.localVariables);
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(3));
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.project_95manager_95winCode.localVariables.length = 0;
}
gdjs.project_95manager_95winCode.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.project_95manager_95winCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.fileSystem.loadStringFromFileAsyncTask(runtimeScene.getScene().getVariables().getFromIndex(4), gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE" + gdjs.fileSystem.getPathDelimiter() + runtimeScene.getScene().getVariables().getFromIndex(8).getChild(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber()).getAsString(), gdjs.VariablesContainer.badVariable, true), (runtimeScene) => (gdjs.project_95manager_95winCode.asyncCallback23304292(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.project_95manager_95winCode.userFunc0x17fdb08 = function GDJSInlineCode(runtimeScene) {
"use strict";
runtimeScene.getSoundManager().unloadAll
if(runtimeScene.getGame().getSoundManager()._resourceLoader.getResource("audio.ogg").file = runtimeScene.getGame().getVariables().get("data").getChildNamed("audio").getAsString()){
    runtimeScene.getVariables().get("change").setNumber(3)

}

//var audio = new Audio()
//audio.src = runtimeScene.getGame().getVariables().get("data").getChildNamed("audio").getAsString()
//audio.play()

};
gdjs.project_95manager_95winCode.eventsList22 = function(runtimeScene) {

{


gdjs.project_95manager_95winCode.userFunc0x17fdb08(runtimeScene);

}


{



}


};gdjs.project_95manager_95winCode.userFunc0x1175cd0 = function GDJSInlineCode(runtimeScene) {
"use strict";
const audio = new Audio();
audio.src = runtimeScene.getGame().getVariables().get("data").getChildNamed("audio").getAsString()
audio.addEventListener('loadedmetadata', () => {
    console.log(`Duration: ${audio.duration} seconds`);
    runtimeScene.getGame().getVariables().get("audio_len").setNumber(audio.duration)
    runtimeScene.getVariables().get("change").setNumber(3)
});





};
gdjs.project_95manager_95winCode.eventsList23 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{



}


{



}


{


gdjs.project_95manager_95winCode.userFunc0x1175cd0(runtimeScene);

}


};gdjs.project_95manager_95winCode.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber() == 0);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95winCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber() == 1);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95winCode.eventsList23(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(14).getAsNumber() == 3);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "loader");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mse_win", false);
}}

}


};gdjs.project_95manager_95winCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.project_95manager_95winCode.GDgearObjects2);
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.project_95manager_95winCode.GDgearObjects2.length === 0 ) ? 0 :gdjs.project_95manager_95winCode.GDgearObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) + (gdjs.evtTools.window.getWindowInnerHeight() / 2), "", 0);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gear"), gdjs.project_95manager_95winCode.GDgearObjects1);
{for(var i = 0, len = gdjs.project_95manager_95winCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDgearObjects1[i].SetMaxValue(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDgearObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDgearObjects1[i].SetStepSize(0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.project_95manager_95winCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("project_namer"), gdjs.project_95manager_95winCode.GDproject_9595namerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.project_95manager_95winCode.GDproject_9595namerObjects2.length;i<l;++i) {
    if ( gdjs.project_95manager_95winCode.GDproject_9595namerObjects2[i].getBehavior("Text").getText() == "Name of The Project" ) {
        isConditionTrue_1 = true;
        gdjs.project_95manager_95winCode.GDproject_9595namerObjects2[k] = gdjs.project_95manager_95winCode.GDproject_9595namerObjects2[i];
        ++k;
    }
}
gdjs.project_95manager_95winCode.GDproject_9595namerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.project_95manager_95winCode.GDproject_9595namerObjects2.length;i<l;++i) {
    if ( gdjs.project_95manager_95winCode.GDproject_9595namerObjects2[i].isFocused() ) {
        isConditionTrue_1 = true;
        gdjs.project_95manager_95winCode.GDproject_9595namerObjects2[k] = gdjs.project_95manager_95winCode.GDproject_9595namerObjects2[i];
        ++k;
    }
}
gdjs.project_95manager_95winCode.GDproject_9595namerObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(19).getChild("input-1").getAsNumber() == 0);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20653836);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95winCode.GDproject_9595namerObjects2 */
{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namerObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namerObjects2[i].setTextColor("255;255;255");
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namerObjects2.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namerObjects2[i].getBehavior("Text").setText("");
}
}{runtimeScene.getScene().getVariables().getFromIndex(19).getChild("input-1").setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("project_namer"), gdjs.project_95manager_95winCode.GDproject_9595namerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length;i<l;++i) {
    if ( gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[i].getBehavior("Text").getText() == "" ) {
        isConditionTrue_1 = true;
        gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[k] = gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[i];
        ++k;
    }
}
gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length;i<l;++i) {
    if ( !(gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[i].isFocused()) ) {
        isConditionTrue_1 = true;
        gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[k] = gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[i];
        ++k;
    }
}
gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20622716);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95winCode.GDproject_9595namerObjects1 */
{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[i].setTextColor("200;200;200");
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[i].getBehavior("Text").setText("Name of The Project");
}
}{runtimeScene.getScene().getVariables().getFromIndex(19).getChild("input-1").setNumber(0);
}}

}


};gdjs.project_95manager_95winCode.eventsList27 = function(runtimeScene) {

{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "h");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio.ogg", 1, false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "k");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "audio.ogg", 2, false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "f");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.preloadMusic(runtimeScene, "audio.ogg");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "g");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "j");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "project_manager_win", false);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "o");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.fileSystem.pathExists(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95winCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.project_95manager_95winCode.GDaddObjects1);
gdjs.copyArray(runtimeScene.getObjects("project_namer"), gdjs.project_95manager_95winCode.GDproject_9595namerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDaddObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length;i<l;++i) {
    if ( gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[i].getBehavior("Text").getText() != "" ) {
        isConditionTrue_0 = true;
        gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[k] = gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[i];
        ++k;
    }
}
gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !((gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getScene().getVariables().getFromIndex(8))).includes((( gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length === 0 ) ? "" :gdjs.project_95manager_95winCode.GDproject_9595namerObjects1[0].getText())));
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(1);
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(8)) != gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.project_95manager_95winCode.mapOfEmptyGDprojectObjects));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("path_display"), gdjs.project_95manager_95winCode.GDpath_9595displayObjects1);
gdjs.copyArray(runtimeScene.getObjects("project"), gdjs.project_95manager_95winCode.GDprojectObjects1);
gdjs.copyArray(runtimeScene.getObjects("project_names"), gdjs.project_95manager_95winCode.GDproject_9595namesObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(128);
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDprojectObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDprojectObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDproject_9595namesObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDproject_9595namesObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.project_95manager_95winCode.GDpath_9595displayObjects1.length ;i < len;++i) {
    gdjs.project_95manager_95winCode.GDpath_9595displayObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.fileSystem.pathExists(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("MSE(V)", "MSE(V)", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(7));
}{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(7).getAsString(), runtimeScene.getScene().getVariables().getFromIndex(8));
}{runtimeScene.getScene().getVariables().getFromIndex(15).setString(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE");
}{gdjs.evtTools.sound.unloadMusic(runtimeScene, "audio.ogg");
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.fileSystem.pathExists(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE"));
if (isConditionTrue_0) {
{gdjs.fileSystem.makeDirectory(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE", gdjs.VariablesContainer.badVariable);
}{runtimeScene.getScene().getVariables().getFromIndex(15).setString(gdjs.fileSystem.getDocumentsPath(runtimeScene) + gdjs.fileSystem.getPathDelimiter() + "MSE");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("project"), gdjs.project_95manager_95winCode.GDprojectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95winCode.GDprojectObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(13).setNumber(((gdjs.project_95manager_95winCode.GDprojectObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.project_95manager_95winCode.GDprojectObjects1[0].getVariables()).getFromIndex(0).getAsNumber());
}{gdjs.evtTools.camera.showLayer(runtimeScene, "loader");
}{runtimeScene.getGame().getVariables().getFromIndex(11).setString(runtimeScene.getScene().getVariables().getFromIndex(8).getChild(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber()).getAsString());
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23346884);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95winCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !((runtimeScene.getScene().getVariables().getFromIndex(20).getAsString()).includes("1.4.0"));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(20).getAsString()) > 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18861380);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "info");
}}

}


{

gdjs.project_95manager_95winCode.GDjj2Objects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.project_95manager_95winCode.GDjj2Objects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = ((runtimeScene.getScene().getVariables().getFromIndex(20).getAsString()).includes("1.4.0"));
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("jj2"), gdjs.project_95manager_95winCode.GDjj2Objects2);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDjj2Objects2Objects, runtimeScene, true, true);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.project_95manager_95winCode.GDjj2Objects2.length; j < jLen ; ++j) {
        if ( gdjs.project_95manager_95winCode.GDjj2Objects1_1final.indexOf(gdjs.project_95manager_95winCode.GDjj2Objects2[j]) === -1 )
            gdjs.project_95manager_95winCode.GDjj2Objects1_1final.push(gdjs.project_95manager_95winCode.GDjj2Objects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.project_95manager_95winCode.GDjj2Objects1_1final, gdjs.project_95manager_95winCode.GDjj2Objects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "info");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("download"), gdjs.project_95manager_95winCode.GDdownloadObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.project_95manager_95winCode.GDdownloadObjects1.length;i<l;++i) {
    if ( gdjs.project_95manager_95winCode.GDdownloadObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.project_95manager_95winCode.GDdownloadObjects1[k] = gdjs.project_95manager_95winCode.GDdownloadObjects1[i];
        ++k;
    }
}
gdjs.project_95manager_95winCode.GDdownloadObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://michaelgd.itch.io/mse", runtimeScene);
}}

}


{


gdjs.project_95manager_95winCode.eventsList17(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("project"), gdjs.project_95manager_95winCode.GDprojectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.project_95manager_95winCode.mapOfGDgdjs_9546project_959595manager_959595winCode_9546GDprojectObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.project_95manager_95winCode.GDprojectObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("audio").setString("");
}{runtimeScene.getScene().getVariables().getFromIndex(13).setNumber(((gdjs.project_95manager_95winCode.GDprojectObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.project_95manager_95winCode.GDprojectObjects1[0].getVariables()).getFromIndex(0).getAsNumber());
}{gdjs.evtTools.camera.showLayer(runtimeScene, "loader");
}{runtimeScene.getGame().getVariables().getFromIndex(11).setString(runtimeScene.getScene().getVariables().getFromIndex(8).getChild(runtimeScene.getScene().getVariables().getFromIndex(13).getAsNumber()).getAsString());
}
{ //Subevents
gdjs.project_95manager_95winCode.eventsList21(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("audio").getAsString()) > 7);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "loader");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(11).getAsNumber() == 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23323484);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.project_95manager_95winCode.eventsList24(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.deleteElementFromJSONFile("MSE(V)", "MSE(V)");
}}

}


{


gdjs.project_95manager_95winCode.eventsList25(runtimeScene);
}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.project_95manager_95winCode.eventsList26(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.project_95manager_95winCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.project_95manager_95winCode.GDnameObjects1.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects2.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects3.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects4.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects5.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects6.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects7.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects1.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects2.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects3.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects4.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects5.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects6.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects7.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects1.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects2.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects3.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects4.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects5.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects6.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects7.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects1.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects2.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects3.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects4.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects5.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects6.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects7.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects1.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects2.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects3.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects4.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects5.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects6.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects7.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects1.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects2.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects3.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects4.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects5.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects6.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects7.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects1.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects2.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects3.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects4.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects5.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects6.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects7.length = 0;
gdjs.project_95manager_95winCode.GDokObjects1.length = 0;
gdjs.project_95manager_95winCode.GDokObjects2.length = 0;
gdjs.project_95manager_95winCode.GDokObjects3.length = 0;
gdjs.project_95manager_95winCode.GDokObjects4.length = 0;
gdjs.project_95manager_95winCode.GDokObjects5.length = 0;
gdjs.project_95manager_95winCode.GDokObjects6.length = 0;
gdjs.project_95manager_95winCode.GDokObjects7.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects1.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects2.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects3.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects4.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects5.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects6.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects7.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects1.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects2.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects3.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects4.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects5.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects6.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects7.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects1.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects2.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects3.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects4.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects5.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects6.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects7.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects1.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects2.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects3.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects4.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects5.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects6.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects7.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects1.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects2.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects3.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects4.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects5.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects6.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects7.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects1.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects2.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects3.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects4.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects5.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects6.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects7.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects1.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects2.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects3.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects4.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects5.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects6.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects7.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects1.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects2.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects3.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects4.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects5.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects6.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects7.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects1.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects2.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects3.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects4.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects5.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects6.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects7.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects2.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects3.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects4.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects5.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects6.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects7.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects1.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects2.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects3.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects4.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects5.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects6.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects7.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects1.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects2.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects3.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects4.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects5.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects6.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects7.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects1.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects2.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects3.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects4.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects5.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects6.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects7.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects1.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects2.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects3.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects4.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects5.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects6.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects7.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects1.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects2.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects3.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects4.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects5.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects6.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects7.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects1.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects2.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects3.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects4.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects5.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects6.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects7.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects1.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects2.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects3.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects4.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects5.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects6.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects7.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects1.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects2.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects3.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects4.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects5.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects6.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects7.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects1.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects2.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects3.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects4.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects5.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects6.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects7.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects1.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects2.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects3.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects4.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects5.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects6.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects7.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects1.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects2.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects3.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects4.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects5.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects6.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects7.length = 0;

gdjs.project_95manager_95winCode.eventsList27(runtimeScene);
gdjs.project_95manager_95winCode.GDnameObjects1.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects2.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects3.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects4.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects5.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects6.length = 0;
gdjs.project_95manager_95winCode.GDnameObjects7.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects1.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects2.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects3.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects4.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects5.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects6.length = 0;
gdjs.project_95manager_95winCode.GDinfoObjects7.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects1.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects2.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects3.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects4.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects5.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects6.length = 0;
gdjs.project_95manager_95winCode.GDaddObjects7.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects1.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects2.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects3.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects4.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects5.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects6.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595txtObjects7.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects1.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects2.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects3.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects4.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects5.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects6.length = 0;
gdjs.project_95manager_95winCode.GDsave_9595iconObjects7.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDname2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects1.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects2.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects3.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects4.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects5.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects6.length = 0;
gdjs.project_95manager_95winCode.GDioiObjects7.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects1.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects2.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects3.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects4.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects5.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects6.length = 0;
gdjs.project_95manager_95winCode.GDadd_9595eveObjects7.length = 0;
gdjs.project_95manager_95winCode.GDokObjects1.length = 0;
gdjs.project_95manager_95winCode.GDokObjects2.length = 0;
gdjs.project_95manager_95winCode.GDokObjects3.length = 0;
gdjs.project_95manager_95winCode.GDokObjects4.length = 0;
gdjs.project_95manager_95winCode.GDokObjects5.length = 0;
gdjs.project_95manager_95winCode.GDokObjects6.length = 0;
gdjs.project_95manager_95winCode.GDokObjects7.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects1.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects2.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects3.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects4.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects5.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects6.length = 0;
gdjs.project_95manager_95winCode.GDcancObjects7.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects1.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects2.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects3.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects4.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects5.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects6.length = 0;
gdjs.project_95manager_95winCode.GDpaintObjects7.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects1.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects2.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects3.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects4.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects5.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects6.length = 0;
gdjs.project_95manager_95winCode.GDname3Objects7.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects1.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects2.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects3.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects4.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects5.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects6.length = 0;
gdjs.project_95manager_95winCode.GDpanelObjects7.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects1.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects2.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects3.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects4.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects5.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects6.length = 0;
gdjs.project_95manager_95winCode.GDsprrObjects7.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDpanel2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects1.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects2.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects3.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects4.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects5.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects6.length = 0;
gdjs.project_95manager_95winCode.GDfkObjects7.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects1.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects2.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects3.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects4.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects5.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects6.length = 0;
gdjs.project_95manager_95winCode.GDjjObjects7.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects1.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects2.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects3.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects4.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects5.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects6.length = 0;
gdjs.project_95manager_95winCode.GDlogoObjects7.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects1.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects2.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects3.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects4.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects5.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects6.length = 0;
gdjs.project_95manager_95winCode.GDprojectObjects7.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects1.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects2.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects3.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects4.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects5.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects6.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namerObjects7.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects1.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects2.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects3.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects4.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects5.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects6.length = 0;
gdjs.project_95manager_95winCode.GDproject_9595namesObjects7.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects1.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects2.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects3.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects4.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects5.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects6.length = 0;
gdjs.project_95manager_95winCode.GDNewTextObjects7.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects1.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects2.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects3.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects4.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects5.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects6.length = 0;
gdjs.project_95manager_95winCode.GDloadingObjects7.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDNewText2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects1.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects2.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects3.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects4.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects5.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects6.length = 0;
gdjs.project_95manager_95winCode.GDdebugObjects7.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects1.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects2.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects3.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects4.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects5.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects6.length = 0;
gdjs.project_95manager_95winCode.GDpath_9595displayObjects7.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects1.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects2.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects3.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects4.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects5.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects6.length = 0;
gdjs.project_95manager_95winCode.GDNewSpriteObjects7.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects1.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects2.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects3.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects4.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects5.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects6.length = 0;
gdjs.project_95manager_95winCode.GDfppObjects7.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects1.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects2.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects3.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects4.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects5.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects6.length = 0;
gdjs.project_95manager_95winCode.GDgearObjects7.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects1.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects2.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects3.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects4.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects5.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects6.length = 0;
gdjs.project_95manager_95winCode.GDNbellObjects7.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDinfo2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects1.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects2.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects3.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects4.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects5.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects6.length = 0;
gdjs.project_95manager_95winCode.GDjj2Objects7.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects1.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects2.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects3.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects4.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects5.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects6.length = 0;
gdjs.project_95manager_95winCode.GDdownloadObjects7.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects1.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects2.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects3.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects4.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects5.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects6.length = 0;
gdjs.project_95manager_95winCode.GDjj3Objects7.length = 0;


return;

}

gdjs['project_95manager_95winCode'] = gdjs.project_95manager_95winCode;
