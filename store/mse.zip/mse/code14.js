gdjs.pluginsCode = {};
gdjs.pluginsCode.localVariables = [];
gdjs.pluginsCode.forEachIndex2 = 0;

gdjs.pluginsCode.forEachIndex3 = 0;

gdjs.pluginsCode.forEachObjects2 = [];

gdjs.pluginsCode.forEachObjects3 = [];

gdjs.pluginsCode.forEachTemporary2 = null;

gdjs.pluginsCode.forEachTemporary3 = null;

gdjs.pluginsCode.forEachTotalCount2 = 0;

gdjs.pluginsCode.forEachTotalCount3 = 0;

gdjs.pluginsCode.GDNewToggleSwitchObjects1= [];
gdjs.pluginsCode.GDNewToggleSwitchObjects2= [];
gdjs.pluginsCode.GDNewToggleSwitchObjects3= [];
gdjs.pluginsCode.GDNewToggleSwitchObjects4= [];
gdjs.pluginsCode.GDNewToggleSwitchObjects5= [];
gdjs.pluginsCode.GDNewToggleSwitchObjects6= [];
gdjs.pluginsCode.GDNewToggleSwitchObjects7= [];
gdjs.pluginsCode.GDSquareWhiteToggleObjects1= [];
gdjs.pluginsCode.GDSquareWhiteToggleObjects2= [];
gdjs.pluginsCode.GDSquareWhiteToggleObjects3= [];
gdjs.pluginsCode.GDSquareWhiteToggleObjects4= [];
gdjs.pluginsCode.GDSquareWhiteToggleObjects5= [];
gdjs.pluginsCode.GDSquareWhiteToggleObjects6= [];
gdjs.pluginsCode.GDSquareWhiteToggleObjects7= [];
gdjs.pluginsCode.GDnameObjects1= [];
gdjs.pluginsCode.GDnameObjects2= [];
gdjs.pluginsCode.GDnameObjects3= [];
gdjs.pluginsCode.GDnameObjects4= [];
gdjs.pluginsCode.GDnameObjects5= [];
gdjs.pluginsCode.GDnameObjects6= [];
gdjs.pluginsCode.GDnameObjects7= [];
gdjs.pluginsCode.GDDownloadObjects1= [];
gdjs.pluginsCode.GDDownloadObjects2= [];
gdjs.pluginsCode.GDDownloadObjects3= [];
gdjs.pluginsCode.GDDownloadObjects4= [];
gdjs.pluginsCode.GDDownloadObjects5= [];
gdjs.pluginsCode.GDDownloadObjects6= [];
gdjs.pluginsCode.GDDownloadObjects7= [];
gdjs.pluginsCode.GDavailableObjects1= [];
gdjs.pluginsCode.GDavailableObjects2= [];
gdjs.pluginsCode.GDavailableObjects3= [];
gdjs.pluginsCode.GDavailableObjects4= [];
gdjs.pluginsCode.GDavailableObjects5= [];
gdjs.pluginsCode.GDavailableObjects6= [];
gdjs.pluginsCode.GDavailableObjects7= [];
gdjs.pluginsCode.GDname2Objects1= [];
gdjs.pluginsCode.GDname2Objects2= [];
gdjs.pluginsCode.GDname2Objects3= [];
gdjs.pluginsCode.GDname2Objects4= [];
gdjs.pluginsCode.GDname2Objects5= [];
gdjs.pluginsCode.GDname2Objects6= [];
gdjs.pluginsCode.GDname2Objects7= [];
gdjs.pluginsCode.GDstoreObjects1= [];
gdjs.pluginsCode.GDstoreObjects2= [];
gdjs.pluginsCode.GDstoreObjects3= [];
gdjs.pluginsCode.GDstoreObjects4= [];
gdjs.pluginsCode.GDstoreObjects5= [];
gdjs.pluginsCode.GDstoreObjects6= [];
gdjs.pluginsCode.GDstoreObjects7= [];
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects1= [];
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects2= [];
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects3= [];
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects4= [];
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects5= [];
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects6= [];
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects7= [];
gdjs.pluginsCode.GDYoutubeObjects1= [];
gdjs.pluginsCode.GDYoutubeObjects2= [];
gdjs.pluginsCode.GDYoutubeObjects3= [];
gdjs.pluginsCode.GDYoutubeObjects4= [];
gdjs.pluginsCode.GDYoutubeObjects5= [];
gdjs.pluginsCode.GDYoutubeObjects6= [];
gdjs.pluginsCode.GDYoutubeObjects7= [];
gdjs.pluginsCode.GDKoFiObjects1= [];
gdjs.pluginsCode.GDKoFiObjects2= [];
gdjs.pluginsCode.GDKoFiObjects3= [];
gdjs.pluginsCode.GDKoFiObjects4= [];
gdjs.pluginsCode.GDKoFiObjects5= [];
gdjs.pluginsCode.GDKoFiObjects6= [];
gdjs.pluginsCode.GDKoFiObjects7= [];
gdjs.pluginsCode.GDRetryObjects1= [];
gdjs.pluginsCode.GDRetryObjects2= [];
gdjs.pluginsCode.GDRetryObjects3= [];
gdjs.pluginsCode.GDRetryObjects4= [];
gdjs.pluginsCode.GDRetryObjects5= [];
gdjs.pluginsCode.GDRetryObjects6= [];
gdjs.pluginsCode.GDRetryObjects7= [];
gdjs.pluginsCode.GDNewSpriteObjects1= [];
gdjs.pluginsCode.GDNewSpriteObjects2= [];
gdjs.pluginsCode.GDNewSpriteObjects3= [];
gdjs.pluginsCode.GDNewSpriteObjects4= [];
gdjs.pluginsCode.GDNewSpriteObjects5= [];
gdjs.pluginsCode.GDNewSpriteObjects6= [];
gdjs.pluginsCode.GDNewSpriteObjects7= [];
gdjs.pluginsCode.GDbackObjects1= [];
gdjs.pluginsCode.GDbackObjects2= [];
gdjs.pluginsCode.GDbackObjects3= [];
gdjs.pluginsCode.GDbackObjects4= [];
gdjs.pluginsCode.GDbackObjects5= [];
gdjs.pluginsCode.GDbackObjects6= [];
gdjs.pluginsCode.GDbackObjects7= [];
gdjs.pluginsCode.GDscrollObjects1= [];
gdjs.pluginsCode.GDscrollObjects2= [];
gdjs.pluginsCode.GDscrollObjects3= [];
gdjs.pluginsCode.GDscrollObjects4= [];
gdjs.pluginsCode.GDscrollObjects5= [];
gdjs.pluginsCode.GDscrollObjects6= [];
gdjs.pluginsCode.GDscrollObjects7= [];
gdjs.pluginsCode.GDplugSettingObjects1= [];
gdjs.pluginsCode.GDplugSettingObjects2= [];
gdjs.pluginsCode.GDplugSettingObjects3= [];
gdjs.pluginsCode.GDplugSettingObjects4= [];
gdjs.pluginsCode.GDplugSettingObjects5= [];
gdjs.pluginsCode.GDplugSettingObjects6= [];
gdjs.pluginsCode.GDplugSettingObjects7= [];
gdjs.pluginsCode.GDback2Objects1= [];
gdjs.pluginsCode.GDback2Objects2= [];
gdjs.pluginsCode.GDback2Objects3= [];
gdjs.pluginsCode.GDback2Objects4= [];
gdjs.pluginsCode.GDback2Objects5= [];
gdjs.pluginsCode.GDback2Objects6= [];
gdjs.pluginsCode.GDback2Objects7= [];
gdjs.pluginsCode.GDscrolObjects1= [];
gdjs.pluginsCode.GDscrolObjects2= [];
gdjs.pluginsCode.GDscrolObjects3= [];
gdjs.pluginsCode.GDscrolObjects4= [];
gdjs.pluginsCode.GDscrolObjects5= [];
gdjs.pluginsCode.GDscrolObjects6= [];
gdjs.pluginsCode.GDscrolObjects7= [];
gdjs.pluginsCode.GDinfoObjects1= [];
gdjs.pluginsCode.GDinfoObjects2= [];
gdjs.pluginsCode.GDinfoObjects3= [];
gdjs.pluginsCode.GDinfoObjects4= [];
gdjs.pluginsCode.GDinfoObjects5= [];
gdjs.pluginsCode.GDinfoObjects6= [];
gdjs.pluginsCode.GDinfoObjects7= [];
gdjs.pluginsCode.GDpropertyObjects1= [];
gdjs.pluginsCode.GDpropertyObjects2= [];
gdjs.pluginsCode.GDpropertyObjects3= [];
gdjs.pluginsCode.GDpropertyObjects4= [];
gdjs.pluginsCode.GDpropertyObjects5= [];
gdjs.pluginsCode.GDpropertyObjects6= [];
gdjs.pluginsCode.GDpropertyObjects7= [];
gdjs.pluginsCode.GDboolObjects1= [];
gdjs.pluginsCode.GDboolObjects2= [];
gdjs.pluginsCode.GDboolObjects3= [];
gdjs.pluginsCode.GDboolObjects4= [];
gdjs.pluginsCode.GDboolObjects5= [];
gdjs.pluginsCode.GDboolObjects6= [];
gdjs.pluginsCode.GDboolObjects7= [];
gdjs.pluginsCode.GDnumObjects1= [];
gdjs.pluginsCode.GDnumObjects2= [];
gdjs.pluginsCode.GDnumObjects3= [];
gdjs.pluginsCode.GDnumObjects4= [];
gdjs.pluginsCode.GDnumObjects5= [];
gdjs.pluginsCode.GDnumObjects6= [];
gdjs.pluginsCode.GDnumObjects7= [];
gdjs.pluginsCode.GDstrObjects1= [];
gdjs.pluginsCode.GDstrObjects2= [];
gdjs.pluginsCode.GDstrObjects3= [];
gdjs.pluginsCode.GDstrObjects4= [];
gdjs.pluginsCode.GDstrObjects5= [];
gdjs.pluginsCode.GDstrObjects6= [];
gdjs.pluginsCode.GDstrObjects7= [];
gdjs.pluginsCode.GDscrolbObjects1= [];
gdjs.pluginsCode.GDscrolbObjects2= [];
gdjs.pluginsCode.GDscrolbObjects3= [];
gdjs.pluginsCode.GDscrolbObjects4= [];
gdjs.pluginsCode.GDscrolbObjects5= [];
gdjs.pluginsCode.GDscrolbObjects6= [];
gdjs.pluginsCode.GDscrolbObjects7= [];


gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDDownloadObjects1Objects = Hashtable.newFrom({"Download": gdjs.pluginsCode.GDDownloadObjects1});
gdjs.pluginsCode.userFunc0x1165240 = function GDJSInlineCode(runtimeScene) {
"use strict";
var data = runtimeScene.getVariables().get("dir").getAsString()
const url = "https://raw.githubusercontent.com/Michaelgde/music-sheet/main/plugins/"+data+"/script.js";
const url2 = "https://raw.githubusercontent.com/Michaelgde/music-sheet/main/plugins/"+data+"/settings.json";

fetch(url)
  .then(response => {
    if (!response.ok) {
      throw new Error("Network response was not ok " + response.statusText);
    }
    return response.text();
  })
  .then(text => {
    console.log("File content:", text);

    // You can store the text in a GDevelop variable, or process it further
    var data = runtimeScene.getVariables().get("temp").setString(text)
    
  })
  .catch(error => {
    console.error("There was a problem with the fetch operation:", error);
  });

fetch(url2)
  .then(response => {
    if (!response.ok) {
      throw new Error("Network response was not ok " + response.statusText);
    }
    return response.text();
  })
  .then(text => {
    console.log("setting content:", text);

    // You can store the text in a GDevelop variable, or process it further
    //eval(`var tempjson = JSON.parse(`+text+`)`)
    
    runtimeScene.getVariables().get("tempjson").setString(JSON.stringify(JSON.parse(text)))
    
  })
  .catch(error => {
    console.error("There was a problem with the fetch operation:", error);
  });
};
gdjs.pluginsCode.eventsList0 = function(runtimeScene) {

{


gdjs.pluginsCode.userFunc0x1165240(runtimeScene);

}


};gdjs.pluginsCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(7).setString("");
}}

}


};gdjs.pluginsCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.pluginsCode.userFunc0x108fde8 = function GDJSInlineCode(runtimeScene) {
"use strict";
const repo = "Michaelgde/music-sheet";  // Replace with your GitHub username/repository
const path = "plugins";    // Path to the folder in the repository (leave empty for the root)
const branch = "main";               // Branch name (e.g., main, master)
let q = '"'


fetch(`https://api.github.com/repos/${repo}/contents/${path}?ref=${branch}`)
  .then(response => response.json())
  .then(data => {
    if (Array.isArray(data)) {
      // Loop through and log the file names
      data.forEach(file => {
        if (file.type === "file") {
          console.log("File name:", file.name);
        } else if (file.type === "dir") {
          console.log("Directory name:", file.name);
          runtimeScene.getVariables().get("jsonCheck").setString(runtimeScene.getVariables().get("jsonCheck").getAsString()+","+q+file.name+q)
        }
      });

      // Example: Store the list of file names in a GDevelop variable
      const fileNames = data.filter(file => file.type === "file").map(file => file.name);
      const dirNames = data.filter(file => file.type === "dir").map(file => file.name);
      runtimeScene.getVariables().get("datas").fromJSObject(dirNames);
      runtimeScene.getVariables().get("refresh").setString("y")
    } else {
      console.error("Failed to retrieve the directory contents:", data.message);
    }
  })
  .catch(error => {
    console.error("Error fetching directory contents:", error);
  });


};
gdjs.pluginsCode.eventsList3 = function(runtimeScene) {

{


gdjs.pluginsCode.userFunc0x108fde8(runtimeScene);

}


};gdjs.pluginsCode.mapOfEmptyGDname2Objects = Hashtable.newFrom({"name2": []});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDname2Objects2Objects = Hashtable.newFrom({"name2": gdjs.pluginsCode.GDname2Objects2});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDSquareWhiteToggleObjects2Objects = Hashtable.newFrom({"SquareWhiteToggle": gdjs.pluginsCode.GDSquareWhiteToggleObjects2});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDplugSettingObjects2Objects = Hashtable.newFrom({"plugSetting": gdjs.pluginsCode.GDplugSettingObjects2});
gdjs.pluginsCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString()).getChild("enable").getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.pluginsCode.GDSquareWhiteToggleObjects2, gdjs.pluginsCode.GDSquareWhiteToggleObjects3);

{for(var i = 0, len = gdjs.pluginsCode.GDSquareWhiteToggleObjects3.length ;i < len;++i) {
    gdjs.pluginsCode.GDSquareWhiteToggleObjects3[i].SetChecked(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString()).getChild("enable").getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.pluginsCode.GDSquareWhiteToggleObjects2, gdjs.pluginsCode.GDSquareWhiteToggleObjects3);

{for(var i = 0, len = gdjs.pluginsCode.GDSquareWhiteToggleObjects3.length ;i < len;++i) {
    gdjs.pluginsCode.GDSquareWhiteToggleObjects3[i].SetChecked(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.pluginsCode.eventsList5 = function(runtimeScene) {

{


const keyIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(4);
const valueIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(5);
const iterableReference2 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins");
if(!iterableReference2.isPrimitive()) {
for(
    const iteratorKey2 in 
    iterableReference2.getType() === "structure"
      ? iterableReference2.getAllChildren()
      : iterableReference2.getType() === "array"
        ? iterableReference2.getAllChildrenArray()
        : []
) {
    if(iterableReference2.getType() === "structure")
        keyIteratorReference2.setString(iteratorKey2);
    else if(iterableReference2.getType() === "array")
        keyIteratorReference2.setNumber(iteratorKey2);
    const structureChildVariable2 = iterableReference2.getChild(iteratorKey2)
    valueIteratorReference2.castTo(structureChildVariable2.getType())
    if(structureChildVariable2.isPrimitive()) {
        valueIteratorReference2.setValue(structureChildVariable2.getValue());
    } else if (structureChildVariable2.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference2.replaceChildren(structureChildVariable2.getAllChildren());
    } else if (structureChildVariable2.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference2.replaceChildrenArray(structureChildVariable2.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(gdjs.pluginsCode.GDSquareWhiteToggleObjects1, gdjs.pluginsCode.GDSquareWhiteToggleObjects2);

gdjs.copyArray(gdjs.pluginsCode.GDname2Objects1, gdjs.pluginsCode.GDname2Objects2);

gdjs.copyArray(gdjs.pluginsCode.GDplugSettingObjects1, gdjs.pluginsCode.GDplugSettingObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDname2Objects2Objects, 0, 64 + runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() * 32, "");
}{for(var i = 0, len = gdjs.pluginsCode.GDname2Objects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDname2Objects2[i].returnVariable(gdjs.pluginsCode.GDname2Objects2[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber());
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDSquareWhiteToggleObjects2Objects, 550, 64 + runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() * 32, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDplugSettingObjects2Objects, 590, 64 + runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() * 32, "");
}{for(var i = 0, len = gdjs.pluginsCode.GDname2Objects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDname2Objects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDSquareWhiteToggleObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDSquareWhiteToggleObjects2[i].returnVariable(gdjs.pluginsCode.GDSquareWhiteToggleObjects2[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDplugSettingObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDplugSettingObjects2[i].returnVariable(gdjs.pluginsCode.GDplugSettingObjects2[i].getVariables().getFromIndex(1)).setString(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDname2Objects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDname2Objects2[i].returnVariable(gdjs.pluginsCode.GDname2Objects2[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDSquareWhiteToggleObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDSquareWhiteToggleObjects2[i].returnVariable(gdjs.pluginsCode.GDSquareWhiteToggleObjects2[i].getVariables().getFromIndex(1)).setString(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString());
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).add(1);
}
{ //Subevents: 
gdjs.pluginsCode.eventsList4(runtimeScene);} //Subevents end.
}
}
}

}


};gdjs.pluginsCode.mapOfEmptyGDnameObjects = Hashtable.newFrom({"name": []});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDnameObjects2Objects = Hashtable.newFrom({"name": gdjs.pluginsCode.GDnameObjects2});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDDownloadObjects2Objects = Hashtable.newFrom({"Download": gdjs.pluginsCode.GDDownloadObjects2});
gdjs.pluginsCode.eventsList6 = function(runtimeScene) {

};gdjs.pluginsCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const keyIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(3);
const valueIteratorReference2 = runtimeScene.getScene().getVariables().getFromIndex(2);
const iterableReference2 = runtimeScene.getScene().getVariables().getFromIndex(1);
if(!iterableReference2.isPrimitive()) {
for(
    const iteratorKey2 in 
    iterableReference2.getType() === "structure"
      ? iterableReference2.getAllChildren()
      : iterableReference2.getType() === "array"
        ? iterableReference2.getAllChildrenArray()
        : []
) {
    if(iterableReference2.getType() === "structure")
        keyIteratorReference2.setString(iteratorKey2);
    else if(iterableReference2.getType() === "array")
        keyIteratorReference2.setNumber(iteratorKey2);
    const structureChildVariable2 = iterableReference2.getChild(iteratorKey2)
    valueIteratorReference2.castTo(structureChildVariable2.getType())
    if(structureChildVariable2.isPrimitive()) {
        valueIteratorReference2.setValue(structureChildVariable2.getValue());
    } else if (structureChildVariable2.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference2.replaceChildren(structureChildVariable2.getAllChildren());
    } else if (structureChildVariable2.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference2.replaceChildrenArray(structureChildVariable2.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(gdjs.pluginsCode.GDDownloadObjects1, gdjs.pluginsCode.GDDownloadObjects2);

gdjs.copyArray(gdjs.pluginsCode.GDnameObjects1, gdjs.pluginsCode.GDnameObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDnameObjects2Objects, 672, 64 + runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() * 32, "store");
}{for(var i = 0, len = gdjs.pluginsCode.GDnameObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDnameObjects2[i].returnVariable(gdjs.pluginsCode.GDnameObjects2[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDDownloadObjects2Objects, 1000, 64 + runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() * 32, "store");
}{for(var i = 0, len = gdjs.pluginsCode.GDnameObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDnameObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber()).getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDDownloadObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDDownloadObjects2[i].returnVariable(gdjs.pluginsCode.GDDownloadObjects2[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDnameObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDnameObjects2[i].returnVariable(gdjs.pluginsCode.GDnameObjects2[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}}
}
}

}


};gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDnameObjects1Objects = Hashtable.newFrom({"name": gdjs.pluginsCode.GDnameObjects1});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDname2Objects1Objects = Hashtable.newFrom({"name2": gdjs.pluginsCode.GDname2Objects1});
gdjs.pluginsCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scroll"), gdjs.pluginsCode.GDscrollObjects2);
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.pluginsCode.GDscrollObjects2.length === 0 ) ? 0 :gdjs.pluginsCode.GDscrollObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) + (gdjs.evtTools.window.getWindowInnerHeight() / 2), "store", 0);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scrolb"), gdjs.pluginsCode.GDscrolbObjects2);
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.pluginsCode.GDscrolbObjects2.length === 0 ) ? 0 :gdjs.pluginsCode.GDscrolbObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) + (gdjs.evtTools.window.getWindowInnerHeight() / 2), "", 0);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scrol"), gdjs.pluginsCode.GDscrolObjects2);
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.pluginsCode.GDscrolObjects2.length === 0 ) ? 0 :gdjs.pluginsCode.GDscrolObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) + (gdjs.evtTools.window.getWindowInnerHeight() / 2), "store", 0);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scroll"), gdjs.pluginsCode.GDscrollObjects2);
{for(var i = 0, len = gdjs.pluginsCode.GDscrollObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDscrollObjects2[i].SetMaxValue(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1)) * 32, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.pluginsCode.GDscrollObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDscrollObjects2[i].SetStepSize(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scrolb"), gdjs.pluginsCode.GDscrolbObjects2);
{for(var i = 0, len = gdjs.pluginsCode.GDscrolbObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDscrolbObjects2[i].SetMaxValue(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins")) * 32, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.pluginsCode.GDscrolbObjects2.length ;i < len;++i) {
    gdjs.pluginsCode.GDscrolbObjects2[i].SetStepSize(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scrol"), gdjs.pluginsCode.GDscrolObjects1);
{for(var i = 0, len = gdjs.pluginsCode.GDscrolObjects1.length ;i < len;++i) {
    gdjs.pluginsCode.GDscrolObjects1[i].SetMaxValue(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins")) * 32, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.pluginsCode.GDscrolObjects1.length ;i < len;++i) {
    gdjs.pluginsCode.GDscrolObjects1[i].SetStepSize(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDplugSettingObjects4Objects = Hashtable.newFrom({"plugSetting": gdjs.pluginsCode.GDplugSettingObjects4});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDpropertyObjects5Objects = Hashtable.newFrom({"property": gdjs.pluginsCode.GDpropertyObjects5});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDboolObjects6Objects = Hashtable.newFrom({"bool": gdjs.pluginsCode.GDboolObjects6});
gdjs.pluginsCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("true").getAsBoolean();
}
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDboolObjects6 */
{for(var i = 0, len = gdjs.pluginsCode.GDboolObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDboolObjects6[i].SetChecked(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDnumObjects6Objects = Hashtable.newFrom({"num": gdjs.pluginsCode.GDnumObjects6});
gdjs.pluginsCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDstrObjects6Objects = Hashtable.newFrom({"str": gdjs.pluginsCode.GDstrObjects6});
gdjs.pluginsCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.pluginsCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("type").getAsString() == "bool");
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.pluginsCode.GDpropertyObjects5, gdjs.pluginsCode.GDpropertyObjects6);

gdjs.copyArray(gdjs.pluginsCode.GDboolObjects4, gdjs.pluginsCode.GDboolObjects6);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDboolObjects6Objects, 1300 + (( gdjs.pluginsCode.GDpropertyObjects6.length === 0 ) ? 0 :gdjs.pluginsCode.GDpropertyObjects6[0].getWidth()) + 20, 100 + ((gdjs.pluginsCode.localVariables[0].getFromIndex(0).getAsNumber() - 1) * 32), "");
}{for(var i = 0, len = gdjs.pluginsCode.GDboolObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDboolObjects6[i].returnVariable(gdjs.pluginsCode.GDboolObjects6[i].getVariables().getFromIndex(1)).setString(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDboolObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDboolObjects6[i].returnVariable(gdjs.pluginsCode.GDboolObjects6[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString());
}
}
{ //Subevents
gdjs.pluginsCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("type").getAsString() == "num_input");
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.pluginsCode.GDpropertyObjects5, gdjs.pluginsCode.GDpropertyObjects6);

gdjs.copyArray(gdjs.pluginsCode.GDnumObjects4, gdjs.pluginsCode.GDnumObjects6);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDnumObjects6Objects, 1300 + (( gdjs.pluginsCode.GDpropertyObjects6.length === 0 ) ? 0 :gdjs.pluginsCode.GDpropertyObjects6[0].getWidth()) + 20, 100 + ((gdjs.pluginsCode.localVariables[0].getFromIndex(0).getAsNumber() - 1) * 32), "");
}{for(var i = 0, len = gdjs.pluginsCode.GDnumObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDnumObjects6[i].returnVariable(gdjs.pluginsCode.GDnumObjects6[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDnumObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDnumObjects6[i].returnVariable(gdjs.pluginsCode.GDnumObjects6[i].getVariables().getFromIndex(1)).setString(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDnumObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDnumObjects6[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("value").getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDnumObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDnumObjects6[i].returnVariable(gdjs.pluginsCode.GDnumObjects6[i].getVariables().getFromIndex(2)).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("max").getAsNumber());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDnumObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDnumObjects6[i].returnVariable(gdjs.pluginsCode.GDnumObjects6[i].getVariables().getFromIndex(3)).setNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("min").getAsNumber());
}
}
{ //Subevents
gdjs.pluginsCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("type").getAsString() == "str_input");
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.pluginsCode.GDpropertyObjects5, gdjs.pluginsCode.GDpropertyObjects6);

gdjs.copyArray(gdjs.pluginsCode.GDstrObjects4, gdjs.pluginsCode.GDstrObjects6);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDstrObjects6Objects, 1300 + (( gdjs.pluginsCode.GDpropertyObjects6.length === 0 ) ? 0 :gdjs.pluginsCode.GDpropertyObjects6[0].getWidth()) + 20, 100 + ((gdjs.pluginsCode.localVariables[0].getFromIndex(0).getAsNumber() - 1) * 32), "");
}{for(var i = 0, len = gdjs.pluginsCode.GDstrObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDstrObjects6[i].returnVariable(gdjs.pluginsCode.GDstrObjects6[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDstrObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDstrObjects6[i].returnVariable(gdjs.pluginsCode.GDstrObjects6[i].getVariables().getFromIndex(1)).setString(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString());
}
}{for(var i = 0, len = gdjs.pluginsCode.GDstrObjects6.length ;i < len;++i) {
    gdjs.pluginsCode.GDstrObjects6[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("value").getAsString());
}
}
{ //Subevents
gdjs.pluginsCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.pluginsCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


const keyIteratorReference5 = runtimeScene.getScene().getVariables().getFromIndex(10);
const valueIteratorReference5 = runtimeScene.getScene().getVariables().get("gp");
const iterableReference5 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings");
if(!iterableReference5.isPrimitive()) {
for(
    const iteratorKey5 in 
    iterableReference5.getType() === "structure"
      ? iterableReference5.getAllChildren()
      : iterableReference5.getType() === "array"
        ? iterableReference5.getAllChildrenArray()
        : []
) {
    if(iterableReference5.getType() === "structure")
        keyIteratorReference5.setString(iteratorKey5);
    else if(iterableReference5.getType() === "array")
        keyIteratorReference5.setNumber(iteratorKey5);
    const structureChildVariable5 = iterableReference5.getChild(iteratorKey5)
    valueIteratorReference5.castTo(structureChildVariable5.getType())
    if(structureChildVariable5.isPrimitive()) {
        valueIteratorReference5.setValue(structureChildVariable5.getValue());
    } else if (structureChildVariable5.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference5.replaceChildren(structureChildVariable5.getAllChildren());
    } else if (structureChildVariable5.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference5.replaceChildrenArray(structureChildVariable5.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(gdjs.pluginsCode.GDpropertyObjects4, gdjs.pluginsCode.GDpropertyObjects5);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDpropertyObjects5Objects, 1300, 100 + (gdjs.pluginsCode.localVariables[0].getFromIndex(0).getAsNumber() * 32), "");
}{for(var i = 0, len = gdjs.pluginsCode.GDpropertyObjects5.length ;i < len;++i) {
    gdjs.pluginsCode.GDpropertyObjects5[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(runtimeScene.getScene().getVariables().getFromIndex(10).getAsString()).getChild("text").getAsString());
}
}{gdjs.pluginsCode.localVariables[0].getFromIndex(0).add(1);
}
{ //Subevents: 
gdjs.pluginsCode.eventsList12(runtimeScene);} //Subevents end.
}
}
}

}


};gdjs.pluginsCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.pluginsCode.GDplugSettingObjects3, gdjs.pluginsCode.GDplugSettingObjects4);


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("i", variable);
}
gdjs.pluginsCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDplugSettingObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23798044);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("bool"), gdjs.pluginsCode.GDboolObjects4);
gdjs.copyArray(runtimeScene.getObjects("info"), gdjs.pluginsCode.GDinfoObjects4);
gdjs.copyArray(runtimeScene.getObjects("num"), gdjs.pluginsCode.GDnumObjects4);
/* Reuse gdjs.pluginsCode.GDplugSettingObjects4 */
gdjs.copyArray(runtimeScene.getObjects("property"), gdjs.pluginsCode.GDpropertyObjects4);
gdjs.copyArray(runtimeScene.getObjects("str"), gdjs.pluginsCode.GDstrObjects4);
{runtimeScene.getScene().getVariables().getFromIndex(9).setString(((gdjs.pluginsCode.GDplugSettingObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDplugSettingObjects4[0].getVariables()).getFromIndex(1).getAsString());
}{gdjs.evtTools.camera.setCameraX(runtimeScene, 1280 + (1280 / 2), "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, 1280 + (1280 / 2), "ui", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, 1280 + (1280 / 2), "store", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, 1280 + (1280 / 2), "back", 0);
}{for(var i = 0, len = gdjs.pluginsCode.GDpropertyObjects4.length ;i < len;++i) {
    gdjs.pluginsCode.GDpropertyObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.pluginsCode.GDnumObjects4.length ;i < len;++i) {
    gdjs.pluginsCode.GDnumObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.pluginsCode.GDstrObjects4.length ;i < len;++i) {
    gdjs.pluginsCode.GDstrObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.pluginsCode.GDboolObjects4.length ;i < len;++i) {
    gdjs.pluginsCode.GDboolObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.pluginsCode.GDinfoObjects4.length ;i < len;++i) {
    gdjs.pluginsCode.GDinfoObjects4[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString());
}
}
{ //Subevents
gdjs.pluginsCode.eventsList13(runtimeScene);} //End of subevents
}
gdjs.pluginsCode.localVariables.pop();

}


};gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDback2Objects2Objects = Hashtable.newFrom({"back2": gdjs.pluginsCode.GDback2Objects2});
gdjs.pluginsCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.pluginsCode.GDnumObjects3, gdjs.pluginsCode.GDnumObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.pluginsCode.GDnumObjects4.length;i<l;++i) {
    if ( gdjs.pluginsCode.GDnumObjects4[i].isFocused() ) {
        isConditionTrue_0 = true;
        gdjs.pluginsCode.GDnumObjects4[k] = gdjs.pluginsCode.GDnumObjects4[i];
        ++k;
    }
}
gdjs.pluginsCode.GDnumObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? "" :gdjs.pluginsCode.GDnumObjects4[0].getBehavior("Text").getText())) <= ((gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDnumObjects4[0].getVariables()).getFromIndex(2).getAsNumber());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? "" :gdjs.pluginsCode.GDnumObjects4[0].getBehavior("Text").getText())) >= ((gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDnumObjects4[0].getVariables()).getFromIndex(3).getAsNumber());
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDnumObjects4 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(((gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDnumObjects4[0].getVariables()).getFromIndex(0).getAsString()).getChild("value").setNumber(gdjs.evtTools.common.toNumber((( gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? "" :gdjs.pluginsCode.GDnumObjects4[0].getBehavior("Text").getText())));
}}

}


{

gdjs.copyArray(gdjs.pluginsCode.GDnumObjects3, gdjs.pluginsCode.GDnumObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? "" :gdjs.pluginsCode.GDnumObjects4[0].getBehavior("Text").getText())) > ((gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDnumObjects4[0].getVariables()).getFromIndex(2).getAsNumber());
}
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDnumObjects4 */
{for(var i = 0, len = gdjs.pluginsCode.GDnumObjects4.length ;i < len;++i) {
    gdjs.pluginsCode.GDnumObjects4[i].getBehavior("Text").setText(gdjs.pluginsCode.GDnumObjects4[i].getVariables().getFromIndex(2).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(((gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDnumObjects4[0].getVariables()).getFromIndex(0).getAsString()).getChild("value").setNumber(gdjs.evtTools.common.toNumber((( gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? "" :gdjs.pluginsCode.GDnumObjects4[0].getBehavior("Text").getText())));
}}

}


{

gdjs.copyArray(gdjs.pluginsCode.GDnumObjects3, gdjs.pluginsCode.GDnumObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? "" :gdjs.pluginsCode.GDnumObjects4[0].getBehavior("Text").getText())) < ((gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDnumObjects4[0].getVariables()).getFromIndex(3).getAsNumber());
}
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDnumObjects4 */
{for(var i = 0, len = gdjs.pluginsCode.GDnumObjects4.length ;i < len;++i) {
    gdjs.pluginsCode.GDnumObjects4[i].getBehavior("Text").setText(gdjs.pluginsCode.GDnumObjects4[i].getVariables().getFromIndex(3).getAsString());
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(((gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDnumObjects4[0].getVariables()).getFromIndex(0).getAsString()).getChild("value").setNumber(gdjs.evtTools.common.toNumber((( gdjs.pluginsCode.GDnumObjects4.length === 0 ) ? "" :gdjs.pluginsCode.GDnumObjects4[0].getBehavior("Text").getText())));
}}

}


};gdjs.pluginsCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.pluginsCode.GDboolObjects2, gdjs.pluginsCode.GDboolObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.pluginsCode.GDboolObjects3.length;i<l;++i) {
    if ( gdjs.pluginsCode.GDboolObjects3[i].HasJustBeenUnchecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.pluginsCode.GDboolObjects3[k] = gdjs.pluginsCode.GDboolObjects3[i];
        ++k;
    }
}
gdjs.pluginsCode.GDboolObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDboolObjects3 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(((gdjs.pluginsCode.GDboolObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDboolObjects3[0].getVariables()).getFromIndex(0).getAsString()).getChild("true").setBoolean(false);
}}

}


{

gdjs.copyArray(gdjs.pluginsCode.GDboolObjects2, gdjs.pluginsCode.GDboolObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.pluginsCode.GDboolObjects3.length;i<l;++i) {
    if ( gdjs.pluginsCode.GDboolObjects3[i].HasJustBeenChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.pluginsCode.GDboolObjects3[k] = gdjs.pluginsCode.GDboolObjects3[i];
        ++k;
    }
}
gdjs.pluginsCode.GDboolObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDboolObjects3 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("settings").getChild(((gdjs.pluginsCode.GDboolObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDboolObjects3[0].getVariables()).getFromIndex(0).getAsString()).getChild("true").setBoolean(true);
}}

}


};gdjs.pluginsCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("plugSetting"), gdjs.pluginsCode.GDplugSettingObjects2);

for (gdjs.pluginsCode.forEachIndex3 = 0;gdjs.pluginsCode.forEachIndex3 < gdjs.pluginsCode.GDplugSettingObjects2.length;++gdjs.pluginsCode.forEachIndex3) {
gdjs.pluginsCode.GDplugSettingObjects3.length = 0;


gdjs.pluginsCode.forEachTemporary3 = gdjs.pluginsCode.GDplugSettingObjects2[gdjs.pluginsCode.forEachIndex3];
gdjs.pluginsCode.GDplugSettingObjects3.push(gdjs.pluginsCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.pluginsCode.eventsList14(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("back2"), gdjs.pluginsCode.GDback2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDback2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, (1280 / 2), "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (1280 / 2), "ui", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (1280 / 2), "store", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (1280 / 2), "back", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("num"), gdjs.pluginsCode.GDnumObjects2);

for (gdjs.pluginsCode.forEachIndex3 = 0;gdjs.pluginsCode.forEachIndex3 < gdjs.pluginsCode.GDnumObjects2.length;++gdjs.pluginsCode.forEachIndex3) {
gdjs.pluginsCode.GDnumObjects3.length = 0;


gdjs.pluginsCode.forEachTemporary3 = gdjs.pluginsCode.GDnumObjects2[gdjs.pluginsCode.forEachIndex3];
gdjs.pluginsCode.GDnumObjects3.push(gdjs.pluginsCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.pluginsCode.eventsList15(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bool"), gdjs.pluginsCode.GDboolObjects1);

for (gdjs.pluginsCode.forEachIndex2 = 0;gdjs.pluginsCode.forEachIndex2 < gdjs.pluginsCode.GDboolObjects1.length;++gdjs.pluginsCode.forEachIndex2) {
gdjs.pluginsCode.GDboolObjects2.length = 0;


gdjs.pluginsCode.forEachTemporary2 = gdjs.pluginsCode.GDboolObjects1[gdjs.pluginsCode.forEachIndex2];
gdjs.pluginsCode.GDboolObjects2.push(gdjs.pluginsCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.pluginsCode.eventsList16(runtimeScene);} //Subevents end.
}
}

}


};gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDDoubleChevronArrowLeftObjects1Objects = Hashtable.newFrom({"DoubleChevronArrowLeft": gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects1});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDname2Objects1Objects = Hashtable.newFrom({"name2": gdjs.pluginsCode.GDname2Objects1});
gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDRetryObjects1Objects = Hashtable.newFrom({"Retry": gdjs.pluginsCode.GDRetryObjects1});
gdjs.pluginsCode.userFunc0x1159be8 = function GDJSInlineCode(runtimeScene) {
"use strict";
const repo = "Michaelgde/music-sheet";  // Replace with your GitHub username/repository
const path = "plugins";    // Path to the folder in the repository (leave empty for the root)
const branch = "main";               // Branch name (e.g., main, master)
let q = '"'


fetch(`https://api.github.com/repos/${repo}/contents/${path}?ref=${branch}`)
  .then(response => response.json())
  .then(data => {
    if (Array.isArray(data)) {
      // Loop through and log the file names
      data.forEach(file => {
        if (file.type === "file") {
          console.log("File name:", file.name);
        } else if (file.type === "dir") {
          console.log("Directory name:", file.name);
          runtimeScene.getVariables().get("jsonCheck").setString(runtimeScene.getVariables().get("jsonCheck").getAsString()+","+q+file.name+q)
        }
      });

      // Example: Store the list of file names in a GDevelop variable
      const fileNames = data.filter(file => file.type === "file").map(file => file.name);
      const dirNames = data.filter(file => file.type === "dir").map(file => file.name);
      runtimeScene.getVariables().get("datas").fromJSObject(dirNames);
      runtimeScene.getVariables().get("refresh").setString("y")
    } else {
      console.error("Failed to retrieve the directory contents:", data.message);
    }
  })
  .catch(error => {
    console.error("Error fetching directory contents:", error);
  });


};
gdjs.pluginsCode.eventsList18 = function(runtimeScene) {

{


gdjs.pluginsCode.userFunc0x1159be8(runtimeScene);

}


};gdjs.pluginsCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Download"), gdjs.pluginsCode.GDDownloadObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("0");
variable.addChild("test", variable1);
}
variables._declare("s", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\"");
variables._declare("q", variable);
}
gdjs.pluginsCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDDownloadObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23775764);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(7).getAsString()) < 2);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDDownloadObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).setString(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(((gdjs.pluginsCode.GDDownloadObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDDownloadObjects1[0].getVariables()).getFromIndex(0).getAsNumber()).getAsString());
}{gdjs.evtTools.network.jsonToVariableStructure("{" + gdjs.pluginsCode.localVariables[0].getFromIndex(1).getAsString() + runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() + gdjs.pluginsCode.localVariables[0].getFromIndex(1).getAsString() + ":" + gdjs.pluginsCode.localVariables[0].getFromIndex(1).getAsString() + gdjs.pluginsCode.localVariables[0].getFromIndex(1).getAsString() + "}", gdjs.pluginsCode.localVariables[0].getFromIndex(0));
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString()).getChild("script").setString("");
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString()).getChild("enable").setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(8).setString("");
}
{ //Subevents
gdjs.pluginsCode.eventsList0(runtimeScene);} //End of subevents
}
gdjs.pluginsCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.variableChildExists(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins"), "undefined");
if (isConditionTrue_0) {
{gdjs.evtTools.variable.variableRemoveChild(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins"), "undefined");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(7).getAsString()) > 1);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString()).getChild("script").setString(runtimeScene.getScene().getVariables().getFromIndex(7).getAsString());
}
{ //Subevents
gdjs.pluginsCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(8).getAsString()) > 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23782172);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.network.jsonToVariableStructure(runtimeScene.getScene().getVariables().getFromIndex(8).getAsString(), runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString()).getChild("settings"));
}
{ //Subevents
gdjs.pluginsCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23783244);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.pluginsCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfEmptyGDname2Objects) != gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins"));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareWhiteToggle"), gdjs.pluginsCode.GDSquareWhiteToggleObjects1);
gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.pluginsCode.GDname2Objects1);
gdjs.copyArray(runtimeScene.getObjects("plugSetting"), gdjs.pluginsCode.GDplugSettingObjects1);
{for(var i = 0, len = gdjs.pluginsCode.GDname2Objects1.length ;i < len;++i) {
    gdjs.pluginsCode.GDname2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length ;i < len;++i) {
    gdjs.pluginsCode.GDSquareWhiteToggleObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.pluginsCode.GDplugSettingObjects1.length ;i < len;++i) {
    gdjs.pluginsCode.GDplugSettingObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(0);
}
{ //Subevents
gdjs.pluginsCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.pluginsCode.mapOfEmptyGDnameObjects) != gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23790316);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Download"), gdjs.pluginsCode.GDDownloadObjects1);
gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.pluginsCode.GDnameObjects1);
{for(var i = 0, len = gdjs.pluginsCode.GDnameObjects1.length ;i < len;++i) {
    gdjs.pluginsCode.GDnameObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.pluginsCode.GDDownloadObjects1.length ;i < len;++i) {
    gdjs.pluginsCode.GDDownloadObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.pluginsCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SquareWhiteToggle"), gdjs.pluginsCode.GDSquareWhiteToggleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length;i<l;++i) {
    if ( gdjs.pluginsCode.GDSquareWhiteToggleObjects1[i].HasJustBeenChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.pluginsCode.GDSquareWhiteToggleObjects1[k] = gdjs.pluginsCode.GDSquareWhiteToggleObjects1[i];
        ++k;
    }
}
gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDSquareWhiteToggleObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(((gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDSquareWhiteToggleObjects1[0].getVariables()).getFromIndex(1).getAsString()).getChild("enable").setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.pluginsCode.GDnameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDnameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23795172);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDnameObjects1 */
{gdjs.evtTools.window.openURL("https://github.com/Michaelgde/music-sheet/blob/main/plugins/" + (( gdjs.pluginsCode.GDnameObjects1.length === 0 ) ? "" :gdjs.pluginsCode.GDnameObjects1[0].getBehavior("Text").getText()) + "/README.md", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.pluginsCode.GDname2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDname2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23796316);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDname2Objects1 */
{gdjs.evtTools.window.openURL("https://github.com/Michaelgde/music-sheet/blob/main/plugins/" + (( gdjs.pluginsCode.GDname2Objects1.length === 0 ) ? "" :gdjs.pluginsCode.GDname2Objects1[0].getBehavior("Text").getText()) + "/README.md", runtimeScene);
}}

}


{


gdjs.pluginsCode.eventsList8(runtimeScene);
}


{


gdjs.pluginsCode.eventsList17(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("SquareWhiteToggle"), gdjs.pluginsCode.GDSquareWhiteToggleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length;i<l;++i) {
    if ( gdjs.pluginsCode.GDSquareWhiteToggleObjects1[i].HasJustBeenUnchecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.pluginsCode.GDSquareWhiteToggleObjects1[k] = gdjs.pluginsCode.GDSquareWhiteToggleObjects1[i];
        ++k;
    }
}
gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDSquareWhiteToggleObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins").getChild(((gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.pluginsCode.GDSquareWhiteToggleObjects1[0].getVariables()).getFromIndex(1).getAsString()).getChild("enable").setBoolean(false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DoubleChevronArrowLeft"), gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDDoubleChevronArrowLeftObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.pluginsCode.GDname2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDname2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23817572);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.pluginsCode.GDname2Objects1 */
{gdjs.evtTools.variable.variableRemoveChild(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("plugins"), (( gdjs.pluginsCode.GDname2Objects1.length === 0 ) ? "" :gdjs.pluginsCode.GDname2Objects1[0].getBehavior("Text").getText()));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Retry"), gdjs.pluginsCode.GDRetryObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.pluginsCode.mapOfGDgdjs_9546pluginsCode_9546GDRetryObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23818660);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.pluginsCode.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.pluginsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.pluginsCode.GDNewToggleSwitchObjects1.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects2.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects3.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects4.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects5.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects6.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects7.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects2.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects3.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects4.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects5.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects6.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects7.length = 0;
gdjs.pluginsCode.GDnameObjects1.length = 0;
gdjs.pluginsCode.GDnameObjects2.length = 0;
gdjs.pluginsCode.GDnameObjects3.length = 0;
gdjs.pluginsCode.GDnameObjects4.length = 0;
gdjs.pluginsCode.GDnameObjects5.length = 0;
gdjs.pluginsCode.GDnameObjects6.length = 0;
gdjs.pluginsCode.GDnameObjects7.length = 0;
gdjs.pluginsCode.GDDownloadObjects1.length = 0;
gdjs.pluginsCode.GDDownloadObjects2.length = 0;
gdjs.pluginsCode.GDDownloadObjects3.length = 0;
gdjs.pluginsCode.GDDownloadObjects4.length = 0;
gdjs.pluginsCode.GDDownloadObjects5.length = 0;
gdjs.pluginsCode.GDDownloadObjects6.length = 0;
gdjs.pluginsCode.GDDownloadObjects7.length = 0;
gdjs.pluginsCode.GDavailableObjects1.length = 0;
gdjs.pluginsCode.GDavailableObjects2.length = 0;
gdjs.pluginsCode.GDavailableObjects3.length = 0;
gdjs.pluginsCode.GDavailableObjects4.length = 0;
gdjs.pluginsCode.GDavailableObjects5.length = 0;
gdjs.pluginsCode.GDavailableObjects6.length = 0;
gdjs.pluginsCode.GDavailableObjects7.length = 0;
gdjs.pluginsCode.GDname2Objects1.length = 0;
gdjs.pluginsCode.GDname2Objects2.length = 0;
gdjs.pluginsCode.GDname2Objects3.length = 0;
gdjs.pluginsCode.GDname2Objects4.length = 0;
gdjs.pluginsCode.GDname2Objects5.length = 0;
gdjs.pluginsCode.GDname2Objects6.length = 0;
gdjs.pluginsCode.GDname2Objects7.length = 0;
gdjs.pluginsCode.GDstoreObjects1.length = 0;
gdjs.pluginsCode.GDstoreObjects2.length = 0;
gdjs.pluginsCode.GDstoreObjects3.length = 0;
gdjs.pluginsCode.GDstoreObjects4.length = 0;
gdjs.pluginsCode.GDstoreObjects5.length = 0;
gdjs.pluginsCode.GDstoreObjects6.length = 0;
gdjs.pluginsCode.GDstoreObjects7.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects1.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects2.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects3.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects4.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects5.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects6.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects7.length = 0;
gdjs.pluginsCode.GDYoutubeObjects1.length = 0;
gdjs.pluginsCode.GDYoutubeObjects2.length = 0;
gdjs.pluginsCode.GDYoutubeObjects3.length = 0;
gdjs.pluginsCode.GDYoutubeObjects4.length = 0;
gdjs.pluginsCode.GDYoutubeObjects5.length = 0;
gdjs.pluginsCode.GDYoutubeObjects6.length = 0;
gdjs.pluginsCode.GDYoutubeObjects7.length = 0;
gdjs.pluginsCode.GDKoFiObjects1.length = 0;
gdjs.pluginsCode.GDKoFiObjects2.length = 0;
gdjs.pluginsCode.GDKoFiObjects3.length = 0;
gdjs.pluginsCode.GDKoFiObjects4.length = 0;
gdjs.pluginsCode.GDKoFiObjects5.length = 0;
gdjs.pluginsCode.GDKoFiObjects6.length = 0;
gdjs.pluginsCode.GDKoFiObjects7.length = 0;
gdjs.pluginsCode.GDRetryObjects1.length = 0;
gdjs.pluginsCode.GDRetryObjects2.length = 0;
gdjs.pluginsCode.GDRetryObjects3.length = 0;
gdjs.pluginsCode.GDRetryObjects4.length = 0;
gdjs.pluginsCode.GDRetryObjects5.length = 0;
gdjs.pluginsCode.GDRetryObjects6.length = 0;
gdjs.pluginsCode.GDRetryObjects7.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects1.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects2.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects3.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects4.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects5.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects6.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects7.length = 0;
gdjs.pluginsCode.GDbackObjects1.length = 0;
gdjs.pluginsCode.GDbackObjects2.length = 0;
gdjs.pluginsCode.GDbackObjects3.length = 0;
gdjs.pluginsCode.GDbackObjects4.length = 0;
gdjs.pluginsCode.GDbackObjects5.length = 0;
gdjs.pluginsCode.GDbackObjects6.length = 0;
gdjs.pluginsCode.GDbackObjects7.length = 0;
gdjs.pluginsCode.GDscrollObjects1.length = 0;
gdjs.pluginsCode.GDscrollObjects2.length = 0;
gdjs.pluginsCode.GDscrollObjects3.length = 0;
gdjs.pluginsCode.GDscrollObjects4.length = 0;
gdjs.pluginsCode.GDscrollObjects5.length = 0;
gdjs.pluginsCode.GDscrollObjects6.length = 0;
gdjs.pluginsCode.GDscrollObjects7.length = 0;
gdjs.pluginsCode.GDplugSettingObjects1.length = 0;
gdjs.pluginsCode.GDplugSettingObjects2.length = 0;
gdjs.pluginsCode.GDplugSettingObjects3.length = 0;
gdjs.pluginsCode.GDplugSettingObjects4.length = 0;
gdjs.pluginsCode.GDplugSettingObjects5.length = 0;
gdjs.pluginsCode.GDplugSettingObjects6.length = 0;
gdjs.pluginsCode.GDplugSettingObjects7.length = 0;
gdjs.pluginsCode.GDback2Objects1.length = 0;
gdjs.pluginsCode.GDback2Objects2.length = 0;
gdjs.pluginsCode.GDback2Objects3.length = 0;
gdjs.pluginsCode.GDback2Objects4.length = 0;
gdjs.pluginsCode.GDback2Objects5.length = 0;
gdjs.pluginsCode.GDback2Objects6.length = 0;
gdjs.pluginsCode.GDback2Objects7.length = 0;
gdjs.pluginsCode.GDscrolObjects1.length = 0;
gdjs.pluginsCode.GDscrolObjects2.length = 0;
gdjs.pluginsCode.GDscrolObjects3.length = 0;
gdjs.pluginsCode.GDscrolObjects4.length = 0;
gdjs.pluginsCode.GDscrolObjects5.length = 0;
gdjs.pluginsCode.GDscrolObjects6.length = 0;
gdjs.pluginsCode.GDscrolObjects7.length = 0;
gdjs.pluginsCode.GDinfoObjects1.length = 0;
gdjs.pluginsCode.GDinfoObjects2.length = 0;
gdjs.pluginsCode.GDinfoObjects3.length = 0;
gdjs.pluginsCode.GDinfoObjects4.length = 0;
gdjs.pluginsCode.GDinfoObjects5.length = 0;
gdjs.pluginsCode.GDinfoObjects6.length = 0;
gdjs.pluginsCode.GDinfoObjects7.length = 0;
gdjs.pluginsCode.GDpropertyObjects1.length = 0;
gdjs.pluginsCode.GDpropertyObjects2.length = 0;
gdjs.pluginsCode.GDpropertyObjects3.length = 0;
gdjs.pluginsCode.GDpropertyObjects4.length = 0;
gdjs.pluginsCode.GDpropertyObjects5.length = 0;
gdjs.pluginsCode.GDpropertyObjects6.length = 0;
gdjs.pluginsCode.GDpropertyObjects7.length = 0;
gdjs.pluginsCode.GDboolObjects1.length = 0;
gdjs.pluginsCode.GDboolObjects2.length = 0;
gdjs.pluginsCode.GDboolObjects3.length = 0;
gdjs.pluginsCode.GDboolObjects4.length = 0;
gdjs.pluginsCode.GDboolObjects5.length = 0;
gdjs.pluginsCode.GDboolObjects6.length = 0;
gdjs.pluginsCode.GDboolObjects7.length = 0;
gdjs.pluginsCode.GDnumObjects1.length = 0;
gdjs.pluginsCode.GDnumObjects2.length = 0;
gdjs.pluginsCode.GDnumObjects3.length = 0;
gdjs.pluginsCode.GDnumObjects4.length = 0;
gdjs.pluginsCode.GDnumObjects5.length = 0;
gdjs.pluginsCode.GDnumObjects6.length = 0;
gdjs.pluginsCode.GDnumObjects7.length = 0;
gdjs.pluginsCode.GDstrObjects1.length = 0;
gdjs.pluginsCode.GDstrObjects2.length = 0;
gdjs.pluginsCode.GDstrObjects3.length = 0;
gdjs.pluginsCode.GDstrObjects4.length = 0;
gdjs.pluginsCode.GDstrObjects5.length = 0;
gdjs.pluginsCode.GDstrObjects6.length = 0;
gdjs.pluginsCode.GDstrObjects7.length = 0;
gdjs.pluginsCode.GDscrolbObjects1.length = 0;
gdjs.pluginsCode.GDscrolbObjects2.length = 0;
gdjs.pluginsCode.GDscrolbObjects3.length = 0;
gdjs.pluginsCode.GDscrolbObjects4.length = 0;
gdjs.pluginsCode.GDscrolbObjects5.length = 0;
gdjs.pluginsCode.GDscrolbObjects6.length = 0;
gdjs.pluginsCode.GDscrolbObjects7.length = 0;

gdjs.pluginsCode.eventsList19(runtimeScene);
gdjs.pluginsCode.GDNewToggleSwitchObjects1.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects2.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects3.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects4.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects5.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects6.length = 0;
gdjs.pluginsCode.GDNewToggleSwitchObjects7.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects1.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects2.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects3.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects4.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects5.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects6.length = 0;
gdjs.pluginsCode.GDSquareWhiteToggleObjects7.length = 0;
gdjs.pluginsCode.GDnameObjects1.length = 0;
gdjs.pluginsCode.GDnameObjects2.length = 0;
gdjs.pluginsCode.GDnameObjects3.length = 0;
gdjs.pluginsCode.GDnameObjects4.length = 0;
gdjs.pluginsCode.GDnameObjects5.length = 0;
gdjs.pluginsCode.GDnameObjects6.length = 0;
gdjs.pluginsCode.GDnameObjects7.length = 0;
gdjs.pluginsCode.GDDownloadObjects1.length = 0;
gdjs.pluginsCode.GDDownloadObjects2.length = 0;
gdjs.pluginsCode.GDDownloadObjects3.length = 0;
gdjs.pluginsCode.GDDownloadObjects4.length = 0;
gdjs.pluginsCode.GDDownloadObjects5.length = 0;
gdjs.pluginsCode.GDDownloadObjects6.length = 0;
gdjs.pluginsCode.GDDownloadObjects7.length = 0;
gdjs.pluginsCode.GDavailableObjects1.length = 0;
gdjs.pluginsCode.GDavailableObjects2.length = 0;
gdjs.pluginsCode.GDavailableObjects3.length = 0;
gdjs.pluginsCode.GDavailableObjects4.length = 0;
gdjs.pluginsCode.GDavailableObjects5.length = 0;
gdjs.pluginsCode.GDavailableObjects6.length = 0;
gdjs.pluginsCode.GDavailableObjects7.length = 0;
gdjs.pluginsCode.GDname2Objects1.length = 0;
gdjs.pluginsCode.GDname2Objects2.length = 0;
gdjs.pluginsCode.GDname2Objects3.length = 0;
gdjs.pluginsCode.GDname2Objects4.length = 0;
gdjs.pluginsCode.GDname2Objects5.length = 0;
gdjs.pluginsCode.GDname2Objects6.length = 0;
gdjs.pluginsCode.GDname2Objects7.length = 0;
gdjs.pluginsCode.GDstoreObjects1.length = 0;
gdjs.pluginsCode.GDstoreObjects2.length = 0;
gdjs.pluginsCode.GDstoreObjects3.length = 0;
gdjs.pluginsCode.GDstoreObjects4.length = 0;
gdjs.pluginsCode.GDstoreObjects5.length = 0;
gdjs.pluginsCode.GDstoreObjects6.length = 0;
gdjs.pluginsCode.GDstoreObjects7.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects1.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects2.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects3.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects4.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects5.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects6.length = 0;
gdjs.pluginsCode.GDDoubleChevronArrowLeftObjects7.length = 0;
gdjs.pluginsCode.GDYoutubeObjects1.length = 0;
gdjs.pluginsCode.GDYoutubeObjects2.length = 0;
gdjs.pluginsCode.GDYoutubeObjects3.length = 0;
gdjs.pluginsCode.GDYoutubeObjects4.length = 0;
gdjs.pluginsCode.GDYoutubeObjects5.length = 0;
gdjs.pluginsCode.GDYoutubeObjects6.length = 0;
gdjs.pluginsCode.GDYoutubeObjects7.length = 0;
gdjs.pluginsCode.GDKoFiObjects1.length = 0;
gdjs.pluginsCode.GDKoFiObjects2.length = 0;
gdjs.pluginsCode.GDKoFiObjects3.length = 0;
gdjs.pluginsCode.GDKoFiObjects4.length = 0;
gdjs.pluginsCode.GDKoFiObjects5.length = 0;
gdjs.pluginsCode.GDKoFiObjects6.length = 0;
gdjs.pluginsCode.GDKoFiObjects7.length = 0;
gdjs.pluginsCode.GDRetryObjects1.length = 0;
gdjs.pluginsCode.GDRetryObjects2.length = 0;
gdjs.pluginsCode.GDRetryObjects3.length = 0;
gdjs.pluginsCode.GDRetryObjects4.length = 0;
gdjs.pluginsCode.GDRetryObjects5.length = 0;
gdjs.pluginsCode.GDRetryObjects6.length = 0;
gdjs.pluginsCode.GDRetryObjects7.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects1.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects2.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects3.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects4.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects5.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects6.length = 0;
gdjs.pluginsCode.GDNewSpriteObjects7.length = 0;
gdjs.pluginsCode.GDbackObjects1.length = 0;
gdjs.pluginsCode.GDbackObjects2.length = 0;
gdjs.pluginsCode.GDbackObjects3.length = 0;
gdjs.pluginsCode.GDbackObjects4.length = 0;
gdjs.pluginsCode.GDbackObjects5.length = 0;
gdjs.pluginsCode.GDbackObjects6.length = 0;
gdjs.pluginsCode.GDbackObjects7.length = 0;
gdjs.pluginsCode.GDscrollObjects1.length = 0;
gdjs.pluginsCode.GDscrollObjects2.length = 0;
gdjs.pluginsCode.GDscrollObjects3.length = 0;
gdjs.pluginsCode.GDscrollObjects4.length = 0;
gdjs.pluginsCode.GDscrollObjects5.length = 0;
gdjs.pluginsCode.GDscrollObjects6.length = 0;
gdjs.pluginsCode.GDscrollObjects7.length = 0;
gdjs.pluginsCode.GDplugSettingObjects1.length = 0;
gdjs.pluginsCode.GDplugSettingObjects2.length = 0;
gdjs.pluginsCode.GDplugSettingObjects3.length = 0;
gdjs.pluginsCode.GDplugSettingObjects4.length = 0;
gdjs.pluginsCode.GDplugSettingObjects5.length = 0;
gdjs.pluginsCode.GDplugSettingObjects6.length = 0;
gdjs.pluginsCode.GDplugSettingObjects7.length = 0;
gdjs.pluginsCode.GDback2Objects1.length = 0;
gdjs.pluginsCode.GDback2Objects2.length = 0;
gdjs.pluginsCode.GDback2Objects3.length = 0;
gdjs.pluginsCode.GDback2Objects4.length = 0;
gdjs.pluginsCode.GDback2Objects5.length = 0;
gdjs.pluginsCode.GDback2Objects6.length = 0;
gdjs.pluginsCode.GDback2Objects7.length = 0;
gdjs.pluginsCode.GDscrolObjects1.length = 0;
gdjs.pluginsCode.GDscrolObjects2.length = 0;
gdjs.pluginsCode.GDscrolObjects3.length = 0;
gdjs.pluginsCode.GDscrolObjects4.length = 0;
gdjs.pluginsCode.GDscrolObjects5.length = 0;
gdjs.pluginsCode.GDscrolObjects6.length = 0;
gdjs.pluginsCode.GDscrolObjects7.length = 0;
gdjs.pluginsCode.GDinfoObjects1.length = 0;
gdjs.pluginsCode.GDinfoObjects2.length = 0;
gdjs.pluginsCode.GDinfoObjects3.length = 0;
gdjs.pluginsCode.GDinfoObjects4.length = 0;
gdjs.pluginsCode.GDinfoObjects5.length = 0;
gdjs.pluginsCode.GDinfoObjects6.length = 0;
gdjs.pluginsCode.GDinfoObjects7.length = 0;
gdjs.pluginsCode.GDpropertyObjects1.length = 0;
gdjs.pluginsCode.GDpropertyObjects2.length = 0;
gdjs.pluginsCode.GDpropertyObjects3.length = 0;
gdjs.pluginsCode.GDpropertyObjects4.length = 0;
gdjs.pluginsCode.GDpropertyObjects5.length = 0;
gdjs.pluginsCode.GDpropertyObjects6.length = 0;
gdjs.pluginsCode.GDpropertyObjects7.length = 0;
gdjs.pluginsCode.GDboolObjects1.length = 0;
gdjs.pluginsCode.GDboolObjects2.length = 0;
gdjs.pluginsCode.GDboolObjects3.length = 0;
gdjs.pluginsCode.GDboolObjects4.length = 0;
gdjs.pluginsCode.GDboolObjects5.length = 0;
gdjs.pluginsCode.GDboolObjects6.length = 0;
gdjs.pluginsCode.GDboolObjects7.length = 0;
gdjs.pluginsCode.GDnumObjects1.length = 0;
gdjs.pluginsCode.GDnumObjects2.length = 0;
gdjs.pluginsCode.GDnumObjects3.length = 0;
gdjs.pluginsCode.GDnumObjects4.length = 0;
gdjs.pluginsCode.GDnumObjects5.length = 0;
gdjs.pluginsCode.GDnumObjects6.length = 0;
gdjs.pluginsCode.GDnumObjects7.length = 0;
gdjs.pluginsCode.GDstrObjects1.length = 0;
gdjs.pluginsCode.GDstrObjects2.length = 0;
gdjs.pluginsCode.GDstrObjects3.length = 0;
gdjs.pluginsCode.GDstrObjects4.length = 0;
gdjs.pluginsCode.GDstrObjects5.length = 0;
gdjs.pluginsCode.GDstrObjects6.length = 0;
gdjs.pluginsCode.GDstrObjects7.length = 0;
gdjs.pluginsCode.GDscrolbObjects1.length = 0;
gdjs.pluginsCode.GDscrolbObjects2.length = 0;
gdjs.pluginsCode.GDscrolbObjects3.length = 0;
gdjs.pluginsCode.GDscrolbObjects4.length = 0;
gdjs.pluginsCode.GDscrolbObjects5.length = 0;
gdjs.pluginsCode.GDscrolbObjects6.length = 0;
gdjs.pluginsCode.GDscrolbObjects7.length = 0;


return;

}

gdjs['pluginsCode'] = gdjs.pluginsCode;
