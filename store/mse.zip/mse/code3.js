gdjs.audio_95manager_95htmlCode = {};
gdjs.audio_95manager_95htmlCode.localVariables = [];
gdjs.audio_95manager_95htmlCode.forEachIndex2 = 0;

gdjs.audio_95manager_95htmlCode.forEachIndex3 = 0;

gdjs.audio_95manager_95htmlCode.forEachObjects2 = [];

gdjs.audio_95manager_95htmlCode.forEachObjects3 = [];

gdjs.audio_95manager_95htmlCode.forEachTemporary2 = null;

gdjs.audio_95manager_95htmlCode.forEachTemporary3 = null;

gdjs.audio_95manager_95htmlCode.forEachTotalCount2 = 0;

gdjs.audio_95manager_95htmlCode.forEachTotalCount3 = 0;

gdjs.audio_95manager_95htmlCode.GDnameObjects1= [];
gdjs.audio_95manager_95htmlCode.GDnameObjects2= [];
gdjs.audio_95manager_95htmlCode.GDnameObjects3= [];
gdjs.audio_95manager_95htmlCode.GDinfoObjects1= [];
gdjs.audio_95manager_95htmlCode.GDinfoObjects2= [];
gdjs.audio_95manager_95htmlCode.GDinfoObjects3= [];
gdjs.audio_95manager_95htmlCode.GDaddObjects1= [];
gdjs.audio_95manager_95htmlCode.GDaddObjects2= [];
gdjs.audio_95manager_95htmlCode.GDaddObjects3= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects1= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects2= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects3= [];
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects1= [];
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects2= [];
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects3= [];
gdjs.audio_95manager_95htmlCode.GDname2Objects1= [];
gdjs.audio_95manager_95htmlCode.GDname2Objects2= [];
gdjs.audio_95manager_95htmlCode.GDname2Objects3= [];
gdjs.audio_95manager_95htmlCode.GDioiObjects1= [];
gdjs.audio_95manager_95htmlCode.GDioiObjects2= [];
gdjs.audio_95manager_95htmlCode.GDioiObjects3= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects1= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects2= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects3= [];
gdjs.audio_95manager_95htmlCode.GDokObjects1= [];
gdjs.audio_95manager_95htmlCode.GDokObjects2= [];
gdjs.audio_95manager_95htmlCode.GDokObjects3= [];
gdjs.audio_95manager_95htmlCode.GDcancObjects1= [];
gdjs.audio_95manager_95htmlCode.GDcancObjects2= [];
gdjs.audio_95manager_95htmlCode.GDcancObjects3= [];
gdjs.audio_95manager_95htmlCode.GDpaintObjects1= [];
gdjs.audio_95manager_95htmlCode.GDpaintObjects2= [];
gdjs.audio_95manager_95htmlCode.GDpaintObjects3= [];
gdjs.audio_95manager_95htmlCode.GDname3Objects1= [];
gdjs.audio_95manager_95htmlCode.GDname3Objects2= [];
gdjs.audio_95manager_95htmlCode.GDname3Objects3= [];
gdjs.audio_95manager_95htmlCode.GDpanelObjects1= [];
gdjs.audio_95manager_95htmlCode.GDpanelObjects2= [];
gdjs.audio_95manager_95htmlCode.GDpanelObjects3= [];
gdjs.audio_95manager_95htmlCode.GDsprrObjects1= [];
gdjs.audio_95manager_95htmlCode.GDsprrObjects2= [];
gdjs.audio_95manager_95htmlCode.GDsprrObjects3= [];
gdjs.audio_95manager_95htmlCode.GDpanel2Objects1= [];
gdjs.audio_95manager_95htmlCode.GDpanel2Objects2= [];
gdjs.audio_95manager_95htmlCode.GDpanel2Objects3= [];
gdjs.audio_95manager_95htmlCode.GDfkObjects1= [];
gdjs.audio_95manager_95htmlCode.GDfkObjects2= [];
gdjs.audio_95manager_95htmlCode.GDfkObjects3= [];
gdjs.audio_95manager_95htmlCode.GDjjObjects1= [];
gdjs.audio_95manager_95htmlCode.GDjjObjects2= [];
gdjs.audio_95manager_95htmlCode.GDjjObjects3= [];
gdjs.audio_95manager_95htmlCode.GDlogoObjects1= [];
gdjs.audio_95manager_95htmlCode.GDlogoObjects2= [];
gdjs.audio_95manager_95htmlCode.GDlogoObjects3= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects1= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects2= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects3= [];
gdjs.audio_95manager_95htmlCode.GDbackObjects1= [];
gdjs.audio_95manager_95htmlCode.GDbackObjects2= [];
gdjs.audio_95manager_95htmlCode.GDbackObjects3= [];
gdjs.audio_95manager_95htmlCode.GDadd2Objects1= [];
gdjs.audio_95manager_95htmlCode.GDadd2Objects2= [];
gdjs.audio_95manager_95htmlCode.GDadd2Objects3= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects1= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects2= [];
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects3= [];
gdjs.audio_95manager_95htmlCode.GDbeatObjects1= [];
gdjs.audio_95manager_95htmlCode.GDbeatObjects2= [];
gdjs.audio_95manager_95htmlCode.GDbeatObjects3= [];
gdjs.audio_95manager_95htmlCode.GDnameeObjects1= [];
gdjs.audio_95manager_95htmlCode.GDnameeObjects2= [];
gdjs.audio_95manager_95htmlCode.GDnameeObjects3= [];


gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDaddObjects2Objects = Hashtable.newFrom({"add": gdjs.audio_95manager_95htmlCode.GDaddObjects2});
gdjs.audio_95manager_95htmlCode.eventsList0 = function(runtimeScene) {

{



}


};gdjs.audio_95manager_95htmlCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtsExt__load_audio__file_loader.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDadd2Objects2Objects = Hashtable.newFrom({"add2": gdjs.audio_95manager_95htmlCode.GDadd2Objects2});
gdjs.audio_95manager_95htmlCode.eventsList2 = function(runtimeScene) {

{



}


};gdjs.audio_95manager_95htmlCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("subAudio"), gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(1));
}
{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.audio_95manager_95htmlCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.audio_95manager_95htmlCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.audio_95manager_95htmlCode.GDaddObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDaddObjects2Objects, runtimeScene, false, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("add2"), gdjs.audio_95manager_95htmlCode.GDadd2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDadd2Objects2Objects, runtimeScene, false, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


};gdjs.audio_95manager_95htmlCode.mapOfEmptyGDname3Objects = Hashtable.newFrom({"name3": []});
gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDname3Objects2Objects = Hashtable.newFrom({"name3": gdjs.audio_95manager_95htmlCode.GDname3Objects2});
gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDnameeObjects2Objects = Hashtable.newFrom({"namee": gdjs.audio_95manager_95htmlCode.GDnameeObjects2});
gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDioiObjects2Objects = Hashtable.newFrom({"ioi": gdjs.audio_95manager_95htmlCode.GDioiObjects2});
gdjs.audio_95manager_95htmlCode.eventsList6 = function(runtimeScene) {

};gdjs.audio_95manager_95htmlCode.eventsList7 = function(runtimeScene) {

{


const repeatCount2 = runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber();
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(gdjs.audio_95manager_95htmlCode.GDioiObjects1, gdjs.audio_95manager_95htmlCode.GDioiObjects2);

gdjs.copyArray(gdjs.audio_95manager_95htmlCode.GDname3Objects1, gdjs.audio_95manager_95htmlCode.GDname3Objects2);

gdjs.copyArray(gdjs.audio_95manager_95htmlCode.GDnameeObjects1, gdjs.audio_95manager_95htmlCode.GDnameeObjects2);


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDname3Objects2Objects, 5, gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDnameeObjects2Objects, 7, gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDnameeObjects2.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDnameeObjects2[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("subAudio").getChild((gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber() - 64) / 32).getChild("name").getAsString());
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDioiObjects2Objects, 645, gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDname3Objects2.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDname3Objects2[i].returnVariable(gdjs.audio_95manager_95htmlCode.GDname3Objects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber() - 64) / 32);
}
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDnameeObjects2.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDnameeObjects2[i].returnVariable(gdjs.audio_95manager_95htmlCode.GDnameeObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber() - 64) / 32);
}
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDioiObjects2.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDioiObjects2[i].returnVariable(gdjs.audio_95manager_95htmlCode.GDioiObjects2[i].getVariables().getFromIndex(0)).setNumber((gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).getAsNumber() - 64) / 32);
}
}{gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).add(32);
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDnameeObjects2.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDnameeObjects2[i].getBehavior("Resizable").setSize(200, 30);
}
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDioiObjects2.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDioiObjects2[i].getBehavior("Resizable").setSize(30, 30);
}
}}
}

}


};gdjs.audio_95manager_95htmlCode.eventsList8 = function(runtimeScene) {

};gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDioiObjects1Objects = Hashtable.newFrom({"ioi": gdjs.audio_95manager_95htmlCode.GDioiObjects1});
gdjs.audio_95manager_95htmlCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.audio_95manager_95htmlCode.GDioiObjects1, gdjs.audio_95manager_95htmlCode.GDioiObjects2);

{gdjs.evtsExt__load_audio__file_loader_to_subs.func(runtimeScene, ((gdjs.audio_95manager_95htmlCode.GDioiObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.audio_95manager_95htmlCode.GDioiObjects2[0].getVariables()).getFromIndex(0).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23112900);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.audio_95manager_95htmlCode.GDioiObjects1 */
{gdjs.evtTools.variable.variableRemoveAt(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("subAudio"), ((gdjs.audio_95manager_95htmlCode.GDioiObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.audio_95manager_95htmlCode.GDioiObjects1[0].getVariables()).getFromIndex(0).getAsNumber());
}}

}


};gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDname2Objects1Objects = Hashtable.newFrom({"name2": gdjs.audio_95manager_95htmlCode.GDname2Objects1});
gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDokObjects1Objects = Hashtable.newFrom({"ok": gdjs.audio_95manager_95htmlCode.GDokObjects1});
gdjs.audio_95manager_95htmlCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mse_win", false);
}}

}


};gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDcancObjects1Objects = Hashtable.newFrom({"canc": gdjs.audio_95manager_95htmlCode.GDcancObjects1});
gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDpanel2Objects3Objects = Hashtable.newFrom({"panel2": gdjs.audio_95manager_95htmlCode.GDpanel2Objects3});
gdjs.audio_95manager_95htmlCode.eventsList11 = function(runtimeScene) {

};gdjs.audio_95manager_95htmlCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.audio_95manager_95htmlCode.GDname2Objects2);

for (gdjs.audio_95manager_95htmlCode.forEachIndex3 = 0;gdjs.audio_95manager_95htmlCode.forEachIndex3 < gdjs.audio_95manager_95htmlCode.GDname2Objects2.length;++gdjs.audio_95manager_95htmlCode.forEachIndex3) {
gdjs.audio_95manager_95htmlCode.GDpanel2Objects3.length = 0;

gdjs.audio_95manager_95htmlCode.GDname2Objects3.length = 0;


gdjs.audio_95manager_95htmlCode.forEachTemporary3 = gdjs.audio_95manager_95htmlCode.GDname2Objects2[gdjs.audio_95manager_95htmlCode.forEachIndex3];
gdjs.audio_95manager_95htmlCode.GDname2Objects3.push(gdjs.audio_95manager_95htmlCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDpanel2Objects3Objects, (( gdjs.audio_95manager_95htmlCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects3[0].getX()), (( gdjs.audio_95manager_95htmlCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects3[0].getY()), "prompt");
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDpanel2Objects3.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDpanel2Objects3[i].getBehavior("Resizable").setSize((( gdjs.audio_95manager_95htmlCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects3[0].getWidth()), (( gdjs.audio_95manager_95htmlCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects3[0].getHeight()));
}
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDpanel2Objects3.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDpanel2Objects3[i].setZOrder((( gdjs.audio_95manager_95htmlCode.GDname2Objects3.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects3[0].getZOrder()) + 1);
}
}}
}

}


{



}


};gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDbackObjects1Objects = Hashtable.newFrom({"back": gdjs.audio_95manager_95htmlCode.GDbackObjects1});
gdjs.audio_95manager_95htmlCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("add"), gdjs.audio_95manager_95htmlCode.GDaddObjects1);
gdjs.copyArray(runtimeScene.getObjects("add_txt"), gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects1);
{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects1.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects1[i].setCenterPositionInScene((( gdjs.audio_95manager_95htmlCode.GDaddObjects1.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDaddObjects1[0].getCenterXInScene()),(( gdjs.audio_95manager_95htmlCode.GDaddObjects1.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDaddObjects1[0].getCenterYInScene()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("subAudio")));
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("temp", variable);
}
{
const variable = new gdjs.Variable();
{
const variable1 = new gdjs.Variable();
variable1.setString("");
variable.addChild("data", variable1);
}
{
const variable1 = new gdjs.Variable();
variable1.setString("new beat");
variable.addChild("name", variable1);
}
variables._declare("sub", variable);
}
gdjs.audio_95manager_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList5(runtimeScene);} //End of subevents
}
gdjs.audio_95manager_95htmlCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("count", variable);
}
gdjs.audio_95manager_95htmlCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.audio_95manager_95htmlCode.mapOfEmptyGDname3Objects) != runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ioi"), gdjs.audio_95manager_95htmlCode.GDioiObjects1);
gdjs.copyArray(runtimeScene.getObjects("name3"), gdjs.audio_95manager_95htmlCode.GDname3Objects1);
gdjs.copyArray(runtimeScene.getObjects("namee"), gdjs.audio_95manager_95htmlCode.GDnameeObjects1);
{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDname3Objects1.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDname3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDnameeObjects1.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDnameeObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDioiObjects1.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDioiObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.audio_95manager_95htmlCode.localVariables[0].getFromIndex(0).setNumber(64);
}
{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList7(runtimeScene);} //End of subevents
}
gdjs.audio_95manager_95htmlCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("namee"), gdjs.audio_95manager_95htmlCode.GDnameeObjects1);

for (gdjs.audio_95manager_95htmlCode.forEachIndex2 = 0;gdjs.audio_95manager_95htmlCode.forEachIndex2 < gdjs.audio_95manager_95htmlCode.GDnameeObjects1.length;++gdjs.audio_95manager_95htmlCode.forEachIndex2) {
gdjs.audio_95manager_95htmlCode.GDnameeObjects2.length = 0;


gdjs.audio_95manager_95htmlCode.forEachTemporary2 = gdjs.audio_95manager_95htmlCode.GDnameeObjects1[gdjs.audio_95manager_95htmlCode.forEachIndex2];
gdjs.audio_95manager_95htmlCode.GDnameeObjects2.push(gdjs.audio_95manager_95htmlCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("subAudio").getChild(((gdjs.audio_95manager_95htmlCode.GDnameeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.audio_95manager_95htmlCode.GDnameeObjects2[0].getVariables()).getFromIndex(0).getAsNumber()).getChild("name").setString((( gdjs.audio_95manager_95htmlCode.GDnameeObjects2.length === 0 ) ? "" :gdjs.audio_95manager_95htmlCode.GDnameeObjects2[0].getBehavior("Text").getText()));
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ioi"), gdjs.audio_95manager_95htmlCode.GDioiObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDioiObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("name2"), gdjs.audio_95manager_95htmlCode.GDname2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDname2Objects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
/* Reuse gdjs.audio_95manager_95htmlCode.GDname2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("paint"), gdjs.audio_95manager_95htmlCode.GDpaintObjects1);
{for(var i = 0, len = gdjs.audio_95manager_95htmlCode.GDpaintObjects1.length ;i < len;++i) {
    gdjs.audio_95manager_95htmlCode.GDpaintObjects1[i].drawRectangle((( gdjs.audio_95manager_95htmlCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects1[0].getX()), (( gdjs.audio_95manager_95htmlCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects1[0].getY()), (( gdjs.audio_95manager_95htmlCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects1[0].getX()) + (( gdjs.audio_95manager_95htmlCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects1[0].getWidth()), (( gdjs.audio_95manager_95htmlCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects1[0].getY()) + (( gdjs.audio_95manager_95htmlCode.GDname2Objects1.length === 0 ) ? 0 :gdjs.audio_95manager_95htmlCode.GDname2Objects1[0].getHeight()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ok"), gdjs.audio_95manager_95htmlCode.GDokObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDokObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("canc"), gdjs.audio_95manager_95htmlCode.GDcancObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDcancObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "audio_manager_html", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString()) > 20);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "prompt");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95manager_95htmlCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("back"), gdjs.audio_95manager_95htmlCode.GDbackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95manager_95htmlCode.mapOfGDgdjs_9546audio_959595manager_959595htmlCode_9546GDbackObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "prompt"));
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mse_html", false);
}}

}


};

gdjs.audio_95manager_95htmlCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.audio_95manager_95htmlCode.GDnameObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDinfoObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDinfoObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDinfoObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDaddObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDaddObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDaddObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDname2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDname2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDname2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDioiObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDioiObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDioiObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDokObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDokObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDokObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDcancObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDcancObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDcancObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDpaintObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDpaintObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDpaintObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDname3Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDname3Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDname3Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanelObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanelObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanelObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDsprrObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDsprrObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDsprrObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanel2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanel2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanel2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDfkObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDfkObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDfkObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDjjObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDjjObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDjjObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDlogoObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDlogoObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDlogoObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDbackObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDbackObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDbackObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDbeatObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDbeatObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDbeatObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameeObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameeObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameeObjects3.length = 0;

gdjs.audio_95manager_95htmlCode.eventsList13(runtimeScene);
gdjs.audio_95manager_95htmlCode.GDnameObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDinfoObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDinfoObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDinfoObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDaddObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDaddObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDaddObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txtObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDsave_9595iconObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDname2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDname2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDname2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDioiObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDioiObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDioiObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eveObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDokObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDokObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDokObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDcancObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDcancObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDcancObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDpaintObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDpaintObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDpaintObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDname3Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDname3Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDname3Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanelObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanelObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanelObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDsprrObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDsprrObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDsprrObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanel2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanel2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDpanel2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDfkObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDfkObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDfkObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDjjObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDjjObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDjjObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDlogoObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDlogoObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDlogoObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595eve2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDbackObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDbackObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDbackObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDadd_9595txt2Objects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDbeatObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDbeatObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDbeatObjects3.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameeObjects1.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameeObjects2.length = 0;
gdjs.audio_95manager_95htmlCode.GDnameeObjects3.length = 0;


return;

}

gdjs['audio_95manager_95htmlCode'] = gdjs.audio_95manager_95htmlCode;
