gdjs.lvlEDITCode = {};
gdjs.lvlEDITCode.localVariables = [];
gdjs.lvlEDITCode.GDaddOBJsObjects2_1final = [];

gdjs.lvlEDITCode.GDaddOBJtObjects2_1final = [];

gdjs.lvlEDITCode.forEachIndex4 = 0;

gdjs.lvlEDITCode.forEachIndex6 = 0;

gdjs.lvlEDITCode.forEachObjects4 = [];

gdjs.lvlEDITCode.forEachObjects6 = [];

gdjs.lvlEDITCode.forEachTemporary4 = null;

gdjs.lvlEDITCode.forEachTemporary6 = null;

gdjs.lvlEDITCode.forEachTotalCount4 = 0;

gdjs.lvlEDITCode.forEachTotalCount6 = 0;

gdjs.lvlEDITCode.GDspriteObjects1= [];
gdjs.lvlEDITCode.GDspriteObjects2= [];
gdjs.lvlEDITCode.GDspriteObjects3= [];
gdjs.lvlEDITCode.GDspriteObjects4= [];
gdjs.lvlEDITCode.GDspriteObjects5= [];
gdjs.lvlEDITCode.GDspriteObjects6= [];
gdjs.lvlEDITCode.GDspriteObjects7= [];
gdjs.lvlEDITCode.GDspriteObjects8= [];
gdjs.lvlEDITCode.GDTiledSpriteObjects1= [];
gdjs.lvlEDITCode.GDTiledSpriteObjects2= [];
gdjs.lvlEDITCode.GDTiledSpriteObjects3= [];
gdjs.lvlEDITCode.GDTiledSpriteObjects4= [];
gdjs.lvlEDITCode.GDTiledSpriteObjects5= [];
gdjs.lvlEDITCode.GDTiledSpriteObjects6= [];
gdjs.lvlEDITCode.GDTiledSpriteObjects7= [];
gdjs.lvlEDITCode.GDTiledSpriteObjects8= [];
gdjs.lvlEDITCode.GDdragCornerULObjects1= [];
gdjs.lvlEDITCode.GDdragCornerULObjects2= [];
gdjs.lvlEDITCode.GDdragCornerULObjects3= [];
gdjs.lvlEDITCode.GDdragCornerULObjects4= [];
gdjs.lvlEDITCode.GDdragCornerULObjects5= [];
gdjs.lvlEDITCode.GDdragCornerULObjects6= [];
gdjs.lvlEDITCode.GDdragCornerULObjects7= [];
gdjs.lvlEDITCode.GDdragCornerULObjects8= [];
gdjs.lvlEDITCode.GDdragCornerURObjects1= [];
gdjs.lvlEDITCode.GDdragCornerURObjects2= [];
gdjs.lvlEDITCode.GDdragCornerURObjects3= [];
gdjs.lvlEDITCode.GDdragCornerURObjects4= [];
gdjs.lvlEDITCode.GDdragCornerURObjects5= [];
gdjs.lvlEDITCode.GDdragCornerURObjects6= [];
gdjs.lvlEDITCode.GDdragCornerURObjects7= [];
gdjs.lvlEDITCode.GDdragCornerURObjects8= [];
gdjs.lvlEDITCode.GDdragCornerDRObjects1= [];
gdjs.lvlEDITCode.GDdragCornerDRObjects2= [];
gdjs.lvlEDITCode.GDdragCornerDRObjects3= [];
gdjs.lvlEDITCode.GDdragCornerDRObjects4= [];
gdjs.lvlEDITCode.GDdragCornerDRObjects5= [];
gdjs.lvlEDITCode.GDdragCornerDRObjects6= [];
gdjs.lvlEDITCode.GDdragCornerDRObjects7= [];
gdjs.lvlEDITCode.GDdragCornerDRObjects8= [];
gdjs.lvlEDITCode.GDdragCornerDLObjects1= [];
gdjs.lvlEDITCode.GDdragCornerDLObjects2= [];
gdjs.lvlEDITCode.GDdragCornerDLObjects3= [];
gdjs.lvlEDITCode.GDdragCornerDLObjects4= [];
gdjs.lvlEDITCode.GDdragCornerDLObjects5= [];
gdjs.lvlEDITCode.GDdragCornerDLObjects6= [];
gdjs.lvlEDITCode.GDdragCornerDLObjects7= [];
gdjs.lvlEDITCode.GDdragCornerDLObjects8= [];
gdjs.lvlEDITCode.GDleftObjects1= [];
gdjs.lvlEDITCode.GDleftObjects2= [];
gdjs.lvlEDITCode.GDleftObjects3= [];
gdjs.lvlEDITCode.GDleftObjects4= [];
gdjs.lvlEDITCode.GDleftObjects5= [];
gdjs.lvlEDITCode.GDleftObjects6= [];
gdjs.lvlEDITCode.GDleftObjects7= [];
gdjs.lvlEDITCode.GDleftObjects8= [];
gdjs.lvlEDITCode.GDrightObjects1= [];
gdjs.lvlEDITCode.GDrightObjects2= [];
gdjs.lvlEDITCode.GDrightObjects3= [];
gdjs.lvlEDITCode.GDrightObjects4= [];
gdjs.lvlEDITCode.GDrightObjects5= [];
gdjs.lvlEDITCode.GDrightObjects6= [];
gdjs.lvlEDITCode.GDrightObjects7= [];
gdjs.lvlEDITCode.GDrightObjects8= [];
gdjs.lvlEDITCode.GDupObjects1= [];
gdjs.lvlEDITCode.GDupObjects2= [];
gdjs.lvlEDITCode.GDupObjects3= [];
gdjs.lvlEDITCode.GDupObjects4= [];
gdjs.lvlEDITCode.GDupObjects5= [];
gdjs.lvlEDITCode.GDupObjects6= [];
gdjs.lvlEDITCode.GDupObjects7= [];
gdjs.lvlEDITCode.GDupObjects8= [];
gdjs.lvlEDITCode.GDdownObjects1= [];
gdjs.lvlEDITCode.GDdownObjects2= [];
gdjs.lvlEDITCode.GDdownObjects3= [];
gdjs.lvlEDITCode.GDdownObjects4= [];
gdjs.lvlEDITCode.GDdownObjects5= [];
gdjs.lvlEDITCode.GDdownObjects6= [];
gdjs.lvlEDITCode.GDdownObjects7= [];
gdjs.lvlEDITCode.GDdownObjects8= [];
gdjs.lvlEDITCode.GDrbObjects1= [];
gdjs.lvlEDITCode.GDrbObjects2= [];
gdjs.lvlEDITCode.GDrbObjects3= [];
gdjs.lvlEDITCode.GDrbObjects4= [];
gdjs.lvlEDITCode.GDrbObjects5= [];
gdjs.lvlEDITCode.GDrbObjects6= [];
gdjs.lvlEDITCode.GDrbObjects7= [];
gdjs.lvlEDITCode.GDrbObjects8= [];
gdjs.lvlEDITCode.GDNewSpriteObjects1= [];
gdjs.lvlEDITCode.GDNewSpriteObjects2= [];
gdjs.lvlEDITCode.GDNewSpriteObjects3= [];
gdjs.lvlEDITCode.GDNewSpriteObjects4= [];
gdjs.lvlEDITCode.GDNewSpriteObjects5= [];
gdjs.lvlEDITCode.GDNewSpriteObjects6= [];
gdjs.lvlEDITCode.GDNewSpriteObjects7= [];
gdjs.lvlEDITCode.GDNewSpriteObjects8= [];
gdjs.lvlEDITCode.GDaddOBJbuttonObjects1= [];
gdjs.lvlEDITCode.GDaddOBJbuttonObjects2= [];
gdjs.lvlEDITCode.GDaddOBJbuttonObjects3= [];
gdjs.lvlEDITCode.GDaddOBJbuttonObjects4= [];
gdjs.lvlEDITCode.GDaddOBJbuttonObjects5= [];
gdjs.lvlEDITCode.GDaddOBJbuttonObjects6= [];
gdjs.lvlEDITCode.GDaddOBJbuttonObjects7= [];
gdjs.lvlEDITCode.GDaddOBJbuttonObjects8= [];
gdjs.lvlEDITCode.GDNewSprite2Objects1= [];
gdjs.lvlEDITCode.GDNewSprite2Objects2= [];
gdjs.lvlEDITCode.GDNewSprite2Objects3= [];
gdjs.lvlEDITCode.GDNewSprite2Objects4= [];
gdjs.lvlEDITCode.GDNewSprite2Objects5= [];
gdjs.lvlEDITCode.GDNewSprite2Objects6= [];
gdjs.lvlEDITCode.GDNewSprite2Objects7= [];
gdjs.lvlEDITCode.GDNewSprite2Objects8= [];
gdjs.lvlEDITCode.GDgridObjects1= [];
gdjs.lvlEDITCode.GDgridObjects2= [];
gdjs.lvlEDITCode.GDgridObjects3= [];
gdjs.lvlEDITCode.GDgridObjects4= [];
gdjs.lvlEDITCode.GDgridObjects5= [];
gdjs.lvlEDITCode.GDgridObjects6= [];
gdjs.lvlEDITCode.GDgridObjects7= [];
gdjs.lvlEDITCode.GDgridObjects8= [];
gdjs.lvlEDITCode.GDpaintObjects1= [];
gdjs.lvlEDITCode.GDpaintObjects2= [];
gdjs.lvlEDITCode.GDpaintObjects3= [];
gdjs.lvlEDITCode.GDpaintObjects4= [];
gdjs.lvlEDITCode.GDpaintObjects5= [];
gdjs.lvlEDITCode.GDpaintObjects6= [];
gdjs.lvlEDITCode.GDpaintObjects7= [];
gdjs.lvlEDITCode.GDpaintObjects8= [];
gdjs.lvlEDITCode.GDspriObjects1= [];
gdjs.lvlEDITCode.GDspriObjects2= [];
gdjs.lvlEDITCode.GDspriObjects3= [];
gdjs.lvlEDITCode.GDspriObjects4= [];
gdjs.lvlEDITCode.GDspriObjects5= [];
gdjs.lvlEDITCode.GDspriObjects6= [];
gdjs.lvlEDITCode.GDspriObjects7= [];
gdjs.lvlEDITCode.GDspriObjects8= [];
gdjs.lvlEDITCode.GDtileObjects1= [];
gdjs.lvlEDITCode.GDtileObjects2= [];
gdjs.lvlEDITCode.GDtileObjects3= [];
gdjs.lvlEDITCode.GDtileObjects4= [];
gdjs.lvlEDITCode.GDtileObjects5= [];
gdjs.lvlEDITCode.GDtileObjects6= [];
gdjs.lvlEDITCode.GDtileObjects7= [];
gdjs.lvlEDITCode.GDtileObjects8= [];
gdjs.lvlEDITCode.GDaddOBJtObjects1= [];
gdjs.lvlEDITCode.GDaddOBJtObjects2= [];
gdjs.lvlEDITCode.GDaddOBJtObjects3= [];
gdjs.lvlEDITCode.GDaddOBJtObjects4= [];
gdjs.lvlEDITCode.GDaddOBJtObjects5= [];
gdjs.lvlEDITCode.GDaddOBJtObjects6= [];
gdjs.lvlEDITCode.GDaddOBJtObjects7= [];
gdjs.lvlEDITCode.GDaddOBJtObjects8= [];
gdjs.lvlEDITCode.GDaddOBJsObjects1= [];
gdjs.lvlEDITCode.GDaddOBJsObjects2= [];
gdjs.lvlEDITCode.GDaddOBJsObjects3= [];
gdjs.lvlEDITCode.GDaddOBJsObjects4= [];
gdjs.lvlEDITCode.GDaddOBJsObjects5= [];
gdjs.lvlEDITCode.GDaddOBJsObjects6= [];
gdjs.lvlEDITCode.GDaddOBJsObjects7= [];
gdjs.lvlEDITCode.GDaddOBJsObjects8= [];
gdjs.lvlEDITCode.GDNewTextObjects1= [];
gdjs.lvlEDITCode.GDNewTextObjects2= [];
gdjs.lvlEDITCode.GDNewTextObjects3= [];
gdjs.lvlEDITCode.GDNewTextObjects4= [];
gdjs.lvlEDITCode.GDNewTextObjects5= [];
gdjs.lvlEDITCode.GDNewTextObjects6= [];
gdjs.lvlEDITCode.GDNewTextObjects7= [];
gdjs.lvlEDITCode.GDNewTextObjects8= [];
gdjs.lvlEDITCode.GDNewText2Objects1= [];
gdjs.lvlEDITCode.GDNewText2Objects2= [];
gdjs.lvlEDITCode.GDNewText2Objects3= [];
gdjs.lvlEDITCode.GDNewText2Objects4= [];
gdjs.lvlEDITCode.GDNewText2Objects5= [];
gdjs.lvlEDITCode.GDNewText2Objects6= [];
gdjs.lvlEDITCode.GDNewText2Objects7= [];
gdjs.lvlEDITCode.GDNewText2Objects8= [];
gdjs.lvlEDITCode.GDnameInputObjects1= [];
gdjs.lvlEDITCode.GDnameInputObjects2= [];
gdjs.lvlEDITCode.GDnameInputObjects3= [];
gdjs.lvlEDITCode.GDnameInputObjects4= [];
gdjs.lvlEDITCode.GDnameInputObjects5= [];
gdjs.lvlEDITCode.GDnameInputObjects6= [];
gdjs.lvlEDITCode.GDnameInputObjects7= [];
gdjs.lvlEDITCode.GDnameInputObjects8= [];
gdjs.lvlEDITCode.GDNewText3Objects1= [];
gdjs.lvlEDITCode.GDNewText3Objects2= [];
gdjs.lvlEDITCode.GDNewText3Objects3= [];
gdjs.lvlEDITCode.GDNewText3Objects4= [];
gdjs.lvlEDITCode.GDNewText3Objects5= [];
gdjs.lvlEDITCode.GDNewText3Objects6= [];
gdjs.lvlEDITCode.GDNewText3Objects7= [];
gdjs.lvlEDITCode.GDNewText3Objects8= [];
gdjs.lvlEDITCode.GDreObjects1= [];
gdjs.lvlEDITCode.GDreObjects2= [];
gdjs.lvlEDITCode.GDreObjects3= [];
gdjs.lvlEDITCode.GDreObjects4= [];
gdjs.lvlEDITCode.GDreObjects5= [];
gdjs.lvlEDITCode.GDreObjects6= [];
gdjs.lvlEDITCode.GDreObjects7= [];
gdjs.lvlEDITCode.GDreObjects8= [];
gdjs.lvlEDITCode.GDunknownObjects1= [];
gdjs.lvlEDITCode.GDunknownObjects2= [];
gdjs.lvlEDITCode.GDunknownObjects3= [];
gdjs.lvlEDITCode.GDunknownObjects4= [];
gdjs.lvlEDITCode.GDunknownObjects5= [];
gdjs.lvlEDITCode.GDunknownObjects6= [];
gdjs.lvlEDITCode.GDunknownObjects7= [];
gdjs.lvlEDITCode.GDunknownObjects8= [];
gdjs.lvlEDITCode.GDinObjects1= [];
gdjs.lvlEDITCode.GDinObjects2= [];
gdjs.lvlEDITCode.GDinObjects3= [];
gdjs.lvlEDITCode.GDinObjects4= [];
gdjs.lvlEDITCode.GDinObjects5= [];
gdjs.lvlEDITCode.GDinObjects6= [];
gdjs.lvlEDITCode.GDinObjects7= [];
gdjs.lvlEDITCode.GDinObjects8= [];
gdjs.lvlEDITCode.GDobjDObjects1= [];
gdjs.lvlEDITCode.GDobjDObjects2= [];
gdjs.lvlEDITCode.GDobjDObjects3= [];
gdjs.lvlEDITCode.GDobjDObjects4= [];
gdjs.lvlEDITCode.GDobjDObjects5= [];
gdjs.lvlEDITCode.GDobjDObjects6= [];
gdjs.lvlEDITCode.GDobjDObjects7= [];
gdjs.lvlEDITCode.GDobjDObjects8= [];
gdjs.lvlEDITCode.GDobjNDObjects1= [];
gdjs.lvlEDITCode.GDobjNDObjects2= [];
gdjs.lvlEDITCode.GDobjNDObjects3= [];
gdjs.lvlEDITCode.GDobjNDObjects4= [];
gdjs.lvlEDITCode.GDobjNDObjects5= [];
gdjs.lvlEDITCode.GDobjNDObjects6= [];
gdjs.lvlEDITCode.GDobjNDObjects7= [];
gdjs.lvlEDITCode.GDobjNDObjects8= [];
gdjs.lvlEDITCode.GDaddTxtObjects1= [];
gdjs.lvlEDITCode.GDaddTxtObjects2= [];
gdjs.lvlEDITCode.GDaddTxtObjects3= [];
gdjs.lvlEDITCode.GDaddTxtObjects4= [];
gdjs.lvlEDITCode.GDaddTxtObjects5= [];
gdjs.lvlEDITCode.GDaddTxtObjects6= [];
gdjs.lvlEDITCode.GDaddTxtObjects7= [];
gdjs.lvlEDITCode.GDaddTxtObjects8= [];
gdjs.lvlEDITCode.GDdummyObjects1= [];
gdjs.lvlEDITCode.GDdummyObjects2= [];
gdjs.lvlEDITCode.GDdummyObjects3= [];
gdjs.lvlEDITCode.GDdummyObjects4= [];
gdjs.lvlEDITCode.GDdummyObjects5= [];
gdjs.lvlEDITCode.GDdummyObjects6= [];
gdjs.lvlEDITCode.GDdummyObjects7= [];
gdjs.lvlEDITCode.GDdummyObjects8= [];
gdjs.lvlEDITCode.GDgridWObjects1= [];
gdjs.lvlEDITCode.GDgridWObjects2= [];
gdjs.lvlEDITCode.GDgridWObjects3= [];
gdjs.lvlEDITCode.GDgridWObjects4= [];
gdjs.lvlEDITCode.GDgridWObjects5= [];
gdjs.lvlEDITCode.GDgridWObjects6= [];
gdjs.lvlEDITCode.GDgridWObjects7= [];
gdjs.lvlEDITCode.GDgridWObjects8= [];
gdjs.lvlEDITCode.GDsprite2Objects1= [];
gdjs.lvlEDITCode.GDsprite2Objects2= [];
gdjs.lvlEDITCode.GDsprite2Objects3= [];
gdjs.lvlEDITCode.GDsprite2Objects4= [];
gdjs.lvlEDITCode.GDsprite2Objects5= [];
gdjs.lvlEDITCode.GDsprite2Objects6= [];
gdjs.lvlEDITCode.GDsprite2Objects7= [];
gdjs.lvlEDITCode.GDsprite2Objects8= [];
gdjs.lvlEDITCode.GDdebugedINFOObjects1= [];
gdjs.lvlEDITCode.GDdebugedINFOObjects2= [];
gdjs.lvlEDITCode.GDdebugedINFOObjects3= [];
gdjs.lvlEDITCode.GDdebugedINFOObjects4= [];
gdjs.lvlEDITCode.GDdebugedINFOObjects5= [];
gdjs.lvlEDITCode.GDdebugedINFOObjects6= [];
gdjs.lvlEDITCode.GDdebugedINFOObjects7= [];
gdjs.lvlEDITCode.GDdebugedINFOObjects8= [];
gdjs.lvlEDITCode.GDcollisionBoxObjects1= [];
gdjs.lvlEDITCode.GDcollisionBoxObjects2= [];
gdjs.lvlEDITCode.GDcollisionBoxObjects3= [];
gdjs.lvlEDITCode.GDcollisionBoxObjects4= [];
gdjs.lvlEDITCode.GDcollisionBoxObjects5= [];
gdjs.lvlEDITCode.GDcollisionBoxObjects6= [];
gdjs.lvlEDITCode.GDcollisionBoxObjects7= [];
gdjs.lvlEDITCode.GDcollisionBoxObjects8= [];
gdjs.lvlEDITCode.GDwidthInputObjects1= [];
gdjs.lvlEDITCode.GDwidthInputObjects2= [];
gdjs.lvlEDITCode.GDwidthInputObjects3= [];
gdjs.lvlEDITCode.GDwidthInputObjects4= [];
gdjs.lvlEDITCode.GDwidthInputObjects5= [];
gdjs.lvlEDITCode.GDwidthInputObjects6= [];
gdjs.lvlEDITCode.GDwidthInputObjects7= [];
gdjs.lvlEDITCode.GDwidthInputObjects8= [];
gdjs.lvlEDITCode.GDheightInputObjects1= [];
gdjs.lvlEDITCode.GDheightInputObjects2= [];
gdjs.lvlEDITCode.GDheightInputObjects3= [];
gdjs.lvlEDITCode.GDheightInputObjects4= [];
gdjs.lvlEDITCode.GDheightInputObjects5= [];
gdjs.lvlEDITCode.GDheightInputObjects6= [];
gdjs.lvlEDITCode.GDheightInputObjects7= [];
gdjs.lvlEDITCode.GDheightInputObjects8= [];
gdjs.lvlEDITCode.GDcamXinputObjects1= [];
gdjs.lvlEDITCode.GDcamXinputObjects2= [];
gdjs.lvlEDITCode.GDcamXinputObjects3= [];
gdjs.lvlEDITCode.GDcamXinputObjects4= [];
gdjs.lvlEDITCode.GDcamXinputObjects5= [];
gdjs.lvlEDITCode.GDcamXinputObjects6= [];
gdjs.lvlEDITCode.GDcamXinputObjects7= [];
gdjs.lvlEDITCode.GDcamXinputObjects8= [];
gdjs.lvlEDITCode.GDcamYinputObjects1= [];
gdjs.lvlEDITCode.GDcamYinputObjects2= [];
gdjs.lvlEDITCode.GDcamYinputObjects3= [];
gdjs.lvlEDITCode.GDcamYinputObjects4= [];
gdjs.lvlEDITCode.GDcamYinputObjects5= [];
gdjs.lvlEDITCode.GDcamYinputObjects6= [];
gdjs.lvlEDITCode.GDcamYinputObjects7= [];
gdjs.lvlEDITCode.GDcamYinputObjects8= [];


gdjs.lvlEDITCode.eventsList0 = function(runtimeScene) {

};gdjs.lvlEDITCode.eventsList1 = function(runtimeScene) {

{


const repeatCount4 = gdjs.evtTools.window.getWindowInnerWidth() / runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber();
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(gdjs.lvlEDITCode.GDpaintObjects2, gdjs.lvlEDITCode.GDpaintObjects4);


let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.lvlEDITCode.GDpaintObjects4.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDpaintObjects4[i].drawLineV2(gdjs.lvlEDITCode.localVariables[1].getFromIndex(0).getAsNumber() + (Math.round(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) / 32) * 32), gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), gdjs.lvlEDITCode.localVariables[1].getFromIndex(0).getAsNumber() + (Math.round(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) / 32) * 32), gdjs.evtTools.window.getWindowInnerHeight() + gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0), 1);
}
}{gdjs.lvlEDITCode.localVariables[1].getFromIndex(0).add(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}}
}

}


};gdjs.lvlEDITCode.eventsList2 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climbX", variable);
}
gdjs.lvlEDITCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.lvlEDITCode.eventsList1(runtimeScene);} //End of subevents
}
gdjs.lvlEDITCode.localVariables.pop();

}


};gdjs.lvlEDITCode.eventsList3 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.window.getWindowInnerHeight() / runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber();
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {
gdjs.copyArray(runtimeScene.getObjects("paint"), gdjs.lvlEDITCode.GDpaintObjects2);

let isConditionTrue_0 = false;
if (true)
{
{for(var i = 0, len = gdjs.lvlEDITCode.GDpaintObjects2.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDpaintObjects2[i].drawLineV2(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.lvlEDITCode.localVariables[0].getFromIndex(0).getAsNumber() + (Math.round(gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) / 32) * 32), gdjs.evtTools.window.getWindowInnerWidth() + gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0), gdjs.lvlEDITCode.localVariables[0].getFromIndex(0).getAsNumber() + (Math.round(gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "", 0) / 32) * 32), 1);
}
}{gdjs.lvlEDITCode.localVariables[0].getFromIndex(0).add(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
{ //Subevents: 
gdjs.lvlEDITCode.eventsList2(runtimeScene);} //Subevents end.
}
}

}


};gdjs.lvlEDITCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("grid"), gdjs.lvlEDITCode.GDgridObjects2);
{for(var i = 0, len = gdjs.lvlEDITCode.GDgridObjects2.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDgridObjects2[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(3).getAsString());
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("grid"), gdjs.lvlEDITCode.GDgridObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDgridObjects2.length;i<l;++i) {
    if ( gdjs.lvlEDITCode.GDgridObjects2[i].isFocused() ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDgridObjects2[k] = gdjs.lvlEDITCode.GDgridObjects2[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDgridObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDgridObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.common.toNumber((( gdjs.lvlEDITCode.GDgridObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDgridObjects2[0].getBehavior("Text").getText())));
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("climbY", variable);
}
gdjs.lvlEDITCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.lvlEDITCode.eventsList3(runtimeScene);} //End of subevents
}
gdjs.lvlEDITCode.localVariables.pop();

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDobjDObjects3Objects = Hashtable.newFrom({"objD": gdjs.lvlEDITCode.GDobjDObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDobjNDObjects3Objects = Hashtable.newFrom({"objND": gdjs.lvlEDITCode.GDobjNDObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDobjDObjects3Objects = Hashtable.newFrom({"objD": gdjs.lvlEDITCode.GDobjDObjects3});
gdjs.lvlEDITCode.eventsList5 = function(runtimeScene) {

};gdjs.lvlEDITCode.eventsList6 = function(runtimeScene) {

{


const keyIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(6);
const valueIteratorReference3 = runtimeScene.getScene().getVariables().getFromIndex(5);
const iterableReference3 = runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg");
if(!iterableReference3.isPrimitive()) {
for(
    const iteratorKey3 in 
    iterableReference3.getType() === "structure"
      ? iterableReference3.getAllChildren()
      : iterableReference3.getType() === "array"
        ? iterableReference3.getAllChildrenArray()
        : []
) {
    if(iterableReference3.getType() === "structure")
        keyIteratorReference3.setString(iteratorKey3);
    else if(iterableReference3.getType() === "array")
        keyIteratorReference3.setNumber(iteratorKey3);
    const structureChildVariable3 = iterableReference3.getChild(iteratorKey3)
    valueIteratorReference3.castTo(structureChildVariable3.getType())
    if(structureChildVariable3.isPrimitive()) {
        valueIteratorReference3.setValue(structureChildVariable3.getValue());
    } else if (structureChildVariable3.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference3.replaceChildren(structureChildVariable3.getAllChildren());
    } else if (structureChildVariable3.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference3.replaceChildrenArray(structureChildVariable3.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.lvlEDITCode.GDobjDObjects3.length = 0;

gdjs.lvlEDITCode.GDobjNDObjects3.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDobjDObjects3Objects, 1058, gdjs.lvlEDITCode.localVariables[0].getFromIndex(0).getAsNumber() * 32, "ui");
}{for(var i = 0, len = gdjs.lvlEDITCode.GDobjDObjects3.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDobjDObjects3[i].returnVariable(gdjs.lvlEDITCode.GDobjDObjects3[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(6).getAsString());
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDobjNDObjects3Objects, 1058 + 35, gdjs.lvlEDITCode.localVariables[0].getFromIndex(0).getAsNumber() * 32, "ui");
}{for(var i = 0, len = gdjs.lvlEDITCode.GDobjNDObjects3.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDobjNDObjects3[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(6).getAsString());
}
}{for(var i = 0, len = gdjs.lvlEDITCode.GDobjDObjects3.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDobjDObjects3[i].getBehavior("Resizable").setSize(32, 32);
}
}{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(5).getChild("texture").getAsString(), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDobjDObjects3Objects, false, 64, 64, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.lvlEDITCode.localVariables[0].getFromIndex(0).add(1);
}}
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}}

}


};gdjs.lvlEDITCode.eventsList7 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(1);
variables._declare("climb", variable);
}
gdjs.lvlEDITCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.lvlEDITCode.eventsList6(runtimeScene);} //End of subevents
}
gdjs.lvlEDITCode.localVariables.pop();

}


};gdjs.lvlEDITCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvlEDITCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJbuttonObjects2Objects = Hashtable.newFrom({"addOBJbutton": gdjs.lvlEDITCode.GDaddOBJbuttonObjects2});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJsObjects2Objects = Hashtable.newFrom({"addOBJs": gdjs.lvlEDITCode.GDaddOBJsObjects2});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJtObjects2Objects = Hashtable.newFrom({"addOBJt": gdjs.lvlEDITCode.GDaddOBJtObjects2});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJsObjects3Objects = Hashtable.newFrom({"addOBJs": gdjs.lvlEDITCode.GDaddOBJsObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJtObjects3Objects = Hashtable.newFrom({"addOBJt": gdjs.lvlEDITCode.GDaddOBJtObjects3});
gdjs.lvlEDITCode.asyncCallback24100836 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvlEDITCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("in"), gdjs.lvlEDITCode.GDinObjects6);

{for(var i = 0, len = gdjs.lvlEDITCode.GDinObjects6.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDinObjects6[i].setCharacterSize(20);
}
}gdjs.lvlEDITCode.localVariables.length = 0;
}
gdjs.lvlEDITCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvlEDITCode.localVariables);
for (const obj of gdjs.lvlEDITCode.GDinObjects5) asyncObjectsList.addObject("in", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.lvlEDITCode.asyncCallback24100836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.lvlEDITCode.asyncCallback24100604 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvlEDITCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("in"), gdjs.lvlEDITCode.GDinObjects5);

{for(var i = 0, len = gdjs.lvlEDITCode.GDinObjects5.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDinObjects5[i].setCharacterSize(20);
}
}
{ //Subevents
gdjs.lvlEDITCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.lvlEDITCode.localVariables.length = 0;
}
gdjs.lvlEDITCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvlEDITCode.localVariables);
for (const obj of gdjs.lvlEDITCode.GDinObjects4) asyncObjectsList.addObject("in", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.lvlEDITCode.asyncCallback24100604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.lvlEDITCode.asyncCallback24100260 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvlEDITCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("in"), gdjs.lvlEDITCode.GDinObjects4);

{for(var i = 0, len = gdjs.lvlEDITCode.GDinObjects4.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDinObjects4[i].setCharacterSize(23);
}
}
{ //Subevents
gdjs.lvlEDITCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.lvlEDITCode.localVariables.length = 0;
}
gdjs.lvlEDITCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvlEDITCode.localVariables);
for (const obj of gdjs.lvlEDITCode.GDinObjects3) asyncObjectsList.addObject("in", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.lvlEDITCode.asyncCallback24100260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.lvlEDITCode.asyncCallback24097428 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.lvlEDITCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("in"), gdjs.lvlEDITCode.GDinObjects3);

{for(var i = 0, len = gdjs.lvlEDITCode.GDinObjects3.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDinObjects3[i].setCharacterSize(20);
}
}
{ //Subevents
gdjs.lvlEDITCode.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.lvlEDITCode.localVariables.length = 0;
}
gdjs.lvlEDITCode.eventsList12 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.lvlEDITCode.localVariables);
for (const obj of gdjs.lvlEDITCode.GDinObjects2) asyncObjectsList.addObject("in", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.lvlEDITCode.asyncCallback24097428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDunknownObjects2Objects = Hashtable.newFrom({"unknown": gdjs.lvlEDITCode.GDunknownObjects2});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDunknownObjects1Objects = Hashtable.newFrom({"unknown": gdjs.lvlEDITCode.GDunknownObjects1});
gdjs.lvlEDITCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("addOBJs"), gdjs.lvlEDITCode.GDaddOBJsObjects2);
gdjs.copyArray(runtimeScene.getObjects("nameInput"), gdjs.lvlEDITCode.GDnameInputObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJsObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.lvlEDITCode.GDnameInputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDnameInputObjects2[0].getBehavior("Text").getText())) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(4).getAsString()) > 4);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDnameInputObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild((( gdjs.lvlEDITCode.GDnameInputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDnameInputObjects2[0].getBehavior("Text").getText())).getChild("texture").setString(runtimeScene.getGame().getVariables().getFromIndex(4).getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild((( gdjs.lvlEDITCode.GDnameInputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDnameInputObjects2[0].getBehavior("Text").getText())).getChild("type").setString("sprite");
}{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "addObjLayer");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("addOBJt"), gdjs.lvlEDITCode.GDaddOBJtObjects2);
gdjs.copyArray(runtimeScene.getObjects("nameInput"), gdjs.lvlEDITCode.GDnameInputObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJtObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.lvlEDITCode.GDnameInputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDnameInputObjects2[0].getBehavior("Text").getText())) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(4).getAsString()) > 4);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDnameInputObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild((( gdjs.lvlEDITCode.GDnameInputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDnameInputObjects2[0].getBehavior("Text").getText())).getChild("texture").setString(runtimeScene.getGame().getVariables().getFromIndex(4).getAsString());
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild((( gdjs.lvlEDITCode.GDnameInputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDnameInputObjects2[0].getBehavior("Text").getText())).getChild("type").setString("tiled sprite");
}{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "addObjLayer");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("nameInput"), gdjs.lvlEDITCode.GDnameInputObjects2);
gdjs.lvlEDITCode.GDaddOBJsObjects2.length = 0;

gdjs.lvlEDITCode.GDaddOBJtObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen((( gdjs.lvlEDITCode.GDnameInputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDnameInputObjects2[0].getBehavior("Text").getText())) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strLen(runtimeScene.getGame().getVariables().getFromIndex(4).getAsString()) <= 4);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.lvlEDITCode.GDaddOBJsObjects2_1final.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("addOBJs"), gdjs.lvlEDITCode.GDaddOBJsObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJsObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.lvlEDITCode.GDaddOBJsObjects3.length; j < jLen ; ++j) {
        if ( gdjs.lvlEDITCode.GDaddOBJsObjects2_1final.indexOf(gdjs.lvlEDITCode.GDaddOBJsObjects3[j]) === -1 )
            gdjs.lvlEDITCode.GDaddOBJsObjects2_1final.push(gdjs.lvlEDITCode.GDaddOBJsObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("addOBJt"), gdjs.lvlEDITCode.GDaddOBJtObjects3);
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJtObjects3Objects, runtimeScene, true, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.lvlEDITCode.GDaddOBJtObjects3.length; j < jLen ; ++j) {
        if ( gdjs.lvlEDITCode.GDaddOBJtObjects2_1final.indexOf(gdjs.lvlEDITCode.GDaddOBJtObjects3[j]) === -1 )
            gdjs.lvlEDITCode.GDaddOBJtObjects2_1final.push(gdjs.lvlEDITCode.GDaddOBJtObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.lvlEDITCode.GDaddOBJsObjects2_1final, gdjs.lvlEDITCode.GDaddOBJsObjects2);
gdjs.copyArray(gdjs.lvlEDITCode.GDaddOBJtObjects2_1final, gdjs.lvlEDITCode.GDaddOBJtObjects2);
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("in"), gdjs.lvlEDITCode.GDinObjects2);
{for(var i = 0, len = gdjs.lvlEDITCode.GDinObjects2.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDinObjects2[i].setCharacterSize(23);
}
}
{ //Subevents
gdjs.lvlEDITCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("unknown"), gdjs.lvlEDITCode.GDunknownObjects2);
{gdjs.evtsExt__resize_image_from_url__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(4).getAsString(), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDunknownObjects2Objects, false, 32, 32, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("unknown"), gdjs.lvlEDITCode.GDunknownObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDunknownObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "resources");
}}

}


};gdjs.lvlEDITCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("addOBJbutton"), gdjs.lvlEDITCode.GDaddOBJbuttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDaddOBJbuttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "addObjLayer");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "addObjLayer");
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvlEDITCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDobjDObjects3Objects = Hashtable.newFrom({"objD": gdjs.lvlEDITCode.GDobjDObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDdummyObjects3Objects = Hashtable.newFrom({"dummy": gdjs.lvlEDITCode.GDdummyObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDdummyObjects3Objects = Hashtable.newFrom({"dummy": gdjs.lvlEDITCode.GDdummyObjects3});
gdjs.lvlEDITCode.userFunc0x110c0e8 = function GDJSInlineCode(runtimeScene) {
"use strict";
var obj = runtimeScene.getObjects('dummy')[0]
obj.setWidth(64)
obj.setHeight(64)
};
gdjs.lvlEDITCode.eventsList15 = function(runtimeScene) {

{


gdjs.lvlEDITCode.userFunc0x110c0e8(runtimeScene);

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDspriteObjects4Objects = Hashtable.newFrom({"sprite": gdjs.lvlEDITCode.GDspriteObjects4});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDcollisionBoxObjects4Objects = Hashtable.newFrom({"collisionBox": gdjs.lvlEDITCode.GDcollisionBoxObjects4});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDspriteObjects4Objects = Hashtable.newFrom({"sprite": gdjs.lvlEDITCode.GDspriteObjects4});
gdjs.lvlEDITCode.userFunc0xd7a8f8 = function GDJSInlineCode(runtimeScene) {
"use strict";
var obj = runtimeScene.getObjects('sprite')[runtimeScene.getObjects('sprite').length-1]
obj.setWidth(64)
obj.setHeight(64)
//console.log(obj)
};
gdjs.lvlEDITCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.lvlEDITCode.userFunc0xd7a8f8(runtimeScene);

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects4Objects = Hashtable.newFrom({"TiledSprite": gdjs.lvlEDITCode.GDTiledSpriteObjects4});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects4Objects = Hashtable.newFrom({"TiledSprite": gdjs.lvlEDITCode.GDTiledSpriteObjects4});
gdjs.lvlEDITCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(8).getAsString() == "sprite");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dummy"), gdjs.lvlEDITCode.GDdummyObjects4);
gdjs.lvlEDITCode.GDcollisionBoxObjects4.length = 0;

gdjs.lvlEDITCode.GDspriteObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDspriteObjects4Objects, (( gdjs.lvlEDITCode.GDdummyObjects4.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDdummyObjects4[0].getPointX("")), (( gdjs.lvlEDITCode.GDdummyObjects4.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDdummyObjects4[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDcollisionBoxObjects4Objects, (( gdjs.lvlEDITCode.GDdummyObjects4.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDdummyObjects4[0].getPointX("")), (( gdjs.lvlEDITCode.GDdummyObjects4.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDdummyObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.lvlEDITCode.GDdummyObjects4.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDdummyObjects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("texture").getAsString(), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDspriteObjects4Objects, false, "sprite", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.lvlEDITCode.GDcollisionBoxObjects4.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDcollisionBoxObjects4[i].returnVariable(gdjs.lvlEDITCode.GDcollisionBoxObjects4[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber());
}
}{for(var i = 0, len = gdjs.lvlEDITCode.GDspriteObjects4.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDspriteObjects4[i].returnVariable(gdjs.lvlEDITCode.GDspriteObjects4[i].getVariables().getFromIndex(2)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(10).add(1);
}{for(var i = 0, len = gdjs.lvlEDITCode.GDspriteObjects4.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDspriteObjects4[i].getBehavior("Resizable").setSize(64, 64);
}
}
{ //Subevents
gdjs.lvlEDITCode.eventsList16(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(8).getAsString() == "tiled sprite");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dummy"), gdjs.lvlEDITCode.GDdummyObjects4);
gdjs.lvlEDITCode.GDTiledSpriteObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects4Objects, (( gdjs.lvlEDITCode.GDdummyObjects4.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDdummyObjects4[0].getPointX("")), (( gdjs.lvlEDITCode.GDdummyObjects4.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDdummyObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.lvlEDITCode.GDdummyObjects4.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDdummyObjects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("texture").getAsString(), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects4Objects, false, "tiled sprite", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.lvlEDITCode.GDTiledSpriteObjects4.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDTiledSpriteObjects4[i].returnVariable(gdjs.lvlEDITCode.GDTiledSpriteObjects4[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(10).add(1);
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(7).setBoolean(false);
}}

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects5Objects = Hashtable.newFrom({"TiledSprite": gdjs.lvlEDITCode.GDTiledSpriteObjects5});
gdjs.lvlEDITCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.lvlEDITCode.GDTiledSpriteObjects4, gdjs.lvlEDITCode.GDTiledSpriteObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDTiledSpriteObjects5.length;i<l;++i) {
    if ( gdjs.lvlEDITCode.GDTiledSpriteObjects5[i].getVariableNumber(gdjs.lvlEDITCode.GDTiledSpriteObjects5[i].getVariables().getFromIndex(0)) == gdjs.lvlEDITCode.GDTiledSpriteObjects5[i].getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDTiledSpriteObjects5[k] = gdjs.lvlEDITCode.GDTiledSpriteObjects5[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDTiledSpriteObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24308100);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDTiledSpriteObjects5 */
gdjs.copyArray(runtimeScene.getObjects("heightInput"), gdjs.lvlEDITCode.GDheightInputObjects5);
gdjs.copyArray(runtimeScene.getObjects("widthInput"), gdjs.lvlEDITCode.GDwidthInputObjects5);
{for(var i = 0, len = gdjs.lvlEDITCode.GDwidthInputObjects5.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDwidthInputObjects5[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.lvlEDITCode.GDTiledSpriteObjects5.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDTiledSpriteObjects5[0].getWidth())));
}
}{for(var i = 0, len = gdjs.lvlEDITCode.GDheightInputObjects5.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDheightInputObjects5[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.lvlEDITCode.GDTiledSpriteObjects5.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDTiledSpriteObjects5[0].getHeight())));
}
}{runtimeScene.getScene().getVariables().getFromIndex(13).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(11).setNumber(((gdjs.lvlEDITCode.GDTiledSpriteObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDTiledSpriteObjects5[0].getVariables()).getFromIndex(0).getAsNumber());
}{runtimeScene.getScene().getVariables().getFromIndex(16).setBoolean(true);
}}

}


{

gdjs.copyArray(gdjs.lvlEDITCode.GDTiledSpriteObjects4, gdjs.lvlEDITCode.GDTiledSpriteObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(13).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(16).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDTiledSpriteObjects5.length;i<l;++i) {
    if ( gdjs.lvlEDITCode.GDTiledSpriteObjects5[i].getVariableNumber(gdjs.lvlEDITCode.GDTiledSpriteObjects5[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(11).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDTiledSpriteObjects5[k] = gdjs.lvlEDITCode.GDTiledSpriteObjects5[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDTiledSpriteObjects5.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDTiledSpriteObjects5 */
gdjs.copyArray(runtimeScene.getObjects("heightInput"), gdjs.lvlEDITCode.GDheightInputObjects5);
gdjs.copyArray(runtimeScene.getObjects("widthInput"), gdjs.lvlEDITCode.GDwidthInputObjects5);
{for(var i = 0, len = gdjs.lvlEDITCode.GDTiledSpriteObjects5.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDTiledSpriteObjects5[i].getBehavior("Resizable").setSize(gdjs.evtTools.common.toNumber((( gdjs.lvlEDITCode.GDwidthInputObjects5.length === 0 ) ? "" :gdjs.lvlEDITCode.GDwidthInputObjects5[0].getBehavior("Text").getText())), gdjs.evtTools.common.toNumber((( gdjs.lvlEDITCode.GDheightInputObjects5.length === 0 ) ? "" :gdjs.lvlEDITCode.GDheightInputObjects5[0].getBehavior("Text").getText())));
}
}}

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDcollisionBoxObjects7Objects = Hashtable.newFrom({"collisionBox": gdjs.lvlEDITCode.GDcollisionBoxObjects7});
gdjs.lvlEDITCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.lvlEDITCode.GDcollisionBoxObjects6, gdjs.lvlEDITCode.GDcollisionBoxObjects7);

gdjs.copyArray(gdjs.lvlEDITCode.GDspriteObjects4, gdjs.lvlEDITCode.GDspriteObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDspriteObjects7.length;i<l;++i) {
    if ( gdjs.lvlEDITCode.GDspriteObjects7[i].getVariableNumber(gdjs.lvlEDITCode.GDspriteObjects7[i].getVariables().getFromIndex(2)) == ((gdjs.lvlEDITCode.GDcollisionBoxObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDcollisionBoxObjects7[0].getVariables()).getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDspriteObjects7[k] = gdjs.lvlEDITCode.GDspriteObjects7[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDspriteObjects7.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDcollisionBoxObjects7 */
/* Reuse gdjs.lvlEDITCode.GDspriteObjects7 */
{for(var i = 0, len = gdjs.lvlEDITCode.GDspriteObjects7.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDspriteObjects7[i].setPosition((( gdjs.lvlEDITCode.GDcollisionBoxObjects7.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDcollisionBoxObjects7[0].getPointX("")),(( gdjs.lvlEDITCode.GDcollisionBoxObjects7.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDcollisionBoxObjects7[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.lvlEDITCode.GDspriteObjects7.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDspriteObjects7[i].returnVariable(gdjs.lvlEDITCode.GDspriteObjects7[i].getVariables().getFromIndex(3)).setNumber((gdjs.lvlEDITCode.GDspriteObjects7[i].getAABBRight()) - (gdjs.lvlEDITCode.GDspriteObjects7[i].getAABBLeft()));
}
}{for(var i = 0, len = gdjs.lvlEDITCode.GDspriteObjects7.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDspriteObjects7[i].returnVariable(gdjs.lvlEDITCode.GDspriteObjects7[i].getVariables().getFromIndex(4)).setNumber((gdjs.lvlEDITCode.GDspriteObjects7[i].getAABBBottom()) - (gdjs.lvlEDITCode.GDspriteObjects7[i].getAABBTop()));
}
}{for(var i = 0, len = gdjs.lvlEDITCode.GDcollisionBoxObjects7.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDcollisionBoxObjects7[i].getBehavior("Resizable").setSize(((gdjs.lvlEDITCode.GDspriteObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDspriteObjects7[0].getVariables()).getFromIndex(3).getAsNumber(), ((gdjs.lvlEDITCode.GDspriteObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDspriteObjects7[0].getVariables()).getFromIndex(4).getAsNumber());
}
}}

}


{

gdjs.copyArray(gdjs.lvlEDITCode.GDcollisionBoxObjects6, gdjs.lvlEDITCode.GDcollisionBoxObjects7);

gdjs.copyArray(gdjs.lvlEDITCode.GDspriteObjects4, gdjs.lvlEDITCode.GDspriteObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDspriteObjects7.length;i<l;++i) {
    if ( gdjs.lvlEDITCode.GDspriteObjects7[i].getVariableNumber(gdjs.lvlEDITCode.GDspriteObjects7[i].getVariables().getFromIndex(2)) == ((gdjs.lvlEDITCode.GDcollisionBoxObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDcollisionBoxObjects7[0].getVariables()).getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDspriteObjects7[k] = gdjs.lvlEDITCode.GDspriteObjects7[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDspriteObjects7.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDcollisionBoxObjects7Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24313036);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDcollisionBoxObjects7 */
gdjs.copyArray(runtimeScene.getObjects("heightInput"), gdjs.lvlEDITCode.GDheightInputObjects7);
/* Reuse gdjs.lvlEDITCode.GDspriteObjects7 */
gdjs.copyArray(runtimeScene.getObjects("widthInput"), gdjs.lvlEDITCode.GDwidthInputObjects7);
{for(var i = 0, len = gdjs.lvlEDITCode.GDwidthInputObjects7.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDwidthInputObjects7[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.lvlEDITCode.GDcollisionBoxObjects7.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDcollisionBoxObjects7[0].getWidth())));
}
}{for(var i = 0, len = gdjs.lvlEDITCode.GDheightInputObjects7.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDheightInputObjects7[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.lvlEDITCode.GDcollisionBoxObjects7.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDcollisionBoxObjects7[0].getHeight())));
}
}{runtimeScene.getScene().getVariables().getFromIndex(13).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(11).setNumber(((gdjs.lvlEDITCode.GDspriteObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDspriteObjects7[0].getVariables()).getFromIndex(2).getAsNumber());
}{runtimeScene.getScene().getVariables().getFromIndex(16).setBoolean(false);
}}

}


};gdjs.lvlEDITCode.userFunc0x1390aa8 = function GDJSInlineCode(runtimeScene, objects) {
"use strict";
objects.forEach(obj=> {
    if(obj.getVariables().get('id').getAsNumber() === runtimeScene.getVariables().get('sid').getAsNumber()){
    obj.setWidth(runtimeScene.getVariables().get('wi').getAsNumber())
    obj.setHeight(runtimeScene.getVariables().get('he').getAsNumber())
    }
})

};
gdjs.lvlEDITCode.eventsList20 = function(runtimeScene) {

{

/* Reuse gdjs.lvlEDITCode.GDspriteObjects5 */

var objects = [];
objects.push.apply(objects,gdjs.lvlEDITCode.GDspriteObjects5);
gdjs.lvlEDITCode.userFunc0x1390aa8(runtimeScene, objects);

}


};gdjs.lvlEDITCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("collisionBox"), gdjs.lvlEDITCode.GDcollisionBoxObjects5);

for (gdjs.lvlEDITCode.forEachIndex6 = 0;gdjs.lvlEDITCode.forEachIndex6 < gdjs.lvlEDITCode.GDcollisionBoxObjects5.length;++gdjs.lvlEDITCode.forEachIndex6) {
gdjs.lvlEDITCode.GDcollisionBoxObjects6.length = 0;


gdjs.lvlEDITCode.forEachTemporary6 = gdjs.lvlEDITCode.GDcollisionBoxObjects5[gdjs.lvlEDITCode.forEachIndex6];
gdjs.lvlEDITCode.GDcollisionBoxObjects6.push(gdjs.lvlEDITCode.forEachTemporary6);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.lvlEDITCode.eventsList19(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(gdjs.lvlEDITCode.GDspriteObjects4, gdjs.lvlEDITCode.GDspriteObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(13).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(11).getAsNumber() == ((gdjs.lvlEDITCode.GDspriteObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDspriteObjects5[0].getVariables()).getFromIndex(2).getAsNumber());
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("heightInput"), gdjs.lvlEDITCode.GDheightInputObjects5);
gdjs.copyArray(runtimeScene.getObjects("widthInput"), gdjs.lvlEDITCode.GDwidthInputObjects5);
{runtimeScene.getScene().getVariables().getFromIndex(14).setNumber(gdjs.evtTools.common.toNumber((( gdjs.lvlEDITCode.GDwidthInputObjects5.length === 0 ) ? "" :gdjs.lvlEDITCode.GDwidthInputObjects5[0].getBehavior("Text").getText())));
}{runtimeScene.getScene().getVariables().getFromIndex(15).setNumber(gdjs.evtTools.common.toNumber((( gdjs.lvlEDITCode.GDheightInputObjects5.length === 0 ) ? "" :gdjs.lvlEDITCode.GDheightInputObjects5[0].getBehavior("Text").getText())));
}
{ //Subevents
gdjs.lvlEDITCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDcollisionBoxObjects3Objects = Hashtable.newFrom({"collisionBox": gdjs.lvlEDITCode.GDcollisionBoxObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects3Objects = Hashtable.newFrom({"TiledSprite": gdjs.lvlEDITCode.GDTiledSpriteObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDspriteObjects3Objects = Hashtable.newFrom({"sprite": gdjs.lvlEDITCode.GDspriteObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDcollisionBoxObjects3Objects = Hashtable.newFrom({"collisionBox": gdjs.lvlEDITCode.GDcollisionBoxObjects3});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDspriteObjects3Objects = Hashtable.newFrom({"sprite": gdjs.lvlEDITCode.GDspriteObjects3});
gdjs.lvlEDITCode.userFunc0x17fdd78 = function GDJSInlineCode(runtimeScene) {
"use strict";
var obj = runtimeScene.getObjects('sprite')[runtimeScene.getObjects('sprite').length-1]
obj.setWidth(64)
obj.setHeight(64)
//console.log(obj)
};
gdjs.lvlEDITCode.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{


gdjs.lvlEDITCode.userFunc0x17fdd78(runtimeScene);

}


};gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects2Objects = Hashtable.newFrom({"TiledSprite": gdjs.lvlEDITCode.GDTiledSpriteObjects2});
gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects2Objects = Hashtable.newFrom({"TiledSprite": gdjs.lvlEDITCode.GDTiledSpriteObjects2});
gdjs.lvlEDITCode.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild(runtimeScene.getScene().getVariables().getFromIndex(12).getAsString()).getChild("type").getAsString() == "sprite");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dummy"), gdjs.lvlEDITCode.GDdummyObjects3);
gdjs.lvlEDITCode.GDcollisionBoxObjects3.length = 0;

gdjs.lvlEDITCode.GDspriteObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDspriteObjects3Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDcollisionBoxObjects3Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.lvlEDITCode.GDdummyObjects3.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDdummyObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild(runtimeScene.getScene().getVariables().getFromIndex(12).getAsString()).getChild("texture").getAsString(), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDspriteObjects3Objects, false, "sprite", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.lvlEDITCode.GDcollisionBoxObjects3.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDcollisionBoxObjects3[i].returnVariable(gdjs.lvlEDITCode.GDcollisionBoxObjects3[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber());
}
}{for(var i = 0, len = gdjs.lvlEDITCode.GDspriteObjects3.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDspriteObjects3[i].returnVariable(gdjs.lvlEDITCode.GDspriteObjects3[i].getVariables().getFromIndex(2)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(10).getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(10).add(1);
}
{ //Subevents
gdjs.lvlEDITCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild(runtimeScene.getScene().getVariables().getFromIndex(12).getAsString()).getChild("type").getAsString() == "tiled sprite");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dummy"), gdjs.lvlEDITCode.GDdummyObjects2);
gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.lvlEDITCode.GDspriteObjects2);
gdjs.lvlEDITCode.GDTiledSpriteObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects2Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{for(var i = 0, len = gdjs.lvlEDITCode.GDdummyObjects2.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDdummyObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild(runtimeScene.getScene().getVariables().getFromIndex(12).getAsString()).getChild("texture").getAsString(), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects2Objects, false, "tiled sprite", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.lvlEDITCode.GDspriteObjects2.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDspriteObjects2[i].returnVariable(gdjs.lvlEDITCode.GDspriteObjects2[i].getVariables().getFromIndex(2)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(17).getAsNumber());
}
}{runtimeScene.getScene().getVariables().getFromIndex(10).add(1);
}}

}


};gdjs.lvlEDITCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("objD"), gdjs.lvlEDITCode.GDobjDObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDobjDObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(7).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24297284);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDobjDObjects3 */
gdjs.lvlEDITCode.GDdummyObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDdummyObjects3Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), "");
}{runtimeScene.getScene().getVariables().getFromIndex(8).setString(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild(((gdjs.lvlEDITCode.GDobjDObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDobjDObjects3[0].getVariables()).getFromIndex(0).getAsString()).getChild("type").getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(9).setString(((gdjs.lvlEDITCode.GDobjDObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDobjDObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{runtimeScene.getScene().getVariables().getFromIndex(7).setBoolean(true);
}{gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getChild("lvl").getChild("objReg").getChild(runtimeScene.getScene().getVariables().getFromIndex(9).getAsString()).getChild("texture").getAsString(), gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDdummyObjects3Objects, false, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(12).setString(((gdjs.lvlEDITCode.GDobjDObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDobjDObjects3[0].getVariables()).getFromIndex(0).getAsString());
}
{ //Subevents
gdjs.lvlEDITCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(7).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dummy"), gdjs.lvlEDITCode.GDdummyObjects3);
{for(var i = 0, len = gdjs.lvlEDITCode.GDdummyObjects3.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDdummyObjects3[i].setCenterPositionInScene(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(7).getAsBoolean();
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvlEDITCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TiledSprite"), gdjs.lvlEDITCode.GDTiledSpriteObjects3);

for (gdjs.lvlEDITCode.forEachIndex4 = 0;gdjs.lvlEDITCode.forEachIndex4 < gdjs.lvlEDITCode.GDTiledSpriteObjects3.length;++gdjs.lvlEDITCode.forEachIndex4) {
gdjs.lvlEDITCode.GDTiledSpriteObjects4.length = 0;


gdjs.lvlEDITCode.forEachTemporary4 = gdjs.lvlEDITCode.GDTiledSpriteObjects3[gdjs.lvlEDITCode.forEachIndex4];
gdjs.lvlEDITCode.GDTiledSpriteObjects4.push(gdjs.lvlEDITCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.lvlEDITCode.eventsList18(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.lvlEDITCode.GDspriteObjects3);

for (gdjs.lvlEDITCode.forEachIndex4 = 0;gdjs.lvlEDITCode.forEachIndex4 < gdjs.lvlEDITCode.GDspriteObjects3.length;++gdjs.lvlEDITCode.forEachIndex4) {
gdjs.lvlEDITCode.GDspriteObjects4.length = 0;


gdjs.lvlEDITCode.forEachTemporary4 = gdjs.lvlEDITCode.GDspriteObjects3[gdjs.lvlEDITCode.forEachIndex4];
gdjs.lvlEDITCode.GDspriteObjects4.push(gdjs.lvlEDITCode.forEachTemporary4);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.lvlEDITCode.eventsList21(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("collisionBox"), gdjs.lvlEDITCode.GDcollisionBoxObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDcollisionBoxObjects3.length;i<l;++i) {
    if ( gdjs.lvlEDITCode.GDcollisionBoxObjects3[i].getBehavior("Draggable").isDragged() ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDcollisionBoxObjects3[k] = gdjs.lvlEDITCode.GDcollisionBoxObjects3[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDcollisionBoxObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDcollisionBoxObjects3 */
{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDcollisionBoxObjects3Objects, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TiledSprite"), gdjs.lvlEDITCode.GDTiledSpriteObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDTiledSpriteObjects3.length;i<l;++i) {
    if ( gdjs.lvlEDITCode.GDTiledSpriteObjects3[i].getBehavior("Draggable").isDragged() ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDTiledSpriteObjects3[k] = gdjs.lvlEDITCode.GDTiledSpriteObjects3[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDTiledSpriteObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDTiledSpriteObjects3 */
{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.lvlEDITCode.mapOfGDgdjs_9546lvlEDITCode_9546GDTiledSpriteObjects3Objects, runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "c");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24318852);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvlEDITCode.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.lvlEDITCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.lvlEDITCode.eventsList24(runtimeScene);} //End of subevents
}

}


{



}


{



}


};gdjs.lvlEDITCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("camXinput"), gdjs.lvlEDITCode.GDcamXinputObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDcamXinputObjects2.length;i<l;++i) {
    if ( (gdjs.lvlEDITCode.GDcamXinputObjects2[i].getBehavior("Text").getText()).startsWith("time,") ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDcamXinputObjects2[k] = gdjs.lvlEDITCode.GDcamXinputObjects2[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDcamXinputObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDcamXinputObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) * gdjs.evtTools.common.toNumber(gdjs.evtTools.string.subStr((( gdjs.lvlEDITCode.GDcamXinputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDcamXinputObjects2[0].getBehavior("Text").getText()), 5, 100000000000)), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("camXinput"), gdjs.lvlEDITCode.GDcamXinputObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDcamXinputObjects2.length;i<l;++i) {
    if ( (gdjs.lvlEDITCode.GDcamXinputObjects2[i].getBehavior("Text").getText()).startsWith("-time,") ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDcamXinputObjects2[k] = gdjs.lvlEDITCode.GDcamXinputObjects2[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDcamXinputObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDcamXinputObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, -(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1)) * gdjs.evtTools.common.toNumber(gdjs.evtTools.string.subStr((( gdjs.lvlEDITCode.GDcamXinputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDcamXinputObjects2[0].getBehavior("Text").getText()), 5, 100000000000)), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("camYinput"), gdjs.lvlEDITCode.GDcamYinputObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDcamYinputObjects2.length;i<l;++i) {
    if ( (gdjs.lvlEDITCode.GDcamYinputObjects2[i].getBehavior("Text").getText()).startsWith("-time,") ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDcamYinputObjects2[k] = gdjs.lvlEDITCode.GDcamYinputObjects2[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDcamYinputObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDcamYinputObjects2 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, -(gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1)) * gdjs.evtTools.common.toNumber(gdjs.evtTools.string.subStr((( gdjs.lvlEDITCode.GDcamYinputObjects2.length === 0 ) ? "" :gdjs.lvlEDITCode.GDcamYinputObjects2[0].getBehavior("Text").getText()), 5, 100000000000)), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("camYinput"), gdjs.lvlEDITCode.GDcamYinputObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.lvlEDITCode.GDcamYinputObjects1.length;i<l;++i) {
    if ( (gdjs.lvlEDITCode.GDcamYinputObjects1[i].getBehavior("Text").getText()).startsWith("time,") ) {
        isConditionTrue_0 = true;
        gdjs.lvlEDITCode.GDcamYinputObjects1[k] = gdjs.lvlEDITCode.GDcamYinputObjects1[i];
        ++k;
    }
}
gdjs.lvlEDITCode.GDcamYinputObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.lvlEDITCode.GDcamYinputObjects1 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.sound.getMusicOnChannelPlayingOffset(runtimeScene, 1) * gdjs.evtTools.common.toNumber(gdjs.evtTools.string.subStr((( gdjs.lvlEDITCode.GDcamYinputObjects1.length === 0 ) ? "" :gdjs.lvlEDITCode.GDcamYinputObjects1[0].getBehavior("Text").getText()), 5, 100000000000)), "", 0);
}}

}


};gdjs.lvlEDITCode.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1);
if (isConditionTrue_0) {

{ //Subevents
gdjs.lvlEDITCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.lvlEDITCode.eventsList28 = function(runtimeScene) {

{



}


{


gdjs.lvlEDITCode.eventsList4(runtimeScene);
}


{


gdjs.lvlEDITCode.eventsList8(runtimeScene);
}


{


gdjs.lvlEDITCode.eventsList14(runtimeScene);
}


{


gdjs.lvlEDITCode.eventsList25(runtimeScene);
}


{


gdjs.lvlEDITCode.eventsList27(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debugedINFO"), gdjs.lvlEDITCode.GDdebugedINFOObjects1);
gdjs.copyArray(runtimeScene.getObjects("sprite"), gdjs.lvlEDITCode.GDspriteObjects1);
{for(var i = 0, len = gdjs.lvlEDITCode.GDdebugedINFOObjects1.length ;i < len;++i) {
    gdjs.lvlEDITCode.GDdebugedINFOObjects1[i].getBehavior("Text").setText("obj bl: " + gdjs.evtTools.common.toString((( gdjs.lvlEDITCode.GDspriteObjects1.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDspriteObjects1[0].getAABBRight())) + " obj x: " + gdjs.evtTools.common.toString((( gdjs.lvlEDITCode.GDspriteObjects1.length === 0 ) ? 0 :gdjs.lvlEDITCode.GDspriteObjects1[0].getPointX(""))) + " obj sw: " + gdjs.evtTools.common.toString(((gdjs.lvlEDITCode.GDspriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.lvlEDITCode.GDspriteObjects1[0].getVariables()).getFromIndex(3).getAsNumber()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mse_win", false);
}}

}


};

gdjs.lvlEDITCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.lvlEDITCode.GDspriteObjects1.length = 0;
gdjs.lvlEDITCode.GDspriteObjects2.length = 0;
gdjs.lvlEDITCode.GDspriteObjects3.length = 0;
gdjs.lvlEDITCode.GDspriteObjects4.length = 0;
gdjs.lvlEDITCode.GDspriteObjects5.length = 0;
gdjs.lvlEDITCode.GDspriteObjects6.length = 0;
gdjs.lvlEDITCode.GDspriteObjects7.length = 0;
gdjs.lvlEDITCode.GDspriteObjects8.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects1.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects2.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects3.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects4.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects5.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects6.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects7.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects8.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects1.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects2.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects3.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects4.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects5.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects6.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects7.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects8.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects1.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects2.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects3.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects4.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects5.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects6.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects7.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects8.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects1.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects2.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects3.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects4.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects5.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects6.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects7.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects8.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects1.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects2.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects3.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects4.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects5.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects6.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects7.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects8.length = 0;
gdjs.lvlEDITCode.GDleftObjects1.length = 0;
gdjs.lvlEDITCode.GDleftObjects2.length = 0;
gdjs.lvlEDITCode.GDleftObjects3.length = 0;
gdjs.lvlEDITCode.GDleftObjects4.length = 0;
gdjs.lvlEDITCode.GDleftObjects5.length = 0;
gdjs.lvlEDITCode.GDleftObjects6.length = 0;
gdjs.lvlEDITCode.GDleftObjects7.length = 0;
gdjs.lvlEDITCode.GDleftObjects8.length = 0;
gdjs.lvlEDITCode.GDrightObjects1.length = 0;
gdjs.lvlEDITCode.GDrightObjects2.length = 0;
gdjs.lvlEDITCode.GDrightObjects3.length = 0;
gdjs.lvlEDITCode.GDrightObjects4.length = 0;
gdjs.lvlEDITCode.GDrightObjects5.length = 0;
gdjs.lvlEDITCode.GDrightObjects6.length = 0;
gdjs.lvlEDITCode.GDrightObjects7.length = 0;
gdjs.lvlEDITCode.GDrightObjects8.length = 0;
gdjs.lvlEDITCode.GDupObjects1.length = 0;
gdjs.lvlEDITCode.GDupObjects2.length = 0;
gdjs.lvlEDITCode.GDupObjects3.length = 0;
gdjs.lvlEDITCode.GDupObjects4.length = 0;
gdjs.lvlEDITCode.GDupObjects5.length = 0;
gdjs.lvlEDITCode.GDupObjects6.length = 0;
gdjs.lvlEDITCode.GDupObjects7.length = 0;
gdjs.lvlEDITCode.GDupObjects8.length = 0;
gdjs.lvlEDITCode.GDdownObjects1.length = 0;
gdjs.lvlEDITCode.GDdownObjects2.length = 0;
gdjs.lvlEDITCode.GDdownObjects3.length = 0;
gdjs.lvlEDITCode.GDdownObjects4.length = 0;
gdjs.lvlEDITCode.GDdownObjects5.length = 0;
gdjs.lvlEDITCode.GDdownObjects6.length = 0;
gdjs.lvlEDITCode.GDdownObjects7.length = 0;
gdjs.lvlEDITCode.GDdownObjects8.length = 0;
gdjs.lvlEDITCode.GDrbObjects1.length = 0;
gdjs.lvlEDITCode.GDrbObjects2.length = 0;
gdjs.lvlEDITCode.GDrbObjects3.length = 0;
gdjs.lvlEDITCode.GDrbObjects4.length = 0;
gdjs.lvlEDITCode.GDrbObjects5.length = 0;
gdjs.lvlEDITCode.GDrbObjects6.length = 0;
gdjs.lvlEDITCode.GDrbObjects7.length = 0;
gdjs.lvlEDITCode.GDrbObjects8.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects1.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects2.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects3.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects4.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects5.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects6.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects7.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects8.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects1.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects2.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects3.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects4.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects5.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects6.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects7.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects8.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects1.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects2.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects3.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects4.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects5.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects6.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects7.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects8.length = 0;
gdjs.lvlEDITCode.GDgridObjects1.length = 0;
gdjs.lvlEDITCode.GDgridObjects2.length = 0;
gdjs.lvlEDITCode.GDgridObjects3.length = 0;
gdjs.lvlEDITCode.GDgridObjects4.length = 0;
gdjs.lvlEDITCode.GDgridObjects5.length = 0;
gdjs.lvlEDITCode.GDgridObjects6.length = 0;
gdjs.lvlEDITCode.GDgridObjects7.length = 0;
gdjs.lvlEDITCode.GDgridObjects8.length = 0;
gdjs.lvlEDITCode.GDpaintObjects1.length = 0;
gdjs.lvlEDITCode.GDpaintObjects2.length = 0;
gdjs.lvlEDITCode.GDpaintObjects3.length = 0;
gdjs.lvlEDITCode.GDpaintObjects4.length = 0;
gdjs.lvlEDITCode.GDpaintObjects5.length = 0;
gdjs.lvlEDITCode.GDpaintObjects6.length = 0;
gdjs.lvlEDITCode.GDpaintObjects7.length = 0;
gdjs.lvlEDITCode.GDpaintObjects8.length = 0;
gdjs.lvlEDITCode.GDspriObjects1.length = 0;
gdjs.lvlEDITCode.GDspriObjects2.length = 0;
gdjs.lvlEDITCode.GDspriObjects3.length = 0;
gdjs.lvlEDITCode.GDspriObjects4.length = 0;
gdjs.lvlEDITCode.GDspriObjects5.length = 0;
gdjs.lvlEDITCode.GDspriObjects6.length = 0;
gdjs.lvlEDITCode.GDspriObjects7.length = 0;
gdjs.lvlEDITCode.GDspriObjects8.length = 0;
gdjs.lvlEDITCode.GDtileObjects1.length = 0;
gdjs.lvlEDITCode.GDtileObjects2.length = 0;
gdjs.lvlEDITCode.GDtileObjects3.length = 0;
gdjs.lvlEDITCode.GDtileObjects4.length = 0;
gdjs.lvlEDITCode.GDtileObjects5.length = 0;
gdjs.lvlEDITCode.GDtileObjects6.length = 0;
gdjs.lvlEDITCode.GDtileObjects7.length = 0;
gdjs.lvlEDITCode.GDtileObjects8.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects1.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects2.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects3.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects4.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects5.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects6.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects7.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects8.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects1.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects2.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects3.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects4.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects5.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects6.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects7.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects8.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects1.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects2.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects3.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects4.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects5.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects6.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects7.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects8.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects1.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects2.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects3.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects4.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects5.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects6.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects7.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects8.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects1.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects2.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects3.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects4.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects5.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects6.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects7.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects8.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects1.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects2.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects3.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects4.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects5.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects6.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects7.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects8.length = 0;
gdjs.lvlEDITCode.GDreObjects1.length = 0;
gdjs.lvlEDITCode.GDreObjects2.length = 0;
gdjs.lvlEDITCode.GDreObjects3.length = 0;
gdjs.lvlEDITCode.GDreObjects4.length = 0;
gdjs.lvlEDITCode.GDreObjects5.length = 0;
gdjs.lvlEDITCode.GDreObjects6.length = 0;
gdjs.lvlEDITCode.GDreObjects7.length = 0;
gdjs.lvlEDITCode.GDreObjects8.length = 0;
gdjs.lvlEDITCode.GDunknownObjects1.length = 0;
gdjs.lvlEDITCode.GDunknownObjects2.length = 0;
gdjs.lvlEDITCode.GDunknownObjects3.length = 0;
gdjs.lvlEDITCode.GDunknownObjects4.length = 0;
gdjs.lvlEDITCode.GDunknownObjects5.length = 0;
gdjs.lvlEDITCode.GDunknownObjects6.length = 0;
gdjs.lvlEDITCode.GDunknownObjects7.length = 0;
gdjs.lvlEDITCode.GDunknownObjects8.length = 0;
gdjs.lvlEDITCode.GDinObjects1.length = 0;
gdjs.lvlEDITCode.GDinObjects2.length = 0;
gdjs.lvlEDITCode.GDinObjects3.length = 0;
gdjs.lvlEDITCode.GDinObjects4.length = 0;
gdjs.lvlEDITCode.GDinObjects5.length = 0;
gdjs.lvlEDITCode.GDinObjects6.length = 0;
gdjs.lvlEDITCode.GDinObjects7.length = 0;
gdjs.lvlEDITCode.GDinObjects8.length = 0;
gdjs.lvlEDITCode.GDobjDObjects1.length = 0;
gdjs.lvlEDITCode.GDobjDObjects2.length = 0;
gdjs.lvlEDITCode.GDobjDObjects3.length = 0;
gdjs.lvlEDITCode.GDobjDObjects4.length = 0;
gdjs.lvlEDITCode.GDobjDObjects5.length = 0;
gdjs.lvlEDITCode.GDobjDObjects6.length = 0;
gdjs.lvlEDITCode.GDobjDObjects7.length = 0;
gdjs.lvlEDITCode.GDobjDObjects8.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects1.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects2.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects3.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects4.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects5.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects6.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects7.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects8.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects1.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects2.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects3.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects4.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects5.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects6.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects7.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects8.length = 0;
gdjs.lvlEDITCode.GDdummyObjects1.length = 0;
gdjs.lvlEDITCode.GDdummyObjects2.length = 0;
gdjs.lvlEDITCode.GDdummyObjects3.length = 0;
gdjs.lvlEDITCode.GDdummyObjects4.length = 0;
gdjs.lvlEDITCode.GDdummyObjects5.length = 0;
gdjs.lvlEDITCode.GDdummyObjects6.length = 0;
gdjs.lvlEDITCode.GDdummyObjects7.length = 0;
gdjs.lvlEDITCode.GDdummyObjects8.length = 0;
gdjs.lvlEDITCode.GDgridWObjects1.length = 0;
gdjs.lvlEDITCode.GDgridWObjects2.length = 0;
gdjs.lvlEDITCode.GDgridWObjects3.length = 0;
gdjs.lvlEDITCode.GDgridWObjects4.length = 0;
gdjs.lvlEDITCode.GDgridWObjects5.length = 0;
gdjs.lvlEDITCode.GDgridWObjects6.length = 0;
gdjs.lvlEDITCode.GDgridWObjects7.length = 0;
gdjs.lvlEDITCode.GDgridWObjects8.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects1.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects2.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects3.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects4.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects5.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects6.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects7.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects8.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects1.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects2.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects3.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects4.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects5.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects6.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects7.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects8.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects1.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects2.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects3.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects4.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects5.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects6.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects7.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects8.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects1.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects2.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects3.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects4.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects5.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects6.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects7.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects8.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects1.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects2.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects3.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects4.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects5.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects6.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects7.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects8.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects1.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects2.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects3.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects4.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects5.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects6.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects7.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects8.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects1.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects2.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects3.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects4.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects5.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects6.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects7.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects8.length = 0;

gdjs.lvlEDITCode.eventsList28(runtimeScene);
gdjs.lvlEDITCode.GDspriteObjects1.length = 0;
gdjs.lvlEDITCode.GDspriteObjects2.length = 0;
gdjs.lvlEDITCode.GDspriteObjects3.length = 0;
gdjs.lvlEDITCode.GDspriteObjects4.length = 0;
gdjs.lvlEDITCode.GDspriteObjects5.length = 0;
gdjs.lvlEDITCode.GDspriteObjects6.length = 0;
gdjs.lvlEDITCode.GDspriteObjects7.length = 0;
gdjs.lvlEDITCode.GDspriteObjects8.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects1.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects2.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects3.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects4.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects5.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects6.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects7.length = 0;
gdjs.lvlEDITCode.GDTiledSpriteObjects8.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects1.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects2.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects3.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects4.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects5.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects6.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects7.length = 0;
gdjs.lvlEDITCode.GDdragCornerULObjects8.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects1.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects2.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects3.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects4.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects5.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects6.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects7.length = 0;
gdjs.lvlEDITCode.GDdragCornerURObjects8.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects1.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects2.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects3.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects4.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects5.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects6.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects7.length = 0;
gdjs.lvlEDITCode.GDdragCornerDRObjects8.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects1.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects2.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects3.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects4.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects5.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects6.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects7.length = 0;
gdjs.lvlEDITCode.GDdragCornerDLObjects8.length = 0;
gdjs.lvlEDITCode.GDleftObjects1.length = 0;
gdjs.lvlEDITCode.GDleftObjects2.length = 0;
gdjs.lvlEDITCode.GDleftObjects3.length = 0;
gdjs.lvlEDITCode.GDleftObjects4.length = 0;
gdjs.lvlEDITCode.GDleftObjects5.length = 0;
gdjs.lvlEDITCode.GDleftObjects6.length = 0;
gdjs.lvlEDITCode.GDleftObjects7.length = 0;
gdjs.lvlEDITCode.GDleftObjects8.length = 0;
gdjs.lvlEDITCode.GDrightObjects1.length = 0;
gdjs.lvlEDITCode.GDrightObjects2.length = 0;
gdjs.lvlEDITCode.GDrightObjects3.length = 0;
gdjs.lvlEDITCode.GDrightObjects4.length = 0;
gdjs.lvlEDITCode.GDrightObjects5.length = 0;
gdjs.lvlEDITCode.GDrightObjects6.length = 0;
gdjs.lvlEDITCode.GDrightObjects7.length = 0;
gdjs.lvlEDITCode.GDrightObjects8.length = 0;
gdjs.lvlEDITCode.GDupObjects1.length = 0;
gdjs.lvlEDITCode.GDupObjects2.length = 0;
gdjs.lvlEDITCode.GDupObjects3.length = 0;
gdjs.lvlEDITCode.GDupObjects4.length = 0;
gdjs.lvlEDITCode.GDupObjects5.length = 0;
gdjs.lvlEDITCode.GDupObjects6.length = 0;
gdjs.lvlEDITCode.GDupObjects7.length = 0;
gdjs.lvlEDITCode.GDupObjects8.length = 0;
gdjs.lvlEDITCode.GDdownObjects1.length = 0;
gdjs.lvlEDITCode.GDdownObjects2.length = 0;
gdjs.lvlEDITCode.GDdownObjects3.length = 0;
gdjs.lvlEDITCode.GDdownObjects4.length = 0;
gdjs.lvlEDITCode.GDdownObjects5.length = 0;
gdjs.lvlEDITCode.GDdownObjects6.length = 0;
gdjs.lvlEDITCode.GDdownObjects7.length = 0;
gdjs.lvlEDITCode.GDdownObjects8.length = 0;
gdjs.lvlEDITCode.GDrbObjects1.length = 0;
gdjs.lvlEDITCode.GDrbObjects2.length = 0;
gdjs.lvlEDITCode.GDrbObjects3.length = 0;
gdjs.lvlEDITCode.GDrbObjects4.length = 0;
gdjs.lvlEDITCode.GDrbObjects5.length = 0;
gdjs.lvlEDITCode.GDrbObjects6.length = 0;
gdjs.lvlEDITCode.GDrbObjects7.length = 0;
gdjs.lvlEDITCode.GDrbObjects8.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects1.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects2.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects3.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects4.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects5.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects6.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects7.length = 0;
gdjs.lvlEDITCode.GDNewSpriteObjects8.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects1.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects2.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects3.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects4.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects5.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects6.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects7.length = 0;
gdjs.lvlEDITCode.GDaddOBJbuttonObjects8.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects1.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects2.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects3.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects4.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects5.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects6.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects7.length = 0;
gdjs.lvlEDITCode.GDNewSprite2Objects8.length = 0;
gdjs.lvlEDITCode.GDgridObjects1.length = 0;
gdjs.lvlEDITCode.GDgridObjects2.length = 0;
gdjs.lvlEDITCode.GDgridObjects3.length = 0;
gdjs.lvlEDITCode.GDgridObjects4.length = 0;
gdjs.lvlEDITCode.GDgridObjects5.length = 0;
gdjs.lvlEDITCode.GDgridObjects6.length = 0;
gdjs.lvlEDITCode.GDgridObjects7.length = 0;
gdjs.lvlEDITCode.GDgridObjects8.length = 0;
gdjs.lvlEDITCode.GDpaintObjects1.length = 0;
gdjs.lvlEDITCode.GDpaintObjects2.length = 0;
gdjs.lvlEDITCode.GDpaintObjects3.length = 0;
gdjs.lvlEDITCode.GDpaintObjects4.length = 0;
gdjs.lvlEDITCode.GDpaintObjects5.length = 0;
gdjs.lvlEDITCode.GDpaintObjects6.length = 0;
gdjs.lvlEDITCode.GDpaintObjects7.length = 0;
gdjs.lvlEDITCode.GDpaintObjects8.length = 0;
gdjs.lvlEDITCode.GDspriObjects1.length = 0;
gdjs.lvlEDITCode.GDspriObjects2.length = 0;
gdjs.lvlEDITCode.GDspriObjects3.length = 0;
gdjs.lvlEDITCode.GDspriObjects4.length = 0;
gdjs.lvlEDITCode.GDspriObjects5.length = 0;
gdjs.lvlEDITCode.GDspriObjects6.length = 0;
gdjs.lvlEDITCode.GDspriObjects7.length = 0;
gdjs.lvlEDITCode.GDspriObjects8.length = 0;
gdjs.lvlEDITCode.GDtileObjects1.length = 0;
gdjs.lvlEDITCode.GDtileObjects2.length = 0;
gdjs.lvlEDITCode.GDtileObjects3.length = 0;
gdjs.lvlEDITCode.GDtileObjects4.length = 0;
gdjs.lvlEDITCode.GDtileObjects5.length = 0;
gdjs.lvlEDITCode.GDtileObjects6.length = 0;
gdjs.lvlEDITCode.GDtileObjects7.length = 0;
gdjs.lvlEDITCode.GDtileObjects8.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects1.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects2.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects3.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects4.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects5.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects6.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects7.length = 0;
gdjs.lvlEDITCode.GDaddOBJtObjects8.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects1.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects2.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects3.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects4.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects5.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects6.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects7.length = 0;
gdjs.lvlEDITCode.GDaddOBJsObjects8.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects1.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects2.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects3.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects4.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects5.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects6.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects7.length = 0;
gdjs.lvlEDITCode.GDNewTextObjects8.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects1.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects2.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects3.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects4.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects5.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects6.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects7.length = 0;
gdjs.lvlEDITCode.GDNewText2Objects8.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects1.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects2.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects3.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects4.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects5.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects6.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects7.length = 0;
gdjs.lvlEDITCode.GDnameInputObjects8.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects1.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects2.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects3.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects4.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects5.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects6.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects7.length = 0;
gdjs.lvlEDITCode.GDNewText3Objects8.length = 0;
gdjs.lvlEDITCode.GDreObjects1.length = 0;
gdjs.lvlEDITCode.GDreObjects2.length = 0;
gdjs.lvlEDITCode.GDreObjects3.length = 0;
gdjs.lvlEDITCode.GDreObjects4.length = 0;
gdjs.lvlEDITCode.GDreObjects5.length = 0;
gdjs.lvlEDITCode.GDreObjects6.length = 0;
gdjs.lvlEDITCode.GDreObjects7.length = 0;
gdjs.lvlEDITCode.GDreObjects8.length = 0;
gdjs.lvlEDITCode.GDunknownObjects1.length = 0;
gdjs.lvlEDITCode.GDunknownObjects2.length = 0;
gdjs.lvlEDITCode.GDunknownObjects3.length = 0;
gdjs.lvlEDITCode.GDunknownObjects4.length = 0;
gdjs.lvlEDITCode.GDunknownObjects5.length = 0;
gdjs.lvlEDITCode.GDunknownObjects6.length = 0;
gdjs.lvlEDITCode.GDunknownObjects7.length = 0;
gdjs.lvlEDITCode.GDunknownObjects8.length = 0;
gdjs.lvlEDITCode.GDinObjects1.length = 0;
gdjs.lvlEDITCode.GDinObjects2.length = 0;
gdjs.lvlEDITCode.GDinObjects3.length = 0;
gdjs.lvlEDITCode.GDinObjects4.length = 0;
gdjs.lvlEDITCode.GDinObjects5.length = 0;
gdjs.lvlEDITCode.GDinObjects6.length = 0;
gdjs.lvlEDITCode.GDinObjects7.length = 0;
gdjs.lvlEDITCode.GDinObjects8.length = 0;
gdjs.lvlEDITCode.GDobjDObjects1.length = 0;
gdjs.lvlEDITCode.GDobjDObjects2.length = 0;
gdjs.lvlEDITCode.GDobjDObjects3.length = 0;
gdjs.lvlEDITCode.GDobjDObjects4.length = 0;
gdjs.lvlEDITCode.GDobjDObjects5.length = 0;
gdjs.lvlEDITCode.GDobjDObjects6.length = 0;
gdjs.lvlEDITCode.GDobjDObjects7.length = 0;
gdjs.lvlEDITCode.GDobjDObjects8.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects1.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects2.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects3.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects4.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects5.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects6.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects7.length = 0;
gdjs.lvlEDITCode.GDobjNDObjects8.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects1.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects2.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects3.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects4.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects5.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects6.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects7.length = 0;
gdjs.lvlEDITCode.GDaddTxtObjects8.length = 0;
gdjs.lvlEDITCode.GDdummyObjects1.length = 0;
gdjs.lvlEDITCode.GDdummyObjects2.length = 0;
gdjs.lvlEDITCode.GDdummyObjects3.length = 0;
gdjs.lvlEDITCode.GDdummyObjects4.length = 0;
gdjs.lvlEDITCode.GDdummyObjects5.length = 0;
gdjs.lvlEDITCode.GDdummyObjects6.length = 0;
gdjs.lvlEDITCode.GDdummyObjects7.length = 0;
gdjs.lvlEDITCode.GDdummyObjects8.length = 0;
gdjs.lvlEDITCode.GDgridWObjects1.length = 0;
gdjs.lvlEDITCode.GDgridWObjects2.length = 0;
gdjs.lvlEDITCode.GDgridWObjects3.length = 0;
gdjs.lvlEDITCode.GDgridWObjects4.length = 0;
gdjs.lvlEDITCode.GDgridWObjects5.length = 0;
gdjs.lvlEDITCode.GDgridWObjects6.length = 0;
gdjs.lvlEDITCode.GDgridWObjects7.length = 0;
gdjs.lvlEDITCode.GDgridWObjects8.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects1.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects2.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects3.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects4.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects5.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects6.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects7.length = 0;
gdjs.lvlEDITCode.GDsprite2Objects8.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects1.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects2.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects3.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects4.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects5.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects6.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects7.length = 0;
gdjs.lvlEDITCode.GDdebugedINFOObjects8.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects1.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects2.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects3.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects4.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects5.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects6.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects7.length = 0;
gdjs.lvlEDITCode.GDcollisionBoxObjects8.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects1.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects2.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects3.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects4.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects5.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects6.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects7.length = 0;
gdjs.lvlEDITCode.GDwidthInputObjects8.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects1.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects2.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects3.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects4.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects5.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects6.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects7.length = 0;
gdjs.lvlEDITCode.GDheightInputObjects8.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects1.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects2.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects3.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects4.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects5.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects6.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects7.length = 0;
gdjs.lvlEDITCode.GDcamXinputObjects8.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects1.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects2.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects3.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects4.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects5.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects6.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects7.length = 0;
gdjs.lvlEDITCode.GDcamYinputObjects8.length = 0;


return;

}

gdjs['lvlEDITCode'] = gdjs.lvlEDITCode;
