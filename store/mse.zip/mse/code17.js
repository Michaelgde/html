gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.GDtestObjects1= [];
gdjs.Untitled_32sceneCode.GDtestObjects2= [];
gdjs.Untitled_32sceneCode.GDtestObjects3= [];
gdjs.Untitled_32sceneCode.GDtestObjects4= [];
gdjs.Untitled_32sceneCode.GDtestObjects5= [];
gdjs.Untitled_32sceneCode.GDresultObjects1= [];
gdjs.Untitled_32sceneCode.GDresultObjects2= [];
gdjs.Untitled_32sceneCode.GDresultObjects3= [];
gdjs.Untitled_32sceneCode.GDresultObjects4= [];
gdjs.Untitled_32sceneCode.GDresultObjects5= [];
gdjs.Untitled_32sceneCode.GDpath2Objects1= [];
gdjs.Untitled_32sceneCode.GDpath2Objects2= [];
gdjs.Untitled_32sceneCode.GDpath2Objects3= [];
gdjs.Untitled_32sceneCode.GDpath2Objects4= [];
gdjs.Untitled_32sceneCode.GDpath2Objects5= [];


gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDpath2Objects2, gdjs.Untitled_32sceneCode.GDpath2Objects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strAt((( gdjs.Untitled_32sceneCode.GDpath2Objects4.length === 0 ) ? "" :gdjs.Untitled_32sceneCode.GDpath2Objects4[0].getBehavior("Text").getText()), gdjs.Untitled_32sceneCode.localVariables[0].getFromIndex(0).getAsNumber()) != gdjs.Untitled_32sceneCode.localVariables[0].getFromIndex(1).getAsString());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDpath2Objects4 */
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDresultObjects1, gdjs.Untitled_32sceneCode.GDresultObjects4);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDresultObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDresultObjects4[i].getBehavior("Text").setText(gdjs.Untitled_32sceneCode.GDresultObjects4[i].getBehavior("Text").getText() + (gdjs.evtTools.string.strAt((( gdjs.Untitled_32sceneCode.GDpath2Objects4.length === 0 ) ? "" :gdjs.Untitled_32sceneCode.GDpath2Objects4[0].getBehavior("Text").getText()), gdjs.Untitled_32sceneCode.localVariables[0].getFromIndex(0).getAsNumber())));
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).concatenateString(gdjs.evtTools.string.strAt((( gdjs.Untitled_32sceneCode.GDpath2Objects4.length === 0 ) ? "" :gdjs.Untitled_32sceneCode.GDpath2Objects4[0].getBehavior("Text").getText()), gdjs.Untitled_32sceneCode.localVariables[0].getFromIndex(0).getAsNumber()));
}{gdjs.Untitled_32sceneCode.localVariables[0].getFromIndex(0).add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDpath2Objects2, gdjs.Untitled_32sceneCode.GDpath2Objects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.strAt((( gdjs.Untitled_32sceneCode.GDpath2Objects4.length === 0 ) ? "" :gdjs.Untitled_32sceneCode.GDpath2Objects4[0].getBehavior("Text").getText()), gdjs.Untitled_32sceneCode.localVariables[0].getFromIndex(0).getAsNumber()) == gdjs.Untitled_32sceneCode.localVariables[0].getFromIndex(1).getAsString());
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDresultObjects1, gdjs.Untitled_32sceneCode.GDresultObjects4);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDresultObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDresultObjects4[i].getBehavior("Text").setText(gdjs.Untitled_32sceneCode.GDresultObjects4[i].getBehavior("Text").getText() + ("/"));
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).concatenateString("/");
}{gdjs.Untitled_32sceneCode.localVariables[0].getFromIndex(0).add(1);
}}

}


};gdjs.Untitled_32sceneCode.userFunc0x10b6760 = function GDJSInlineCode(runtimeScene) {
"use strict";
const imageUrl = runtimeScene.getVariables().get('url').getAsString(); // Replace with your actual image URL

// Load the image as a PixiJS texture
const texture = PIXI.Texture.from(imageUrl);

// Apply it to a Sprite object
const object = runtimeScene.getObjects("test")[0];
if (object) {
    object.getRendererObject().texture = texture; // Set the texture dynamically
}

var behave = {
    "checkCollisionMask": true,
    "name": "Draggable",
    "type": "DraggableBehavior::Draggable"
}

//runtimeScene.getObjects('test')[0].addNewBehavior(behave)

//console.log(runtimeScene)
//var objss = []

//console.log(runtimeScene._objects.keys())
};
gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.userFunc0x10b6760(runtimeScene);

}


};gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("path2"), gdjs.Untitled_32sceneCode.GDpath2Objects2);

const repeatCount3 = gdjs.evtTools.string.strLen((( gdjs.Untitled_32sceneCode.GDpath2Objects2.length === 0 ) ? "" :gdjs.Untitled_32sceneCode.GDpath2Objects2[0].getBehavior("Text").getText()));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}
{ //Subevents: 
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23914180);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.userFunc0x10b68f0 = function GDJSInlineCode(runtimeScene) {
"use strict";

};
gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.userFunc0x10b68f0(runtimeScene);

}


};gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("pos", variable);
}
{
const variable = new gdjs.Variable();
variable.setString("\\");
variables._declare("slash", variable);
}
gdjs.Untitled_32sceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("result"), gdjs.Untitled_32sceneCode.GDresultObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDresultObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDresultObjects1[i].getBehavior("Text").setText("result url => file://");
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setString("");
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);} //End of subevents
}
gdjs.Untitled_32sceneCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24026524);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDtestObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects5.length = 0;

gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);
gdjs.Untitled_32sceneCode.GDtestObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDtestObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDresultObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDpath2Objects5.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
