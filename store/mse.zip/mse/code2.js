gdjs.audio_95editor_95eventCode = {};
gdjs.audio_95editor_95eventCode.localVariables = [];
gdjs.audio_95editor_95eventCode.forEachIndex2 = 0;

gdjs.audio_95editor_95eventCode.forEachObjects2 = [];

gdjs.audio_95editor_95eventCode.forEachTemporary2 = null;

gdjs.audio_95editor_95eventCode.forEachTotalCount2 = 0;

gdjs.audio_95editor_95eventCode.GDpanelObjects1= [];
gdjs.audio_95editor_95eventCode.GDpanelObjects2= [];
gdjs.audio_95editor_95eventCode.GDpanelObjects3= [];
gdjs.audio_95editor_95eventCode.GDpanelObjects4= [];
gdjs.audio_95editor_95eventCode.GDpanel2Objects1= [];
gdjs.audio_95editor_95eventCode.GDpanel2Objects2= [];
gdjs.audio_95editor_95eventCode.GDpanel2Objects3= [];
gdjs.audio_95editor_95eventCode.GDpanel2Objects4= [];
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects1= [];
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects2= [];
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects3= [];
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects4= [];
gdjs.audio_95editor_95eventCode.GDdrawObjects1= [];
gdjs.audio_95editor_95eventCode.GDdrawObjects2= [];
gdjs.audio_95editor_95eventCode.GDdrawObjects3= [];
gdjs.audio_95editor_95eventCode.GDdrawObjects4= [];
gdjs.audio_95editor_95eventCode.GDnameObjects1= [];
gdjs.audio_95editor_95eventCode.GDnameObjects2= [];
gdjs.audio_95editor_95eventCode.GDnameObjects3= [];
gdjs.audio_95editor_95eventCode.GDnameObjects4= [];
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1= [];
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects2= [];
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects3= [];
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects4= [];
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1= [];
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects2= [];
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects3= [];
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects4= [];
gdjs.audio_95editor_95eventCode.GDplayObjects1= [];
gdjs.audio_95editor_95eventCode.GDplayObjects2= [];
gdjs.audio_95editor_95eventCode.GDplayObjects3= [];
gdjs.audio_95editor_95eventCode.GDplayObjects4= [];
gdjs.audio_95editor_95eventCode.GDdebugObjects1= [];
gdjs.audio_95editor_95eventCode.GDdebugObjects2= [];
gdjs.audio_95editor_95eventCode.GDdebugObjects3= [];
gdjs.audio_95editor_95eventCode.GDdebugObjects4= [];
gdjs.audio_95editor_95eventCode.GDstopObjects1= [];
gdjs.audio_95editor_95eventCode.GDstopObjects2= [];
gdjs.audio_95editor_95eventCode.GDstopObjects3= [];
gdjs.audio_95editor_95eventCode.GDstopObjects4= [];
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects1= [];
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects2= [];
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects3= [];
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects4= [];
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects1= [];
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects2= [];
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects3= [];
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects4= [];


gdjs.audio_95editor_95eventCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("draw"), gdjs.audio_95editor_95eventCode.GDdrawObjects3);
gdjs.copyArray(gdjs.audio_95editor_95eventCode.GDnameObjects2, gdjs.audio_95editor_95eventCode.GDnameObjects3);

{for(var i = 0, len = gdjs.audio_95editor_95eventCode.GDdrawObjects3.length ;i < len;++i) {
    gdjs.audio_95editor_95eventCode.GDdrawObjects3[i].drawLineV2(gdjs.evtTools.camera.getCameraX(runtimeScene, "Layer", 0) - (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.audio_95editor_95eventCode.GDnameObjects3.length === 0 ) ? 0 :gdjs.audio_95editor_95eventCode.GDnameObjects3[0].getY()) + 64, gdjs.evtTools.camera.getCameraX(runtimeScene, "Layer", 0) + (gdjs.evtTools.window.getWindowInnerWidth() / 2), (( gdjs.audio_95editor_95eventCode.GDnameObjects3.length === 0 ) ? 0 :gdjs.audio_95editor_95eventCode.GDnameObjects3[0].getY()) + 64, 1);
}
}}

}


};gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDplay_95959595nodeObjects2Objects = Hashtable.newFrom({"play_node": gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects2});
gdjs.audio_95editor_95eventCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDplay_95959595nodeObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(4).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects2);
{for(var i = 0, len = gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects2.length ;i < len;++i) {
    gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects2[i].setX(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}}

}


};gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDstopObjects1Objects = Hashtable.newFrom({"stop": gdjs.audio_95editor_95eventCode.GDstopObjects1});
gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDplayObjects1Objects = Hashtable.newFrom({"play": gdjs.audio_95editor_95eventCode.GDplayObjects1});
gdjs.audio_95editor_95eventCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(3).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.audio_95editor_95eventCode.GDplayObjects1, gdjs.audio_95editor_95eventCode.GDplayObjects2);

{for(var i = 0, len = gdjs.audio_95editor_95eventCode.GDplayObjects2.length ;i < len;++i) {
    gdjs.audio_95editor_95eventCode.GDplayObjects2[i].getBehavior("Animation").setAnimationName("paused");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(3).getAsBoolean();
}
if (isConditionTrue_0) {
/* Reuse gdjs.audio_95editor_95eventCode.GDplayObjects1 */
{for(var i = 0, len = gdjs.audio_95editor_95eventCode.GDplayObjects1.length ;i < len;++i) {
    gdjs.audio_95editor_95eventCode.GDplayObjects1[i].getBehavior("Animation").setAnimationName("playing");
}
}}

}


};gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDplay_95959595nodeObjects1Objects = Hashtable.newFrom({"play_node": gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1});
gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1});
gdjs.audio_95editor_95eventCode.userFunc0x1230640 = function GDJSInlineCode(runtimeScene) {
"use strict";
const na = runtimeScene.getVariables().get("musicData")

const ear = "select"

const sound = new Howl({
    src: [runtimeScene.getGame().getVariables().get("audio").getChildAt(runtimeScene.getVariables().get("arrayCount").getAsNumber()).getAsString()],
    autoplay:true,
    loop:false,
    volume:1.0,
    onload:function(){
        
        console.log("loaded audio")
    }
    
    
})

runtimeScene.getVariables().get("currr").setValue(sound)
console.log()




};
gdjs.audio_95editor_95eventCode.eventsList3 = function(runtimeScene) {

{


gdjs.audio_95editor_95eventCode.userFunc0x1230640(runtimeScene);

}


};gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDmusic_95959595containerObjects1Objects = Hashtable.newFrom({"music_container": gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1});
gdjs.audio_95editor_95eventCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.audio_95editor_95eventCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("name"), gdjs.audio_95editor_95eventCode.GDnameObjects1);

for (gdjs.audio_95editor_95eventCode.forEachIndex2 = 0;gdjs.audio_95editor_95eventCode.forEachIndex2 < gdjs.audio_95editor_95eventCode.GDnameObjects1.length;++gdjs.audio_95editor_95eventCode.forEachIndex2) {
gdjs.audio_95editor_95eventCode.GDnameObjects2.length = 0;


gdjs.audio_95editor_95eventCode.forEachTemporary2 = gdjs.audio_95editor_95eventCode.GDnameObjects1[gdjs.audio_95editor_95eventCode.forEachIndex2];
gdjs.audio_95editor_95eventCode.GDnameObjects2.push(gdjs.audio_95editor_95eventCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.audio_95editor_95eventCode.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.audio_95editor_95eventCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.audio_95editor_95eventCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.audio_95editor_95eventCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "playing" ) {
        isConditionTrue_0 = true;
        gdjs.audio_95editor_95eventCode.GDplayObjects1[k] = gdjs.audio_95editor_95eventCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.audio_95editor_95eventCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1);
{for(var i = 0, len = gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[i].setX(gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[i].getX() + (4));
}
}}

}


{


gdjs.audio_95editor_95eventCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("debug"), gdjs.audio_95editor_95eventCode.GDdebugObjects1);
{for(var i = 0, len = gdjs.audio_95editor_95eventCode.GDdebugObjects1.length ;i < len;++i) {
    gdjs.audio_95editor_95eventCode.GDdebugObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(3).getAsBoolean();
}
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length;i<l;++i) {
    if ( gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[i].getX() > 638 ) {
        isConditionTrue_0 = true;
        gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[k] = gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[i];
        ++k;
    }
}
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length === 0 ) ? 0 :gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[0].getPointX("")), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length;i<l;++i) {
    if ( gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[i].getX() <= 638 ) {
        isConditionTrue_0 = true;
        gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[k] = gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[i];
        ++k;
    }
}
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraX(runtimeScene, 638, "", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(3).getAsBoolean();
}
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.audio_95editor_95eventCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.audio_95editor_95eventCode.GDplayObjects1.length;i<l;++i) {
    if ( gdjs.audio_95editor_95eventCode.GDplayObjects1[i].getBehavior("Animation").getAnimationName() == "paused" ) {
        isConditionTrue_0 = true;
        gdjs.audio_95editor_95eventCode.GDplayObjects1[k] = gdjs.audio_95editor_95eventCode.GDplayObjects1[i];
        ++k;
    }
}
gdjs.audio_95editor_95eventCode.GDplayObjects1.length = k;
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("stop"), gdjs.audio_95editor_95eventCode.GDstopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDstopObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1);
{for(var i = 0, len = gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length ;i < len;++i) {
    gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1[i].setX(224);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("play"), gdjs.audio_95editor_95eventCode.GDplayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDplayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3));
}
{ //Subevents
gdjs.audio_95editor_95eventCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setBoolean(false);
variables._declare("play3", variable);
}
gdjs.audio_95editor_95eventCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
}
gdjs.audio_95editor_95eventCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("play_node"), gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDplay_95959595nodeObjects1Objects, gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDmusic_95959595containerObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23058964);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(((gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1[0].getVariables()).getFromIndex(1).getAsNumber());
}
{ //Subevents
gdjs.audio_95editor_95eventCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("music_container"), gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.audio_95editor_95eventCode.mapOfGDgdjs_9546audio_959595editor_959595eventCode_9546GDmusic_95959595containerObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1 */
{for(var i = 0, len = gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1.length ;i < len;++i) {
    gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1[i].returnVariable(gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1[i].getVariables().getFromIndex(0)).setString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "q");
if (isConditionTrue_0) {
{gdjs.evtsExt__load_audio__file_loader.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "w");
if (isConditionTrue_0) {

{ //Subevents
gdjs.audio_95editor_95eventCode.eventsList4(runtimeScene);} //End of subevents
}

}


};

gdjs.audio_95editor_95eventCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.audio_95editor_95eventCode.GDpanelObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDpanelObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDpanelObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDpanelObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDpanel2Objects1.length = 0;
gdjs.audio_95editor_95eventCode.GDpanel2Objects2.length = 0;
gdjs.audio_95editor_95eventCode.GDpanel2Objects3.length = 0;
gdjs.audio_95editor_95eventCode.GDpanel2Objects4.length = 0;
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDdrawObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDdrawObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDdrawObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDdrawObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDnameObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDnameObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDnameObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDnameObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDplayObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDplayObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDplayObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDplayObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDdebugObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDdebugObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDdebugObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDdebugObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDstopObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDstopObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDstopObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDstopObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects4.length = 0;

gdjs.audio_95editor_95eventCode.eventsList5(runtimeScene);
gdjs.audio_95editor_95eventCode.GDpanelObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDpanelObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDpanelObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDpanelObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDpanel2Objects1.length = 0;
gdjs.audio_95editor_95eventCode.GDpanel2Objects2.length = 0;
gdjs.audio_95editor_95eventCode.GDpanel2Objects3.length = 0;
gdjs.audio_95editor_95eventCode.GDpanel2Objects4.length = 0;
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDsound_9595nameObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDdrawObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDdrawObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDdrawObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDdrawObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDnameObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDnameObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDnameObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDnameObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDmusic_9595containerObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDplay_9595nodeObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDplayObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDplayObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDplayObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDplayObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDdebugObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDdebugObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDdebugObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDdebugObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDstopObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDstopObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDstopObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDstopObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595forwardObjects4.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects1.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects2.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects3.length = 0;
gdjs.audio_95editor_95eventCode.GDfast_9595backwardObjects4.length = 0;


return;

}

gdjs['audio_95editor_95eventCode'] = gdjs.audio_95editor_95eventCode;
