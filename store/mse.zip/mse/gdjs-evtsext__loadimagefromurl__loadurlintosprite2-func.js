
if (typeof gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2 !== "undefined") {
  gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2 = {};


gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2.userFunc0x939e38 = function GDJSInlineCode(runtimeScene, eventsFunctionContext) {
"use strict";
if (eventsFunctionContext.getArgument("ChangeResource")) {
    const texture = PIXI.BaseTexture.from(eventsFunctionContext.getArgument("URL"));
    runtimeScene.getObjects(eventsFunctionContext.getArgument('Object'))[eventsFunctionContext.getArgument('n')].getRendererObject().texture.baseTexture = texture;
} else {
    const texture = PIXI.Texture.from(eventsFunctionContext.getArgument("URL"));
    runtimeScene.getObjects(eventsFunctionContext.getArgument('Object'))[eventsFunctionContext.getArgument('n')].getRendererObject().texture = texture;
}

};
gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2.userFunc0x939e38(runtimeScene, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


};

gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2.func = function(runtimeScene, URL, Object, ChangeResource, n, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("LoadImageFromURL"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("LoadImageFromURL"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "URL") return URL;
if (argName === "Object") return Object;
if (argName === "ChangeResource") return ChangeResource;
if (argName === "n") return n;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2.eventsList0(runtimeScene, eventsFunctionContext);


return;
}

gdjs.evtsExt__LoadImageFromURL__LoadURLIntoSprite2.registeredGdjsCallbacks = [];